#!/bin/bash
set -e
SPAN=~/workspace/learn-spanish-android
BT=$SPAN/sdk/build-tools/36.1.0
AJ=$SPAN/sdk/platforms/android-34/android.jar
export JAVA_HOME=$SPAN/jdk
export PATH=$JAVA_HOME/bin:$BT:$PATH
cd "$(dirname "$0")"
rm -rf build && mkdir -p build/classes build/dexout build/gen
echo "== aapt2 compile =="
aapt2 compile --dir res -o build/res.zip
echo "== aapt2 link =="
# Rich Media (v20): -A assets bundles the produced media (art, audio,
# fonts) into the APK under assets/ — verified in the test suite.
aapt2 link -o build/linked.apk -I "$AJ" --manifest AndroidManifest.xml build/res.zip \
  -A assets \
  --java build/gen --min-sdk-version 21 --target-sdk-version 34 --version-code 22 --version-name 20.1
echo "== javac =="
find src build/gen -name '*.java' > build/sources.txt
javac -encoding UTF-8 -source 8 -target 8 -nowarn -cp "$AJ" -d build/classes @build/sources.txt
echo "== jar + d8 =="
(cd build/classes && jar cf ../app-classes.jar .)
d8 --release --min-api 21 --lib "$AJ" --output build/dexout build/app-classes.jar
echo "== package =="
cp build/linked.apk build/staged.apk
(cd build/dexout && zip -q ../staged.apk classes.dex)
zipalign -f 4 build/staged.apk build/aligned.apk
echo "== sign =="
STORE_PASS=$(grep '^store_password:' $SPAN/signing-credentials.txt | cut -d' ' -f2- | tr -d '\r')
KEY_PASS=$(grep '^key_password:' $SPAN/signing-credentials.txt | cut -d' ' -f2- | tr -d '\r')
printf '%s\n%s\n' "$STORE_PASS" "$KEY_PASS" | apksigner sign \
  --ks $SPAN/signing.keystore --ks-key-alias spanish-key \
  --ks-pass stdin --key-pass stdin \
  --out cricket-club-manager.apk build/aligned.apk
echo "== verify =="
apksigner verify --print-certs cricket-club-manager.apk | grep -i 'SHA-256'
aapt2 dump badging cricket-club-manager.apk | head -3
ls -la cricket-club-manager.apk
