import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.json.JSONObject;

import io.github.farrakhimtiaz74.cricketmanager.Design;
import io.github.farrakhimtiaz74.cricketmanager.Game;
import io.github.farrakhimtiaz74.cricketmanager.GameMath;
import io.github.farrakhimtiaz74.cricketmanager.SaveCodec;
import io.github.farrakhimtiaz74.cricketmanager.Settings;
import io.github.farrakhimtiaz74.cricketmanager.VoiceLine;

/**
 * v21.0 — THE OVERHAUL tests, desktop JVM. Same honest split as
 * TestFix: UNIT checks run the shipped pure classes (SaveCodec,
 * VoiceLine, GameMath, Design theme/avatar helpers, Settings
 * predicates, and the v20.1→v21 save migration); WIRING checks read
 * the shipped sources (Kit API present, MatchDay switch wired, the
 * backup hook placed, and the DELETION greps — scoped to code:
 * Game.java is scanned after its historical BATCHLOG comment block,
 * which is a changelog, not code). The voice manifest is verified
 * against the built APK's zip entries.
 *
 * Args: <srcDir> <apkPath>
 */
public class TestV21 {
    static int pass = 0, fail = 0;
    static List<String> failures = new ArrayList<>();

    static void check(String name, boolean ok) {
        if (ok) { pass++; System.out.println("PASS  " + name); }
        else { fail++; failures.add(name); System.out.println("FAIL  " + name); }
    }

    static String read(File f) throws Exception {
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }

    /** Game.java minus its BATCHLOG: everything up to the end of the
     *  leading block comment is changelog prose, not code. */
    static String codeOnly(String gameSrc) {
        int end = gameSrc.indexOf("*/");
        return end < 0 ? gameSrc : gameSrc.substring(end + 2);
    }

    public static void main(String[] args) throws Exception {
        File srcDir = new File(args[0]);
        String apk = args[1];

        // ================= UNIT: SaveCodec (item 11) =================
        Game g0 = Game.freshForTeam("Islamabad United");
        String json = g0.toJson();
        String enc = SaveCodec.encode(json);
        check("codec: encoded form carries the CCMGZ1 prefix", SaveCodec.isCompressed(enc));
        check("codec: plain JSON is not flagged compressed", !SaveCodec.isCompressed(json));
        check("codec: compressed round-trip is byte-identical", json.equals(SaveCodec.decode(enc)));
        check("codec: plain (pre-v21) payload passes through untouched", json.equals(SaveCodec.decode(json)));
        check("codec: compressed payload really is smaller", enc.length() < json.length());
        check("codec: corrupt compressed payload decodes to null",
                SaveCodec.decode("CCMGZ1:!!!not-base64!!!") == null);
        String uni = "{\"note\":\"کرکٹ · trophy 🏆\"}";
        check("codec: unicode survives the round-trip", uni.equals(SaveCodec.decode(SaveCodec.encode(uni))));

        // ============ UNIT: v20.1 save migration (identical state) ============
        // a v20.1 save = plain JSON + keys v21 no longer writes
        JSONObject old = new JSONObject(json);
        old.put("prediction", new JSONObject().put("key", "L5").put("winnerPick", "Islamabad United"));
        old.put("predSettled", 3);
        old.put("predWins", 2);
        old.put("predBoth", 1);
        Game mig = Game.fromJson(old.toString());
        check("migration: club preserved", "Islamabad United".equals(mig.userTeam));
        check("migration: season/day preserved", mig.season == g0.season && mig.day == g0.day);
        check("migration: CF preserved", mig.cf == g0.cf);
        check("migration: squad preserved", mig.players.length() == g0.players.length());
        String resaved = mig.toJson();
        check("migration: re-save drops the deleted prediction keys",
                !resaved.contains("\"prediction\"") && !resaved.contains("\"predSettled\""));
        Game mig2 = Game.fromJson(SaveCodec.decode(SaveCodec.encode(resaved)));
        check("migration: compressed re-save loads identically",
                mig2.cf == mig.cf && mig2.season == mig.season && mig2.players.length() == mig.players.length());

        // ================= UNIT: VoiceLine (item 2) =================
        List<String> need = VoiceLine.clipsFor("Karachi Kings need 24 off 12 balls.");
        check("voice: chase line stitches team+need+24+off+12+balls",
                need.size() == 7
                        && need.get(0).equals("voice/v_t_karachi.ogg")
                        && need.get(1).equals("voice/v_need.ogg")
                        && need.get(2).equals("voice/v_n20.ogg")
                        && need.get(3).equals("voice/v_n4.ogg")
                        && need.get(4).equals("voice/v_off.ogg")
                        && need.get(5).equals("voice/v_n12.ogg")
                        && need.get(6).equals("voice/v_balls.ogg"));
        List<String> shrt = VoiceLine.clipsFor("Lahore need 24 off 12 balls.");
        check("voice: short club name resolves to the short clip",
                !shrt.isEmpty() && shrt.get(0).equals("voice/v_ts_lahore.ogg"));
        List<String> brk = VoiceLine.clipsFor("Innings break. The target is 187.");
        check("voice: break target stitches 187 as 1+hundred+80+7",
                brk.size() == 6
                        && brk.get(0).equals("voice/v_innings_break.ogg")
                        && brk.get(1).equals("voice/v_the_target_is.ogg")
                        && brk.get(2).equals("voice/v_n1.ogg")
                        && brk.get(3).equals("voice/v_hundred.ogg")
                        && brk.get(4).equals("voice/v_n80.ogg")
                        && brk.get(5).equals("voice/v_n7.ogg"));
        List<String> set = VoiceLine.clipsFor("Innings break. Islamabad United set a target of 156.");
        check("voice: break set-target line parses",
                set.size() == 7 && set.get(1).equals("voice/v_t_islamabad.ogg")
                        && set.get(2).equals("voice/v_set_a_target_of.ogg"));
        List<String> won = VoiceLine.clipsFor("Karachi Kings won by 6 runs · (D/L) rain at the end");
        check("voice: full-time summary prefix parses (won by 6 runs)",
                won.size() == 4 && won.get(1).equals("voice/v_won_by.ogg")
                        && won.get(3).equals("voice/v_runs.ogg"));
        List<String> wk = VoiceLine.clipsFor("Multan Sultans won by 3 wickets");
        check("voice: wickets variant parses", wk.size() == 4 && wk.get(3).equals("voice/v_wickets.ogg"));
        check("voice: 200 is unit+hundred", VoiceLine.numberClips(200).size() == 2
                && VoiceLine.numberClips(200).get(1).equals("voice/v_hundred.ogg"));
        check("voice: 0 speaks zero", VoiceLine.numberClips(0).size() == 1);
        check("voice: 99 composes tens+unit", VoiceLine.numberClips(99).size() == 2);
        check("voice: 1000 is unspeakable (empty)", VoiceLine.numberClips(1000).isEmpty());
        check("voice: custom club line stays silent",
                VoiceLine.clipsFor("Custom XI need 5 off 3 balls.").isEmpty());
        check("voice: unrelated line stays silent",
                VoiceLine.clipsFor("The crowd is loving this.").isEmpty());
        check("voice: null line stays silent", VoiceLine.clipsFor(null).isEmpty());

        // ================= UNIT: avatars (item 14) =================
        int a1 = Design.avatarIndex("Babar Azam");
        check("avatar: index is deterministic", a1 == Design.avatarIndex("Babar Azam"));
        check("avatar: index in 0..3", a1 >= 0 && a1 <= 3);
        boolean spread = false;
        int first = Design.avatarIndex("Shaheen Afridi");
        for (String n : new String[]{"Haris Rauf", "Shadab Khan", "Mohammad Rizwan", "Naseem Shah", "Fakhar Zaman"})
            if (Design.avatarIndex(n) != first) spread = true;
        check("avatar: different names spread across portraits", spread);
        check("avatar: club asset path uses the club slug",
                Design.avatarAsset("Babar Azam", "Lahore Qalandars").startsWith("art/avatar_lahore_"));
        check("avatar: custom club falls back to the neutral set",
                Design.avatarAsset("Babar Azam", "My Custom Club").startsWith("art/avatar_neutral_"));

        // ================= UNIT: theme engine (item 10) =================
        Game gi = Game.freshForTeam("Islamabad United");
        int savedMode = Design.themeMode;
        Design.themeMode = Design.THEME_CLUB;
        check("theme: Club look resolves the club accent",
                Design.themedAccent(gi) == Design.accentFor(gi));
        Design.themeMode = Design.THEME_MIDNIGHT;
        check("theme: Midnight resolves silver", Design.themedAccent(gi) == Design.SILVER);
        Design.themeMode = Design.THEME_CLASSIC;
        check("theme: Classic resolves gold", Design.themedAccent(gi) == Design.GOLD);
        Design.themeMode = savedMode;

        // ================= UNIT: GameMath (item 6) =================
        boolean lvlAgree = true;
        for (int xp : new int[]{0, 40, 49, 50, 119, 120, 300, 999, 5000})
            if (GameMath.levelForXp(xp, Game.XP_THRESHOLDS) != Game.levelForXp(xp)) lvlAgree = false;
        check("split: GameMath.levelForXp agrees with the Game wrapper", lvlAgree);
        check("split: finance categories classify",
                GameMath.financeCategory("Gate receipts — home vs X").equals("gate")
                        && GameMath.financeCategory("Sponsor deal signed").equals("sponsor")
                        && GameMath.financeCategory("Weekly wages").equals("wages")
                        && GameMath.financeCategory("Auction signing").equals("transfers")
                        && GameMath.financeCategory("Champions prize").equals("prizes")
                        && GameMath.financeCategory("Merchandise sales").equals("merch")
                        && GameMath.financeCategory("Something else").equals("other"));
        check("split: morale maths", GameMath.clampMorale(-5) == 0 && GameMath.clampMorale(130) == 100
                && GameMath.moraleLabel(85).equals("High") && GameMath.moraleLabel(65).equals("Good")
                && GameMath.moraleLabel(50).equals("Okay") && GameMath.moraleLabel(10).equals("Low"));
        check("split: surname takes the last word", GameMath.surname("Babar Azam").equals("Azam")
                && GameMath.surname("").equals("") && GameMath.surname(null).equals(""));

        // ================= UNIT: upgrade predicate (item 11) =================
        check("backup: first-ever launch is not an upgrade", !Settings.isUpgrade(0, 23));
        check("backup: 22 -> 23 is an upgrade", Settings.isUpgrade(22, 23));
        check("backup: same version is not an upgrade", !Settings.isUpgrade(23, 23));
        check("backup: downgrade is not an upgrade", !Settings.isUpgrade(24, 23));

        // ============ MANIFEST: every referenced voice clip is in the APK ============
        Set<String> entries = new HashSet<>();
        int voiceCount = 0;
        boolean voiceSizesOk = true;
        try (ZipFile z = new ZipFile(apk)) {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                entries.add(e.getName());
                if (e.getName().startsWith("assets/voice/")) {
                    voiceCount++;
                    if (e.getSize() < 400) voiceSizesOk = false; // a real clip, not a stub
                }
            }
        }
        check("voice manifest: 59 clips in the APK", voiceCount == 59);
        check("voice manifest: every clip is real audio (>400 B)", voiceSizesOk);
        boolean allPresent = true;
        List<List<String>> spoken = new ArrayList<>();
        spoken.add(need); spoken.add(shrt); spoken.add(brk);
        spoken.add(set); spoken.add(won); spoken.add(wk);
        for (List<String> line : spoken)
            for (String clip : line)
                if (!entries.contains("assets/" + clip)) allPresent = false;
        check("voice manifest: every stitched clip exists in the APK", allPresent);
        check("art manifest: theme pack + frame + flag + emblem + splash present",
                entries.contains("assets/art/theme_islamabad.webp")
                        && entries.contains("assets/art/frame_elite.webp")
                        && entries.contains("assets/art/flag_pak.webp")
                        && entries.contains("assets/art/emblem_cup.webp")
                        && entries.contains("assets/art/splash_13.webp")
                        && entries.contains("assets/art/art_interior.webp")
                        && entries.contains("assets/art/avatar_islamabad_0.webp"));
        check("audio manifest: rain + tension files present (ex-synth loops)",
                entries.contains("assets/audio/rain.ogg") && entries.contains("assets/audio/tension.ogg"));

        // ================= WIRING =================
        String ui = read(new File(srcDir, "Ui.java"));
        check("kit: Ui carries the canonical kit API",
                ui.contains("kitCard") && ui.contains("kitRow") && ui.contains("kitMeter")
                        && ui.contains("kitChip") && ui.contains("kitSegmented")
                        && ui.contains("kitHeader") && ui.contains("kitButton")
                        && ui.contains("kitGlassCard") && ui.contains("foilText"));
        String match = read(new File(srcDir, "MatchScreen.java"));
        check("matchday: the segmented Live/Tactics/Scorecard/Timeline switch is wired",
                match.contains("Ui.kitSegmented(act, new String[]{\"Live\", \"Tactics\", \"Scorecard\", \"Timeline\"}"));
        String main = read(new File(srcDir, "MainActivity.java"));
        check("backup: MainActivity copies the raw save pre-update",
                main.contains("Store.KEY_PREUPDATE") && main.contains("loadRaw()")
                        && main.contains("settings.appVersion() != appVersionCode"));
        check("backup: restore path is wired", main.contains("restorePreUpdateBackup()"));
        String store = read(new File(srcDir, "Store.java"));
        check("save v2: Store writes compressed and reads both forms",
                store.contains("SaveCodec.encode") && store.contains("SaveCodec.decode"));
        String hub = read(new File(srcDir, "HubScreen.java"));
        check("hub: dashboard builds through the Kit", hub.contains("Ui.kitCard") && hub.contains("Ui.kitButton"));
        String settingsScr = read(new File(srcDir, "SettingsScreen.java"));
        check("theme: the look switch is in Settings",
                settingsScr.contains("Settings.THEME_NAMES") && settingsScr.contains("setThemeLook"));

        // ================= DELETIONS (code-scoped greps) =================
        check("D2: SoundSynth.java is deleted", !new File(srcDir, "SoundSynth.java").exists());
        check("D5: CsvExport.java is deleted", !new File(srcDir, "CsvExport.java").exists());
        File[] files = srcDir.listFiles((d, n) -> n.endsWith(".java"));
        boolean synthRef = false, ttsRef = false, csvRef = false, predRef = false,
                codeRef = false, viewModeRef = false;
        for (File f : files) {
            String s = read(f);
            if (f.getName().equals("Game.java")) s = codeOnly(s);
            if (s.contains("SoundSynth")) synthRef = true;
            if (s.contains("TextToSpeech") || s.contains("android.speech")) ttsRef = true;
            if (s.contains("CsvExport")) csvRef = true;
            if (s.contains("ensurePrediction(") || s.contains("settlePrediction(")
                    || s.contains(".prediction") || s.contains("predSettled")) predRef = true;
            if (s.contains("seasonResultCode(") || s.contains("careerResultCode(")) codeRef = true;
            if (s.contains("teamViewMode")) viewModeRef = true;
        }
        check("D2: no code references the deleted synthesizer", !synthRef);
        check("D1: no code references Android TTS", !ttsRef);
        check("D5: no code references CsvExport", !csvRef);
        check("D4: no code references the prediction game", !predRef);
        check("D3: no code references the result codes", !codeRef);
        check("D6: no code references the Cards/Rows view mode", !viewModeRef);
        String crest = read(new File(srcDir, "CrestView.java"));
        check("D7: CrestView draws art first, drawn shield is fallback-only",
                crest.contains("artBmp != null") && crest.contains("custom-club fallback only"));

        System.out.println();
        System.out.println("TestV21: " + pass + " passed, " + fail + " failed");
        if (fail > 0) {
            for (String f : failures) System.out.println("  FAILED: " + f);
            System.exit(1);
        }
    }
}
