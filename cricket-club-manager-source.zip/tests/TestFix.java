import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.json.JSONObject;

import io.github.farrakhimtiaz74.cricketmanager.Design;
import io.github.farrakhimtiaz74.cricketmanager.Game;
import io.github.farrakhimtiaz74.cricketmanager.Present;

/**
 * v20.1 (item 12) — LAYOUT-INVARIANT + regression tests, desktop JVM.
 *
 * Honest split, stated in the v20.1 report:
 *  - UNIT checks run the shipped pure classes (Design.gaugeFillWidth,
 *    Design.nationCode, Present.PLAYER_CARD_HEIGHT_DP, Game logic).
 *  - WIRING checks read the shipped .java sources and assert the
 *    layout rules are actually connected (the render path clears the
 *    action slot through parkActionBar, the card factory assigns the
 *    fixed-height constant, GaugeView draws via the clamped maths).
 *    Android views cannot be instantiated on this JVM (the stub
 *    android.jar throws), so NO device rendering is claimed.
 *
 * Args: <srcDir> <apkPath>
 */
public class TestFix {
    static int pass = 0, fail = 0;
    static List<String> failures = new ArrayList<>();

    static void check(String name, boolean ok) {
        if (ok) { pass++; System.out.println("PASS  " + name); }
        else { fail++; failures.add(name); System.out.println("FAIL  " + name); }
    }

    static String read(File f) throws Exception {
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }

    static int count(String hay, String needle) {
        int n = 0, i = 0;
        while ((i = hay.indexOf(needle, i)) >= 0) { n++; i += needle.length(); }
        return n;
    }

    static long ledgerSum(Game g) throws Exception {
        long s = 0;
        for (int i = 0; i < g.ledger.length(); i++) s += g.ledger.optJSONObject(i).optInt("amt");
        return s;
    }

    public static void main(String[] args) throws Exception {
        File srcDir = new File(args[0]);
        File apk = new File(args[1]);

        // ---------- UNIT: gauge clamp (item 12b) ----------
        check("gauge 0 -> 0", Design.gaugeFillWidth(200, 0) == 0);
        check("gauge 70 of 200 -> 140", Design.gaugeFillWidth(200, 70) == 140);
        check("gauge 100 of 200 -> 200", Design.gaugeFillWidth(200, 100) == 200);
        check("gauge 130 over-range clamps to track", Design.gaugeFillWidth(200, 130) == 200);
        check("gauge -5 clamps to 0", Design.gaugeFillWidth(200, -5) == 0);
        check("gauge zero track -> 0", Design.gaugeFillWidth(0, 50) == 0);
        boolean sweep = true;
        for (int v = -10; v <= 130; v += 7) {
            int f = Design.gaugeFillWidth(137, v);
            if (f < 0 || f > 137) sweep = false;
        }
        check("gauge sweep -10..130 stays within track", sweep);

        // ---------- UNIT: card height constant (item 12c) ----------
        check("PLAYER_CARD_HEIGHT_DP pinned at 124", Present.PLAYER_CARD_HEIGHT_DP == 124);

        // ---------- UNIT: nation codes (item 8) ----------
        check("nationCode PAK", "PAK".equals(Design.nationCode("PAK")));
        check("nationCode Pakistan", "PAK".equals(Design.nationCode("Pakistan")));
        check("nationCode Australia", "AUS".equals(Design.nationCode("Australia")));
        check("nationCode West Indies", "WI".equals(Design.nationCode("West Indies")));
        check("nationCode New Zealand", "NZ".equals(Design.nationCode("New Zealand")));
        check("nationCode South Africa", "SA".equals(Design.nationCode("South Africa")));
        check("nationCode unknown -> empty", Design.nationCode("Atlantis").isEmpty());
        check("nationCode null -> empty", Design.nationCode(null).isEmpty());
        check("nationCode ' your nation' tag -> empty", Design.nationCode(" your nation").isEmpty());

        // ---------- REGRESSION: save round-trip ----------
        Game g0 = Game.freshForTeam("Islamabad United");
        String j1 = g0.toJson();
        Game g1 = Game.fromJson(j1);
        check("v20-shaped save round-trips byte-identical", j1.equals(g1.toJson()));

        // ---------- REGRESSION: XI validator ----------
        Game gx = Game.freshForTeam("Islamabad United");
        gx.pickBestXI(0);
        check("pickBestXI gives 11", gx.xiCount() == 11);
        check("pickBestXI is legal", gx.xiProblems().isEmpty());
        for (int i = 0; i < gx.players.length(); i++) {
            JSONObject p = gx.player(i);
            if ("WK".equals(p.optString("role"))) p.put("inXI", false);
        }
        check("removing the keeper breaks legality", !gx.xiProblems().isEmpty());
        gx.pickBestXI(0);
        check("pickBestXI restores legality", gx.xiProblems().isEmpty());

        // ---------- REGRESSION: ledger invariant ----------
        Game gl = Game.freshForTeam("Islamabad United");
        int cfBefore = gl.cf;
        long sumBefore = ledgerSum(gl);
        gl.ledgerCf(-50, "test out");
        gl.ledgerCf(200, "test in");
        check("ledgerCf moves cf by the amounts", gl.cf == cfBefore + 150);
        check("ledger sums to the cf movement", ledgerSum(gl) == sumBefore + 150);
        check("ledger newest-first head is the +200", gl.ledger.optJSONObject(0).optInt("amt") == 200);

        // ---------- REGRESSION: two-season drive ----------
        Game gd = Game.freshForTeam("Islamabad United");
        gd.pickBestXI(0);
        int guard = 0;
        while (gd.season < 3 && guard++ < 6000) {
            if (gd.offseason == 1) { gd.confirmOffseason(); continue; }
            if (gd.offseason == 2) { gd.skipAuction(); continue; }
            if (gd.playoffPhase == 2) { gd.acknowledgeCeremony(); continue; }
            gd.advanceDay();
        }
        check("two-season drive reaches Season 3", gd.season >= 3);
        check("ledger never exceeds its 80-entry cap", gd.ledger.length() <= 80);
        String jd = gd.toJson();
        check("driven save round-trips byte-identical", jd.equals(Game.fromJson(jd).toJson()));

        // ---------- REGRESSION: auction ----------
        Game ga = Game.freshForTeam("Islamabad United");
        ga.beginAuction();
        check("beginAuction opens lots", ga.auction != null);
        int aguard = 0, lastIdx = -1;
        while (ga.auction != null && aguard++ < 3000) {
            int idx = ga.auction.optInt("idx");
            if (idx != lastIdx) { lastIdx = idx; ga.auctionBid(); continue; }
            String r = ga.auctionPass();
            if (r != null && r.contains("highest bidder")) ga.auctionBid();
        }
        check("auction concludes (bid/pass smoke)", ga.auction == null);

        // ---------- REGRESSION: asset manifest in the built APK ----------
        // v21: the manifest grew with the overhaul (theme packs,
        // splash frames, tier frames, avatars, flags, emblems, the
        // realistic set, rain/tension files and the 59-clip voice
        // pack). These counts are the v21 build contract.
        int assets = 0, art = 0, audio = 0, fonts = 0, voice = 0;
        boolean hasPitch = false, hasDisplayFont = false, hasIslCrest = false;
        boolean hasVoiceClip = false, hasRain = false;
        try (ZipFile z = new ZipFile(apk)) {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName();
                if (!n.startsWith("assets/")) continue;
                assets++;
                if (n.startsWith("assets/art/")) art++;
                if (n.startsWith("assets/audio/")) audio++;
                if (n.startsWith("assets/fonts/")) fonts++;
                if (n.startsWith("assets/voice/")) voice++;
                if (n.equals("assets/art/art_pitch.webp")) hasPitch = true;
                if (n.equals("assets/fonts/font_display.ttf")) hasDisplayFont = true;
                if (n.equals("assets/art/crest_islamabad.webp")) hasIslCrest = true;
                if (n.equals("assets/voice/v_hundred.ogg") || n.equals("assets/voice/v_t_islamabad.ogg")) hasVoiceClip = true;
                if (n.equals("assets/audio/rain.ogg")) hasRain = true;
            }
        }
        check("APK asset manifest is the v21 manifest (193 files)", assets == 193);
        check("APK assets split 106 art / 24 audio / 4 fonts / 59 voice",
                art == 106 && audio == 24 && fonts == 4 && voice == 59);
        check("APK carries pitch art + display font + Islamabad crest", hasPitch && hasDisplayFont && hasIslCrest);
        check("APK carries voice clips + the rain file loop", hasVoiceClip && hasRain);

        // ---------- WIRING: item-12 layout invariants in the sources ----------
        String main = read(new File(srcDir, "MainActivity.java"));
        String team = read(new File(srcDir, "TeamScreen.java"));
        String match = read(new File(srcDir, "MatchScreen.java"));
        String transfers = read(new File(srcDir, "TransfersScreen.java"));
        String hub = read(new File(srcDir, "HubScreen.java"));
        String hq = read(new File(srcDir, "HqScreen.java"));
        String world = read(new File(srcDir, "WorldScreen.java"));
        String league = read(new File(srcDir, "LeagueScreen.java"));
        String gauge = read(new File(srcDir, "GaugeView.java"));
        String whatsNew = read(new File(srcDir, "WhatsNewScreen.java"));

        // (a) action-slot clearing: the render path clears via
        // parkActionBar(null) BEFORE any screen build, and the banned
        // framework-shadowing call token appears in NO source file.
        int clearAt = main.indexOf("parkActionBar(null);");
        int buildAt = main.indexOf("TeamScreen.build");
        check("render() clears the action slot via parkActionBar(null)", clearAt >= 0);
        check("the clear runs before the screen builds", clearAt >= 0 && buildAt > clearAt);
        int scanned = 0; boolean bannedFound = false;
        List<File> stack = new ArrayList<>();
        stack.add(srcDir);
        while (!stack.isEmpty()) {
            File d = stack.remove(stack.size() - 1);
            File[] kids = d.listFiles();
            if (kids == null) continue;
            for (File f : kids) {
                if (f.isDirectory()) { stack.add(f); continue; }
                if (!f.getName().endsWith(".java")) continue;
                scanned++;
                if (read(f).contains("setActionBar(")) bannedFound = true;
            }
        }
        check("no source calls setActionBar( anywhere (scanned " + scanned + " files)", !bannedFound && scanned > 30);
        check("Team parks its bar via parkActionBar", team.contains("act.parkActionBar(bar);"));
        check("Match parks its bar via parkActionBar", match.contains("act.parkActionBar(pin);"));
        check("Transfers parks its bar via parkActionBar", transfers.contains("act.parkActionBar(bar);"));

        // (b) the gauge view actually draws through the clamped maths
        check("GaugeView fills via Design.gaugeFillWidth", gauge.contains("Design.gaugeFillWidth"));

        // (c) the card factory assigns the fixed-height constant
        check("TeamScreen assigns Present.PLAYER_CARD_HEIGHT_DP", team.contains("Present.PLAYER_CARD_HEIGHT_DP"));

        // shared components actually wired
        check("Hub meters use Ui.meterRow (x2)", count(hub, "Ui.meterRow") >= 2);
        check("HQ meters use Ui.meterRow (x2)", count(hq, "Ui.meterRow") >= 2);
        check("World switches use Ui.segmented (x2)", count(world, "Ui.segmented") >= 2);
        check("World rows use Icons.flag", world.contains("Icons.flag"));
        check("League strip carries the position line", league.contains("in Group "));
        check("World strip carries the best-player line", world.contains("Your club's best: "));
        check("What's New has the v20.1 group", whatsNew.contains("v20.1 — Fixes & Polish (this update)"));

        System.out.println();
        System.out.println("TestFix: " + pass + " passed, " + fail + " failed");
        if (fail > 0) {
            for (String f : failures) System.out.println("  FAILED: " + f);
            System.exit(1);
        }
    }
}
