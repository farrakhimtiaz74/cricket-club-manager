#!/bin/bash
# v20.1 desktop tests (tests/TestFix.java): unit checks on the pure
# classes + wiring checks on the shipped sources + the standard
# regression. Requires a built APK first (bash build.sh) — the test
# reads build/app-classes.jar and the APK's asset manifest.
# Static verification only: Android views cannot run on this JVM.
set -e
cd "$(dirname "$0")/.."
SPAN=~/workspace/learn-spanish-android
export JAVA_HOME=$SPAN/jdk
export PATH=$JAVA_HOME/bin:$PATH
AJAR=$(find "$SPAN/sdk/platforms" -name android.jar | sort | tail -1)
mkdir -p build/test-classes
javac -encoding UTF-8 -cp "build/app-classes.jar:test-libs/json.jar:$AJAR" -d build/test-classes tests/TestFix.java
java -cp "build/test-classes:build/app-classes.jar:test-libs/json.jar:$AJAR" \
  TestFix "src/io/github/farrakhimtiaz74/cricketmanager" "cricket-club-manager.apk"
