package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Professional Pack P4 (suggestion 35): the potential bar on a
 *  market card — one track on a 40–100 scale: the solid gold fill is
 *  the player's CURRENT rating, the pale extension is his potential
 *  (a single point when the POT is known exactly, a band when only
 *  the scouted range is). Inputs come from Present.potBar. */
public class PotBarView extends View {
    private final int rating, potLow, potHigh;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public PotBarView(Context c, int rating, int potLow, int potHigh) {
        super(c);
        this.rating = rating;
        this.potLow = potLow;
        this.potHigh = potHigh;
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(getContext(), 10));
    }

    private float x(float w, int v) {
        int vv = Math.max(40, Math.min(100, v));
        return w * (vv - 40) / 60f;
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float r = h / 2f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.CARD2);
        cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
        float pl = x(w, potLow), ph = x(w, potHigh);
        if (ph > 0) {
            p.setColor(0x59F59E0B); // pale gold band: the potential range
            cv.drawRoundRect(new RectF(pl, 0, Math.max(pl + 3, ph), h), r, r, p);
        }
        float rw = x(w, rating);
        if (rw > 0) {
            p.setColor(Ui.GOLD);
            cv.drawRoundRect(new RectF(0, 0, Math.max(h, rw), h), r, r, p);
        }
    }
}
