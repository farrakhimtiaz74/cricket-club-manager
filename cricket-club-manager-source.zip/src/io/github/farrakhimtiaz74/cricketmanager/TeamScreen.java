package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/** Team tab. v2: live team-sheet validator + rested system + watchlist.
 *  Batch C adds: player meta on cards (age, POT, morale, tags, injuries),
 *  form spark bars (idea 22), a per-player detail view with season/career
 *  stats + milestones (ideas 21/29), captain controls (idea 26), the
 *  Auto-pick Best XI button (idea 27), a two-player comparison (idea 28)
 *  and the physio queue (idea 24). */
public class TeamScreen {
    private static final String[] FILTERS = {"All", "Bat", "Bowl", "AR", "WK"};

    public static View build(final MainActivity act) {
        final Game g = act.g;
        if (act.teamDetail != null) {
            JSONObject dp = g.playerByName(act.teamDetail);
            if (dp != null) return detail(act, dp);
            act.teamDetail = null;
        }
        LinearLayout root = Ui.col(act);

        // header + LIVE team-sheet validator (v2): every problem listed as you pick
        LinearLayout head = Ui.card(act);
        head.addView(Ui.h2(act, "Squad — Starting XI: " + g.xiCount() + "/11 · Overseas: "
                + g.xiOverseasCount() + "/" + Game.MAX_OVERSEAS));
        List<String> problems = g.xiProblems();
        if (problems.isEmpty()) {
            head.addView(Ui.text(act, "✓ Team sheet is legal — ready for match day.", 13, Ui.GREEN, true));
        } else {
            head.addView(Ui.text(act, "Team sheet problems (match day is blocked until fixed):", 13, Ui.RED, true));
            for (String pr : problems) head.addView(Ui.text(act, "•  " + pr, 13, Ui.RED, false));
        }
        // Batch J (idea 98): the squad's season stats as a spreadsheet file
        Button expS = Ui.darkBtn(act, "📤 Export Squad Stats (CSV)");
        expS.setOnClickListener(v -> act.shareTextFile("squad-stats.csv",
                CsvExport.squadCsv(act.g), "text/csv"));
        head.addView(expS);
        // Batch C (idea 26): captain status — a warning, not a validator block
        head.addView(Ui.text(act, "Captain: " + g.captain, 13, Ui.GOLD, true));
        if (!g.captainInXi()) {
            head.addView(Ui.text(act, "⚠ Your captain is not in the XI — his on-field boost is lost.", 12, Ui.RED, false));
        }
        // Batch C (idea 27): auto-pick the best legal XI for the next pitch
        Button best = Ui.goldBtn(act, "Auto-pick Best XI");
        best.setOnClickListener(v -> {
            JSONObject next = act.g.nextUserFixture();
            int pitch = 0;
            if (next != null) {
                Game.ensureFixtureMeta(next, act.g.season);
                pitch = next.optInt("pitch", 0);
            }
            String msg = act.g.pickBestXI(pitch);
            act.save();
            act.toast(msg);
            act.render();
        });
        head.addView(best);
        Button cmp = Ui.darkBtn(act, act.compareMode ? "Compare: ON (tap two players)" : "Compare players");
        cmp.setOnClickListener(v -> {
            act.compareMode = !act.compareMode;
            if (!act.compareMode) { act.compareA = ""; act.compareB = ""; }
            act.render();
        });
        head.addView(cmp);
        root.addView(head);

        // Batch C (idea 28): side-by-side comparison, once two are picked
        if (act.compareMode) {
            LinearLayout cc = Ui.card(act);
            cc.addView(Ui.h2(act, "Player Comparison"));
            JSONObject a = g.playerByName(act.compareA);
            JSONObject b = g.playerByName(act.compareB);
            if (a == null || b == null) {
                cc.addView(Ui.small(act, "Tap \"Compare +\" on two player cards below. Picked so far: "
                        + (a != null ? a.optString("name") : "—") + " / " + (b != null ? b.optString("name") : "—")));
            } else {
                cc.addView(compareTable(act, a, b));
            }
            root.addView(cc);
        }

        // Batch C (idea 24): physio queue — who is out, and for how long
        StringBuilder physio = new StringBuilder();
        for (int i = 0; i < g.players.length(); i++) {
            JSONObject p = g.player(i);
            if (p.optInt("injured", 0) > 0) {
                physio.append("•  ").append(p.optString("name")).append(" — ")
                        .append(p.optString("injType")).append(" · ")
                        .append(p.optInt("injured")).append(" day(s) left\n");
            }
        }
        if (physio.length() > 0) {
            LinearLayout pc = Ui.card(act);
            pc.addView(Ui.text(act, "PHYSIO QUEUE", 13, Ui.RED, true));
            pc.addView(Ui.body(act, physio.toString().trim()));
            pc.addView(Ui.small(act, "Injured players heal one day per Advance Day. A better Medical Centre (HQ) shortens new injuries."));
            root.addView(pc);
        }

        // role filters
        LinearLayout chipWrap = new LinearLayout(act);
        chipWrap.setOrientation(LinearLayout.HORIZONTAL);
        for (final String f : FILTERS) {
            Button c = Ui.chip(act, f, f.equals(act.teamFilter));
            c.setOnClickListener(v -> { act.teamFilter = f; act.render(); });
            chipWrap.addView(c);
        }
        root.addView(chipWrap);

        // players
        for (int i = 0; i < g.players.length(); i++) {
            final JSONObject p = g.player(i);
            if (!"All".equals(act.teamFilter) && !act.teamFilter.equals(p.optString("role"))) continue;
            root.addView(playerCard(act, p));
        }
        return root;
    }

    private static View playerCard(final MainActivity act, final JSONObject p) {
        final Game g = act.g;
        final String name = p.optString("name");
        final boolean inXI = p.optBoolean("inXI");
        final boolean rested = p.optBoolean("rested");
        final boolean loanOut = p.optBoolean("loanOut");
        final boolean loanIn = p.optBoolean("loanIn");
        final int injured = p.optInt("injured", 0);
        final boolean watched = g.isWatched(name);
        final boolean isCaptain = name.equals(g.captain);
        LinearLayout card = Ui.card(act);
        LinearLayout top = Ui.row(act);
        LinearLayout nameCol = Ui.col(act);
        nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        nameCol.addView(Ui.text(act, name + (isCaptain ? "  ©" : ""), 16, Ui.INK, true));
        StringBuilder sub = new StringBuilder(p.optString("role"));
        sub.append(inXI ? " · In XI" : " · Bench");
        if (p.optBoolean("overseas")) sub.append(" · OVERSEAS");
        sub.append(" · Age ").append(p.optInt("age", 0));
        sub.append(" · POT ").append(p.optInt("pot", 0));
        // Batch D (ideas 34/35): deal + wage on the card
        if (loanIn) sub.append(" · ON LOAN (in)");
        else {
            int ct = p.optInt("contract", 1);
            sub.append(ct <= 0 ? " · OUT OF CONTRACT" : ct == 1 ? " · Deal: final year" : " · Deal: " + ct + " yrs");
            sub.append(" · Wage ").append(p.optInt("wage", 0)).append("/wk");
        }
        nameCol.addView(Ui.small(act, sub.toString()));
        if (rested) {
            TextView badge = Ui.text(act, "RESTED — recovering +" + Game.RESTED_REGEN + " stamina/day, cannot be selected", 12, Ui.RED, true);
            badge.setPadding(0, Ui.dp(act, 2), 0, 0);
            nameCol.addView(badge);
        }
        if (injured > 0) {
            TextView badge = Ui.text(act, "INJURED — " + p.optString("injType") + " · " + injured + " day(s) out, cannot be selected", 12, Ui.RED, true);
            badge.setPadding(0, Ui.dp(act, 2), 0, 0);
            nameCol.addView(badge);
        }
        if (loanOut) {
            TextView badge = Ui.text(act, "ON LOAN — away for the season, returns at rollover, cannot be selected", 12, Ui.GOLD, true);
            badge.setPadding(0, Ui.dp(act, 2), 0, 0);
            nameCol.addView(badge);
        }
        // Batch F (idea 55): away on international duty during the off-season
        if (g.offseason > 0 && g.isCalledUp(name)) {
            TextView badge = Ui.text(act, "🌍 ON INTERNATIONAL DUTY — touring with his national side until the season starts", 12, Ui.GOLD, true);
            badge.setPadding(0, Ui.dp(act, 2), 0, 0);
            nameCol.addView(badge);
        }
        top.addView(nameCol);
        TextView rat = Ui.gold(act, String.valueOf(Game.rating(p)), 22);
        rat.setGravity(android.view.Gravity.END);
        top.addView(rat);
        card.addView(top);
        card.addView(attr(act, "Batting", p.optInt("bat"), Ui.GOLD));
        card.addView(attr(act, "Bowling", p.optInt("bowl"), Ui.GREEN));
        card.addView(attr(act, "Stamina", p.optInt("stam"), Ui.RED));
        card.addView(attr(act, "Set % (morale/form)", p.optInt("set"), Ui.MUTED));
        // Batch C (idea 25): morale, with its label
        int morale = p.optInt("morale", 70);
        card.addView(attr(act, "Morale (" + Game.moraleLabel(morale) + ")", morale,
                morale >= 60 ? Ui.GREEN : morale >= 40 ? Ui.GOLD : Ui.RED));
        // Batch C (idea 30): specialist tags
        List<String> tags = g.tagsOf(name);
        if (!tags.isEmpty()) {
            StringBuilder tb = new StringBuilder("Tags: ");
            for (int k = 0; k < tags.size(); k++) { if (k > 0) tb.append(" · "); tb.append(tags.get(k)); }
            card.addView(Ui.text(act, tb.toString(), 12, Ui.GOLD, false));
        }
        // Batch C (idea 21): season snapshot line
        JSONObject ss = p.optJSONObject("ss");
        if (ss != null) {
            card.addView(Ui.small(act, "Season: " + ss.optInt("runs") + " runs (HS " + ss.optInt("hs") + ") · "
                    + ss.optInt("wkts") + " wkts · " + ss.optInt("m") + " matches"));
        }
        // Batch C (idea 22): form spark bars (last 5 batting scores) + trend
        card.addView(formView(act, p));

        Button toggle = inXI ? Ui.darkBtn(act, "Remove from XI") : Ui.goldBtn(act, "Add to XI");
        if (injured > 0 && !inXI) {
            toggle.setText("Injured — unavailable");
            toggle.setEnabled(false);
        }
        if (loanOut && !inXI) {
            toggle.setText("On loan — unavailable");
            toggle.setEnabled(false);
        }
        toggle.setOnClickListener(v -> {
            try {
                if (!inXI) {
                    // pick-time guards: rested (v2), injured (Batch C), on loan (Batch D) and a 5th overseas are refused here
                    if (p.optBoolean("rested")) { act.toast(name + " is RESTED — un-rest him first"); return; }
                    if (p.optBoolean("loanOut")) { act.toast(name + " is ON LOAN for the season"); return; }
                    if (injured > 0) { act.toast(name + " is INJURED — " + injured + " day(s) out"); return; }
                    if (act.g.xiCount() >= 11) { act.toast("XI is full — remove someone first"); return; }
                    if (p.optBoolean("overseas") && act.g.xiOverseasCount() >= Game.MAX_OVERSEAS) {
                        act.toast("Overseas limit reached — max " + Game.MAX_OVERSEAS + " in the XI");
                        return;
                    }
                }
                p.put("inXI", !inXI);
                act.save();
                act.render();
            } catch (Exception ignored) {}
        });
        card.addView(toggle);

        LinearLayout row = Ui.row(act);
        Button rest = Ui.darkBtn(act, rested ? "Un-rest" : "Rest");
        rest.setEnabled(injured == 0 && !loanOut);
        rest.setOnClickListener(v -> {
            act.g.setRested(p, !p.optBoolean("rested"));
            act.save();
            act.toast(p.optBoolean("rested")
                    ? name + " rested — removed from XI, +" + Game.RESTED_REGEN + " stamina/day"
                    : name + " available again");
            act.render();
        });
        Button watch = Ui.darkBtn(act, watched ? "★ Watching" : "☆ Watch");
        watch.setOnClickListener(v -> {
            act.g.toggleWatch(name);
            act.save();
            act.toast(act.g.isWatched(name)
                    ? "Watching " + name + " — century / 5-for alerts on"
                    : "Stopped watching " + name);
            act.render();
        });
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        rest.setLayoutParams(half);
        watch.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(rest);
        row.addView(watch);
        card.addView(row);

        LinearLayout row2 = Ui.row(act);
        Button cap = Ui.darkBtn(act, isCaptain ? "Captain ©" : "Make Captain");
        cap.setOnClickListener(v -> {
            if (isCaptain) { act.toast(name + " is already your captain"); return; }
            act.g.setCaptain(name);
            act.save();
            act.toast(name + " named captain — his morale rises, the old skipper's dips");
            act.render();
        });
        Button stats = Ui.darkBtn(act, "Stats & Form");
        stats.setOnClickListener(v -> { act.teamDetail = name; act.render(); });
        cap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        stats.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row2.addView(cap);
        row2.addView(stats);
        card.addView(row2);

        if (act.compareMode) {
            final boolean isA = name.equals(act.compareA), isB = name.equals(act.compareB);
            Button pick = Ui.darkBtn(act, isA ? "✓ Compare A" : isB ? "✓ Compare B" : "Compare +");
            pick.setOnClickListener(v -> {
                if (isA) act.compareA = "";
                else if (isB) act.compareB = "";
                else if (act.compareA.isEmpty()) act.compareA = name;
                else if (act.compareB.isEmpty()) act.compareB = name;
                else act.compareB = name;
                act.render();
            });
            card.addView(pick);
        }
        return card;
    }

    /** Batch C (idea 22): mini bar chart of the last 5 batting scores. */
    private static View formView(MainActivity act, JSONObject p) {
        LinearLayout wrap = Ui.col(act);
        JSONArray f = p.optJSONArray("formB");
        int trend = StatsBook.formTrend(p);
        String trendTxt = "Form: " + StatsBook.trendArrow(trend)
                + (trend > 0 ? " Hot" : trend < 0 ? " Cold" : " Steady");
        if (f == null || f.length() == 0) {
            wrap.addView(Ui.small(act, trendTxt + " · no innings yet this season"));
            return wrap;
        }
        LinearLayout bars = new LinearLayout(act);
        bars.setOrientation(LinearLayout.HORIZONTAL);
        bars.setGravity(android.view.Gravity.BOTTOM);
        StringBuilder nums = new StringBuilder("Last 5: ");
        for (int i = 0; i < f.length(); i++) {
            int runs = f.optInt(i);
            View bar = new View(act);
            int h = 4 + Math.min(40, runs / 2);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(act, 16), Ui.dp(act, h));
            lp.setMargins(0, 0, Ui.dp(act, 5), Ui.dp(act, 4));
            bar.setLayoutParams(lp);
            bar.setBackground(Ui.round(runs >= 50 ? Ui.GREEN : Ui.GOLD, 3, act));
            bars.addView(bar);
            if (i > 0) nums.append(" · ");
            nums.append(runs);
        }
        wrap.addView(bars);
        wrap.addView(Ui.small(act, nums + "  ·  " + trendTxt));
        JSONArray fw = p.optJSONArray("formW");
        if (fw != null && fw.length() > 0) {
            StringBuilder spells = new StringBuilder("Last spells: ");
            for (int i = 0; i < fw.length(); i++) { if (i > 0) spells.append(" · "); spells.append(fw.optString(i)); }
            spells.append(" (wkts/runs)");
            wrap.addView(Ui.small(act, spells.toString()));
        }
        return wrap;
    }

    /** Batch C (ideas 21/29/30): the per-player detail view. */
    private static View detail(final MainActivity act, final JSONObject p) {
        final Game g = act.g;
        final String name = p.optString("name");
        LinearLayout root = Ui.col(act);
        Button back = Ui.darkBtn(act, "← Back to Squad");
        back.setOnClickListener(v -> { act.teamDetail = null; act.render(); });
        root.addView(back);

        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, name + (name.equals(g.captain) ? "  © Captain" : "")));
        card.addView(Ui.small(act, p.optString("role") + (p.optBoolean("overseas") ? " · OVERSEAS" : " · Local")
                + " · Age " + p.optInt("age", 0) + " · Rating " + Game.rating(p) + " · POT " + p.optInt("pot", 0)));
        int injured = p.optInt("injured", 0);
        String status = injured > 0 ? "INJURED — " + p.optString("injType") + ", " + injured + " day(s) out"
                : p.optBoolean("loanOut") ? "ON LOAN (out for the season)"
                : p.optBoolean("rested") ? "RESTED" : "Fit";
        card.addView(Ui.text(act, "Status: " + status + " · Morale " + p.optInt("morale", 70)
                + " (" + Game.moraleLabel(p.optInt("morale", 70)) + ")", 13,
                injured > 0 ? Ui.RED : Ui.GREEN, true));
        // Batch D (ideas 34/35): contract + wage in the detail view
        if (p.optBoolean("loanIn")) {
            card.addView(Ui.body(act, "Here on loan — no wage, returns to his parent club at rollover."));
        } else {
            int ct = p.optInt("contract", 1);
            card.addView(Ui.body(act, "Contract: " + (ct <= 0 ? "OUT OF CONTRACT — renew him in the off-season (Transfers)"
                    : ct + " season(s) left" + (ct == 1 ? " — FINAL YEAR, rivals can circle" : ""))
                    + " · Wage: " + p.optInt("wage", 0) + " CF/week"));
        }
        card.addView(attr(act, "Batting", p.optInt("bat"), Ui.GOLD));
        card.addView(attr(act, "Bowling", p.optInt("bowl"), Ui.GREEN));
        card.addView(attr(act, "Stamina", p.optInt("stam"), Ui.RED));
        root.addView(card);

        LinearLayout tagsCard = Ui.card(act);
        tagsCard.addView(Ui.h2(act, "Specialist Tags"));
        List<String> tags = g.tagsOf(name);
        if (tags.isEmpty()) tagsCard.addView(Ui.small(act, "No tags."));
        for (String t : tags) {
            tagsCard.addView(Ui.text(act, t, 14, Ui.GOLD, true));
            tagsCard.addView(Ui.small(act, Data.tagDesc(t)));
        }
        root.addView(tagsCard);

        JSONObject ss = p.optJSONObject("ss");
        JSONObject cs = p.optJSONObject("cs");
        LinearLayout season = Ui.card(act);
        season.addView(Ui.h2(act, "This Season"));
        season.addView(Ui.body(act, "Matches: " + (ss == null ? 0 : ss.optInt("m"))));
        season.addView(Ui.body(act, "Batting — " + StatsBook.batLine(ss)));
        season.addView(Ui.body(act, "Bowling — " + StatsBook.bowlLine(ss)));
        root.addView(season);

        LinearLayout career = Ui.card(act);
        career.addView(Ui.h2(act, "Career"));
        career.addView(Ui.body(act, "Matches: " + (cs == null ? 0 : cs.optInt("m"))));
        career.addView(Ui.body(act, "Batting — " + StatsBook.batLine(cs)));
        career.addView(Ui.body(act, "Bowling — " + StatsBook.bowlLine(cs)));
        root.addView(career);

        LinearLayout formCard = Ui.card(act);
        formCard.addView(Ui.h2(act, "Form"));
        formCard.addView(formView(act, p));
        root.addView(formCard);

        // Batch F (idea 60): rename — every name-keyed record migrates
        LinearLayout ren = Ui.card(act);
        ren.addView(Ui.h2(act, "Rename Player"));
        ren.addView(Ui.small(act, "Give him a new name — squad, season & career stats, records, "
                + "watchlist, captaincy and any live match all update to match."));
        Button rb = Ui.darkBtn(act, "Rename " + name);
        rb.setOnClickListener(v -> {
            final android.widget.EditText in = new android.widget.EditText(act);
            in.setText(name);
            in.setSingleLine(true);
            new android.app.AlertDialog.Builder(act)
                    .setTitle("Rename player")
                    .setView(in)
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Rename", (d, w) -> {
                        String nn = in.getText().toString().trim();
                        String res = act.g.renamePlayer(name, nn);
                        act.save();
                        if (!nn.equals(name) && act.g.playerByName(nn) != null) act.teamDetail = nn;
                        act.toast(res);
                        act.render();
                    })
                    .show();
        });
        ren.addView(rb);
        root.addView(ren);

        LinearLayout miles = Ui.card(act);
        miles.addView(Ui.h2(act, "Milestones"));
        JSONArray ms = p.optJSONArray("miles");
        if (ms == null || ms.length() == 0) {
            miles.addView(Ui.small(act, "None yet — 500 career runs, 50 wickets and 50 matches are the first ones to chase."));
        } else {
            for (int i = 0; i < ms.length(); i++) {
                miles.addView(Ui.body(act, "✓ " + StatsBook.milestoneText(ms.optString(i))));
            }
        }
        root.addView(miles);
        return root;
    }

    /** Batch C (idea 28): side-by-side rows for two players. */
    private static View compareTable(MainActivity act, JSONObject a, JSONObject b) {
        LinearLayout t = Ui.col(act);
        t.addView(cmpRow(act, "", shortName(a.optString("name")), shortName(b.optString("name")), true));
        t.addView(cmpRow(act, "Role", a.optString("role"), b.optString("role"), false));
        t.addView(cmpRow(act, "Age", String.valueOf(a.optInt("age", 0)), String.valueOf(b.optInt("age", 0)), false));
        t.addView(cmpRow(act, "Rating", String.valueOf(Game.rating(a)), String.valueOf(Game.rating(b)), false));
        t.addView(cmpRow(act, "POT", String.valueOf(a.optInt("pot", 0)), String.valueOf(b.optInt("pot", 0)), false));
        t.addView(cmpRow(act, "Batting", String.valueOf(a.optInt("bat")), String.valueOf(b.optInt("bat")), false));
        t.addView(cmpRow(act, "Bowling", String.valueOf(a.optInt("bowl")), String.valueOf(b.optInt("bowl")), false));
        t.addView(cmpRow(act, "Stamina", String.valueOf(a.optInt("stam")), String.valueOf(b.optInt("stam")), false));
        t.addView(cmpRow(act, "Morale", a.optInt("morale", 70) + " (" + Game.moraleLabel(a.optInt("morale", 70)) + ")",
                b.optInt("morale", 70) + " (" + Game.moraleLabel(b.optInt("morale", 70)) + ")", false));
        JSONObject sa = a.optJSONObject("ss"), sb = b.optJSONObject("ss");
        t.addView(cmpRow(act, "Season runs", String.valueOf(sa == null ? 0 : sa.optInt("runs")), String.valueOf(sb == null ? 0 : sb.optInt("runs")), false));
        t.addView(cmpRow(act, "Season wkts", String.valueOf(sa == null ? 0 : sa.optInt("wkts")), String.valueOf(sb == null ? 0 : sb.optInt("wkts")), false));
        t.addView(cmpRow(act, "Form", StatsBook.trendArrow(StatsBook.formTrend(a)), StatsBook.trendArrow(StatsBook.formTrend(b)), false));
        return t;
    }

    private static String shortName(String n) {
        String[] parts = n.split(" ");
        return parts.length > 1 ? parts[0].charAt(0) + ". " + parts[parts.length - 1] : n;
    }

    private static View cmpRow(MainActivity act, String label, String va, String vb, boolean header) {
        LinearLayout row = Ui.row(act);
        TextView l = Ui.text(act, label, 12, Ui.MUTED, false);
        l.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 86), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(l);
        TextView x = Ui.text(act, va, header ? 14 : 13, header ? Ui.GOLD : Ui.INK, true);
        x.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(x);
        TextView y = Ui.text(act, vb, header ? 14 : 13, header ? Ui.GOLD : Ui.INK, true);
        y.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(y);
        row.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
        return row;
    }

    private static View attr(MainActivity act, String label, int val, int color) {
        LinearLayout row = Ui.row(act);
        TextView l = Ui.small(act, label);
        l.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 118), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(l);
        LinearLayout barWrap = Ui.col(act);
        barWrap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        barWrap.addView(Ui.bar(act, val, color));
        row.addView(barWrap);
        TextView v = Ui.text(act, String.valueOf(val), 13, Ui.INK, true);
        v.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 32), ViewGroup.LayoutParams.WRAP_CONTENT));
        v.setGravity(android.view.Gravity.END);
        row.addView(v);
        return row;
    }
}
