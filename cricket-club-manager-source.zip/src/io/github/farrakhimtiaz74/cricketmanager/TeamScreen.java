package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/** Team tab. v2: live team-sheet validator + rested system + watchlist.
 * Batch C adds: player meta on cards (age, POT, morale, tags, injuries),
 * form spark bars (idea 22), a per-player detail view with season/career
 * stats + milestones (ideas 21/29), captain controls (idea 26), the
 * Auto-pick Best XI button (idea 27), a two-player comparison (idea 28)
 * and the physio queue (idea 24). */
public class TeamScreen {
 private static final String[] FILTERS = {"All", "Bat", "Bowl", "AR", "WK"};

 public static View build(final MainActivity act) {
 final Game g = act.g;
 if (act.teamDetail != null) {
 JSONObject dp = g.playerByName(act.teamDetail);
 if (dp != null) return detail(act, dp);
 act.teamDetail = null;
 }
 LinearLayout root = Ui.col(act);
 // P2 (suggestion 14): the category header leads the tab
 root.addView(Ui.sectionHeader(act, "SQUAD"));

 // header + LIVE team-sheet validator (v2): every problem listed as you pick
 LinearLayout head = Ui.card(act);
 head.addView(Ui.h2(act, "Squad — Starting XI: " + g.xiCount() + "/11 · Overseas: "
 + g.xiOverseasCount() + "/" + Game.MAX_OVERSEAS));
 List<String> problems = g.xiProblems();
 if (problems.isEmpty()) {
 head.addView(Ui.text(act, "Team sheet is legal — ready for match day.", 13, Ui.GREEN, true));
 } else {
 head.addView(Ui.text(act, "Team sheet problems (match day is blocked until fixed):", 13, Ui.RED, true));
 for (String pr : problems) head.addView(Ui.text(act, "•  " + pr, 13, Ui.RED, false));
 }
 // Batch J (idea 98): the squad's season stats as a spreadsheet file
 Button expS = Ui.darkBtn(act, "Export Squad Stats (CSV)");
 expS.setOnClickListener(v -> act.shareTextFile("squad-stats.csv",
 CsvExport.squadCsv(act.g), "text/csv"));
 head.addView(expS);
 // Batch C (idea 26): captain status — a warning, not a validator block
 head.addView(Ui.text(act, "Captain: " + g.captain, 13, Ui.GOLD, true));
 if (!g.captainInXi()) {
 head.addView(Ui.text(act, "Your captain is not in the XI — his on-field boost is lost.", 12, Ui.RED, false));
 }
 // Batch C (idea 27): auto-pick the best legal XI for the next pitch
 Button best = Ui.goldBtn(act, "Auto-pick Best XI");
 best.setOnClickListener(v -> autoPick(act));
 head.addView(best);
 Button cmp = Ui.darkBtn(act, act.compareMode ? "Compare: ON (tap two players)" : "Compare players");
 cmp.setOnClickListener(v -> {
 act.compareMode = !act.compareMode;
 if (!act.compareMode) { act.compareA = ""; act.compareB = ""; }
 act.render();
 });
 head.addView(cmp);
 root.addView(head);

 // Batch C (idea 28): side-by-side comparison, once two are picked
 if (act.compareMode) {
 LinearLayout cc = Ui.card(act);
 cc.addView(Ui.h2(act, "Player Comparison"));
 JSONObject a = g.playerByName(act.compareA);
 JSONObject b = g.playerByName(act.compareB);
 if (a == null || b == null) {
 cc.addView(Ui.small(act, "Tap \"Compare +\" on two player cards below. Picked so far: "
 + (a != null ? a.optString("name") : "—") + " / " + (b != null ? b.optString("name") : "—")));
 } else {
 cc.addView(compareTable(act, a, b));
 }
 root.addView(cc);
 }

 // Batch C (idea 24): physio queue — who is out, and for how long
 StringBuilder physio = new StringBuilder();
 for (int i = 0; i < g.players.length(); i++) {
 JSONObject p = g.player(i);
 if (p.optInt("injured", 0) > 0) {
 physio.append("•  ").append(p.optString("name")).append(" — ")
 .append(p.optString("injType")).append(" · ")
 .append(p.optInt("injured")).append(" day(s) left\n");
 }
 }
 if (physio.length() > 0) {
 LinearLayout pc = Ui.card(act);
 pc.addView(Ui.text(act, "PHYSIO QUEUE", 13, Ui.RED, true));
 pc.addView(Ui.body(act, physio.toString().trim()));
 pc.addView(Ui.small(act, "Injured players heal one day per Advance Day. A better Medical Centre (HQ) shortens new injuries."));
 root.addView(pc);
 }

 // role filters — P2 (suggestion 15): STICKY. The chip rows are
 // parked in MainActivity's sticky slot (outside the ScrollView),
 // so they stay on screen while the squad list scrolls; render()
 // clears and re-parks them on every rebuild, so the active chips
 // always reflect state after any action.
 // P4 (suggestions 32/33): a second row switches Cards | Rows, and
 // in Rows view a third row carries the in-memory sort keys.
 LinearLayout stickyBox = Ui.col(act);
 LinearLayout chipWrap = new LinearLayout(act);
 chipWrap.setOrientation(LinearLayout.HORIZONTAL);
 for (final String f : FILTERS) {
 Button c = Ui.chip(act, f, f.equals(act.teamFilter));
 c.setOnClickListener(v -> { act.teamFilter = f; act.render(); });
 chipWrap.addView(c);
 }
 stickyBox.addView(chipWrap);
 LinearLayout viewWrap = new LinearLayout(act);
 viewWrap.setOrientation(LinearLayout.HORIZONTAL);
 for (final String vm : new String[]{"Cards", "Rows"}) {
 Button c = Ui.chip(act, vm, vm.equals(act.teamViewMode));
 c.setOnClickListener(v -> { act.teamViewMode = vm; act.render(); });
 viewWrap.addView(c);
 }
 stickyBox.addView(viewWrap);
 if ("Rows".equals(act.teamViewMode)) {
 LinearLayout sortWrap = new LinearLayout(act);
 sortWrap.setOrientation(LinearLayout.HORIZONTAL);
 for (final String s : Present.SORTS) {
 Button c = Ui.chip(act, s, s.equals(act.teamSort));
 c.setOnClickListener(v -> { act.teamSort = s; act.render(); });
 sortWrap.addView(c);
 }
 stickyBox.addView(sortWrap);
 }
 act.setSticky(stickyBox);

 // players
 if ("Rows".equals(act.teamViewMode)) {
 // P4 (suggestion 33): compact rows, sorted in memory
 JSONArray filtered = new JSONArray();
 for (int i = 0; i < g.players.length(); i++) {
 JSONObject p = g.player(i);
 if (!"All".equals(act.teamFilter) && !act.teamFilter.equals(p.optString("role"))) continue;
 filtered.put(p);
 }
 for (JSONObject p : Present.sortPlayers(filtered, act.teamSort)) root.addView(squadRow(act, p));
 } else {
 for (int i = 0; i < g.players.length(); i++) {
 final JSONObject p = g.player(i);
 if (!"All".equals(act.teamFilter) && !act.teamFilter.equals(p.optString("role"))) continue;
 root.addView(playerCard(act, p));
 }
 }

 // P2 (suggestion 20): the pinned XI bar — XI count + legality and
 // the Auto-pick shortcut, parked under the scroll area so they
 // are reachable however far the squad list has scrolled.
 LinearLayout bar = new LinearLayout(act);
 bar.setOrientation(LinearLayout.HORIZONTAL);
 bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
 bar.setBackgroundColor(Ui.CARD);
 bar.setPadding(Ui.dp(act, 14), Ui.dp(act, 6), Ui.dp(act, 14), Ui.dp(act, 6));
 List<String> probs = g.xiProblems();
 TextView xiStat = Ui.text(act, "XI: " + g.xiCount() + "/11 · "
 + (probs.isEmpty() ? "Legal" : "Blocked — " + probs.size() + " problem(s)"),
 13, probs.isEmpty() ? Ui.GREEN : Ui.RED, true);
 xiStat.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 bar.addView(xiStat);
 Button barPick = Ui.darkBtn(act, "Auto-pick Best XI");
 barPick.setOnClickListener(v -> autoPick(act));
 barPick.setLayoutParams(new LinearLayout.LayoutParams(
 ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(act, 40)));
 bar.addView(barPick);
 act.setActionBar(bar);
 return root;
 }

 /** Batch C (idea 27): the one Auto-pick path — head card button
 *  and the P2 pinned bar both call this. */
 private static void autoPick(final MainActivity act) {
 JSONObject next = act.g.nextUserFixture();
 int pitch = 0;
 if (next != null) {
 Game.ensureFixtureMeta(next, act.g.season);
 pitch = next.optInt("pitch", 0);
 }
 String msg = act.g.pickBestXI(pitch);
 act.save();
 act.toast(msg);
 act.render();
 }

 private static View playerCard(final MainActivity act, final JSONObject p) {
 final Game g = act.g;
 final String name = p.optString("name");
 final boolean inXI = p.optBoolean("inXI");
 final boolean rested = p.optBoolean("rested");
 final boolean loanOut = p.optBoolean("loanOut");
 final boolean loanIn = p.optBoolean("loanIn");
 final int injured = p.optInt("injured", 0);
 final boolean watched = g.isWatched(name);
 final boolean isCaptain = name.equals(g.captain);
 LinearLayout card = Ui.card(act);
 // Design Batch (item 9c): the rating-tier frame — a coloured
 // strip crowns the card (Bronze/Silver/Gold/Elite by rating)
 int rating = Game.rating(p);
 View tierStrip = new View(act);
 tierStrip.setBackground(Ui.round(Design.tierColor(rating), 3, act));
 tierStrip.setLayoutParams(new LinearLayout.LayoutParams(
 ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 4)));
 card.addView(tierStrip);
 LinearLayout top = Ui.row(act);
 // Design Batch (item 9a): initials disc in the role colour
 AvatarView av = new AvatarView(act, name, p.optString("role"), 42);
 LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(Ui.dp(act, 42), Ui.dp(act, 42));
 avLp.setMargins(0, 0, Ui.dp(act, 10), 0);
 av.setLayoutParams(avLp);
 top.addView(av);
 LinearLayout nameCol = Ui.col(act);
 nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 nameCol.addView(Ui.text(act, name, 16, Ui.INK, true));
 StringBuilder sub = new StringBuilder(p.optString("role"));
 sub.append(inXI ? " · In XI" : " · Bench");
 if (p.optBoolean("overseas")) sub.append(" · OVERSEAS");
 sub.append(" · Age ").append(p.optInt("age", 0));
 sub.append(" · POT ").append(p.optInt("pot", 0));
 // Batch D (ideas 34/35): deal + wage on the card
 if (loanIn) sub.append(" · ON LOAN (in)");
 else {
 int ct = p.optInt("contract", 1);
 sub.append(ct <= 0 ? " · OUT OF CONTRACT" : ct == 1 ? " · Deal: final year" : " · Deal: " + ct + " yrs");
 sub.append(" · Wage ").append(p.optInt("wage", 0)).append("/wk");
 }
 nameCol.addView(Ui.small(act, sub.toString()));
 if (rested) {
 TextView badge = Ui.text(act, "RESTED — recovering +" + Game.RESTED_REGEN + " stamina/day, cannot be selected", 12, Ui.RED, true);
 badge.setPadding(0, Ui.dp(act, 2), 0, 0);
 nameCol.addView(badge);
 }
 if (injured > 0) {
 TextView badge = Ui.text(act, "INJURED — " + p.optString("injType") + " · " + injured + " day(s) out, cannot be selected", 12, Ui.RED, true);
 badge.setPadding(0, Ui.dp(act, 2), 0, 0);
 nameCol.addView(badge);
 }
 if (loanOut) {
 TextView badge = Ui.text(act, "ON LOAN — away for the season, returns at rollover, cannot be selected", 12, Ui.GOLD, true);
 badge.setPadding(0, Ui.dp(act, 2), 0, 0);
 nameCol.addView(badge);
 }
 // Batch F (idea 55): away on international duty during the off-season
 if (g.offseason > 0 && g.isCalledUp(name)) {
 TextView badge = Ui.text(act, "ON INTERNATIONAL DUTY — touring with his national side until the season starts", 12, Ui.GOLD, true);
 badge.setPadding(0, Ui.dp(act, 2), 0, 0);
 nameCol.addView(badge);
 }
 top.addView(nameCol);
 // Design Batch (items 4/9c): rating as a display numeral with
 // the tier name under it
 LinearLayout ratCol = Ui.col(act);
 TextView rat = Ui.display(act, String.valueOf(rating), 22, Ui.GOLD);
 rat.setGravity(android.view.Gravity.END);
 ratCol.addView(rat);
 TextView tierLab = Ui.micro(act, Design.tierName(rating).toUpperCase());
 tierLab.setGravity(android.view.Gravity.END);
 ratCol.addView(tierLab);
 top.addView(ratCol);
 card.addView(top);
 // Design Batch (item 3): the drawn status-icon cluster — the
 // descriptive text badges above stay; these supplement them
 LinearLayout badges = new LinearLayout(act);
 badges.setOrientation(LinearLayout.HORIZONTAL);
 if (isCaptain) badges.addView(Icons.labelled(act, Icons.CAPTAIN, "Captain", Ui.GOLD));
 if (injured > 0) badges.addView(Icons.labelled(act, Icons.INJURED, "Injured", Ui.RED));
 if (rested) badges.addView(Icons.labelled(act, Icons.RESTED, "Rested", 0xFF93C5FD));
 if (watched) badges.addView(Icons.labelled(act, Icons.STAR, "Watching", Ui.GOLD));
 if (badges.getChildCount() > 0) card.addView(badges);
 // P4 (suggestion 31): the compact card — ONLY three key figures,
 // chosen by role (Present.keyStats); every other number lives in
 // the sheet / detail tabs now.
 String[][] ks = Present.keyStats(p);
 LinearLayout ksRow = Ui.row(act);
 for (String[] kv : ks) {
 LinearLayout cell = Ui.col(act);
 cell.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 cell.addView(Ui.micro(act, kv[0]));
 cell.addView(Ui.display(act, kv[1], 15, Ui.INK));
 ksRow.addView(cell);
 }
 ksRow.setPadding(0, Ui.dp(act, 6), 0, Ui.dp(act, 2));
 card.addView(ksRow);
 // P4 (suggestion 34): stamina + morale as labelled meters — the
 // gauge AND the word, so colour never speaks alone
 int stam = p.optInt("stam");
 card.addView(new MeterChip(act, "Stamina", stam, Present.staminaLabel(stam)));
 int morale = p.optInt("morale", 70);
 card.addView(new MeterChip(act, "Morale", morale, Game.moraleLabel(morale)));
 // Batch C (idea 30): specialist tags — one quiet line
 List<String> tags = g.tagsOf(name);
 if (!tags.isEmpty()) {
 StringBuilder tb = new StringBuilder("Tags: ");
 for (int k = 0; k < tags.size(); k++) { if (k > 0) tb.append(" · "); tb.append(tags.get(k)); }
 card.addView(Ui.text(act, tb.toString(), 12, Ui.GOLD, false));
 }

 // P4 (suggestion 31): the card's actions shrink to chips — the XI
 // toggle (compact), captaincy, and the compare pick while that
 // mode is on. Rest / Watch moved into the quick-view sheet and
 // the detail Overview tab (same handlers, nothing lost).
 LinearLayout acts = Ui.row(act);
 boolean xiBlocked = (injured > 0 || loanOut) && !inXI;
 Button xiChip = Ui.chip(act, xiBlocked ? (injured > 0 ? "Injured" : "On loan")
 : inXI ? "In XI" : "Add to XI", inXI);
 xiChip.setEnabled(!xiBlocked);
 xiChip.setOnClickListener(v -> toggleXi(act, p));
 acts.addView(xiChip);
 Button capChip = Ui.chip(act, isCaptain ? "Captain ©" : "Make Captain", isCaptain);
 capChip.setOnClickListener(v -> {
 if (isCaptain) { act.toast(name + " is already your captain"); return; }
 act.g.setCaptain(name);
 act.save();
 act.toast(name + " named captain — his morale rises, the old skipper's dips");
 act.render();
 });
 acts.addView(capChip);
 if (act.compareMode) {
 final boolean isA = name.equals(act.compareA), isB = name.equals(act.compareB);
 Button pick = Ui.chip(act, isA ? "Compare A (set)" : isB ? "Compare B (set)" : "Compare +", isA || isB);
 pick.setOnClickListener(v -> comparePick(act, name));
 acts.addView(pick);
 }
 card.addView(acts);
 card.addView(Ui.micro(act, "Tap the card for the quick view — Rest and Watch live there and in Full Details."));
 // P2 (suggestion 17): tapping the card itself opens the quick-view
 // sheet (avatar, tier, key numbers, stamina/morale gauges); the
 // card's own buttons keep their own taps, and the sheet's Full
 // Details button routes to the detail screen below.
 card.setOnClickListener(v -> SearchScreen.playerSheet(act, p));
 return card;
 }

 /** P4: the one XI-toggle path — the card chip and the row chip
 *  share it, guards and all (rested / injured / on loan / XI full /
 *  overseas limit are refused exactly as the old card button did). */
 public static void toggleXi(final MainActivity act, final JSONObject p) {
 final String name = p.optString("name");
 final boolean inXI = p.optBoolean("inXI");
 try {
 if (!inXI) {
 if (p.optBoolean("rested")) { act.toast(name + " is RESTED — un-rest him first"); return; }
 if (p.optBoolean("loanOut")) { act.toast(name + " is ON LOAN for the season"); return; }
 int injured = p.optInt("injured", 0);
 if (injured > 0) { act.toast(name + " is INJURED — " + injured + " day(s) out"); return; }
 if (act.g.xiCount() >= 11) { act.toast("XI is full — remove someone first"); return; }
 if (p.optBoolean("overseas") && act.g.xiOverseasCount() >= Game.MAX_OVERSEAS) {
 act.toast("Overseas limit reached — max " + Game.MAX_OVERSEAS + " in the XI");
 return;
 }
 }
 p.put("inXI", !inXI);
 act.save();
 act.render();
 } catch (Exception ignored) {}
 }

 /** P4: the compare pick, shared by the card chip and the row chip. */
 public static void comparePick(final MainActivity act, String name) {
 if (name.equals(act.compareA)) act.compareA = "";
 else if (name.equals(act.compareB)) act.compareB = "";
 else if (act.compareA.isEmpty()) act.compareA = name;
 else if (act.compareB.isEmpty()) act.compareB = name;
 else act.compareB = name;
 act.render();
 }

 /** P4 (suggestion 31): Rest, shared by the sheet and detail tabs. */
 public static void restToggle(final MainActivity act, final JSONObject p) {
 final String name = p.optString("name");
 act.g.setRested(p, !p.optBoolean("rested"));
 act.save();
 act.toast(p.optBoolean("rested")
 ? name + " rested — removed from XI, +" + Game.RESTED_REGEN + " stamina/day"
 : name + " available again");
 }

 /** P4 (suggestion 31): Watch, shared by the sheet and detail tabs. */
 public static void watchToggle(final MainActivity act, final JSONObject p) {
 final String name = p.optString("name");
 act.g.toggleWatch(name);
 act.save();
 act.toast(act.g.isWatched(name)
 ? "Watching " + name + " — century / 5-for alerts on"
 : "Stopped watching " + name);
 }

 /** P4 (suggestion 33): the compact squad row — avatar, name + role,
 *  a stamina ring with its WORD (suggestion 34), the rating, and the
 *  same XI chip the cards carry. Tap opens the quick-view sheet. */
 private static View squadRow(final MainActivity act, final JSONObject p) {
 final Game g = act.g;
 final String name = p.optString("name");
 final boolean inXI = p.optBoolean("inXI");
 final int injured = p.optInt("injured", 0);
 final boolean loanOut = p.optBoolean("loanOut");
 LinearLayout wrap = Ui.col(act);
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 7), 0, Ui.dp(act, 7));
 AvatarView av = new AvatarView(act, name, p.optString("role"), 34);
 LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(Ui.dp(act, 34), Ui.dp(act, 34));
 avLp.setMargins(0, 0, Ui.dp(act, 9), 0);
 av.setLayoutParams(avLp);
 row.addView(av);
 LinearLayout texts = Ui.col(act);
 texts.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 texts.addView(Ui.text(act, name + (name.equals(g.captain) ? " ©" : ""), 14, Ui.INK, true));
 texts.addView(Ui.small(act, p.optString("role")
 + (p.optBoolean("overseas") ? " · OVERSEAS" : "")
 + (injured > 0 ? " · INJURED " + injured + "d" : p.optBoolean("rested") ? " · RESTED" : loanOut ? " · ON LOAN" : "")));
 row.addView(texts);
 int stam = p.optInt("stam");
 LinearLayout stamCol = Ui.col(act);
 stamCol.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
 stamCol.addView(new RingView(act, stam, 22));
 stamCol.addView(Ui.micro(act, stam + " " + Present.staminaLabel(stam)));
 LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(Ui.dp(act, 56), ViewGroup.LayoutParams.WRAP_CONTENT);
 scLp.setMargins(0, 0, Ui.dp(act, 6), 0);
 stamCol.setLayoutParams(scLp);
 row.addView(stamCol);
 TextView rat = Ui.display(act, String.valueOf(Game.rating(p)), 16, Ui.GOLD);
 rat.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 34), ViewGroup.LayoutParams.WRAP_CONTENT));
 rat.setGravity(android.view.Gravity.END);
 row.addView(rat);
 if (act.compareMode) {
 final boolean isA = name.equals(act.compareA), isB = name.equals(act.compareB);
 Button pick = Ui.chip(act, isA ? "A (set)" : isB ? "B (set)" : "Compare +", isA || isB);
 pick.setOnClickListener(v -> comparePick(act, name));
 row.addView(pick);
 } else {
 boolean xiBlocked = (injured > 0 || loanOut) && !inXI;
 Button xiChip = Ui.chip(act, xiBlocked ? "Out" : inXI ? "In XI" : "Add", inXI);
 xiChip.setEnabled(!xiBlocked);
 xiChip.setOnClickListener(v -> toggleXi(act, p));
 row.addView(xiChip);
 }
 row.setOnClickListener(v -> SearchScreen.playerSheet(act, p));
 wrap.addView(row);
 View div = new View(act);
 div.setBackgroundColor(Ui.CARD2);
 div.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 1)));
 wrap.addView(div);
 return wrap;
 }

 /** Batch C (idea 22) + Design Batch (item 8): the last-5 form as a
 * DRAWN chart (FormBarsView: runs bars + wickets bars) with the
 * numbers and the ▲/▼/● trend as text companions. */
 private static View formView(MainActivity act, JSONObject p) {
 LinearLayout wrap = Ui.col(act);
 JSONArray f = p.optJSONArray("formB");
 JSONArray fw = p.optJSONArray("formW");
 int trend = StatsBook.formTrend(p);
 String trendTxt = "Form: " + StatsBook.trendArrow(trend)
 + (trend > 0 ? "Hot" : trend < 0 ? "Cold" : "Steady");
 FormBarsView chart = new FormBarsView(act, f, fw);
 if (!chart.hasData()) {
 wrap.addView(Ui.small(act, trendTxt + " · no innings yet this season"));
 return wrap;
 }
 wrap.addView(chart);
 StringBuilder nums = new StringBuilder("Last 5: ");
 if (f != null) {
 for (int i = 0; i < f.length(); i++) {
 if (i > 0) nums.append(" · ");
 nums.append(f.optInt(i));
 }
 }
 wrap.addView(Ui.small(act, nums + " runs · sky bars = wickets · " + trendTxt));
 return wrap;
 }

 /** Batch C (ideas 21/29/30): the per-player detail view. */
 private static View detail(final MainActivity act, final JSONObject p) {
 final Game g = act.g;
 final String name = p.optString("name");
 LinearLayout root = Ui.col(act);
 // P2 (suggestions 13/19): the standard sub-screen header replaces
 // the old back button — player name as the title, his context as
 // the subtitle
 root.addView(Ui.subHeader(act,
 name + (name.equals(g.captain) ? " — Captain" : ""),
 p.optString("role") + " · " + g.userTeam + " · "
 + Design.tierName(Game.rating(p)) + " tier · Rating " + Game.rating(p),
 v -> { act.teamDetail = null; act.render(); }));

 // P4 (suggestion 32): in-screen tab chips — Overview / Stats /
 // Form / Contract swap the content below; the selection lives on
 // the activity (in memory only) and survives re-renders.
 LinearLayout tabRow = Ui.row(act);
 for (final String t : new String[]{"Overview", "Stats", "Form", "Contract"}) {
 Button c = Ui.chip(act, t, t.equals(act.teamDetailTab));
 c.setOnClickListener(v -> { act.teamDetailTab = t; act.render(); });
 tabRow.addView(c);
 }
 root.addView(tabRow);
 final String dtab = act.teamDetailTab;

 if ("Overview".equals(dtab)) {
 LinearLayout card = Ui.card(act);
 // Design Batch (item 9): tier strip + avatar on the detail too
 View dStrip = new View(act);
 dStrip.setBackground(Ui.round(Design.tierColor(Game.rating(p)), 3, act));
 dStrip.setLayoutParams(new LinearLayout.LayoutParams(
 ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 4)));
 card.addView(dStrip);
 LinearLayout dTop = Ui.row(act);
 AvatarView dAv = new AvatarView(act, name, p.optString("role"), 46);
 LinearLayout.LayoutParams dAvLp = new LinearLayout.LayoutParams(Ui.dp(act, 46), Ui.dp(act, 46));
 dAvLp.setMargins(0, 0, Ui.dp(act, 10), 0);
 dAv.setLayoutParams(dAvLp);
 dTop.addView(dAv);
 LinearLayout dName = Ui.col(act);
 // P2: the name itself is the subHeader title now — the card leads
 // with the tier line instead of repeating it
 dName.addView(Ui.micro(act, Design.tierName(Game.rating(p)).toUpperCase() + " TIER"));
 dTop.addView(dName);
 card.addView(dTop);
 LinearLayout potLineRow = Ui.row(act);
 TextView potLineTxt = Ui.small(act, p.optString("role") + (p.optBoolean("overseas") ? " · OVERSEAS" : " · Local")
 + " · Age " + p.optInt("age", 0) + " · Rating " + Game.rating(p) + " · POT " + p.optInt("pot", 0));
 potLineTxt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 potLineRow.addView(potLineTxt);
 potLineRow.addView(Ui.infoChip(act, "POT")); // P5 (suggestion 44)
 card.addView(potLineRow);
 int injured = p.optInt("injured", 0);
 String status = injured > 0 ? "INJURED — " + p.optString("injType") + ", " + injured + " day(s) out"
 : p.optBoolean("loanOut") ? "ON LOAN (out for the season)"
 : p.optBoolean("rested") ? "RESTED" : "Fit";
 card.addView(Ui.text(act, "Status: " + status + " · Morale " + p.optInt("morale", 70)
 + " (" + Game.moraleLabel(p.optInt("morale", 70)) + ")", 13,
 injured > 0 ? Ui.RED : Ui.GREEN, true));
 // Batch D (ideas 34/35): contract + wage in the detail view
 if (p.optBoolean("loanIn")) {
 card.addView(Ui.body(act, "Here on loan — no wage, returns to his parent club at rollover."));
 } else {
 int ct = p.optInt("contract", 1);
 card.addView(Ui.body(act, "Contract: " + (ct <= 0 ? "OUT OF CONTRACT — renew him in the off-season (Transfers)"
 : ct + " season(s) left" + (ct == 1 ? " — FINAL YEAR, rivals can circle" : ""))
 + " · Wage: " + p.optInt("wage", 0) + " CF/week"));
 }
 card.addView(attr(act, "Batting", p.optInt("bat"), Ui.GOLD));
 card.addView(attr(act, "Bowling", p.optInt("bowl"), Ui.GREEN));
 int stam2 = p.optInt("stam");
 card.addView(attr(act, "Stamina", stam2,
 stam2 >= 60 ? Ui.GREEN : stam2 >= 40 ? Ui.GOLD : Ui.RED));
 // P5 (suggestion 44): Set % is back on the detail (the P4 compact
 // cards dropped the bar) — with its info badge beside the label
 card.addView(setRow(act, p.optInt("set")));
 root.addView(card);

 LinearLayout tagsCard = Ui.card(act);
 tagsCard.addView(Ui.h2(act, "Specialist Tags"));
 List<String> tags = g.tagsOf(name);
 if (tags.isEmpty()) tagsCard.addView(Ui.small(act, "No tags."));
 for (String t : tags) {
 tagsCard.addView(Ui.text(act, t, 14, Ui.GOLD, true));
 tagsCard.addView(Ui.small(act, Data.tagDesc(t)));
 }
 root.addView(tagsCard);

 // P4 (suggestion 31): Rest / Watch live here too (and in the
 // quick-view sheet) — the compact card gave up its buttons to them
 LinearLayout actCard = Ui.card(act);
 actCard.addView(Ui.h2(act, "Manage"));
 LinearLayout mRow = Ui.row(act);
 Button restB = Ui.darkBtn(act, p.optBoolean("rested") ? "Un-rest" : "Rest");
 restB.setEnabled(injured == 0 && !p.optBoolean("loanOut"));
 restB.setOnClickListener(v -> { restToggle(act, p); act.render(); });
 Button watchB = Ui.darkBtn(act, g.isWatched(name) ? "Watching" : "Watch");
 watchB.setOnClickListener(v -> { watchToggle(act, p); act.render(); });
 restB.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 watchB.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 mRow.addView(restB);
 mRow.addView(watchB);
 actCard.addView(mRow);
 root.addView(actCard);
 }

 if ("Stats".equals(dtab)) {
 JSONObject ss = p.optJSONObject("ss");
 JSONObject cs = p.optJSONObject("cs");
 LinearLayout season = Ui.card(act);
 season.addView(Ui.h2(act, "This Season"));
 season.addView(Ui.body(act, "Matches: " + (ss == null ? 0 : ss.optInt("m"))));
 season.addView(Ui.body(act, "Batting — " + StatsBook.batLine(ss)));
 season.addView(Ui.body(act, "Bowling — " + StatsBook.bowlLine(ss)));
 root.addView(season);

 LinearLayout career = Ui.card(act);
 career.addView(Ui.h2(act, "Career"));
 career.addView(Ui.body(act, "Matches: " + (cs == null ? 0 : cs.optInt("m"))));
 // P2 (suggestion 16): the career batting/bowling detail is
 // secondary to the season card above — it rides in a collapsible,
 // closed by default, state living only for this screen visit
 LinearLayout csLines = Ui.col(act);
 csLines.addView(Ui.body(act, "Batting — " + StatsBook.batLine(cs)));
 csLines.addView(Ui.body(act, "Bowling — " + StatsBook.bowlLine(cs)));
 career.addView(Ui.collapsible(act, "CAREER BATTING & BOWLING DETAIL", csLines, false));
 root.addView(career);
 }

 if ("Form".equals(dtab)) {
 LinearLayout formCard = Ui.card(act);
 formCard.addView(Ui.h2(act, "Form"));
 formCard.addView(formView(act, p));
 root.addView(formCard);

 LinearLayout miles = Ui.card(act);
 miles.addView(Ui.h2(act, "Milestones"));
 JSONArray ms = p.optJSONArray("miles");
 if (ms == null || ms.length() == 0) {
 miles.addView(Ui.small(act, "None yet — 500 career runs, 50 wickets and 50 matches are the first ones to chase."));
 } else {
 for (int i = 0; i < ms.length(); i++) {
 miles.addView(Ui.body(act, StatsBook.milestoneText(ms.optString(i))));
 }
 }
 root.addView(miles);
 }

 if ("Contract".equals(dtab)) {
 // P4 (suggestion 32): the deal, the wage and the renewal state
 // in one place — plus the rename action that has always lived
 // on this screen
 LinearLayout deal = Ui.card(act);
 deal.addView(Ui.h2(act, "Contract"));
 if (p.optBoolean("loanIn")) {
 deal.addView(Ui.body(act, "Here on loan for Season " + g.season + " — no wage, and he returns to his parent club at rollover. There is nothing to renew."));
 } else if (p.optBoolean("loanOut")) {
 deal.addView(Ui.body(act, "Out on loan for Season " + g.season + " — his host club pays the wage. He returns at rollover, sharper."));
 } else {
 int ct2 = p.optInt("contract", 1);
 deal.addView(Ui.text(act, ct2 <= 0 ? "OUT OF CONTRACT" : ct2 == 1 ? "FINAL YEAR of his deal" : ct2 + " season(s) left on his deal",
 15, ct2 <= 1 ? Ui.RED : Ui.INK, true));
 deal.addView(Ui.body(act, "Wage: " + p.optInt("wage", 0) + " CF/week · Squad wage bill: " + g.weeklyWages() + " CF/week"));
 deal.addView(Ui.small(act, ct2 <= 0
 ? "Renew him in Transfers during the off-season, or he leaves for free into the auction pool."
 : ct2 == 1
 ? "Renewals open in the off-season (Transfers). In his final year, rivals can circle with a poaching bid if his morale drops."
 : "Renewals open in the off-season (Transfers) once a deal enters its final year."));
 }
 root.addView(deal);

 // Batch F (idea 60): rename — every name-keyed record migrates
 LinearLayout ren = Ui.card(act);
 ren.addView(Ui.h2(act, "Rename Player"));
 ren.addView(Ui.small(act, "Give him a new name — squad, season & career stats, records, "
 + "watchlist, captaincy and any live match all update to match."));
 Button rb = Ui.darkBtn(act, "Rename " + name);
 rb.setOnClickListener(v -> {
 final android.widget.EditText in = new android.widget.EditText(act);
 in.setText(name);
 in.setSingleLine(true);
 new android.app.AlertDialog.Builder(act)
 .setTitle("Rename player")
 .setView(in)
 .setNegativeButton("Cancel", null)
 .setPositiveButton("Rename", (d, w) -> {
 String nn = in.getText().toString().trim();
 String res = act.g.renamePlayer(name, nn);
 act.save();
 if (!nn.equals(name) && act.g.playerByName(nn) != null) act.teamDetail = nn;
 act.toast(res);
 act.render();
 })
 .show();
 });
 ren.addView(rb);
 root.addView(ren);
 }
 return root;
 }

 /** Batch C (idea 28): side-by-side rows for two players. */
 private static View compareTable(MainActivity act, JSONObject a, JSONObject b) {
 LinearLayout t = Ui.col(act);
 t.addView(cmpRow(act, "", shortName(a.optString("name")), shortName(b.optString("name")), true));
 t.addView(cmpRow(act, "Role", a.optString("role"), b.optString("role"), false));
 t.addView(cmpRow(act, "Age", String.valueOf(a.optInt("age", 0)), String.valueOf(b.optInt("age", 0)), false));
 t.addView(cmpRow(act, "Rating", String.valueOf(Game.rating(a)), String.valueOf(Game.rating(b)), false));
 t.addView(cmpRow(act, "POT", String.valueOf(a.optInt("pot", 0)), String.valueOf(b.optInt("pot", 0)), false));
 t.addView(cmpRow(act, "Batting", String.valueOf(a.optInt("bat")), String.valueOf(b.optInt("bat")), false));
 t.addView(cmpRow(act, "Bowling", String.valueOf(a.optInt("bowl")), String.valueOf(b.optInt("bowl")), false));
 t.addView(cmpRow(act, "Stamina", String.valueOf(a.optInt("stam")), String.valueOf(b.optInt("stam")), false));
 t.addView(cmpRow(act, "Morale", a.optInt("morale", 70) + " (" + Game.moraleLabel(a.optInt("morale", 70)) + ")",
 b.optInt("morale", 70) + " (" + Game.moraleLabel(b.optInt("morale", 70)) + ")", false));
 JSONObject sa = a.optJSONObject("ss"), sb = b.optJSONObject("ss");
 t.addView(cmpRow(act, "Season runs", String.valueOf(sa == null ? 0 : sa.optInt("runs")), String.valueOf(sb == null ? 0 : sb.optInt("runs")), false));
 t.addView(cmpRow(act, "Season wkts", String.valueOf(sa == null ? 0 : sa.optInt("wkts")), String.valueOf(sb == null ? 0 : sb.optInt("wkts")), false));
 t.addView(cmpRow(act, "Form", StatsBook.trendArrow(StatsBook.formTrend(a)), StatsBook.trendArrow(StatsBook.formTrend(b)), false));
 return t;
 }

 private static String shortName(String n) {
 String[] parts = n.split(" ");
 return parts.length > 1 ? parts[0].charAt(0) + ". " + parts[parts.length - 1] : n;
 }

 private static View cmpRow(MainActivity act, String label, String va, String vb, boolean header) {
 LinearLayout row = Ui.row(act);
 TextView l = Ui.text(act, label, 12, Ui.MUTED, false);
 l.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 86), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(l);
 TextView x = Ui.text(act, va, header ? 14 : 13, header ? Ui.GOLD : Ui.INK, true);
 x.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(x);
 TextView y = Ui.text(act, vb, header ? 14 : 13, header ? Ui.GOLD : Ui.INK, true);
 y.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(y);
 row.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
 return row;
 }

 /** P5 (suggestion 44): the Set % attribute row — same shape as
 * attr(), but the label carries the info badge that opens the
 * glossary sheet for "Set %". */
 private static View setRow(MainActivity act, int val) {
 LinearLayout row = Ui.row(act);
 LinearLayout lab = Ui.row(act);
 lab.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 118), ViewGroup.LayoutParams.WRAP_CONTENT));
 lab.addView(Ui.small(act, "Set %"));
 View badge = Ui.infoBadge(act, "Set %");
 LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(Ui.dp(act, 17), Ui.dp(act, 17));
 blp.setMargins(Ui.dp(act, 5), 0, 0, 0);
 badge.setLayoutParams(blp);
 lab.addView(badge);
 row.addView(lab);
 LinearLayout barWrap = Ui.col(act);
 barWrap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 barWrap.addView(Ui.bar(act, val, Ui.MUTED));
 row.addView(barWrap);
 TextView v = Ui.text(act, String.valueOf(val), 13, Ui.INK, true);
 v.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 32), ViewGroup.LayoutParams.WRAP_CONTENT));
 v.setGravity(android.view.Gravity.END);
 row.addView(v);
 return row;
 }

 private static View attr(MainActivity act, String label, int val, int color) {
 LinearLayout row = Ui.row(act);
 TextView l = Ui.small(act, label);
 l.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 118), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(l);
 LinearLayout barWrap = Ui.col(act);
 barWrap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 barWrap.addView(Ui.bar(act, val, color));
 row.addView(barWrap);
 TextView v = Ui.text(act, String.valueOf(val), 13, Ui.INK, true);
 v.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 32), ViewGroup.LayoutParams.WRAP_CONTENT));
 v.setGravity(android.view.Gravity.END);
 row.addView(v);
 return row;
 }
}
