package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

public class TeamScreen {
    private static final String[] FILTERS = {"All", "Bat", "Bowl", "AR", "WK"};

    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        // header + warnings
        LinearLayout head = Ui.card(act);
        head.addView(Ui.h2(act, "Squad — Starting XI: " + g.xiCount() + "/11"));
        boolean hasWK = false;
        int bowlers = 0;
        for (JSONObject p : g.xi()) {
            if ("WK".equals(p.optString("role"))) hasWK = true;
            if (p.optInt("bowl") >= 60) bowlers++;
        }
        if (!hasWK) head.addView(Ui.text(act, "Warning: no wicket-keeper (WK) in your XI!", 13, Ui.RED, true));
        if (bowlers < 4) head.addView(Ui.text(act, "Warning: only " + bowlers + " strong bowling options (need 4+).", 13, Ui.RED, true));
        if (hasWK && bowlers >= 4 && g.xiCount() == 11)
            head.addView(Ui.text(act, "XI looks balanced. Ready for match day.", 13, Ui.GREEN, false));
        root.addView(head);

        // role filters
        LinearLayout chips = Ui.row(act);
        chips.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout chipWrap = new LinearLayout(act);
        chipWrap.setOrientation(LinearLayout.HORIZONTAL);
        for (final String f : FILTERS) {
            Button c = Ui.chip(act, f, f.equals(act.teamFilter));
            c.setOnClickListener(v -> { act.teamFilter = f; act.render(); });
            chipWrap.addView(c);
        }
        root.addView(chipWrap);

        // players
        for (int i = 0; i < g.players.length(); i++) {
            final JSONObject p = g.player(i);
            if (!"All".equals(act.teamFilter) && !act.teamFilter.equals(p.optString("role"))) continue;
            final boolean inXI = p.optBoolean("inXI");
            LinearLayout card = Ui.card(act);
            LinearLayout top = Ui.row(act);
            LinearLayout nameCol = Ui.col(act);
            nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            nameCol.addView(Ui.text(act, p.optString("name"), 16, Ui.INK, true));
            nameCol.addView(Ui.small(act, p.optString("role") + (inXI ? " · In XI" : " · Bench")));
            top.addView(nameCol);
            TextView rat = Ui.gold(act, String.valueOf(Game.rating(p)), 22);
            rat.setGravity(android.view.Gravity.END);
            top.addView(rat);
            card.addView(top);
            card.addView(attr(act, "Batting", p.optInt("bat"), Ui.GOLD));
            card.addView(attr(act, "Bowling", p.optInt("bowl"), Ui.GREEN));
            card.addView(attr(act, "Stamina", p.optInt("stam"), Ui.RED));
            card.addView(attr(act, "Set % (morale/form)", p.optInt("set"), Ui.MUTED));
            Button toggle = inXI ? Ui.darkBtn(act, "Remove from XI") : Ui.goldBtn(act, "Add to XI");
            toggle.setOnClickListener(v -> {
                try {
                    if (!inXI && act.g.xiCount() >= 11) { act.toast("XI is full — remove someone first"); return; }
                    p.put("inXI", !inXI);
                    act.save();
                    act.render();
                } catch (Exception ignored) {}
            });
            card.addView(toggle);
            root.addView(card);
        }
        return root;
    }

    private static View attr(MainActivity act, String label, int val, int color) {
        LinearLayout row = Ui.row(act);
        TextView l = Ui.small(act, label);
        l.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 118), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(l);
        LinearLayout barWrap = Ui.col(act);
        barWrap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        barWrap.addView(Ui.bar(act, val, color));
        row.addView(barWrap);
        TextView v = Ui.text(act, String.valueOf(val), 13, Ui.INK, true);
        v.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 32), ViewGroup.LayoutParams.WRAP_CONTENT));
        v.setGravity(android.view.Gravity.END);
        row.addView(v);
        return row;
    }
}
