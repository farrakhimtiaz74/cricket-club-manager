package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;

public class TeamScreen {
    private static final String[] FILTERS = {"All", "Bat", "Bowl", "AR", "WK"};

    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        // header + LIVE team-sheet validator (v2): every problem listed as you pick
        LinearLayout head = Ui.card(act);
        head.addView(Ui.h2(act, "Squad — Starting XI: " + g.xiCount() + "/11 · Overseas: "
                + g.xiOverseasCount() + "/" + Game.MAX_OVERSEAS));
        List<String> problems = g.xiProblems();
        if (problems.isEmpty()) {
            head.addView(Ui.text(act, "✓ Team sheet is legal — ready for match day.", 13, Ui.GREEN, true));
        } else {
            head.addView(Ui.text(act, "Team sheet problems (match day is blocked until fixed):", 13, Ui.RED, true));
            for (String pr : problems) head.addView(Ui.text(act, "•  " + pr, 13, Ui.RED, false));
        }
        root.addView(head);

        // role filters
        LinearLayout chipWrap = new LinearLayout(act);
        chipWrap.setOrientation(LinearLayout.HORIZONTAL);
        for (final String f : FILTERS) {
            Button c = Ui.chip(act, f, f.equals(act.teamFilter));
            c.setOnClickListener(v -> { act.teamFilter = f; act.render(); });
            chipWrap.addView(c);
        }
        root.addView(chipWrap);

        // players
        for (int i = 0; i < g.players.length(); i++) {
            final JSONObject p = g.player(i);
            if (!"All".equals(act.teamFilter) && !act.teamFilter.equals(p.optString("role"))) continue;
            final boolean inXI = p.optBoolean("inXI");
            final boolean rested = p.optBoolean("rested");
            final boolean watched = g.isWatched(p.optString("name"));
            LinearLayout card = Ui.card(act);
            LinearLayout top = Ui.row(act);
            LinearLayout nameCol = Ui.col(act);
            nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            nameCol.addView(Ui.text(act, p.optString("name"), 16, Ui.INK, true));
            StringBuilder sub = new StringBuilder(p.optString("role"));
            sub.append(inXI ? " · In XI" : " · Bench");
            if (p.optBoolean("overseas")) sub.append(" · OVERSEAS");
            nameCol.addView(Ui.small(act, sub.toString()));
            if (rested) {
                TextView badge = Ui.text(act, "RESTED — recovering +" + Game.RESTED_REGEN + " stamina/day, cannot be selected", 12, Ui.RED, true);
                badge.setPadding(0, Ui.dp(act, 2), 0, 0);
                nameCol.addView(badge);
            }
            top.addView(nameCol);
            TextView rat = Ui.gold(act, String.valueOf(Game.rating(p)), 22);
            rat.setGravity(android.view.Gravity.END);
            top.addView(rat);
            card.addView(top);
            card.addView(attr(act, "Batting", p.optInt("bat"), Ui.GOLD));
            card.addView(attr(act, "Bowling", p.optInt("bowl"), Ui.GREEN));
            card.addView(attr(act, "Stamina", p.optInt("stam"), Ui.RED));
            card.addView(attr(act, "Set % (morale/form)", p.optInt("set"), Ui.MUTED));

            Button toggle = inXI ? Ui.darkBtn(act, "Remove from XI") : Ui.goldBtn(act, "Add to XI");
            toggle.setOnClickListener(v -> {
                try {
                    if (!inXI) {
                        // pick-time guards (v2): rested players and a 5th overseas are refused here,
                        // everything else is flagged live by the validator panel above
                        if (p.optBoolean("rested")) { act.toast(p.optString("name") + " is RESTED — un-rest him first"); return; }
                        if (act.g.xiCount() >= 11) { act.toast("XI is full — remove someone first"); return; }
                        if (p.optBoolean("overseas") && act.g.xiOverseasCount() >= Game.MAX_OVERSEAS) {
                            act.toast("Overseas limit reached — max " + Game.MAX_OVERSEAS + " in the XI");
                            return;
                        }
                    }
                    p.put("inXI", !inXI);
                    act.save();
                    act.render();
                } catch (Exception ignored) {}
            });
            card.addView(toggle);

            LinearLayout row = Ui.row(act);
            Button rest = Ui.darkBtn(act, rested ? "Un-rest" : "Rest");
            rest.setOnClickListener(v -> {
                act.g.setRested(p, !p.optBoolean("rested"));
                act.save();
                act.toast(p.optBoolean("rested")
                        ? p.optString("name") + " rested — removed from XI, +" + Game.RESTED_REGEN + " stamina/day"
                        : p.optString("name") + " available again");
                act.render();
            });
            Button watch = Ui.darkBtn(act, watched ? "★ Watching" : "☆ Watch");
            watch.setOnClickListener(v -> {
                act.g.toggleWatch(p.optString("name"));
                act.save();
                act.toast(act.g.isWatched(p.optString("name"))
                        ? "Watching " + p.optString("name") + " — century / 5-for alerts on"
                        : "Stopped watching " + p.optString("name"));
                act.render();
            });
            LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            rest.setLayoutParams(half);
            watch.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(rest);
            row.addView(watch);
            card.addView(row);
            root.addView(card);
        }
        return root;
    }

    private static View attr(MainActivity act, String label, int val, int color) {
        LinearLayout row = Ui.row(act);
        TextView l = Ui.small(act, label);
        l.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 118), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(l);
        LinearLayout barWrap = Ui.col(act);
        barWrap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        barWrap.addView(Ui.bar(act, val, color));
        row.addView(barWrap);
        TextView v = Ui.text(act, String.valueOf(val), 13, Ui.INK, true);
        v.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 32), ViewGroup.LayoutParams.WRAP_CONTENT));
        v.setGravity(android.view.Gravity.END);
        row.addView(v);
        return row;
    }
}
