package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Batch J (ideas 91, 93–96, 99, 100): the Settings sub-screen — reached
 * from Profile, everything app-level in one place. What lives where:
 * display/sound/language settings sit in the ccm_settings prefs (the
 * Settings class) so they survive career resets, slot loads and
 * imports; match speed edits the career's Game.speed (Batch A) because
 * that is where the engine reads it; the backup & sync section works
 * through SyncCode (idea 100's mechanism powers idea 91's import too —
 * backup once, two doors). The safe reset reuses the exact Profile
 * flow.
 *
 * Professional Pack P5 (v18, suggestions 46/47/49): the screen is
 * REGROUPED under section headers — DISPLAY / SOUND / COMMENTARY /
 * GAMEPLAY / DATA / HELP & ABOUT. Re-grouping and labels only: every
 * existing control keeps its exact handler and behaviour. The backup
 * card speaks plainly ("Create my career code" / "Continue from a
 * career code"), and About becomes a trust card (offline · no account
 * · zero permissions). */
public class SettingsScreen {

 public static View build(final MainActivity act) {
 final Game g = act.g;
 final Settings st = act.settings;
 LinearLayout root = Ui.col(act);

 // P2 (suggestions 13/19): the standard sub-screen header
 root.addView(Ui.subHeader(act, "Settings",
 "Display · Sound · Commentary · Gameplay · Data",
 v -> { act.settingsMode = false; act.tab = 4; act.render(); }));

 // ---------------- DISPLAY (idea 95) ----------------
 root.addView(Ui.sectionHeader(act, "DISPLAY"));
 LinearLayout disp = Ui.card(act);
 disp.addView(Ui.h2(act, "Display & Motion"));
 Button big = Ui.darkBtn(act, "Big Text: " + (st.bigText() ? "ON (+25%)" : "OFF"));
 big.setOnClickListener(v -> {
 st.setBigText(!st.bigText());
 Ui.TEXT_SCALE = Settings.textScale(st.bigText());
 act.render();
 act.toast("Big Text " + (st.bigText() ? "on — text is bigger everywhere" : "off"));
 });
 disp.addView(big);
 Button anim = Ui.darkBtn(act, "Reduce Animations: " + (st.reduceAnim() ? "ON — sims run Instant" : "OFF"));
 anim.setOnClickListener(v -> {
 st.setReduceAnim(!st.reduceAnim());
 if (st.reduceAnim()) act.stopAuto();
 act.render();
 act.toast(st.reduceAnim() ? "Animations reduced — sims and Highlights jump straight ahead"
 : "Animations back to normal");
 });
 disp.addView(anim);
 disp.addView(Ui.small(act, "Reduce Animations settles the staged sim pacing: Sim buttons and Highlights"
 + " resolve instantly instead of stepping ball by ball."));
 root.addView(disp);

 // ---------------- SOUND (idea 94, rebuilt as the Audio Pack mixer, v19) ----------------
 root.addView(Ui.sectionHeader(act, "SOUND"));
 LinearLayout snd = Ui.card(act);
 snd.addView(Ui.h2(act, "Sound & Music"));
 snd.addView(Ui.small(act, "Real synthesized sounds now — bat on ball, the crowd, stings and a"
 + " quiet music bed — all generated inside the app. No audio files, no downloads."));
 Button sOn = Ui.darkBtn(act, "Sounds: " + (st.soundOn() ? "ON" : "OFF"));
 sOn.setOnClickListener(v -> {
 st.setSoundOn(!st.soundOn());
 act.render();
 act.toast("Sounds " + (st.soundOn() ? "on" : "off"));
 });
 snd.addView(sOn);
 snd.addView(Ui.small(act, "Master volume:"));
 LinearLayout vrow = Ui.row(act);
 final String[] vNames = {"Low", "Med", "High"};
 for (int i = 0; i < 3; i++) {
 final int vv = i;
 Button c = Ui.chip(act, vNames[i], st.volume() == vv);
 c.setOnClickListener(v -> { st.setVolume(vv); act.render(); });
 vrow.addView(c);
 }
 snd.addView(vrow);
 snd.addView(Ui.small(act, "Mixer — each channel 0 to 100. Test plays that channel's sound:"));
 for (int ch = 0; ch < 5; ch++) {
 final int fch = ch;
 LinearLayout crow = Ui.row(act);
 TextView clab = Ui.body(act, Settings.CH_NAMES[ch]);
 clab.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 crow.addView(clab);
 Button minus = Ui.chip(act, "−", false);
 minus.setOnClickListener(v -> { st.setChannelVol(fch, st.channelVol(fch) - 10); act.render(); });
 crow.addView(minus);
 crow.addView(Ui.display(act, st.channelVol(ch) + "", 14, Ui.GOLD));
 Button plus = Ui.chip(act, "+", false);
 plus.setOnClickListener(v -> { st.setChannelVol(fch, st.channelVol(fch) + 10); act.render(); });
 crow.addView(plus);
 Button ctest = Ui.darkBtn(act, "Test");
 ctest.setOnClickListener(v -> act.testChannel(fch));
 crow.addView(ctest);
 snd.addView(crow);
 }
 Button quiet = Ui.darkBtn(act, "Quiet Mode: " + (st.quietMode() ? "ON — big events only" : "OFF"));
 quiet.setOnClickListener(v -> {
 st.setQuietMode(!st.quietMode());
 act.render();
 act.toast(st.quietMode() ? "Quiet Mode on — wickets, boundaries, results and titles only"
 : "Quiet Mode off — all sounds play");
 });
 snd.addView(quiet);
 Button voice = Ui.darkBtn(act, "Voice score updates: " + (st.voiceOn() ? "ON" : "OFF"));
 voice.setOnClickListener(v -> {
 st.setVoiceOn(!st.voiceOn());
 act.render();
 act.toast(st.voiceOn() ? "Voice on — score updates at the break, late in a chase, and full time"
 : "Voice off");
 });
 snd.addView(voice);
 snd.addView(Ui.small(act, "Voice speaks through your phone's own text-to-speech voice (English score"
 + " lines only — Roman Urdu commentary has no voice). Sounds use the music stream and stay"
 + " silent while your phone is on silent or vibrate. Instant sims never make a sound."));
 root.addView(snd);

 // ---------------- COMMENTARY (idea 93 + speed) ----------------
 root.addView(Ui.sectionHeader(act, "COMMENTARY"));
 LinearLayout com = Ui.card(act);
 com.addView(Ui.h2(act, "Commentary"));
 com.addView(Ui.small(act, "Commentary language (scores and results stay in English):"));
 LinearLayout lrow = Ui.row(act);
 Button en = Ui.chip(act, "English", st.commLang() == Settings.LANG_ENGLISH);
 en.setOnClickListener(v -> { st.setCommLang(Settings.LANG_ENGLISH); MatchEngine.urduComm = false; act.render(); });
 Button ur = Ui.chip(act, "Roman Urdu", st.commLang() == Settings.LANG_ROMAN_URDU);
 ur.setOnClickListener(v -> { st.setCommLang(Settings.LANG_ROMAN_URDU); MatchEngine.urduComm = true; act.render(); });
 lrow.addView(en);
 lrow.addView(ur);
 com.addView(lrow);
 com.addView(Ui.small(act, "Match speed — the default for Sim and Highlights (the same setting as the match screen):"));
 LinearLayout srow = Ui.row(act);
 final String[] spNames = {"Instant", "1x", "2x"};
 for (int i = 0; i < 3; i++) {
 final int sv = i;
 Button c = Ui.chip(act, spNames[i], g.speed == sv);
 c.setOnClickListener(v -> { g.speed = sv; act.save(); act.render(); });
 srow.addView(c);
 }
 com.addView(srow);
 if (st.reduceAnim()) com.addView(Ui.small(act, "Reduce Animations is ON — sims run Instant regardless of this."));
 root.addView(com);

 // ---------------- GAMEPLAY (P5: display/change entry + state) ----------------
 root.addView(Ui.sectionHeader(act, "GAMEPLAY"));
 LinearLayout play = Ui.card(act);
 play.addView(Ui.h2(act, "Difficulty & Hardcore"));
 LinearLayout drow = Ui.row(act);
 TextView dlab = Ui.body(act, "Difficulty");
 dlab.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 drow.addView(dlab);
 drow.addView(Ui.display(act, Game.DIFF_NAMES[g.difficulty], 15, Ui.GOLD));
 play.addView(drow);
 if (g.offseason > 0) {
 LinearLayout dChips = Ui.row(act);
 for (int d = 0; d < 3; d++) {
 final int dd = d;
 Button c = Ui.chip(act, Game.DIFF_NAMES[d], g.difficulty == d);
 c.setOnClickListener(v -> { act.toast(act.g.setDifficulty(dd)); act.save(); act.render(); });
 dChips.addView(c);
 }
 play.addView(dChips);
 } else {
 play.addView(Ui.small(act, "Difficulty can be changed between seasons — the choices unlock here and in Profile during the off-season."));
 }
 if (g.hardcore) {
 play.addView(Ui.text(act, "HARDCORE IS ON", 13, Ui.RED, true));
 play.addView(Ui.small(act, "Sack line: end a season under " + g.sackThreshold()
 + " board confidence and the career ends. Rewards halved, no load undo."));
 } else {
 play.addView(Ui.small(act, "Hardcore is off — it can be switched on in Profile at a season start, or when you start a new career."));
 }
 root.addView(play);

 // ---------------- DATA: backup & sync (ideas 91/100, P5 plain words) ----------------
 root.addView(Ui.sectionHeader(act, "DATA"));
 LinearLayout bak = Ui.card(act);
 bak.addView(Ui.h2(act, "Backup & Sync"));
 bak.addView(Ui.body(act, "Your career lives only on this phone. Make a career code and keep it"
 + " somewhere safe — paste it on any phone to continue this exact career."));
 bak.addView(Ui.small(act, "Your career right now: " + g.userTeam + " · Season " + g.season + " · Day " + g.day
 + " · " + g.cf + " CF · " + g.career.optInt("titles") + " title(s)."));
 Button expFile = Ui.darkBtn(act, "Export Career File (.json)");
 expFile.setOnClickListener(v -> act.exportCareerFile());
 bak.addView(expFile);
 Button getCode = Ui.goldBtn(act, "Create my career code");
 getCode.setOnClickListener(v -> {
 act.syncCodeShown = SyncCode.encode(g.toJson());
 act.render();
 });
 bak.addView(getCode);
 if (act.syncCodeShown != null) {
 bak.addView(Ui.small(act, "This code is LONG (" + act.syncCodeShown.length()
 + " characters) — it holds your whole career. Anyone with it can load your career;"
 + " keep it somewhere private."));
 TextView codeView = Ui.small(act, act.syncCodeShown);
 codeView.setTextIsSelectable(true);
 bak.addView(codeView);
 Button copy = Ui.darkBtn(act, "Copy career code");
 copy.setOnClickListener(v -> { copyText(act, "CCM Career Code", act.syncCodeShown); act.toast("Career code copied — that's your simplest backup"); });
 bak.addView(copy);
 Button shareCode = Ui.darkBtn(act, "Share career code as file");
 shareCode.setOnClickListener(v -> act.shareTextFile("ccm-sync-code.txt", act.syncCodeShown, "text/plain"));
 bak.addView(shareCode);
 }
 bak.addView(Ui.small(act, "Continue a career — paste a career code below. Your current career is"
 + " backed up first, and you can undo the import until you play a season match"
 + (g.hardcore ? " — HARDCORE: imports cannot be undone." : ".")));
 final EditText imp = new EditText(act);
 imp.setHint("Paste career code here…");
 imp.setText(act.importDraft);
 imp.setTextColor(Ui.INK);
 imp.setHintTextColor(Ui.MUTED);
 imp.setSingleLine(false);
 imp.setMinLines(3);
 bak.addView(imp);
 Button doImport = Ui.darkBtn(act, "Continue from a career code");
 doImport.setOnClickListener(v -> {
 String code = imp.getText().toString();
 act.importDraft = code;
 final String json;
 try {
 // a career code (CCM1:…) — or a raw career .json pasted
 // straight from the exported backup file (idea 91)
 String t = code.trim();
 if (t.startsWith("{")) {
 String err = SyncCode.validateCareerJson(t);
 if (err != null) throw new IllegalArgumentException(err);
 json = t;
 } else {
 json = SyncCode.importJson(code);
 }
 } catch (IllegalArgumentException e) {
 act.toast(e.getMessage());
 return;
 }
 JSONObject sum = Slots.summary(json);
 String line = sum == null ? "a saved career" : Slots.summaryLine(sum);
 new AlertDialog.Builder(act)
 .setTitle("Replace your career?")
 .setMessage("Import: " + line + "\n\nYour current career (" + g.userTeam + ", Season "
 + g.season + ") is backed up first"
 + (g.hardcore ? ".\n\n HARDCORE: this import cannot be undone."
 : " and the import can be undone from Profile → Career Slots until you play a season match.")
 + "\nYour save slots and hardcore record are not touched.")
 .setNegativeButton("Cancel", null)
 .setPositiveButton("Import", (d, w) -> act.importCareerJson(json))
 .show();
 });
 bak.addView(doImport);
 bak.addView(Ui.small(act, "You can also import the exported .json file: open it in any text app,"
 + " copy everything, and paste it here instead of a code."));
 root.addView(bak);

 // career slots live in Profile — a plain link, no behaviour change
 LinearLayout slots = Ui.card(act);
 slots.addView(Ui.h2(act, "Career Slots"));
 slots.addView(Ui.small(act, "Three save slots for parallel careers — they live on the Profile tab."));
 Button openSlots = Ui.darkBtn(act, "Open Career Slots");
 openSlots.setOnClickListener(v -> { act.settingsMode = false; act.tab = 4; act.render(); });
 slots.addView(openSlots);
 root.addView(slots);

 // ---------------- safe reset (existing flow) ----------------
 LinearLayout danger = Ui.card(act);
 danger.addView(Ui.h2(act, "Danger Zone"));
 Button reset = Ui.dangerBtn(act, "Reset Career (start over)"); // P1
 reset.setOnClickListener(v -> new AlertDialog.Builder(act)
 .setTitle("Reset career?")
 .setMessage("All progress, CF, facilities and records will be wiped — then you pick your club for the new career. "
 + "(Your Career Slots, app settings and the hardcore record are NOT wiped.)")
 .setNegativeButton("Cancel", null)
 .setPositiveButton("Reset", (d, w) -> act.resetCareerToPicker())
 .show());
 danger.addView(reset);
 danger.addView(Ui.small(act, "App settings above (sound, language, text size) survive a reset — they are app-level, not career-level."));
 root.addView(danger);

 // ---------------- HELP & ABOUT (P5 suggestions 43/49) ----------------
 root.addView(Ui.sectionHeader(act, "HELP & ABOUT"));
 LinearLayout help = Ui.card(act);
 help.addView(Ui.h2(act, "Help & Guides"));
 help.addView(Ui.small(act, "Short guides and every game term explained, in plain words."));
 Button openHelp = Ui.darkBtn(act, "Open Help & Guides");
 openHelp.setOnClickListener(v -> act.openHelp(true));
 help.addView(openHelp);
 root.addView(help);

 // ---------------- What's New (idea 92) ----------------
 LinearLayout wn = Ui.card(act);
 wn.addView(Ui.h2(act, "What's New"));
 wn.addView(Ui.small(act, "Every update so far, newest first — in plain words."));
 Button openWn = Ui.darkBtn(act, "Open What's New");
 openWn.setOnClickListener(v -> { act.whatsNewMode = true; act.render(); });
 wn.addView(openWn);
 root.addView(wn);

 // ---------------- About & trust (P5 suggestion 49) ----------------
 LinearLayout about = Ui.card(act);
 LinearLayout abRow = Ui.row(act);
 abRow.addView(CrestView.forTeam(act, act.g, act.g.userTeam, 40));
 LinearLayout abTitles = Ui.col(act);
 abTitles.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 abTitles.setPadding(Ui.dp(act, 10), 0, 0, 0);
 abTitles.addView(Ui.h2(act, "Cricket Club Manager"));
 abTitles.addView(Ui.small(act, "Manage. Win. Lift the trophy."));
 abRow.addView(abTitles);
 about.addView(abRow);
 about.addView(Ui.small(act, "Version " + act.appVersionName + " (versionCode " + act.appVersionCode + ")"));
 LinearLayout pills = Ui.row(act);
 pills.addView(Ui.pill(act, "100% offline"));
 pills.addView(Ui.pill(act, "No account"));
 pills.addView(Ui.pill(act, "Zero permissions"));
 about.addView(pills);
 about.addView(Ui.body(act, "Your data never leaves this phone."));
 about.addView(Ui.small(act, "Run a T20 club through seasons, playoffs, auctions and a 50-over cup."));
 about.addView(Ui.small(act, "Home-screen name: CCM · Package: io.github.farrakhimtiaz74.cricketmanager"));
 about.addView(Ui.gold(act, "Built for Farrakh · Lahore Qalandars theme", 13));
 TextView repo = Ui.text(act, "github.com/farrakhimtiaz74/cricket-club-manager", 12, Ui.GOLD, false);
 repo.setPadding(0, Ui.dp(act, 4), 0, 0);
 repo.setOnClickListener(v -> {
 try {
 act.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,
 android.net.Uri.parse("https://github.com/farrakhimtiaz74/cricket-club-manager")));
 } catch (Exception e) {
 act.toast("No browser available — the address is on screen to copy");
 }
 });
 about.addView(repo);
 root.addView(about);

 return root;
 }

 private static void copyText(MainActivity act, String label, String s) {
 android.content.ClipboardManager cm = (android.content.ClipboardManager)
 act.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
 if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText(label, s));
 }
}
