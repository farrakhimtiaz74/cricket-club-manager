package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Batch J (ideas 91, 93–96, 99, 100): the Settings sub-screen — reached
 *  from Profile, everything app-level in one place. What lives where:
 *  display/sound/language settings sit in the ccm_settings prefs (the
 *  Settings class) so they survive career resets, slot loads and
 *  imports; match speed edits the career's Game.speed (Batch A) because
 *  that is where the engine reads it; the backup & sync section works
 *  through SyncCode (idea 100's mechanism powers idea 91's import too —
 *  backup once, two doors). The safe reset reuses the exact Profile
 *  flow. The About block closes the screen (idea 99's in-app polish). */
public class SettingsScreen {

    public static View build(final MainActivity act) {
        final Game g = act.g;
        final Settings st = act.settings;
        LinearLayout root = Ui.col(act);

        Button back = Ui.darkBtn(act, "← Back to Profile");
        back.setOnClickListener(v -> { act.settingsMode = false; act.tab = 4; act.render(); });
        root.addView(back);
        root.addView(Ui.h1(act, "⚙️ Settings"));

        // ---------------- idea 95: display & motion ----------------
        LinearLayout disp = Ui.card(act);
        disp.addView(Ui.h2(act, "Display & Motion"));
        Button big = Ui.darkBtn(act, "Big Text: " + (st.bigText() ? "ON (+25%)" : "OFF"));
        big.setOnClickListener(v -> {
            st.setBigText(!st.bigText());
            Ui.TEXT_SCALE = Settings.textScale(st.bigText());
            act.render();
            act.toast("Big Text " + (st.bigText() ? "on — text is bigger everywhere" : "off"));
        });
        disp.addView(big);
        Button anim = Ui.darkBtn(act, "Reduce Animations: " + (st.reduceAnim() ? "ON — sims run Instant" : "OFF"));
        anim.setOnClickListener(v -> {
            st.setReduceAnim(!st.reduceAnim());
            if (st.reduceAnim()) act.stopAuto();
            act.render();
            act.toast(st.reduceAnim() ? "Animations reduced — sims and Highlights jump straight ahead"
                    : "Animations back to normal");
        });
        disp.addView(anim);
        disp.addView(Ui.small(act, "Reduce Animations settles the staged sim pacing: Sim buttons and Highlights"
                + " resolve instantly instead of stepping ball by ball."));
        root.addView(disp);

        // ---------------- idea 94 + 96: sound ----------------
        LinearLayout snd = Ui.card(act);
        snd.addView(Ui.h2(act, "Sound Effects"));
        Button sOn = Ui.darkBtn(act, "Sounds: " + (st.soundOn() ? "ON" : "OFF"));
        sOn.setOnClickListener(v -> {
            st.setSoundOn(!st.soundOn());
            act.render();
            act.toast("Sound effects " + (st.soundOn() ? "on" : "off"));
        });
        snd.addView(sOn);
        snd.addView(Ui.small(act, "Volume:"));
        LinearLayout vrow = Ui.row(act);
        final String[] vNames = {"Low", "Med", "High"};
        for (int i = 0; i < 3; i++) {
            final int vv = i;
            Button c = Ui.chip(act, vNames[i], st.volume() == vv);
            c.setOnClickListener(v -> { st.setVolume(vv); act.resetToneGen(); act.render(); });
            vrow.addView(c);
        }
        snd.addView(vrow);
        Button test = Ui.darkBtn(act, "🔊 Test Sound");
        test.setOnClickListener(v -> { act.resetToneGen(); act.playTone(Settings.SND_SIX); });
        snd.addView(test);
        snd.addView(Ui.small(act, "A tick on runs, a rising tone on a four, two tones on a six, a buzz on a"
                + " wicket and a short jingle when you win. Only while you play live — Instant sims stay silent."));
        root.addView(snd);

        // ---------------- ideas 93 + 96: commentary & speed ----------------
        LinearLayout com = Ui.card(act);
        com.addView(Ui.h2(act, "Commentary"));
        com.addView(Ui.small(act, "Commentary language (scores and results stay in English):"));
        LinearLayout lrow = Ui.row(act);
        Button en = Ui.chip(act, "English", st.commLang() == Settings.LANG_ENGLISH);
        en.setOnClickListener(v -> { st.setCommLang(Settings.LANG_ENGLISH); MatchEngine.urduComm = false; act.render(); });
        Button ur = Ui.chip(act, "Roman Urdu", st.commLang() == Settings.LANG_ROMAN_URDU);
        ur.setOnClickListener(v -> { st.setCommLang(Settings.LANG_ROMAN_URDU); MatchEngine.urduComm = true; act.render(); });
        lrow.addView(en);
        lrow.addView(ur);
        com.addView(lrow);
        com.addView(Ui.small(act, "Match speed — the default for Sim and Highlights (the same setting as the match screen):"));
        LinearLayout srow = Ui.row(act);
        final String[] spNames = {"Instant", "1x", "2x"};
        for (int i = 0; i < 3; i++) {
            final int sv = i;
            Button c = Ui.chip(act, spNames[i], g.speed == sv);
            c.setOnClickListener(v -> { g.speed = sv; act.save(); act.render(); });
            srow.addView(c);
        }
        com.addView(srow);
        if (st.reduceAnim()) com.addView(Ui.small(act, "Reduce Animations is ON — sims run Instant regardless of this."));
        root.addView(com);

        // ---------------- ideas 91 + 100: backup & sync ----------------
        LinearLayout bak = Ui.card(act);
        bak.addView(Ui.h2(act, "💾 Backup & Sync"));
        bak.addView(Ui.small(act, "Your career right now: " + g.userTeam + " · Season " + g.season + " · Day " + g.day
                + " · " + g.cf + " CF · " + g.career.optInt("titles") + " title(s)."));
        Button expFile = Ui.darkBtn(act, "📤 Export Career File (.json)");
        expFile.setOnClickListener(v -> act.exportCareerFile());
        bak.addView(expFile);
        Button getCode = Ui.darkBtn(act, "🔑 Get Sync Code");
        getCode.setOnClickListener(v -> {
            act.syncCodeShown = SyncCode.encode(g.toJson());
            act.render();
        });
        bak.addView(getCode);
        if (act.syncCodeShown != null) {
            bak.addView(Ui.small(act, "⚠️ This code is LONG (" + act.syncCodeShown.length()
                    + " characters) — it holds your whole career. Anyone with it can load your career;"
                    + " keep it somewhere private."));
            TextView codeView = Ui.small(act, act.syncCodeShown);
            codeView.setTextIsSelectable(true);
            bak.addView(codeView);
            Button copy = Ui.darkBtn(act, "📋 Copy Sync Code");
            copy.setOnClickListener(v -> { copyText(act, "CCM Sync Code", act.syncCodeShown); act.toast("Sync code copied — that's your simplest backup"); });
            bak.addView(copy);
            Button shareCode = Ui.darkBtn(act, "📤 Share Sync Code as File");
            shareCode.setOnClickListener(v -> act.shareTextFile("ccm-sync-code.txt", act.syncCodeShown, "text/plain"));
            bak.addView(shareCode);
        }
        bak.addView(Ui.small(act, "Import a career — paste a sync code (CCM1:…) below. Your current career is"
                + " auto-backed-up first, and you can undo the import until you play a season match"
                + (g.hardcore ? " — ⚠ HARDCORE: imports get NO undo, like slot loads." : ".")));
        final EditText imp = new EditText(act);
        imp.setHint("Paste sync code here…");
        imp.setText(act.importDraft);
        imp.setTextColor(Ui.INK);
        imp.setHintTextColor(Ui.MUTED);
        imp.setSingleLine(false);
        imp.setMinLines(3);
        bak.addView(imp);
        Button doImport = Ui.goldBtn(act, "⬇ Import Career from Code");
        doImport.setOnClickListener(v -> {
            String code = imp.getText().toString();
            act.importDraft = code;
            final String json;
            try {
                // a sync code (CCM1:…) — or a raw career .json pasted
                // straight from the exported backup file (idea 91)
                String t = code.trim();
                if (t.startsWith("{")) {
                    String err = SyncCode.validateCareerJson(t);
                    if (err != null) throw new IllegalArgumentException(err);
                    json = t;
                } else {
                    json = SyncCode.importJson(code);
                }
            } catch (IllegalArgumentException e) {
                act.toast(e.getMessage());
                return;
            }
            JSONObject sum = Slots.summary(json);
            String line = sum == null ? "a saved career" : Slots.summaryLine(sum);
            new AlertDialog.Builder(act)
                    .setTitle("Replace your career?")
                    .setMessage("Import: " + line + "\n\nYour current career (" + g.userTeam + ", Season "
                            + g.season + ") is auto-backed-up first"
                            + (g.hardcore ? ".\n\n⚠ HARDCORE: this import cannot be undone."
                                          : " and the import can be undone from Profile → Career Slots until you play a season match.")
                            + "\nYour save slots and hardcore record are not touched.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Import", (d, w) -> act.importCareerJson(json))
                    .show();
        });
        bak.addView(doImport);
        bak.addView(Ui.small(act, "File backup path (idea 91): the exported .json above imports too — open it in"
                + " any text app, copy everything, and paste it here instead of a code. Same validation, same auto-backup."));
        root.addView(bak);

        // ---------------- idea 92: What's New ----------------
        LinearLayout wn = Ui.card(act);
        wn.addView(Ui.h2(act, "What's New"));
        wn.addView(Ui.small(act, "Everything the 100-update mega-batch added, version by version (v3.0 – v12.0)."));
        Button openWn = Ui.darkBtn(act, "🆕 Open What's New");
        openWn.setOnClickListener(v -> { act.whatsNewMode = true; act.render(); });
        wn.addView(openWn);
        root.addView(wn);

        // ---------------- safe reset (existing flow) ----------------
        LinearLayout danger = Ui.card(act);
        danger.addView(Ui.h2(act, "Danger Zone"));
        Button reset = Ui.darkBtn(act, "Reset Career (start over)");
        reset.setOnClickListener(v -> new AlertDialog.Builder(act)
                .setTitle("Reset career?")
                .setMessage("All progress, CF, facilities and records will be wiped — then you pick your club for the new career. "
                        + "(Your Career Slots, app settings and the hardcore record are NOT wiped.)")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (d, w) -> act.resetCareerToPicker())
                .show());
        danger.addView(reset);
        danger.addView(Ui.small(act, "App settings above (sound, language, text size) survive a reset — they are app-level, not career-level."));
        root.addView(danger);

        // ---------------- idea 99: About ----------------
        LinearLayout about = Ui.card(act);
        about.addView(Ui.h2(act, "About This App"));
        about.addView(Ui.body(act, "🏏 Cricket Club Manager (CCM)"));
        about.addView(Ui.small(act, "Version " + act.appVersionName + " (versionCode " + act.appVersionCode + ")"));
        about.addView(Ui.small(act, "Package: io.github.farrakhimtiaz74.cricketmanager"));
        about.addView(Ui.small(act, "Short name on your home screen: CCM · Fully offline · No permissions, no ads, no accounts."));
        about.addView(Ui.small(act, "Run a T20 club through seasons, playoffs, auctions and a one-day cup —"
                + " 100 updates shipped in versions 3.0 to 12.0."));
        about.addView(Ui.gold(act, "Built for Farrakh", 13));
        root.addView(about);

        return root;
    }

    private static void copyText(MainActivity act, String label, String s) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager)
                act.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText(label, s));
    }
}
