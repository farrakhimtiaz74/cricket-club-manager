package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.widget.LinearLayout;

/** Batch B (idea 17): a tiny dot-map of the field for the selected preset.
 *  Eleven dots per preset: keeper (white), bowler (red-gold) and nine
 *  fielders (gold) on a green oval. Positions are normalised (x, y) with
 *  y=0 behind the keeper (slips / third man) and y=1 at the striker's end
 *  (long-off / long-on). Index order matches MatchEngine.FIELD:
 *  0 Attacking, 1 Balanced, 2 Defensive, 3 Slips Attack, 4 Ring Field,
 *  5 Boundary Riders. The engine weights behind each preset live in
 *  MatchEngine.bowlBall and stay consistent with the v2 settings. */
public class FieldMapView extends View {
    private final int preset;
    private final Paint oval = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ovalEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pitchPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goldDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint whiteDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bowlDot = new Paint(Paint.ANTI_ALIAS_FLAG);

    // [preset][dot][x,y] — dot 0 = keeper, dot 1 = bowler, dots 2..10 = fielders
    private static final float[][][] POS = {
        { // 0 Attacking: two slips, gully, close catchers in
            {0.50f, 0.30f}, {0.50f, 0.60f},
            {0.42f, 0.26f}, {0.36f, 0.31f}, {0.64f, 0.32f}, {0.80f, 0.48f},
            {0.70f, 0.70f}, {0.60f, 0.86f}, {0.40f, 0.86f}, {0.28f, 0.68f}, {0.30f, 0.38f}},
        { // 1 Balanced: one of everything
            {0.50f, 0.30f}, {0.50f, 0.60f},
            {0.42f, 0.25f}, {0.74f, 0.22f}, {0.82f, 0.48f}, {0.72f, 0.68f},
            {0.60f, 0.88f}, {0.40f, 0.88f}, {0.26f, 0.66f}, {0.22f, 0.48f}, {0.28f, 0.26f}},
        { // 2 Defensive: boundary riders all round
            {0.50f, 0.30f}, {0.50f, 0.60f},
            {0.43f, 0.26f}, {0.80f, 0.16f}, {0.94f, 0.44f}, {0.86f, 0.74f},
            {0.64f, 0.95f}, {0.36f, 0.95f}, {0.14f, 0.72f}, {0.08f, 0.44f}, {0.18f, 0.18f}},
        { // 3 Slips Attack: three slips + gully, everything hunting edges
            {0.50f, 0.30f}, {0.50f, 0.60f},
            {0.40f, 0.22f}, {0.47f, 0.20f}, {0.33f, 0.27f}, {0.62f, 0.30f},
            {0.78f, 0.46f}, {0.68f, 0.68f}, {0.58f, 0.84f}, {0.26f, 0.50f}, {0.30f, 0.34f}},
        { // 4 Ring Field: the ring is sealed, singles are hard work
            {0.50f, 0.30f}, {0.50f, 0.60f},
            {0.42f, 0.25f}, {0.72f, 0.30f}, {0.78f, 0.46f}, {0.70f, 0.66f},
            {0.62f, 0.78f}, {0.56f, 0.86f}, {0.44f, 0.86f}, {0.30f, 0.66f}, {0.24f, 0.48f}},
        { // 5 Boundary Riders: one slip, eight men on the rope
            {0.50f, 0.30f}, {0.50f, 0.60f},
            {0.43f, 0.26f}, {0.82f, 0.14f}, {0.95f, 0.42f}, {0.88f, 0.72f},
            {0.66f, 0.96f}, {0.34f, 0.96f}, {0.12f, 0.78f}, {0.06f, 0.46f}, {0.16f, 0.16f}},
    };

    public FieldMapView(Context c, int preset) {
        super(c);
        this.preset = Math.max(0, Math.min(POS.length - 1, preset));
        setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 168)));
        oval.setColor(Color.rgb(21, 80, 45));
        oval.setStyle(Paint.Style.FILL);
        ovalEdge.setColor(Ui.LINE);
        ovalEdge.setStyle(Paint.Style.STROKE);
        ovalEdge.setStrokeWidth(Ui.dp(c, 1));
        pitchPaint.setColor(Color.rgb(186, 166, 116));
        goldDot.setColor(Ui.GOLD);
        whiteDot.setColor(Ui.INK);
        bowlDot.setColor(Ui.RED);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float rx = w * 0.47f, ry = h * 0.46f;
        canvas.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, oval);
        canvas.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, ovalEdge);
        // pitch strip down the middle
        float pw = w * 0.055f;
        canvas.drawRect(cx - pw, cy - ry * 0.42f, cx + pw, cy + ry * 0.42f, pitchPaint);
        float[][] dots = POS[preset];
        float r = Ui.dp(getContext(), 5);
        for (int i = 0; i < dots.length; i++) {
            float x = cx + (dots[i][0] - 0.5f) * 2 * rx * 0.94f;
            float y = cy + (dots[i][1] - 0.5f) * 2 * ry * 0.94f;
            Paint p = i == 0 ? whiteDot : i == 1 ? bowlDot : goldDot;
            canvas.drawCircle(x, y, i <= 1 ? r * 0.85f : r, p);
        }
    }
}
