package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONObject;

/** Batch I (ideas 87/90): career save slots + the persistent hardcore
 *  record. All logic lives here, pure over a tiny key-value interface,
 *  so it is desktop-testable; Store implements Kv over the SAME
 *  SharedPreferences file as the live save (state_v1), which means
 *  Profile Reset — removing only state_v1 — never touches the slots.
 *
 *  Keys: slot_1..slot_3 (full career JSON copies), autoslot (the
 *  pre-load backup that powers Undo Load), hardcore_record (a tiny
 *  JSON that survives every career clear). */
public class Slots {

    public interface Kv {
        String get(String k);
        void put(String k, String v);
        void remove(String k);
    }

    public static final int SLOT_COUNT = 3;
    public static final String AUTOSLOT = "autoslot";
    public static final String HARDCORE_RECORD = "hardcore_record";

    public static String slotKey(int n) { return "slot_" + n; }

    /** Copies the live career JSON into slot n. */
    public static boolean saveSlot(Kv kv, int n, Game g) {
        if (kv == null || g == null || n < 1 || n > SLOT_COUNT) return false;
        kv.put(slotKey(n), g.toJson());
        return true;
    }

    /** Loads slot n over the live career. Unless the OUTGOING career is
     *  hardcore (idea 90: no undo there), the live career is first backed
     *  up into autoslot and the loaded career is armed for one Undo —
     *  unless the LOADED career is itself hardcore, which also forbids
     *  undo. Returns the loaded Game, or null when the slot is empty. */
    public static Game loadSlot(Kv kv, int n, Game current) {
        if (kv == null || n < 1 || n > SLOT_COUNT) return null;
        String s = kv.get(slotKey(n));
        if (s == null || s.isEmpty()) return null;
        boolean backup = current != null && !current.hardcore;
        if (backup) kv.put(AUTOSLOT, current.toJson());
        Game loaded = Game.fromJson(s);
        loaded.undoArmed = backup && !loaded.hardcore;
        return loaded;
    }

    /** Restores the autoslot backup exactly once: any played season match
     *  spends the undo (Game.undoArmed, cleared in onUserMatchFinished),
     *  a hardcore career never gets one, and a successful undo consumes
     *  the backup. Returns the restored Game or null. */
    public static Game undoLoad(Kv kv, Game current) {
        if (kv == null || current == null) return null;
        if (current.hardcore || !current.undoArmed) return null;
        String s = kv.get(AUTOSLOT);
        if (s == null || s.isEmpty()) return null;
        kv.remove(AUTOSLOT);
        Game restored = Game.fromJson(s);
        restored.undoArmed = false;
        return restored;
    }

    public static boolean hasAutoslot(Kv kv) {
        String s = kv == null ? null : kv.get(AUTOSLOT);
        return s != null && !s.isEmpty();
    }

    /** The slot card summary: team, season, day, CF, titles — parsed from
     *  the stored JSON without building a whole Game. Null when empty or
     *  unreadable. */
    public static JSONObject summary(String json) {
        if (json == null || json.isEmpty()) return null;
        try {
            JSONObject o = new JSONObject(json);
            JSONObject career = o.optJSONObject("career");
            JSONObject s = new JSONObject();
            s.put("team", o.optString("userTeam", Data.USER_TEAM));
            s.put("season", o.optInt("season", 1));
            s.put("day", o.optInt("day", 1));
            s.put("cf", o.optInt("cf", 0));
            s.put("titles", career == null ? 0 : career.optInt("titles", 0));
            s.put("cups", career == null ? 0 : career.optInt("cups", 0));
            s.put("hardcore", o.optBoolean("hardcore", false));
            s.put("sacked", o.optBoolean("sacked", false));
            return s;
        } catch (Exception e) {
            return null;
        }
    }

    public static String summaryLine(JSONObject s) {
        if (s == null) return "Empty slot";
        return s.optString("team") + " · Season " + s.optInt("season") + " · Day " + s.optInt("day")
                + " · " + String.format(java.util.Locale.US, "%,d", s.optInt("cf")) + " CF"
                + " · Titles " + s.optInt("titles")
                + (s.optBoolean("hardcore") ? " · ☠ Hardcore" : "")
                + (s.optBoolean("sacked") ? " · (sacked)" : "");
    }

    // ---- the persistent hardcore record (idea 90) ----

    /** Folds one ended hardcore career into the record JSON: attempts
     *  +1, the best season reached, and whether any title was won. */
    public static String hardcoreRecordUpdate(String json, int seasonReached, boolean wonTitle) {
        int attempts = 0, bestSeason = 0;
        boolean bestTitle = false;
        try {
            if (json != null && !json.isEmpty()) {
                JSONObject o = new JSONObject(json);
                attempts = o.optInt("attempts", 0);
                bestSeason = o.optInt("bestSeason", 0);
                bestTitle = o.optBoolean("bestTitle", false);
            }
        } catch (Exception ignored) {}
        attempts++;
        bestSeason = Math.max(bestSeason, seasonReached);
        bestTitle = bestTitle || wonTitle;
        try {
            JSONObject o = new JSONObject();
            o.put("attempts", attempts).put("bestSeason", bestSeason).put("bestTitle", bestTitle);
            return o.toString();
        } catch (Exception e) {
            return json;
        }
    }

    /** "Hardcore attempts: N · Best: Season X finish" (🏆 when the best
     *  run also lifted a title). Empty string when no attempt is on file. */
    public static String hardcoreRecordLine(String json) {
        try {
            if (json == null || json.isEmpty()) return "";
            JSONObject o = new JSONObject(json);
            int attempts = o.optInt("attempts", 0);
            if (attempts <= 0) return "";
            return "Hardcore attempts: " + attempts + " · Best: Season " + o.optInt("bestSeason", 0)
                    + " finish" + (o.optBoolean("bestTitle") ? " 🏆 (title won)" : "");
        } catch (Exception e) {
            return "";
        }
    }
}
