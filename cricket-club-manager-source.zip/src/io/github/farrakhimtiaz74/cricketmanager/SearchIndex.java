package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Batch J (idea 97): global search over everything the manager might
 *  want to find — his own squad, every AI squad, the World stars, the
 *  eight clubs and every fixture on the calendar (league, cup, playoff).
 *  Plain substring matching over the in-memory save + Data tables; no
 *  new storage. Pure Java so the matching is desktop-testable; the
 *  SearchScreen renders Hits and routes the taps (squad player → Team
 *  detail, team → info dialog, fixture → the Season Calendar). */
public class SearchIndex {

    public static final String PLAYER = "player";     // user's squad — opens the detail view
    public static final String AI_PLAYER = "aiplayer"; // an AI club's man — info dialog
    public static final String WORLD = "world";        // a World rankings star — info dialog
    public static final String TEAM = "team";
    public static final String FIXTURE = "fixture";

    public static class Hit {
        public final String kind, title, info, ref;
        public Hit(String kind, String title, String info, String ref) {
            this.kind = kind; this.title = title; this.info = info; this.ref = ref;
        }
    }

    public static List<Hit> search(Game g, String query) {
        List<Hit> out = new ArrayList<>();
        if (g == null || query == null) return out;
        String q = query.trim().toLowerCase(Locale.US);
        if (q.length() < 2) return out;

        // ---- the user's own squad ----
        for (int i = 0; i < g.players.length(); i++) {
            JSONObject p = g.players.optJSONObject(i);
            if (p == null) continue;
            String name = p.optString("name");
            if (name.toLowerCase(Locale.US).contains(q)) {
                out.add(new Hit(PLAYER, name,
                        p.optString("role") + " · Bat " + p.optInt("bat") + " · Bowl " + p.optInt("bowl")
                                + " · " + g.userTeam + " (your squad)", name));
            }
        }

        // ---- AI squads (full 18s, Batch F data) ----
        for (String team : g.allTeams()) {
            if (team.equals(g.userTeam)) continue;
            Object[][] squad = Data.squadFor(team);
            for (Object[] r : squad) {
                String name = String.valueOf(r[0]);
                if (name.toLowerCase(Locale.US).contains(q)) {
                    out.add(new Hit(AI_PLAYER, name,
                            r[1] + " · Bat " + r[2] + " · Bowl " + r[3] + " · " + team, name));
                }
            }
        }

        // ---- World stars (rankings tables + the watchlist star list) ----
        Set<String> worldSeen = new LinkedHashSet<>();
        for (int f = 0; f < Data.FORMATS.length; f++) {
            for (int c = 0; c < Data.CATEGORIES.length; c++) {
                for (String[] w : Data.worldPlayers(f, c)) {
                    if (w[0].toLowerCase(Locale.US).contains(q) && worldSeen.add(w[0])) {
                        out.add(new Hit(WORLD, w[0],
                                "World " + Data.FORMATS[f] + " " + Data.CATEGORIES[c] + " · " + w[1]
                                        + " · " + w[2] + " pts", w[0]));
                    }
                }
            }
        }
        for (String[] s : Data.OPP_STARS) {
            if (s[0].toLowerCase(Locale.US).contains(q) && worldSeen.add(s[0])) {
                out.add(new Hit(WORLD, s[0], "League star · " + s[1], s[0]));
            }
        }

        // ---- teams ----
        for (String team : g.allTeams()) {
            if (team.toLowerCase(Locale.US).contains(q)) {
                JSONObject h = g.h2h.optJSONObject(team);
                String info = "Strength " + Data.teamStrength(team) + " · " + Data.groundName(team)
                        + " · Rivals: " + Data.rivalOf(team)
                        + (team.equals(g.userTeam) ? " · YOUR CLUB"
                           : h == null ? " · No meetings yet"
                           : " · vs you: P" + h.optInt("p") + " W" + h.optInt("w") + " L" + h.optInt("l"));
                out.add(new Hit(TEAM, team, info, team));
            }
        }

        // ---- fixtures: league, cup, playoffs ----
        addFixtures(out, g, g.fixtures, q, "League");
        addFixtures(out, g, g.cupFixtures, q, "One-Day Cup");
        addFixtures(out, g, g.playoffFixtures, q, "Playoff");
        return out;
    }

    private static void addFixtures(List<Hit> out, Game g, org.json.JSONArray fixtures,
                                    String q, String comp) {
        if (fixtures == null) return;
        for (int i = 0; i < fixtures.length(); i++) {
            JSONObject f = fixtures.optJSONObject(i);
            if (f == null) continue;
            String home = f.optString("home"), away = f.optString("away");
            String summary = f.optString("summary");
            String dayTag = "day " + f.optInt("day");
            boolean hit = home.toLowerCase(Locale.US).contains(q)
                    || away.toLowerCase(Locale.US).contains(q)
                    || summary.toLowerCase(Locale.US).contains(q)
                    || q.equals(dayTag);
            if (!hit) continue;
            String stage = f.optString("stage");
            String title = (stage.isEmpty() ? "" : stage + " · ") + home + " vs " + away;
            String info = comp + " · Day " + f.optInt("day")
                    + (f.optBoolean("played") ? " · " + summary : " · Not played yet");
            out.add(new Hit(FIXTURE, title, info, String.valueOf(f.optInt("day"))));
        }
    }

    /** Hits of one kind, in search order — the screen renders by group. */
    public static List<Hit> ofKind(List<Hit> hits, String kind) {
        List<Hit> out = new ArrayList<>();
        for (Hit h : hits) if (h.kind.equals(kind)) out.add(h);
        return out;
    }
}
