package io.github.farrakhimtiaz74.cricketmanager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Save System v2 (v21, item 11): the live career is stored
 *  GZIP-compressed + Base64-wrapped under a version prefix, instead
 *  of plain JSON. Pure Java (hand-rolled Base64: java.util.Base64 is
 *  API 26+, android.util.Base64 cannot run on the desktop harness),
 *  so the codec is fully desktop-tested.
 *
 *  Migration contract: decode() accepts BOTH forms — a string with
 *  the "CCMGZ1:" prefix is inflated; anything else is returned
 *  unchanged (the v1–v20 plain-JSON saves, slot JSON, sync codes).
 *  encode() always writes the compressed form, so the first v21
 *  save migrates the stored career forward with no user action. */
public class SaveCodec {

    public static final String PREFIX = "CCMGZ1:";

    public static boolean isCompressed(String s) {
        return s != null && s.startsWith(PREFIX);
    }

    /** json -> "CCMGZ1:" + base64(gzip(utf8(json))). Null-safe;
     *  on any failure falls back to the plain string (a save must
     *  never be lost to a codec error). */
    public static String encode(String json) {
        if (json == null) return null;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            GZIPOutputStream gz = new GZIPOutputStream(bos);
            gz.write(json.getBytes(StandardCharsets.UTF_8));
            gz.close();
            return PREFIX + base64Encode(bos.toByteArray());
        } catch (Exception e) {
            return json;
        }
    }

    /** Inverse of encode(); plain (pre-v21) strings pass through
     *  untouched. A corrupt compressed payload returns null so the
     *  caller can fall back to backups rather than half a career. */
    public static String decode(String stored) {
        if (stored == null) return null;
        if (!isCompressed(stored)) return stored;
        try {
            byte[] raw = base64Decode(stored.substring(PREFIX.length()));
            GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(raw));
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = gz.read(buf)) > 0) bos.write(buf, 0, n);
            gz.close();
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    // ---- Base64 (standard alphabet, padded) ----

    private static final char[] B64 =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
    private static final int[] B64_REV = new int[128];

    static {
        for (int i = 0; i < B64_REV.length; i++) B64_REV[i] = -1;
        for (int i = 0; i < B64.length; i++) B64_REV[B64[i]] = i;
    }

    public static String base64Encode(byte[] data) {
        StringBuilder sb = new StringBuilder((data.length + 2) / 3 * 4);
        for (int i = 0; i < data.length; i += 3) {
            int b0 = data[i] & 0xFF;
            int b1 = i + 1 < data.length ? data[i + 1] & 0xFF : 0;
            int b2 = i + 2 < data.length ? data[i + 2] & 0xFF : 0;
            sb.append(B64[b0 >> 2]);
            sb.append(B64[((b0 & 3) << 4) | (b1 >> 4)]);
            sb.append(i + 1 < data.length ? B64[((b1 & 15) << 2) | (b2 >> 6)] : '=');
            sb.append(i + 2 < data.length ? B64[b2 & 63] : '=');
        }
        return sb.toString();
    }

    public static byte[] base64Decode(String s) {
        int len = s.length();
        ByteArrayOutputStream out = new ByteArrayOutputStream(len * 3 / 4 + 3);
        int acc = 0, bits = 0;
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (c == '=') break;
            if (c >= 128 || B64_REV[c] < 0) continue; // skip whitespace etc.
            acc = (acc << 6) | B64_REV[c];
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                out.write((acc >> bits) & 0xFF);
            }
        }
        return out.toByteArray();
    }
}
