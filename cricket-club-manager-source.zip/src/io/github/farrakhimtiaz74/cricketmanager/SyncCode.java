package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Batch J (ideas 91/100): the portable career sync code — the whole
 *  save JSON, GZIP-compressed and Base64-armoured behind a "CCM1:"
 *  prefix, so a career can move between installs (or just live in a
 *  notes app) as one copyable block of text. No backend, no account:
 *  the code IS the backup, and idea 91's import is this same mechanism.
 *
 *  The Base64 codec is hand-rolled (standard alphabet, with padding,
 *  no line wraps) so this class stays pure Java — it runs identically
 *  on minSdk 21 (where java.util.Base64 does not exist) and on the
 *  desktop test JVM. Decoding ignores stray whitespace, so a code that
 *  was pasted through a chat app with line breaks still works. */
public class SyncCode {

    public static final String PREFIX = "CCM1:";
    private static final int MAX_JSON_BYTES = 16 * 1024 * 1024; // decompression guard
    private static final char[] B64 =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();

    // ---------------- encode ----------------

    public static String encode(String careerJson) {
        try {
            ByteArrayOutputStream raw = new ByteArrayOutputStream();
            GZIPOutputStream gz = new GZIPOutputStream(raw);
            gz.write(careerJson.getBytes("UTF-8"));
            gz.close();
            return PREFIX + b64Encode(raw.toByteArray());
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------- decode ----------------

    /** Returns the career JSON, or throws IllegalArgumentException with
     *  a user-readable message. Nothing is mutated anywhere on failure. */
    public static String decode(String code) {
        if (code == null) throw new IllegalArgumentException("No code pasted.");
        String c = code.trim();
        if (!c.startsWith(PREFIX)) {
            throw new IllegalArgumentException("That doesn't look like a sync code — it should start with " + PREFIX);
        }
        byte[] packed;
        try {
            packed = b64Decode(c.substring(PREFIX.length()));
        } catch (Exception e) {
            throw new IllegalArgumentException("The code is damaged — some characters don't decode. Copy the whole code and try again.");
        }
        try {
            GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(packed));
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = gz.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > MAX_JSON_BYTES) {
                    throw new IllegalArgumentException("That code unpacks to something far too big to be a career.");
                }
            }
            gz.close();
            return new String(out.toByteArray(), "UTF-8");
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException("The code is damaged — it doesn't unpack into a career save.");
        }
    }

    // ---------------- validation ----------------

    /** Shape check for an import: returns null when the JSON is a career
     *  this build can safely load, else a plain-English reason. Checks
     *  the fields the loader and every screen lean on (squad, season,
     *  career counters) plus the userTeam sanity from the brief: a
     *  non-custom club must be one of the eight league teams. */
    public static String validateCareerJson(String json) {
        if (json == null || json.trim().isEmpty()) return "The code unpacked to nothing.";
        JSONObject o;
        try {
            o = new JSONObject(json);
        } catch (Exception e) {
            return "The code doesn't contain a valid career save.";
        }
        JSONArray players = o.optJSONArray("players");
        if (players == null || players.length() == 0) return "That save has no squad in it — not a career.";
        if (o.optInt("season", 0) < 1) return "That save has no season number — not a career.";
        if (o.optJSONObject("career") == null) return "That save is missing its career record — not a career.";
        boolean custom = o.optBoolean("customTeam", false);
        String team = o.optString("userTeam", "");
        if (team.isEmpty()) return "That save doesn't name its club.";
        if (!custom && !isLeagueTeam(team)) {
            return "\"" + team + "\" isn't one of the eight league clubs — the save looks edited or corrupt.";
        }
        return null;
    }

    public static boolean isLeagueTeam(String team) {
        for (String t : Data.GROUP_A) if (t.equals(team)) return true;
        for (String t : Data.GROUP_B) if (t.equals(team)) return true;
        return false;
    }

    /** Full import pipeline used by the UI: decode + validate. Returns
     *  the career JSON, or throws IllegalArgumentException (message is
     *  shown to the user verbatim). */
    public static String importJson(String code) {
        String json = decode(code);
        String err = validateCareerJson(json);
        if (err != null) throw new IllegalArgumentException(err);
        return json;
    }

    // ---------------- hand-rolled Base64 (standard, padded) ----------------

    static String b64Encode(byte[] data) {
        StringBuilder sb = new StringBuilder((data.length + 2) / 3 * 4);
        for (int i = 0; i < data.length; i += 3) {
            int b0 = data[i] & 0xff;
            int b1 = i + 1 < data.length ? data[i + 1] & 0xff : 0;
            int b2 = i + 2 < data.length ? data[i + 2] & 0xff : 0;
            sb.append(B64[b0 >> 2]);
            sb.append(B64[((b0 & 0x3) << 4) | (b1 >> 4)]);
            sb.append(i + 1 < data.length ? B64[((b1 & 0xf) << 2) | (b2 >> 6)] : '=');
            sb.append(i + 2 < data.length ? B64[b2 & 0x3f] : '=');
        }
        return sb.toString();
    }

    static byte[] b64Decode(String s) {
        // strip whitespace a chat app may have folded into the paste
        StringBuilder clean = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (!Character.isWhitespace(ch)) clean.append(ch);
        }
        s = clean.toString();
        if (s.length() % 4 != 0) throw new IllegalArgumentException("bad length");
        ByteArrayOutputStream out = new ByteArrayOutputStream(s.length() * 3 / 4 + 3);
        for (int i = 0; i < s.length(); i += 4) {
            int[] v = new int[4];
            int pad = 0;
            for (int j = 0; j < 4; j++) {
                char ch = s.charAt(i + j);
                if (ch == '=') { v[j] = 0; pad++; }
                else {
                    int idx = indexOf(ch);
                    if (idx < 0) throw new IllegalArgumentException("bad char");
                    v[j] = idx;
                }
            }
            int triple = (v[0] << 18) | (v[1] << 12) | (v[2] << 6) | v[3];
            out.write((triple >> 16) & 0xff);
            if (pad < 2) out.write((triple >> 8) & 0xff);
            if (pad < 1) out.write(triple & 0xff);
        }
        return out.toByteArray();
    }

    private static int indexOf(char ch) {
        if (ch >= 'A' && ch <= 'Z') return ch - 'A';
        if (ch >= 'a' && ch <= 'z') return ch - 'a' + 26;
        if (ch >= '0' && ch <= '9') return ch - '0' + 52;
        if (ch == '+') return 62;
        if (ch == '/') return 63;
        return -1;
    }
}
