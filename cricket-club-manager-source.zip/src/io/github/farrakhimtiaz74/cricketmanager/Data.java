package io.github.farrakhimtiaz74.cricketmanager;

/** Static game data: Lahore squad, teams, opponent XIs, facilities, world rankings. */
public class Data {

    public static final String USER_TEAM = "Lahore Qalandars";

    // name, role, batting, bowling, overseas (v2: team-sheet overseas limit = max 4 in XI)
    public static final Object[][] SQUAD = {
        {"Fakhar Zaman", "Bat", 88, 20, false},
        {"Saim Ayub", "Bat", 86, 35, false},
        {"Abdullah Shafique", "Bat", 82, 10, false},
        {"Daryl Mitchell", "AR", 80, 62, true},
        {"Sam Billings", "WK", 78, 5, true},
        {"Sikandar Raza", "AR", 76, 74, true},
        {"David Wiese", "AR", 72, 76, true},
        {"Shaheen Shah Afridi", "Bowl", 45, 93, false},
        {"Haris Rauf", "Bowl", 30, 90, false},
        {"Rashid Khan", "Bowl", 55, 94, true},
        {"Zaman Khan", "Bowl", 25, 82, false},
        {"Kusal Perera", "WK", 79, 5, true},
        {"Jahandad Khan", "AR", 60, 78, false},
        {"Sahibzada Farhan", "Bat", 80, 8, false},
        {"Muhammad Akhlaq", "Bat", 70, 15, false},
        {"Tom Curran", "AR", 68, 80, true},
        {"Asif Afridi", "Bowl", 35, 80, false},
        {"Ubaid Shah", "Bowl", 20, 74, false},
    };

    /** Overseas flag by player name — used for v1-save migration and academy prospects (local). */
    public static boolean overseasFor(String name) {
        switch (name) {
            case "Daryl Mitchell": case "Sam Billings": case "Sikandar Raza":
            case "David Wiese": case "Rashid Khan": case "Kusal Perera":
            case "Tom Curran":
                return true;
            default:
                return false;
        }
    }

    /** Default starting XI (v2): legal under the new rules — exactly 4 overseas
     *  (Mitchell, Billings, Raza, Rashid), Billings keeps wicket, 7 bowling options. */
    public static final String[] DEFAULT_XI = {
        "Fakhar Zaman", "Saim Ayub", "Abdullah Shafique", "Daryl Mitchell",
        "Sam Billings", "Sikandar Raza", "Jahandad Khan", "Shaheen Shah Afridi",
        "Haris Rauf", "Rashid Khan", "Zaman Khan"};

    public static boolean inDefaultXI(String name) {
        for (String n : DEFAULT_XI) if (n.equals(name)) return true;
        return false;
    }

    /** Opponent league stars the manager can put on the watchlist (name, team). */
    public static final String[][] OPP_STARS = {
        {"Babar Azam", "Peshawar Zalmi"},
        {"Mohammad Rizwan", "Multan Sultans"},
        {"David Warner", "Karachi Kings"},
        {"Shadab Khan", "Islamabad United"},
        {"Jason Roy", "Quetta Gladiators"},
        {"Naseem Shah", "Islamabad United"},
        {"Mohammad Amir", "Quetta Gladiators"},
        {"Hasan Ali", "Karachi Kings"},
    };

    public static final String[] GROUP_A = {"Lahore Qalandars", "Karachi Kings", "Multan Sultans", "Islamabad United"};
    public static final String[] GROUP_B = {"Peshawar Zalmi", "Quetta Gladiators", "Sialkot Stallions", "Hyderabad Hawks"};

    public static int teamStrength(String team) {
        switch (team) {
            case "Lahore Qalandars": return 86;
            case "Islamabad United": return 85;
            case "Multan Sultans": return 84;
            case "Peshawar Zalmi": return 84;
            case "Karachi Kings": return 83;
            case "Quetta Gladiators": return 82;
            case "Sialkot Stallions": return 78;
            default: return 76; // Hyderabad Hawks
        }
    }

    public static String shortName(String team) {
        switch (team) {
            case "Lahore Qalandars": return "LAH";
            case "Karachi Kings": return "KAR";
            case "Multan Sultans": return "MUL";
            case "Islamabad United": return "ISL";
            case "Peshawar Zalmi": return "PES";
            case "Quetta Gladiators": return "QUE";
            case "Sialkot Stallions": return "SIA";
            default: return "HYD";
        }
    }

    // Opponent playing XIs: name, batting, bowling  (user team XI comes from the squad)
    public static Object[][] xiFor(String team) {
        switch (team) {
            case "Karachi Kings": return new Object[][]{
                {"James Vince", 85, 5}, {"Tim Seifert", 80, 5}, {"David Warner", 87, 5},
                {"Shan Masood", 78, 5}, {"Khushdil Shah", 74, 60}, {"Mohammad Nabi", 70, 78},
                {"Irfan Khan", 68, 40}, {"Hasan Ali", 30, 84}, {"Abbas Afridi", 28, 82},
                {"Tabraiz Shamsi", 15, 85}, {"Zahid Mahmood", 15, 78}};
            case "Islamabad United": return new Object[][]{
                {"Alex Hales", 84, 5}, {"Colin Munro", 83, 5}, {"Agha Salman", 78, 55},
                {"Shadab Khan", 74, 84}, {"Azam Khan", 76, 5}, {"Imad Wasim", 70, 80},
                {"Haider Ali", 72, 5}, {"Naseem Shah", 25, 88}, {"Rumman Raees", 20, 78},
                {"Hunain Shah", 18, 76}, {"Riley Meredith", 15, 82}};
            case "Multan Sultans": return new Object[][]{
                {"Mohammad Rizwan", 86, 5}, {"Yasir Khan", 76, 5}, {"Kamran Ghulam", 77, 30},
                {"Iftikhar Ahmed", 75, 55}, {"Michael Bracewell", 74, 76}, {"David Willey", 62, 80},
                {"Chris Jordan", 45, 84}, {"Usama Mir", 30, 82}, {"Mohammad Hasnain", 20, 83},
                {"Akif Javed", 15, 78}, {"Shahnawaz Dahani", 15, 79}};
            case "Peshawar Zalmi": return new Object[][]{
                {"Babar Azam", 90, 10}, {"Mohammad Haris", 78, 5}, {"Tom Kohler-Cadmore", 80, 5},
                {"Hussain Talat", 72, 50}, {"Najibullah Zadran", 74, 5}, {"Abdul Samad", 70, 30},
                {"Alzarri Joseph", 30, 86}, {"Luke Wood", 35, 82}, {"Sufiyan Muqeem", 15, 80},
                {"Mehran Mumtaz", 20, 76}, {"Ali Raza", 15, 78}};
            case "Quetta Gladiators": return new Object[][]{
                {"Saud Shakeel", 78, 10}, {"Jason Roy", 84, 5}, {"Rilee Rossouw", 82, 5},
                {"Kusal Mendis", 79, 5}, {"Mark Chapman", 76, 30}, {"Faheem Ashraf", 62, 76},
                {"Mohammad Amir", 25, 85}, {"Abrar Ahmed", 15, 84}, {"Akeal Hosein", 35, 82},
                {"Mohammad Wasim", 25, 80}, {"Usman Tariq", 10, 74}};
            case "Sialkot Stallions": return new Object[][]{
                {"Ahmed Shehzad", 76, 5}, {"Mohammad Huraira", 74, 5}, {"Azan Awais", 72, 5},
                {"Tayyab Tahir", 75, 20}, {"Shoaib Malik", 74, 60}, {"Bismillah Khan", 68, 5},
                {"Saad Khan", 70, 40}, {"Jalat Khan", 55, 70}, {"Ali Shafique", 20, 76},
                {"Mohammad Ali", 18, 78}, {"Tabish Khan", 15, 72}};
            default: return new Object[][]{ // Hyderabad Hawks
                {"Sharjeel Khan", 78, 5}, {"Zeeshan Ashraf", 72, 5}, {"Omair Yousuf", 73, 5},
                {"Danish Aziz", 68, 55}, {"Khalid Usman", 60, 72}, {"Aamer Yamin", 58, 74},
                {"Asif Mehmood", 55, 68}, {"Mohammad Ilyas", 18, 74}, {"Arshad Iqbal", 15, 76},
                {"Faisal Akram", 20, 75}, {"Sameen Gul", 12, 73}};
        }
    }

    // ---- HQ facilities: name, base cost, effect text ----
    public static final String[] FACILITY_NAMES = {
        "Stadium", "Medical Centre", "Training Complex", "Youth Academy", "Commercial Centre"};
    public static final int[] FACILITY_BASE_COST = {400, 300, 350, 300, 350};
    public static final String[] FACILITY_EFFECT = {
        "Bigger crowds: higher attendance at home games, and gate receipts grow with every level.",
        "Faster healing: Recovery restores more stamina and costs less CF per level.",
        "Better coaching: small rating boost to the whole squad per upgrade.",
        "Scouts find a young prospect who joins at each season rollover (level 2+) — and he arrives better as this climbs.",
        "Commercial income every few days, growing per level (the old flat sponsor rate until sponsor deals take over)."};
    public static final int FACILITY_MAX = 10; // Batch G (idea 62): was 5 — upgrade costs stay base x level all the way up

    // ---- World rankings: [format][category] -> rows of {name, country/tag, rating} ----
    public static final String[] FORMATS = {"T20I", "ODI", "Test"};
    public static final String[] CATEGORIES = {"Batting", "Bowling", "All-rounder"};

    public static String[][] worldPlayers(int format, int category) {
        return WORLD[format][category];
    }

    private static final String[][][][] WORLD = {
        { // T20I
            {{"Travis Head", "AUS", "856"}, {"Abhishek Sharma", "IND", "829"}, {"Phil Salt", "ENG", "815"}, {"Babar Azam", "PAK", "790"}, {"Jos Buttler", "ENG", "780"}},
            {{"Akeal Hosein", "WI", "707"}, {"Adil Rashid", "ENG", "701"}, {"Wanindu Hasaranga", "SL", "690"}, {"Rashid Khan", "AFG", "685"}, {"Shaheen Shah Afridi", "PAK", "660"}},
            {{"Hardik Pandya", "IND", "290"}, {"Marcus Stoinis", "AUS", "275"}, {"Sikandar Raza", "ZIM", "260"}, {"Wanindu Hasaranga", "SL", "250"}, {"Liam Livingstone", "ENG", "240"}}
        },
        { // ODI
            {{"Shubman Gill", "IND", "857"}, {"Babar Azam", "PAK", "825"}, {"Rohit Sharma", "IND", "815"}, {"Harry Tector", "IRE", "750"}, {"Virat Kohli", "IND", "745"}},
            {{"Rashid Khan", "AFG", "675"}, {"Kuldeep Yadav", "IND", "660"}, {"Keshav Maharaj", "SA", "650"}, {"Shaheen Shah Afridi", "PAK", "640"}, {"Josh Hazlewood", "AUS", "630"}},
            {{"Azmatullah Omarzai", "AFG", "310"}, {"Sikandar Raza", "ZIM", "285"}, {"Mehidy Hasan Miraz", "BAN", "280"}, {"Glenn Maxwell", "AUS", "270"}, {"Ravindra Jadeja", "IND", "265"}}
        },
        { // Test
            {{"Joe Root", "ENG", "895"}, {"Harry Brook", "ENG", "870"}, {"Kane Williamson", "NZ", "850"}, {"Yashasvi Jaiswal", "IND", "830"}, {"Steve Smith", "AUS", "815"}},
            {{"Jasprit Bumrah", "IND", "885"}, {"Kagiso Rabada", "SA", "850"}, {"Pat Cummins", "AUS", "830"}, {"Josh Hazlewood", "AUS", "820"}, {"Noman Ali", "PAK", "790"}},
            {{"Ravindra Jadeja", "IND", "420"}, {"Ben Stokes", "ENG", "310"}, {"Pat Cummins", "AUS", "280"}, {"Marco Jansen", "SA", "270"}, {"Shakib Al Hasan", "BAN", "260"}}
        }
    };

    public static String[][] worldNations(int format) {
        return NATIONS[format];
    }

    private static final String[][][] NATIONS = {
        {{"India", "269"}, {"Australia", "257"}, {"England", "254"}, {"West Indies", "252"}, {"Pakistan", "245"}},
        {{"India", "122"}, {"Australia", "114"}, {"Pakistan", "108"}, {"New Zealand", "105"}, {"South Africa", "102"}},
        {{"Australia", "124"}, {"India", "118"}, {"England", "110"}, {"South Africa", "105"}, {"New Zealand", "98"}}
    };

    // ---- Batch A: pitch types (idea 3) — index stored per fixture / match ----
    public static final String[] PITCH_TYPES = {"Flat", "Green", "Dry", "Turning"};
    public static final String[] PITCH_DESC = {
        "Flat — a road. Big scores, bowlers suffer.",
        "Green — seam and swing early. Tough first overs.",
        "Dry — slow and low. Hard to force the pace.",
        "Turning — spin will grip. Spinners are gold here."};

    /** Spinner lookup by name (Batch A: Green/Turning pitch modifiers).
     *  Covers the user squad and every opponent XI in xiFor(). */
    public static boolean isSpinner(String name) {
        switch (name) {
            case "Rashid Khan": case "Sikandar Raza": case "Asif Afridi":
            case "Tabraiz Shamsi": case "Usama Mir": case "Shadab Khan":
            case "Imad Wasim": case "Abrar Ahmed": case "Akeal Hosein":
            case "Sufiyan Muqeem": case "Mehran Mumtaz": case "Faisal Akram":
            case "Waqar Salamkheil": case "Kashif Bhatti": case "Nauman Ali":
            case "Maaz Khan": case "Arif Yaqoob": case "Hassan Khan": case "Ali Usman":
            case "George Linde":
            case "Usman Tariq": case "Mohammad Nabi": case "Michael Bracewell":
                return true;
            default:
                return false;
        }
    }

    // ---- Batch C (ideas 23, 30): ages, potentials and specialist tags ----
    // Deterministic by name (same pattern as overseasFor) so v4 saves migrate
    // to identical values on every load. Unknown names = academy prospects.

    /** Plausible age by player name; prospects default to 20. */
    public static int ageFor(String name) {
        switch (name) {
            case "Fakhar Zaman": return 35;
            case "Saim Ayub": return 23;
            case "Abdullah Shafique": return 25;
            case "Daryl Mitchell": return 34;
            case "Sam Billings": return 34;
            case "Sikandar Raza": return 39;
            case "David Wiese": return 40;
            case "Shaheen Shah Afridi": return 25;
            case "Haris Rauf": return 31;
            case "Rashid Khan": return 27;
            case "Zaman Khan": return 24;
            case "Kusal Perera": return 35;
            case "Jahandad Khan": return 22;
            case "Sahibzada Farhan": return 29;
            case "Muhammad Akhlaq": return 32;
            case "Tom Curran": return 30;
            case "Asif Afridi": return 38;
            case "Ubaid Shah": return 19;
            // Batch D: auction stars / generated pool / loan pool names
            case "Jos Buttler": return 33;
            case "Glenn Maxwell": return 37;
            case "Trent Boult": return 36;
            case "Sunil Narine": return 37;
            case "Aamer Jamal": return 29;
            case "Haseebullah Khan": return 22;
            case "Mohammad Zeeshan": return 21;
            case "Zafar Gohar": return 31;
            case "Bilal Asif": return 40;
            case "Sajid Khan": return 32;
            case "Khurram Shahzad": return 25;
            case "Ihsanullah": return 22;
            case "Mir Hamza": return 33;
            case "Usman Qadir": return 32;
            case "Mohammad Nawaz": return 31;
            case "Shawaiz Irfan": return 22;
            case "Ali Asfand": return 21;
            case "Mubasir Khan": return 23;
            // Batch E: genuinely young opponents (Emerging Player award pool)
            case "Ali Raza": return 18;
            case "Hunain Shah": return 21;
            case "Azan Awais": return 21;
            case "Mehran Mumtaz": return 22;
            default: return 20;
        }
    }

    /** Batch E (idea 47): is the age above a REAL known age, or the default?
     *  The Emerging Player award only considers players whose age is actually
     *  known — the squad, the Batch D pools, and the named young opponents —
     *  so an unlisted 30-year-old never sneaks in via the default of 20. */
    public static boolean hasAge(String name) {
        switch (name) {
            // the Lahore squad
            case "Fakhar Zaman": case "Saim Ayub": case "Abdullah Shafique":
            case "Daryl Mitchell": case "Sam Billings": case "Sikandar Raza":
            case "David Wiese": case "Shaheen Shah Afridi": case "Haris Rauf":
            case "Rashid Khan": case "Zaman Khan": case "Kusal Perera":
            case "Jahandad Khan": case "Sahibzada Farhan": case "Muhammad Akhlaq":
            case "Tom Curran": case "Asif Afridi": case "Ubaid Shah":
            // Batch D auction / generated / loan pools
            case "Jos Buttler": case "Glenn Maxwell": case "Trent Boult":
            case "Sunil Narine": case "Aamer Jamal": case "Haseebullah Khan":
            case "Mohammad Zeeshan": case "Zafar Gohar": case "Bilal Asif":
            case "Sajid Khan": case "Khurram Shahzad": case "Ihsanullah":
            case "Mir Hamza": case "Usman Qadir": case "Mohammad Nawaz":
            case "Shawaiz Irfan": case "Ali Asfand": case "Mubasir Khan":
            // Batch E young opponents
            case "Ali Raza": case "Hunain Shah": case "Azan Awais":
            case "Mehran Mumtaz":
                return true;
            default:
                return false;
        }
    }

    // ---- Batch D (ideas 31–40): contracts, auction, free agents, loans ----

    /** Starting contract length in seasons (1–3), deterministic by name so a
     *  v5 save migrates to the same deal on every load. */
    public static int contractFor(String name) {
        return (name.hashCode() & 0x7fffffff) % 3 + 1;
    }

    /** Auction star lots (idea 31): name, role, bat, bowl, overseas. */
    public static final Object[][] AUCTION_STARS = {
        {"Jos Buttler", "WK", 88, 8, true},
        {"Glenn Maxwell", "AR", 85, 72, true},
        {"Trent Boult", "Bowl", 28, 90, true},
        {"Sunil Narine", "AR", 72, 86, true},
    };

    /** Generated/free names (ideas 31/37): name, role, bat, bowl, overseas.
     *  Deliberately avoids every opponent-XI name so pools never duplicate a
     *  named opponent in the same match. */
    public static final Object[][] GEN_POOL = {
        {"Aamer Jamal", "AR", 62, 78, false},
        {"Haseebullah Khan", "WK", 74, 5, false},
        {"Mohammad Zeeshan", "Bowl", 22, 76, false},
        {"Zafar Gohar", "Bowl", 40, 74, false},
        {"Bilal Asif", "AR", 55, 72, false},
        {"Sajid Khan", "Bowl", 30, 72, false},
        {"Khurram Shahzad", "Bowl", 25, 79, false},
        {"Ihsanullah", "Bowl", 20, 80, false},
        {"Mir Hamza", "Bowl", 22, 77, false},
        {"Usman Qadir", "Bowl", 25, 75, false},
        {"Mohammad Nawaz", "AR", 68, 78, false},
    };

    /** Young players other clubs will loan IN (idea 36): name, role, bat, bowl, overseas. */
    public static final Object[][] LOAN_POOL = {
        {"Shawaiz Irfan", "Bat", 73, 15, false},
        {"Ali Asfand", "AR", 55, 70, false},
        {"Mubasir Khan", "AR", 66, 68, false},
    };

    /** Potential = the overall rating a player can grow toward (idea 23).
     *  Youngsters sit well above their current rating; veterans at/below it. */
    public static int potFor(String name, int currentRating) {
        switch (name) {
            case "Fakhar Zaman": return 80;
            case "Saim Ayub": return 92;
            case "Abdullah Shafique": return 88;
            case "Daryl Mitchell": return 82;
            case "Sam Billings": return 80;
            case "Sikandar Raza": return 79;
            case "David Wiese": return 74;
            case "Shaheen Shah Afridi": return 95;
            case "Haris Rauf": return 91;
            case "Rashid Khan": return 96;
            case "Zaman Khan": return 86;
            case "Kusal Perera": return 80;
            case "Jahandad Khan": return 85;
            case "Sahibzada Farhan": return 84;
            case "Muhammad Akhlaq": return 74;
            case "Tom Curran": return 82;
            case "Asif Afridi": return 78;
            case "Ubaid Shah": return 88;
            default: return Math.min(96, currentRating + 12); // prospects: headroom
        }
    }

    /** Specialist tags (idea 30): 1–2 per squad player, derived plausibly from
     *  role/skill. MatchEngine reads them for real situational effects. */
    public static String[] tagsFor(String name, int bat, int bowl) {
        switch (name) {
            case "Fakhar Zaman": return new String[]{"Powerplay Specialist", "Safe Hands"};
            case "Saim Ayub": return new String[]{"Powerplay Specialist"};
            case "Abdullah Shafique": return new String[]{"Anchor"};
            case "Daryl Mitchell": return new String[]{"Anchor", "Safe Hands"};
            case "Sam Billings": return new String[]{"Finisher", "Safe Hands"};
            case "Sikandar Raza": return new String[]{"Spin Option", "Finisher"};
            case "David Wiese": return new String[]{"Death Bowler", "Finisher"};
            case "Shaheen Shah Afridi": return new String[]{"Pace Battery", "Death Bowler"};
            case "Haris Rauf": return new String[]{"Pace Battery", "Death Bowler"};
            case "Rashid Khan": return new String[]{"Spin Option", "Death Bowler"};
            case "Zaman Khan": return new String[]{"Death Bowler"};
            case "Kusal Perera": return new String[]{"Powerplay Specialist"};
            case "Jahandad Khan": return new String[]{"Pace Battery"};
            case "Sahibzada Farhan": return new String[]{"Powerplay Specialist"};
            case "Muhammad Akhlaq": return new String[]{"Anchor"};
            case "Tom Curran": return new String[]{"Death Bowler"};
            case "Asif Afridi": return new String[]{"Spin Option"};
            case "Ubaid Shah": return new String[]{"Pace Battery"};
            default:
                if (bowl >= 82) return new String[]{isSpinner(name) ? "Spin Option" : "Pace Battery"};
                if (bat >= 80) return new String[]{"Anchor"};
                if (bowl >= 70) return new String[]{"Death Bowler"};
                return new String[]{"Safe Hands"};
        }
    }

    /** One-line effect text per tag, shown in the player detail view. */
    public static String tagDesc(String tag) {
        switch (tag) {
            case "Finisher": return "Bats better in overs 16–20: more boundaries, fewer dismissals.";
            case "Anchor": return "Harder to dismiss in overs 7–15, scores a touch slower.";
            case "Powerplay Specialist": return "Bats better in overs 1–6: more boundaries.";
            case "Death Bowler": return "Bowls better in overs 16–20: more wickets, fewer boundaries.";
            case "Spin Option": return "Extra threat on Turning pitches.";
            case "Pace Battery": return "Extra threat on Green pitches.";
            case "Safe Hands": return "Lifts the side's run-out chance when fielding.";
            default: return "";
        }
    }

    /** Injury types for idea 24 (days out rolled 3–14, cut by Medical level). */
    public static final String[] INJURY_TYPES = {"Hamstring", "Side Strain", "Finger", "Back Spasm", "Ankle"};

    // Academy prospect name pool
    public static final String[] PROSPECTS = {
        "Maaz Sadaqat", "Ali Hassan Baloch", "Shamyl Hussain", "Arafat Minhas",
        "Qasim Akram", "Saad Baig", "Riazullah", "Ahmed Daniyal"};

    // =====================================================================
    // Batch F (ideas 51–60): full 18-man squads for every team, captains,
    // rivals, grounds and world-ranking nation lookup.
    // Squad rows: name, role, batting, bowling, overseas — the same shape as
    // SQUAD. Every squad's DEFAULT_XI_F entry is validator-legal (WK present,
    // <= 4 overseas, >= 5 men with bowl >= 60).
    // =====================================================================

    public static Object[][] squadFor(String team) {
        switch (team) {
            case "Karachi Kings": return KAR_SQUAD;
            case "Islamabad United": return ISL_SQUAD;
            case "Multan Sultans": return MUL_SQUAD;
            case "Peshawar Zalmi": return PES_SQUAD;
            case "Quetta Gladiators": return QUE_SQUAD;
            case "Sialkot Stallions": return SIA_SQUAD;
            case "Hyderabad Hawks": return HYD_SQUAD;
            default: return SQUAD; // Lahore Qalandars
        }
    }

    private static final Object[][] KAR_SQUAD = {
        {"David Warner", "Bat", 87, 5, true}, {"James Vince", "Bat", 85, 5, true},
        {"Tim Seifert", "WK", 80, 5, true}, {"Shan Masood", "Bat", 78, 5, false},
        {"Khushdil Shah", "AR", 74, 60, false}, {"Mohammad Nabi", "AR", 70, 78, true},
        {"Irfan Khan", "Bat", 68, 40, false}, {"Hasan Ali", "Bowl", 30, 84, false},
        {"Abbas Afridi", "Bowl", 28, 82, false}, {"Tabraiz Shamsi", "Bowl", 15, 85, true},
        {"Zahid Mahmood", "Bowl", 15, 78, false}, {"Sohail Khan", "Bowl", 22, 76, false},
        {"Umaid Asif", "AR", 40, 72, false}, {"Joe Clarke", "WK", 74, 5, true},
        {"Tahir Baig", "Bat", 70, 5, false}, {"Imran Randhawa", "AR", 55, 65, false},
        {"Hasan Mohsin", "AR", 58, 62, false}, {"Fawad Ali", "Bowl", 15, 70, false},
    };

    private static final Object[][] ISL_SQUAD = {
        {"Alex Hales", "Bat", 84, 5, true}, {"Colin Munro", "Bat", 83, 5, true},
        {"Agha Salman", "AR", 78, 55, false}, {"Shadab Khan", "AR", 74, 84, false},
        {"Azam Khan", "WK", 76, 5, false}, {"Imad Wasim", "AR", 70, 80, false},
        {"Haider Ali", "Bat", 72, 5, false}, {"Naseem Shah", "Bowl", 25, 88, false},
        {"Rumman Raees", "Bowl", 20, 78, false}, {"Hunain Shah", "Bowl", 18, 76, false},
        {"Riley Meredith", "Bowl", 15, 82, true}, {"Rassie van der Dussen", "Bat", 80, 5, true},
        {"Jordan Cox", "WK", 74, 5, true}, {"Mohammad Shahzad", "AR", 60, 66, false},
        {"Shahzaib Khan", "Bat", 71, 10, false}, {"Salman Irshad", "Bowl", 18, 77, false},
        {"Zeeshan Zameer", "Bowl", 15, 74, false}, {"Musa Khan", "Bowl", 16, 73, false},
    };

    private static final Object[][] MUL_SQUAD = {
        {"Mohammad Rizwan", "WK", 86, 5, false}, {"Yasir Khan", "Bat", 76, 5, false},
        {"Kamran Ghulam", "Bat", 77, 30, false}, {"Iftikhar Ahmed", "AR", 75, 55, false},
        {"Michael Bracewell", "AR", 74, 76, true}, {"David Willey", "AR", 62, 80, true},
        {"Chris Jordan", "Bowl", 45, 84, true}, {"Usama Mir", "Bowl", 30, 82, false},
        {"Mohammad Hasnain", "Bowl", 20, 83, false}, {"Akif Javed", "Bowl", 15, 78, false},
        {"Shahnawaz Dahani", "Bowl", 15, 79, false}, {"Reeza Hendricks", "Bat", 79, 5, true},
        {"Johnson Charles", "WK", 75, 5, true}, {"Tayyab Abbas", "Bowl", 15, 72, false},
        {"Mohammad Imran", "Bowl", 18, 75, false}, {"Aamer Azmat", "Bat", 70, 10, false},
        {"Sharoon Siraj", "AR", 58, 60, false}, {"Ali Usman", "Bowl", 20, 71, false},
    };

    private static final Object[][] PES_SQUAD = {
        {"Babar Azam", "Bat", 90, 10, false}, {"Mohammad Haris", "WK", 78, 5, false},
        {"Tom Kohler-Cadmore", "Bat", 80, 5, true}, {"Hussain Talat", "AR", 72, 50, false},
        {"Najibullah Zadran", "Bat", 74, 5, true}, {"Abdul Samad", "Bat", 70, 30, false},
        {"Alzarri Joseph", "Bowl", 30, 86, true}, {"Luke Wood", "Bowl", 35, 82, true},
        {"Sufiyan Muqeem", "Bowl", 15, 80, false}, {"Mehran Mumtaz", "Bowl", 20, 76, false},
        {"Ali Raza", "Bowl", 15, 78, false}, {"Waqar Salamkheil", "Bowl", 14, 78, true},
        {"George Linde", "AR", 55, 72, true}, {"Tom Alsop", "WK", 72, 5, true},
        {"Adil Amin", "Bat", 71, 20, false}, {"Maaz Khan", "Bowl", 15, 72, false},
        {"Mohammad Imran Jr", "Bowl", 16, 74, false}, {"Arif Yaqoob", "Bowl", 14, 75, false},
    };

    private static final Object[][] QUE_SQUAD = {
        {"Saud Shakeel", "Bat", 78, 10, false}, {"Jason Roy", "Bat", 84, 5, true},
        {"Rilee Rossouw", "Bat", 82, 5, true}, {"Kusal Mendis", "WK", 79, 5, true},
        {"Mark Chapman", "AR", 76, 30, true}, {"Faheem Ashraf", "AR", 62, 76, false},
        {"Mohammad Amir", "Bowl", 25, 85, false}, {"Abrar Ahmed", "Bowl", 15, 84, false},
        {"Akeal Hosein", "AR", 35, 82, true}, {"Mohammad Wasim", "Bowl", 25, 80, false},
        {"Usman Tariq", "Bowl", 10, 74, false}, {"Sarfaraz Ahmed", "WK", 72, 5, false},
        {"Will Smeed", "Bat", 76, 5, true}, {"Laurie Evans", "Bat", 74, 5, true},
        {"Anwar Ali", "AR", 45, 72, false}, {"Ghulam Mudassar", "Bowl", 15, 73, false},
        {"Kashif Bhatti", "Bowl", 18, 74, false}, {"Rameez Aziz", "Bat", 69, 5, false},
    };

    private static final Object[][] SIA_SQUAD = {
        {"Ahmed Shehzad", "Bat", 76, 5, false}, {"Mohammad Huraira", "Bat", 74, 5, false},
        {"Azan Awais", "Bat", 72, 5, false}, {"Tayyab Tahir", "Bat", 75, 20, false},
        {"Shoaib Malik", "AR", 74, 60, false}, {"Bismillah Khan", "WK", 68, 5, false},
        {"Saad Khan", "AR", 70, 40, false}, {"Jalat Khan", "AR", 55, 70, false},
        {"Ali Shafique", "Bowl", 20, 76, false}, {"Mohammad Ali", "Bowl", 18, 78, false},
        {"Tabish Khan", "Bowl", 15, 72, false}, {"Usman Khalid", "Bat", 68, 10, false},
        {"Hasan Nawaz", "Bat", 72, 15, false}, {"Mohammad Taha", "AR", 60, 62, false},
        {"Umar Siddiq", "WK", 66, 5, false}, {"Ahmed Safi Abdullah", "Bowl", 15, 71, false},
        {"Hamza Nazar", "Bowl", 14, 70, false}, {"Saif Badar", "Bat", 67, 25, false},
    };

    private static final Object[][] HYD_SQUAD = {
        {"Sharjeel Khan", "Bat", 78, 5, false}, {"Zeeshan Ashraf", "WK", 72, 5, false},
        {"Omair Yousuf", "Bat", 73, 5, false}, {"Danish Aziz", "AR", 68, 55, false},
        {"Khalid Usman", "AR", 60, 72, false}, {"Aamer Yamin", "AR", 58, 74, false},
        {"Asif Mehmood", "AR", 55, 68, false}, {"Mohammad Ilyas", "Bowl", 18, 74, false},
        {"Arshad Iqbal", "Bowl", 15, 76, false}, {"Faisal Akram", "Bowl", 20, 75, false},
        {"Sameen Gul", "Bowl", 12, 73, false}, {"Bilawal Bhatti", "AR", 50, 72, false},
        {"Hassan Khan", "AR", 55, 70, false}, {"Mohammad Sarwar", "Bat", 66, 20, false},
        {"Gulraiz Sadaf", "WK", 64, 5, false}, {"Nauman Ali", "Bowl", 16, 76, false},
        {"Aizaz Cheema", "Bowl", 12, 70, false}, {"Rohail Nazir", "WK", 68, 5, false},
    };

    /** The default (validator-legal) starting XI for a fresh career with this
     *  team — names drawn from squadFor(team). */
    public static String[] defaultXiNames(String team) {
        switch (team) {
            case "Karachi Kings": return new String[]{"David Warner", "James Vince", "Tim Seifert",
                "Shan Masood", "Khushdil Shah", "Mohammad Nabi", "Irfan Khan", "Hasan Ali",
                "Abbas Afridi", "Zahid Mahmood", "Sohail Khan"};
            case "Islamabad United": return new String[]{"Alex Hales", "Colin Munro", "Agha Salman",
                "Shadab Khan", "Azam Khan", "Imad Wasim", "Haider Ali", "Naseem Shah",
                "Rumman Raees", "Hunain Shah", "Riley Meredith"};
            case "Multan Sultans": return new String[]{"Mohammad Rizwan", "Yasir Khan", "Kamran Ghulam",
                "Iftikhar Ahmed", "Michael Bracewell", "David Willey", "Chris Jordan", "Usama Mir",
                "Mohammad Hasnain", "Akif Javed", "Shahnawaz Dahani"};
            case "Peshawar Zalmi": return new String[]{"Babar Azam", "Mohammad Haris", "Tom Kohler-Cadmore",
                "Hussain Talat", "Najibullah Zadran", "Abdul Samad", "Alzarri Joseph", "Luke Wood",
                "Sufiyan Muqeem", "Mehran Mumtaz", "Ali Raza"};
            case "Quetta Gladiators": return new String[]{"Saud Shakeel", "Jason Roy", "Rilee Rossouw",
                "Kusal Mendis", "Faheem Ashraf", "Sarfaraz Ahmed", "Mohammad Amir", "Abrar Ahmed",
                "Akeal Hosein", "Mohammad Wasim", "Usman Tariq"};
            case "Sialkot Stallions": return new String[]{"Ahmed Shehzad", "Mohammad Huraira", "Azan Awais",
                "Tayyab Tahir", "Shoaib Malik", "Bismillah Khan", "Saad Khan", "Jalat Khan",
                "Ali Shafique", "Mohammad Ali", "Tabish Khan"};
            case "Hyderabad Hawks": return new String[]{"Sharjeel Khan", "Zeeshan Ashraf", "Omair Yousuf",
                "Danish Aziz", "Khalid Usman", "Aamer Yamin", "Asif Mehmood", "Mohammad Ilyas",
                "Arshad Iqbal", "Faisal Akram", "Sameen Gul"};
            default: return DEFAULT_XI; // Lahore Qalandars
        }
    }

    public static boolean inTeamXi(String team, String name) {
        for (String n : defaultXiNames(team)) if (n.equals(name)) return true;
        return false;
    }

    /** The named captain of each club (used for fresh careers and for the
     *  world-ranking champion-captain boost). */
    public static String captainFor(String team) {
        switch (team) {
            case "Karachi Kings": return "Shan Masood";
            case "Islamabad United": return "Shadab Khan";
            case "Multan Sultans": return "Mohammad Rizwan";
            case "Peshawar Zalmi": return "Babar Azam";
            case "Quetta Gladiators": return "Saud Shakeel";
            case "Sialkot Stallions": return "Shoaib Malik";
            case "Hyderabad Hawks": return "Danish Aziz";
            default: return "Shaheen Shah Afridi"; // Lahore Qalandars
        }
    }

    /** Idea 58: each club's biggest rival. A custom team replaces Lahore, so
     *  it inherits Lahore's rival (Karachi) via the default below. */
    public static String rivalOf(String team) {
        switch (team) {
            case "Lahore Qalandars": return "Karachi Kings";
            case "Karachi Kings": return "Lahore Qalandars";
            case "Islamabad United": return "Peshawar Zalmi";
            case "Peshawar Zalmi": return "Islamabad United";
            case "Multan Sultans": return "Lahore Qalandars";
            case "Quetta Gladiators": return "Karachi Kings";
            case "Sialkot Stallions": return "Lahore Qalandars";
            case "Hyderabad Hawks": return "Karachi Kings";
            default: return "Karachi Kings"; // custom team (Lahore's slot)
        }
    }

    /** Batch H (idea 80): a fictional manager for every club — the
     *  rival gaffers are the voices of the pre/post-match quote banks.
     *  All names invented for this game. */
    public static String managerFor(String team) {
        switch (team) {
            case "Lahore Qalandars": return "Kamran 'Kami' Siddiqui";
            case "Karachi Kings": return "Derek Vance";
            case "Islamabad United": return "Fahad Mirza";
            case "Multan Sultans": return "Tom Ellery";
            case "Peshawar Zalmi": return "Rizwan 'Riz' Chaudhry";
            case "Quetta Gladiators": return "Shane Doyle";
            case "Sialkot Stallions": return "Imtiaz 'Immi' Sheikh";
            case "Hyderabad Hawks": return "Paul Hendricks";
            default: return "The Gaffer";
        }
    }

    // Idea 59: home grounds. Character index into GROUND_CHARS:
    // 0 High-scoring, 1 Balanced, 2 Bowler-friendly.
    public static final String[] GROUND_CHARS = {"High-scoring", "Balanced", "Bowler-friendly"};

    public static String groundName(String team) {
        switch (team) {
            case "Lahore Qalandars": return "Gaddafi Stadium";
            case "Karachi Kings": return "National Stadium Karachi";
            case "Multan Sultans": return "Multan Cricket Stadium";
            case "Islamabad United": return "Rawalpindi Cricket Stadium";
            case "Peshawar Zalmi": return "Arbab Niaz Stadium";
            case "Quetta Gladiators": return "Bugti Stadium";
            case "Sialkot Stallions": return "Jinnah Stadium Sialkot";
            case "Hyderabad Hawks": return "Niaz Stadium Hyderabad";
            default: return team + " Stadium"; // custom team
        }
    }

    public static int groundChar(String team) {
        switch (team) {
            case "Karachi Kings": case "Islamabad United": case "Hyderabad Hawks": return 0;
            case "Peshawar Zalmi": case "Quetta Gladiators": return 2;
            default: return 1; // Balanced (Lahore, Multan, Sialkot, custom)
        }
    }

    /** Idea 54 helper: the listed T20I nation of a world-ranked player, by
     *  name across every static world table; "" when unknown or when his
     *  nation is not one of the five tracked T20I nations. League players
     *  who are not overseas and not listed resolve to Pakistan. */
    public static String nationOfPlayer(String name) {
        String code = "";
        outer:
        for (int f = 0; f < WORLD.length; f++) {
            for (int c = 0; c < WORLD[f].length; c++) {
                for (String[] row : WORLD[f][c]) {
                    if (row[0].equals(name)) { code = row[1]; break outer; }
                }
            }
        }
        if (code.isEmpty()) return "";
        switch (code) {
            case "PAK": return "Pakistan";
            case "IND": return "India";
            case "AUS": return "Australia";
            case "ENG": return "England";
            case "WI": return "West Indies";
            default: return ""; // NZ / SA / others are outside the tracked five
        }
    }

    /** The six custom-team colours (idea 52): display name + RGB int. */
    public static final String[] CUSTOM_COLOR_NAMES = {"Emerald", "Crimson", "Royal Blue", "Violet", "Teal", "Orange"};
    public static final int[] CUSTOM_COLORS = {
        0xFF10B981, 0xFFEF4444, 0xFF3B82F6, 0xFF8B5CF6, 0xFF14B8A6, 0xFFF97316};
}
