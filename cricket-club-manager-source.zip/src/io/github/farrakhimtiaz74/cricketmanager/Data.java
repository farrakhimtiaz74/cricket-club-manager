package io.github.farrakhimtiaz74.cricketmanager;

/** Static game data: Lahore squad, teams, opponent XIs, facilities, world rankings. */
public class Data {

    public static final String USER_TEAM = "Lahore Qalandars";

    // name, role, batting, bowling
    public static final Object[][] SQUAD = {
        {"Fakhar Zaman", "Bat", 88, 20},
        {"Saim Ayub", "Bat", 86, 35},
        {"Abdullah Shafique", "Bat", 82, 10},
        {"Daryl Mitchell", "AR", 80, 62},
        {"Sam Billings", "WK", 78, 5},
        {"Sikandar Raza", "AR", 76, 74},
        {"David Wiese", "AR", 72, 76},
        {"Shaheen Shah Afridi", "Bowl", 45, 93},
        {"Haris Rauf", "Bowl", 30, 90},
        {"Rashid Khan", "Bowl", 55, 94},
        {"Zaman Khan", "Bowl", 25, 82},
        {"Kusal Perera", "WK", 79, 5},
        {"Jahandad Khan", "AR", 60, 78},
        {"Sahibzada Farhan", "Bat", 80, 8},
        {"Muhammad Akhlaq", "Bat", 70, 15},
        {"Tom Curran", "AR", 68, 80},
        {"Asif Afridi", "Bowl", 35, 80},
        {"Ubaid Shah", "Bowl", 20, 74},
    };

    public static final String[] GROUP_A = {"Lahore Qalandars", "Karachi Kings", "Multan Sultans", "Islamabad United"};
    public static final String[] GROUP_B = {"Peshawar Zalmi", "Quetta Gladiators", "Sialkot Stallions", "Hyderabad Hawks"};

    public static int teamStrength(String team) {
        switch (team) {
            case "Lahore Qalandars": return 86;
            case "Islamabad United": return 85;
            case "Multan Sultans": return 84;
            case "Peshawar Zalmi": return 84;
            case "Karachi Kings": return 83;
            case "Quetta Gladiators": return 82;
            case "Sialkot Stallions": return 78;
            default: return 76; // Hyderabad Hawks
        }
    }

    public static String shortName(String team) {
        switch (team) {
            case "Lahore Qalandars": return "LAH";
            case "Karachi Kings": return "KAR";
            case "Multan Sultans": return "MUL";
            case "Islamabad United": return "ISL";
            case "Peshawar Zalmi": return "PES";
            case "Quetta Gladiators": return "QUE";
            case "Sialkot Stallions": return "SIA";
            default: return "HYD";
        }
    }

    // Opponent playing XIs: name, batting, bowling  (user team XI comes from the squad)
    public static Object[][] xiFor(String team) {
        switch (team) {
            case "Karachi Kings": return new Object[][]{
                {"James Vince", 85, 5}, {"Tim Seifert", 80, 5}, {"David Warner", 87, 5},
                {"Shan Masood", 78, 5}, {"Khushdil Shah", 74, 60}, {"Mohammad Nabi", 70, 78},
                {"Irfan Khan", 68, 40}, {"Hasan Ali", 30, 84}, {"Abbas Afridi", 28, 82},
                {"Tabraiz Shamsi", 15, 85}, {"Zahid Mahmood", 15, 78}};
            case "Islamabad United": return new Object[][]{
                {"Alex Hales", 84, 5}, {"Colin Munro", 83, 5}, {"Agha Salman", 78, 55},
                {"Shadab Khan", 74, 84}, {"Azam Khan", 76, 5}, {"Imad Wasim", 70, 80},
                {"Haider Ali", 72, 5}, {"Naseem Shah", 25, 88}, {"Rumman Raees", 20, 78},
                {"Hunain Shah", 18, 76}, {"Riley Meredith", 15, 82}};
            case "Multan Sultans": return new Object[][]{
                {"Mohammad Rizwan", 86, 5}, {"Yasir Khan", 76, 5}, {"Kamran Ghulam", 77, 30},
                {"Iftikhar Ahmed", 75, 55}, {"Michael Bracewell", 74, 76}, {"David Willey", 62, 80},
                {"Chris Jordan", 45, 84}, {"Usama Mir", 30, 82}, {"Mohammad Hasnain", 20, 83},
                {"Akif Javed", 15, 78}, {"Shahnawaz Dahani", 15, 79}};
            case "Peshawar Zalmi": return new Object[][]{
                {"Babar Azam", 90, 10}, {"Mohammad Haris", 78, 5}, {"Tom Kohler-Cadmore", 80, 5},
                {"Hussain Talat", 72, 50}, {"Najibullah Zadran", 74, 5}, {"Abdul Samad", 70, 30},
                {"Alzarri Joseph", 30, 86}, {"Luke Wood", 35, 82}, {"Sufiyan Muqeem", 15, 80},
                {"Mehran Mumtaz", 20, 76}, {"Ali Raza", 15, 78}};
            case "Quetta Gladiators": return new Object[][]{
                {"Saud Shakeel", 78, 10}, {"Jason Roy", 84, 5}, {"Rilee Rossouw", 82, 5},
                {"Kusal Mendis", 79, 5}, {"Mark Chapman", 76, 30}, {"Faheem Ashraf", 62, 76},
                {"Mohammad Amir", 25, 85}, {"Abrar Ahmed", 15, 84}, {"Akeal Hosein", 35, 82},
                {"Mohammad Wasim", 25, 80}, {"Usman Tariq", 10, 74}};
            case "Sialkot Stallions": return new Object[][]{
                {"Ahmed Shehzad", 76, 5}, {"Mohammad Huraira", 74, 5}, {"Azan Awais", 72, 5},
                {"Tayyab Tahir", 75, 20}, {"Shoaib Malik", 74, 60}, {"Bismillah Khan", 68, 5},
                {"Saad Khan", 70, 40}, {"Jalat Khan", 55, 70}, {"Ali Shafique", 20, 76},
                {"Mohammad Ali", 18, 78}, {"Tabish Khan", 15, 72}};
            default: return new Object[][]{ // Hyderabad Hawks
                {"Sharjeel Khan", 78, 5}, {"Zeeshan Ashraf", 72, 5}, {"Omair Yousuf", 73, 5},
                {"Danish Aziz", 68, 55}, {"Khalid Usman", 60, 72}, {"Aamer Yamin", 58, 74},
                {"Asif Mehmood", 55, 68}, {"Mohammad Ilyas", 18, 74}, {"Arshad Iqbal", 15, 76},
                {"Faisal Akram", 20, 75}, {"Sameen Gul", 12, 73}};
        }
    }

    // ---- HQ facilities: name, base cost, effect text ----
    public static final String[] FACILITY_NAMES = {
        "Stadium", "Medical Centre", "Training Complex", "Youth Academy", "Commercial Centre"};
    public static final int[] FACILITY_BASE_COST = {400, 300, 350, 300, 350};
    public static final String[] FACILITY_EFFECT = {
        "Bigger crowds: +40 CF gate income per home match, per level.",
        "Faster healing: Recovery restores more stamina per level.",
        "Better coaching: small rating boost to the whole squad per upgrade.",
        "Scouts find a young prospect who joins at each season rollover (level 2+).",
        "Sponsors pay a CF bonus every few days, growing per level."};
    public static final int FACILITY_MAX = 5;

    // ---- World rankings: [format][category] -> rows of {name, country/tag, rating} ----
    public static final String[] FORMATS = {"T20I", "ODI", "Test"};
    public static final String[] CATEGORIES = {"Batting", "Bowling", "All-rounder"};

    public static String[][] worldPlayers(int format, int category) {
        return WORLD[format][category];
    }

    private static final String[][][][] WORLD = {
        { // T20I
            {{"Travis Head", "AUS", "856"}, {"Abhishek Sharma", "IND", "829"}, {"Phil Salt", "ENG", "815"}, {"Babar Azam", "PAK", "790"}, {"Jos Buttler", "ENG", "780"}},
            {{"Akeal Hosein", "WI", "707"}, {"Adil Rashid", "ENG", "701"}, {"Wanindu Hasaranga", "SL", "690"}, {"Rashid Khan", "AFG", "685"}, {"Shaheen Shah Afridi", "PAK", "660"}},
            {{"Hardik Pandya", "IND", "290"}, {"Marcus Stoinis", "AUS", "275"}, {"Sikandar Raza", "ZIM", "260"}, {"Wanindu Hasaranga", "SL", "250"}, {"Liam Livingstone", "ENG", "240"}}
        },
        { // ODI
            {{"Shubman Gill", "IND", "857"}, {"Babar Azam", "PAK", "825"}, {"Rohit Sharma", "IND", "815"}, {"Harry Tector", "IRE", "750"}, {"Virat Kohli", "IND", "745"}},
            {{"Rashid Khan", "AFG", "675"}, {"Kuldeep Yadav", "IND", "660"}, {"Keshav Maharaj", "SA", "650"}, {"Shaheen Shah Afridi", "PAK", "640"}, {"Josh Hazlewood", "AUS", "630"}},
            {{"Azmatullah Omarzai", "AFG", "310"}, {"Sikandar Raza", "ZIM", "285"}, {"Mehidy Hasan Miraz", "BAN", "280"}, {"Glenn Maxwell", "AUS", "270"}, {"Ravindra Jadeja", "IND", "265"}}
        },
        { // Test
            {{"Joe Root", "ENG", "895"}, {"Harry Brook", "ENG", "870"}, {"Kane Williamson", "NZ", "850"}, {"Yashasvi Jaiswal", "IND", "830"}, {"Steve Smith", "AUS", "815"}},
            {{"Jasprit Bumrah", "IND", "885"}, {"Kagiso Rabada", "SA", "850"}, {"Pat Cummins", "AUS", "830"}, {"Josh Hazlewood", "AUS", "820"}, {"Noman Ali", "PAK", "790"}},
            {{"Ravindra Jadeja", "IND", "420"}, {"Ben Stokes", "ENG", "310"}, {"Pat Cummins", "AUS", "280"}, {"Marco Jansen", "SA", "270"}, {"Shakib Al Hasan", "BAN", "260"}}
        }
    };

    public static String[][] worldNations(int format) {
        return NATIONS[format];
    }

    private static final String[][][] NATIONS = {
        {{"India", "269"}, {"Australia", "257"}, {"England", "254"}, {"West Indies", "252"}, {"Pakistan", "245"}},
        {{"India", "122"}, {"Australia", "114"}, {"Pakistan", "108"}, {"New Zealand", "105"}, {"South Africa", "102"}},
        {{"Australia", "124"}, {"India", "118"}, {"England", "110"}, {"South Africa", "105"}, {"New Zealand", "98"}}
    };

    // Academy prospect name pool
    public static final String[] PROSPECTS = {
        "Maaz Sadaqat", "Ali Hassan Baloch", "Shamyl Hussain", "Arafat Minhas",
        "Qasim Akram", "Saad Baig", "Riazullah", "Ahmed Daniyal"};
}
