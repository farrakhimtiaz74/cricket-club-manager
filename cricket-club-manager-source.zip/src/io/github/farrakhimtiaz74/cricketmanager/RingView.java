package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Professional Pack P4 (suggestion 34): a small drawn ring for
 *  compact rows — a slate track circle with a coloured arc for the
 *  value (colour bands from Design.gaugeColor). The word label always
 *  sits beside it in the row; the ring never speaks alone. */
public class RingView extends View {
    private final int value;
    private final int sizeDp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public RingView(Context c, int value, int sizeDp) {
        super(c);
        this.value = Design.clamp100(value);
        this.sizeDp = sizeDp;
    }

    @Override
    protected void onMeasure(int w, int h) {
        int s = Ui.dp(getContext(), sizeDp);
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float stroke = Math.max(2.5f, w * 0.14f);
        RectF oval = new RectF(stroke / 2f, stroke / 2f, w - stroke / 2f, h - stroke / 2f);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setColor(Ui.CARD2);
        cv.drawArc(oval, 0, 360, false, p);
        if (value > 0) {
            p.setColor(Design.gaugeColor(value));
            p.setStrokeCap(Paint.Cap.ROUND);
            cv.drawArc(oval, -90, value * 3.6f, false, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        }
    }
}
