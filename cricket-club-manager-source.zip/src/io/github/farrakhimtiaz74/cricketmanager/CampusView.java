package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Rich Media Edition (v20): the HQ campus — the generated aerial
 *  artwork of the club grounds with five tappable hotspot labels, one
 *  over each building the art actually shows (stadium top-centre,
 *  medical centre left, training complex right, youth academy
 *  bottom-left, commercial centre bottom-right). A tap reports the
 *  facility index (Data.FACILITY_NAMES order) to the listener, which
 *  scrolls the still-complete facility list to that card — the image
 *  is a map INTO the list, never a replacement for it.
 *
 *  The bitmap is drawn centre-crop; hotspot positions are fractions
 *  of the VIEW (they were placed against the artwork's composition,
 *  which the crop preserves closely at this aspect). Labels are
 *  drawn pills: facility name + live level from the Game. If the art
 *  fails to decode the view does not exist (HqScreen checks Art
 *  first) — there is no drawn fallback because the list below IS
 *  the fallback. */
public class CampusView extends View {

    public interface OnHotspot {
        void onHotspot(int facilityIdx);
    }

    // fraction positions (x, y) of the five buildings in the artwork
    private static final float[][] SPOTS = {
            {0.50f, 0.16f}, // 0 Stadium — top centre
            {0.20f, 0.40f}, // 1 Medical Centre — left
            {0.79f, 0.42f}, // 2 Training Complex — right
            {0.22f, 0.80f}, // 3 Youth Academy — bottom left
            {0.76f, 0.82f}, // 4 Commercial Centre — bottom right
    };
    private static final String[] SHORT = {
            "Stadium", "Medical", "Training", "Academy", "Commercial"};

    private final Bitmap bmp;
    private final Game g;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pillBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pillTxt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private OnHotspot listener;

    public CampusView(Context c, Bitmap bmp, Game g) {
        super(c);
        this.bmp = bmp;
        this.g = g;
        pillBg.setColor(0xD90F172A);
        pillTxt.setColor(0xFFF59E0B);
        pillTxt.setTextAlign(Paint.Align.CENTER);
        pillTxt.setFakeBoldText(true);
        android.graphics.Typeface d = Art.bodyMedFont(c);
        if (d != null) pillTxt.setTypeface(d);
    }

    public void setOnHotspot(OnHotspot l) { this.listener = l; }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = Ui.dp(getContext(), 252);
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (bmp != null) {
            // centre-crop the artwork into the view
            float scale = Math.max(w / bmp.getWidth(), h / bmp.getHeight());
            float dw = bmp.getWidth() * scale, dh = bmp.getHeight() * scale;
            cv.save();
            cv.clipRect(0, 0, w, h);
            cv.drawBitmap(bmp, null, new RectF((w - dw) / 2f, (h - dh) / 2f,
                    (w + dw) / 2f, (h + dh) / 2f), paint);
            cv.restore();
        }
        // hotspot pills
        float fontPx = Ui.dp(getContext(), 11) * Ui.TEXT_SCALE;
        pillTxt.setTextSize(fontPx);
        for (int i = 0; i < SPOTS.length; i++) {
            String label = SHORT[i] + " · L" + g.facilityLevel(i);
            float tw = pillTxt.measureText(label);
            float pw = tw + Ui.dp(getContext(), 16), ph = fontPx + Ui.dp(getContext(), 11);
            float cx = SPOTS[i][0] * w, cy = SPOTS[i][1] * h;
            float x0 = Math.max(2, Math.min(w - pw - 2, cx - pw / 2f));
            float y0 = Math.max(2, Math.min(h - ph - 2, cy - ph / 2f));
            cv.drawRoundRect(new RectF(x0, y0, x0 + pw, y0 + ph), ph / 2f, ph / 2f, pillBg);
            cv.drawText(label, x0 + pw / 2f, y0 + ph / 2f + fontPx * 0.36f, pillTxt);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP || listener == null) {
            return e.getAction() == MotionEvent.ACTION_DOWN || super.onTouchEvent(e);
        }
        float x = e.getX() / Math.max(1, getWidth());
        float y = e.getY() / Math.max(1, getHeight());
        int best = -1;
        float bestD = 0.30f; // generous tap radius in fraction space
        for (int i = 0; i < SPOTS.length; i++) {
            float d = Math.abs(x - SPOTS[i][0]) + Math.abs(y - SPOTS[i][1]);
            if (d < bestD) { bestD = d; best = i; }
        }
        if (best >= 0) {
            performClick();
            listener.onHotspot(best);
            return true;
        }
        return super.onTouchEvent(e);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
