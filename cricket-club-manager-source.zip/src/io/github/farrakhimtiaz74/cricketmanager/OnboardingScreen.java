package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Professional Pack P5 (suggestion 41): the first-launch welcome —
 *  three short steps shown BEFORE the team picker, only when no
 *  career exists and the tour has not been seen (the predicate is
 *  Settings.shouldShowOnboarding; the flag lives in the ccm_settings
 *  prefs, never in the career save). Finishing or skipping sets the
 *  flag and lands on the existing picker. Help's "Replay welcome"
 *  re-enters this screen view-only over a live career — finishing
 *  then simply returns to the tabs and touches nothing. */
public class OnboardingScreen {

    private static final String[] TITLES = {
            "Welcome to the hot seat",
            "How a season works",
            "Your money, your phone"};

    public static View build(final MainActivity act) {
        final int step = Math.max(0, Math.min(2, act.onboardingStep));
        LinearLayout root = Ui.col(act);

        LinearLayout card = Ui.card(act);
        // the crest lockup, same lockup as the header / picker / About
        LinearLayout lock = Ui.row(act);
        lock.addView(CrestView.forTeam(act, act.g, act.g.userTeam, 52));
        LinearLayout titles = Ui.col(act);
        titles.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        titles.setPadding(Ui.dp(act, 10), 0, 0, 0);
        titles.addView(Ui.micro(act, "WELCOME · STEP " + (step + 1) + " OF 3"));
        titles.addView(Ui.h1(act, TITLES[step]));
        lock.addView(titles);
        card.addView(lock);
        card.addView(dotRow(act, step));

        if (step == 0) {
            card.addView(Ui.body(act, "You manage a PSL-style club through a full season — "
                    + "picking the team, calling the tactics and answering to the board."));
            card.addView(Ui.body(act, "Win the playoffs and you lift the trophy. "
                    + "Fall too far and the board shows you the door."));
        } else if (step == 1) {
            card.addView(iconLine(act, Icons.SHIRT,
                    "Pick your XI — 11 players, one of them a wicketkeeper."));
            card.addView(iconLine(act, Icons.TROPHY,
                    "Play the matches — ball by ball, or sim them — and finish in your group's top two."));
            card.addView(iconLine(act, Icons.STAR,
                    "Win the playoffs — Qualifier, Eliminator, Final — and the trophy is yours."));
        } else {
            card.addView(iconLine(act, Icons.COIN,
                    "Club Cash (CF) runs the club: prizes and ticket sales pay in; wages, signings and facilities pay out."));
            card.addView(iconLine(act, Icons.HOME,
                    "100% offline — your career never leaves this phone. No account, no uploads."));
        }
        root.addView(card);

        LinearLayout row = Ui.row(act);
        Button skip = Ui.darkBtn(act, "Skip");
        skip.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        skip.setOnClickListener(v -> act.finishOnboarding());
        row.addView(skip);
        Button next = Ui.goldBtn(act, step == 2 ? "Pick my club" : "Next");
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 2);
        nlp.setMargins(Ui.dp(act, 8), 0, 0, 0);
        next.setLayoutParams(nlp);
        next.setOnClickListener(v -> {
            if (step >= 2) act.finishOnboarding();
            else { act.onboardingStep = step + 1; act.render(); }
        });
        row.addView(next);
        root.addView(row);
        return root;
    }

    /** Three dots, the current step in gold — the step indicator. */
    private static View dotRow(MainActivity act, int step) {
        LinearLayout row = Ui.row(act);
        row.setPadding(0, Ui.dp(act, 10), 0, Ui.dp(act, 6));
        for (int i = 0; i < 3; i++) {
            View d = new View(act);
            d.setBackground(Ui.round(i == step ? Ui.GOLD : Ui.CARD2, 4, act));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    Ui.dp(act, i == step ? 22 : 8), Ui.dp(act, 8));
            lp.setMargins(0, 0, Ui.dp(act, 6), 0);
            d.setLayoutParams(lp);
            row.addView(d);
        }
        return row;
    }

    /** One guide line with a drawn icon in front of it. */
    private static View iconLine(MainActivity act, int icon, String line) {
        LinearLayout row = Ui.row(act);
        row.setPadding(0, Ui.dp(act, 5), 0, Ui.dp(act, 5));
        Icons.BadgeView b = new Icons.BadgeView(act, icon);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                Ui.dp(act, 26), Ui.dp(act, 26));
        blp.setMargins(0, 0, Ui.dp(act, 10), 0);
        b.setLayoutParams(blp);
        row.addView(b);
        TextView t = Ui.body(act, line);
        t.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(t);
        return row;
    }
}
