package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** Batch J (idea 97): global search — one box over the whole game:
 * your squad (tap → his Team detail), AI squads and World stars
 * (tap → info), the eight clubs (tap → info: strength, ground, rival,
 * head-to-head) and every fixture on the calendar (tap → the Season
 * Calendar). The matching itself is pure (SearchIndex); this screen
 * only renders groups and routes taps. The query lives on the activity
 * so it survives re-renders, like the picker's drafts. */
public class SearchScreen {

 public static View build(final MainActivity act) {
 LinearLayout root = Ui.col(act);

 // P2 (suggestions 13/19): the standard sub-screen header
 root.addView(Ui.subHeader(act, "Search the Club World",
 "Your squad · every other club · World stars · all fixtures",
 v -> { act.searchMode = false; act.render(); }));

 final EditText q = new EditText(act);
 q.setHint("Player, team or fixture — e.g. Shaheen, Karachi, Day 12");
 q.setText(act.searchQuery);
 q.setTextColor(Ui.INK);
 q.setHintTextColor(Ui.MUTED);
 q.setSingleLine(true);
 root.addView(q);
 Button go = Ui.goldBtn(act, "Search");
 go.setOnClickListener(v -> { act.searchQuery = q.getText().toString(); act.render(); });
 root.addView(go);

 String query = act.searchQuery == null ? "" : act.searchQuery.trim();
 if (query.length() < 2) {
 root.addView(Ui.small(act, "Type at least 2 letters. Searches your squad, every AI squad,"
 + " the World stars, all 8 clubs and every fixture this season."));
 return root;
 }

 List<SearchIndex.Hit> hits = SearchIndex.search(act.g, query);
 if (hits.isEmpty()) {
 root.addView(Ui.small(act, "Nothing found for \"" + query + "\". Try a shorter spelling."));
 return root;
 }

 group(act, root, hits, SearchIndex.PLAYER, "Your Squad", h -> quickView(act, h));
 group(act, root, hits, SearchIndex.AI_PLAYER, "Players at Other Clubs", h ->
 info(act, h.title, h.info + "\n\nScout and sign players like him in Transfers during the windows."));
 group(act, root, hits, SearchIndex.WORLD, "World Stars", h ->
 info(act, h.title, h.info + "\n\nWorld rankings update as the season plays (World tab)."));
 group(act, root, hits, SearchIndex.TEAM, "Clubs", h ->
 info(act, h.title, h.info + "\n\nFull tables and head-to-head records live on the League tab."));
 group(act, root, hits, SearchIndex.FIXTURE, "Fixtures", h -> {
 act.searchMode = false;
 act.calendarMode = true;
 act.render();
 });
 return root;
 }

 private interface Tap { void on(SearchIndex.Hit h); }

 private static void group(final MainActivity act, LinearLayout root, List<SearchIndex.Hit> hits,
 String kind, String title, final Tap tap) {
 List<SearchIndex.Hit> rows = SearchIndex.ofKind(hits, kind);
 if (rows.isEmpty()) return;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, title + " (" + rows.size() + ")"));
 // P2 (suggestion 18): results are list rows — a left visual, the
 // title + info lines, and a right-aligned kind tag
 for (final SearchIndex.Hit h : rows) {
 View left;
 String tag;
 if (SearchIndex.PLAYER.equals(kind)) {
 org.json.JSONObject p = act.g.playerByName(h.ref);
 left = p != null ? new AvatarView(act, p.optString("name"), p.optString("role"), 36)
 : Icons.badge(act, Icons.STAR);
 tag = "SQUAD";
 } else if (SearchIndex.TEAM.equals(kind)) {
 left = CrestView.forTeam(act, act.g, h.ref, 30);
 tag = "CLUB";
 } else if (SearchIndex.WORLD.equals(kind)) {
 left = Icons.badge(act, Icons.STAR);
 tag = "WORLD";
 } else if (SearchIndex.FIXTURE.equals(kind)) {
 left = Icons.badge(act, Icons.CONTRACT);
 tag = "FIXTURE";
 } else {
 left = Icons.badge(act, Icons.OVERSEAS);
 tag = "PLAYER";
 }
 card.addView(Ui.listRow(act, left, h.title, h.info, tag, v -> tap.on(h)));
 }
 root.addView(card);
 }

 private static void info(MainActivity act, String title, String msg) {
 new AlertDialog.Builder(act).setTitle(title).setMessage(msg)
 .setPositiveButton("Close", null).show();
 }

 /** Design Batch (item 5): the player quick-view bottom sheet —
 * avatar, tier, the headline numbers and his season line, with a
 * jump to the full Team detail. Built from the live player object
 * so it can never disagree with the Team tab.
 * P2 (suggestion 17): now public and player-based — the Team list
 * opens this exact sheet on a card tap, Search keeps its route. */
 public static void playerSheet(final MainActivity act, final org.json.JSONObject p) {
 final Game g = act.g;
 final String name = p.optString("name");
 LinearLayout sheet = Ui.col(act);
 LinearLayout top = Ui.row(act);
 AvatarView av = new AvatarView(act, name, p.optString("role"), 48);
 LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(Ui.dp(act, 48), Ui.dp(act, 48));
 avLp.setMargins(0, 0, Ui.dp(act, 10), 0);
 av.setLayoutParams(avLp);
 top.addView(av);
 LinearLayout nameCol = Ui.col(act);
 nameCol.addView(Ui.h2(act, name));
 nameCol.addView(Ui.small(act, p.optString("role") + " · " + g.userTeam
 + " · " + Design.tierName(Game.rating(p)) + " tier"));
 top.addView(nameCol);
 LinearLayout.LayoutParams topLp = new LinearLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
 top.setLayoutParams(topLp);
 sheet.addView(top);
 // P2: the quick view carries the two drawn gauges too
 // P4 (suggestion 34): the WORD rides beside each gauge — colour
 // is never the only signal
 LinearLayout stRow = Ui.row(act);
 TextView stLab = Ui.micro(act, "STAMINA");
 stLab.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 52), android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
 stRow.addView(stLab);
 LinearLayout stWrap = Ui.col(act);
 stWrap.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 stWrap.addView(new GaugeView(act, p.optInt("stam")));
 stRow.addView(stWrap);
 stRow.addView(Ui.text(act, p.optInt("stam") + " · " + Present.staminaLabel(p.optInt("stam")), 12, Ui.INK, true));
 sheet.addView(stRow);
 LinearLayout moRow = Ui.row(act);
 TextView moLab = Ui.micro(act, "MORALE");
 moLab.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 52), android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
 moRow.addView(moLab);
 LinearLayout moWrap = Ui.col(act);
 moWrap.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 moWrap.addView(new GaugeView(act, p.optInt("morale", 70)));
 moRow.addView(moWrap);
 moRow.addView(Ui.text(act, p.optInt("morale", 70) + " · " + Game.moraleLabel(p.optInt("morale", 70)), 12, Ui.INK, true));
 sheet.addView(moRow);
 sheet.addView(Ui.body(act, "Rating " + Game.rating(p) + " · Bat " + p.optInt("bat")
 + " · Bowl " + p.optInt("bowl") + " · Stamina " + p.optInt("stam")
 + " · Morale " + p.optInt("morale", 70)));
 org.json.JSONObject ss = p.optJSONObject("ss");
 if (ss != null) {
 sheet.addView(Ui.small(act, "This season: " + ss.optInt("runs") + " runs (HS " + ss.optInt("hs")
 + ") · " + ss.optInt("wkts") + " wickets · " + ss.optInt("m") + " matches"));
 }
 if (p.optInt("injured", 0) > 0) {
 sheet.addView(Ui.text(act, "Injured — " + p.optString("injType") + " · "
 + p.optInt("injured") + " day(s) out", 13, Ui.RED, true));
 }
 // P4 (suggestion 31): Rest / Watch moved onto the compact cards'
 // behalf — they live here and in the detail Overview tab
 if (g.playerByName(name) != null) {
 LinearLayout rw = Ui.row(act);
 Button restB = Ui.darkBtn(act, p.optBoolean("rested") ? "Un-rest" : "Rest");
 restB.setEnabled(p.optInt("injured", 0) == 0 && !p.optBoolean("loanOut"));
 restB.setOnClickListener(v -> { TeamScreen.restToggle(act, p); act.hideSheet(); act.render(); });
 Button watchB = Ui.darkBtn(act, g.isWatched(name) ? "Watching" : "Watch");
 watchB.setOnClickListener(v -> { TeamScreen.watchToggle(act, p); act.hideSheet(); act.render(); });
 restB.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 watchB.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 rw.addView(restB);
 rw.addView(watchB);
 sheet.addView(rw);
 // v20.1 (item 3): the XI toggle and captaincy moved here from the
 // old squad card (the fixed-height compact card has no room for
 // buttons) — same handlers the card chips used, nothing lost.
 LinearLayout xw = Ui.row(act);
 final boolean inXI = p.optBoolean("inXI");
 final boolean xiBlocked = (p.optInt("injured", 0) > 0 || p.optBoolean("loanOut")) && !inXI;
 Button xiB = Ui.darkBtn(act, xiBlocked ? (p.optInt("injured", 0) > 0 ? "Injured" : "On loan")
 : inXI ? "In the XI — tap to drop" : "Add to XI");
 xiB.setEnabled(!xiBlocked);
 xiB.setOnClickListener(v -> { TeamScreen.toggleXi(act, p); act.hideSheet(); });
 final boolean isCap = name.equals(g.captain);
 Button capB = Ui.darkBtn(act, isCap ? "Captain ©" : "Make Captain");
 capB.setOnClickListener(v -> {
 if (isCap) { act.toast(name + " is already your captain"); return; }
 g.setCaptain(name);
 act.save();
 act.hideSheet();
 act.toast(name + " named captain — his morale rises, the old skipper's dips");
 act.render();
 });
 xiB.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 capB.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 xw.addView(xiB);
 xw.addView(capB);
 sheet.addView(xw);
 }
 Button full = Ui.goldBtn(act, "Full Details");
 full.setOnClickListener(v -> {
 act.hideSheet();
 act.searchMode = false;
 act.tab = 1;
 act.teamDetail = name;
 act.render();
 });
 sheet.addView(full);
 Button close = Ui.darkBtn(act, "Close");
 close.setOnClickListener(v -> act.hideSheet());
 sheet.addView(close);
 act.showSheet(sheet);
 }

 private static void quickView(final MainActivity act, final SearchIndex.Hit h) {
 final org.json.JSONObject p = act.g.playerByName(h.ref);
 if (p == null) { info(act, h.title, h.info); return; }
 playerSheet(act, p);
 }
}
