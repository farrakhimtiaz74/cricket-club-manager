package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.List;

/** Batch J (idea 97): global search — one box over the whole game:
 *  your squad (tap → his Team detail), AI squads and World stars
 *  (tap → info), the eight clubs (tap → info: strength, ground, rival,
 *  head-to-head) and every fixture on the calendar (tap → the Season
 *  Calendar). The matching itself is pure (SearchIndex); this screen
 *  only renders groups and routes taps. The query lives on the activity
 *  so it survives re-renders, like the picker's drafts. */
public class SearchScreen {

    public static View build(final MainActivity act) {
        LinearLayout root = Ui.col(act);

        Button back = Ui.darkBtn(act, "← Back to Hub");
        back.setOnClickListener(v -> { act.searchMode = false; act.render(); });
        root.addView(back);
        root.addView(Ui.h1(act, "🔍 Search the Club World"));

        final EditText q = new EditText(act);
        q.setHint("Player, team or fixture — e.g. Shaheen, Karachi, Day 12");
        q.setText(act.searchQuery);
        q.setTextColor(Ui.INK);
        q.setHintTextColor(Ui.MUTED);
        q.setSingleLine(true);
        root.addView(q);
        Button go = Ui.goldBtn(act, "Search");
        go.setOnClickListener(v -> { act.searchQuery = q.getText().toString(); act.render(); });
        root.addView(go);

        String query = act.searchQuery == null ? "" : act.searchQuery.trim();
        if (query.length() < 2) {
            root.addView(Ui.small(act, "Type at least 2 letters. Searches your squad, every AI squad,"
                    + " the World stars, all 8 clubs and every fixture this season."));
            return root;
        }

        List<SearchIndex.Hit> hits = SearchIndex.search(act.g, query);
        if (hits.isEmpty()) {
            root.addView(Ui.small(act, "Nothing found for \"" + query + "\". Try a shorter spelling."));
            return root;
        }

        group(act, root, hits, SearchIndex.PLAYER, "⭐ Your Squad", h -> {
            act.searchMode = false;
            act.tab = 1;
            act.teamDetail = h.ref;
            act.render();
        });
        group(act, root, hits, SearchIndex.AI_PLAYER, "🏏 Players at Other Clubs", h ->
                info(act, h.title, h.info + "\n\nScout and sign players like him in Transfers during the windows."));
        group(act, root, hits, SearchIndex.WORLD, "🌍 World Stars", h ->
                info(act, h.title, h.info + "\n\nWorld rankings update as the season plays (World tab)."));
        group(act, root, hits, SearchIndex.TEAM, "🛡 Clubs", h ->
                info(act, h.title, h.info + "\n\nFull tables and head-to-head records live on the League tab."));
        group(act, root, hits, SearchIndex.FIXTURE, "📅 Fixtures", h -> {
            act.searchMode = false;
            act.calendarMode = true;
            act.render();
        });
        return root;
    }

    private interface Tap { void on(SearchIndex.Hit h); }

    private static void group(final MainActivity act, LinearLayout root, List<SearchIndex.Hit> hits,
                              String kind, String title, final Tap tap) {
        List<SearchIndex.Hit> rows = SearchIndex.ofKind(hits, kind);
        if (rows.isEmpty()) return;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, title + " (" + rows.size() + ")"));
        for (final SearchIndex.Hit h : rows) {
            Button b = Ui.darkBtn(act, h.title + "\n" + h.info);
            b.setOnClickListener(v -> tap.on(h));
            card.addView(b);
        }
        root.addView(card);
    }

    private static void info(MainActivity act, String title, String msg) {
        new AlertDialog.Builder(act).setTitle(title).setMessage(msg)
                .setPositiveButton("Close", null).show();
    }
}
