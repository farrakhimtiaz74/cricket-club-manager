package io.github.farrakhimtiaz74.cricketmanager;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

/** Batch H (idea 77): the smallest possible content provider — it serves
 *  ONLY the files the app itself writes into its private cache dir
 *  (cache/reports/*.png originally), so the share sheet can attach them
 *  through a content:// URI with a temporary grant. Stock androidx
 *  FileProvider is not available to this pure-framework build, hence
 *  this hand-rolled equivalent. It is NOT a permission: the provider is
 *  exported=false and the app still declares zero permissions. Any path
 *  outside the two cache folders, and any ".." trickery, is refused.
 *
 *  Batch J (ideas 91/98/100): cache/share/ is served too, for the text
 *  exports — the career-backup .json, the sync-code .txt and the stats
 *  .csv files. The extension whitelist is the whole policy: .png from
 *  reports/, .csv/.json/.txt from share/, nothing else, ever. */
public class ShareProvider extends ContentProvider {

    public static final String AUTHORITY = "io.github.farrakhimtiaz74.cricketmanager.share";

    private File reportsDir() {
        return new File(getContext().getCacheDir(), "reports");
    }

    private File shareDir() {
        return new File(getContext().getCacheDir(), "share");
    }

    private File resolve(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("..")) return null;
        if (name.endsWith(".png")) return new File(reportsDir(), name);
        if (name.endsWith(".csv") || name.endsWith(".json") || name.endsWith(".txt")) {
            return new File(shareDir(), name);
        }
        return null;
    }

    @Override public boolean onCreate() { return true; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        if (f == null || !f.exists() || !"r".equals(mode)) throw new FileNotFoundException(String.valueOf(uri));
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name != null && name.endsWith(".csv")) return "text/csv";
        if (name != null && name.endsWith(".json")) return "application/json";
        if (name != null && name.endsWith(".txt")) return "text/plain";
        return "image/png";
    }

    @Override public Cursor query(Uri uri, String[] p, String s, String[] a, String o) { return null; }
    @Override public Uri insert(Uri uri, ContentValues v) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
