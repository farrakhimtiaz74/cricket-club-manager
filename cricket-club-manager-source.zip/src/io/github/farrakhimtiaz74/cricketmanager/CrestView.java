package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Design Batch (v13, item 9b): a club crest — a shield drawn in the
 *  club's two colours (Design.clubColors) with its short code on the
 *  chest band. Pure Canvas: no image assets, no fonts to break.
 *
 *  Rich Media Edition (v20): forTeam() first tries the bundled crest
 *  ARTWORK (original PIL-drawn shields in assets/art/, richer than
 *  Canvas can draw — layered gradients, stars, a ball motif). The
 *  bitmap is drawn clipped to this view's own shield path so the
 *  silhouette matches the drawn version exactly. A custom club, an
 *  unknown club or any decode failure keeps the drawn shield below —
 *  the fallback is total, by construction. */
public class CrestView extends View {
    private final String code;
    private final int primary, secondary;
    private final int sizeDp;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private android.graphics.Bitmap artBmp;

    public CrestView(Context c, String code, int primary, int secondary, int sizeDp) {
        super(c);
        this.code = code == null ? "?" : code;
        this.primary = primary;
        this.secondary = secondary;
        this.sizeDp = sizeDp;
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setFakeBoldText(true);
        txt.setColor(0xFFFFFFFF);
    }

    /** Crest for any club in a fixture — resolves custom-club colours. */
    public static CrestView forTeam(Context c, Game g, String team, int sizeDp) {
        CrestView v = new CrestView(c, g == null ? Data.shortName(team) : g.shortFor(team),
                Design.colorForTeam(g, team), Design.secondaryForTeam(g, team), sizeDp);
        // v20: attach the artwork when this club has some (the user's
        // custom club resolves to null inside Art — drawn fallback)
        v.artBmp = Art.crestBitmap(c, g, team, Math.max(96, sizeDp * 3));
        return v;
    }

    @Override
    protected void onMeasure(int w, int h) {
        int s = Ui.dp(getContext(), sizeDp);
        setMeasuredDimension(s, (int) (s * 1.12f));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (artBmp != null) {
            // the artwork clipped to the same shield silhouette
            float m = 1.5f;
            Path clip = new Path();
            clip.moveTo(m, m);
            clip.lineTo(w - m, m);
            clip.lineTo(w - m, h * 0.52f);
            clip.quadTo(w - m, h * 0.86f, w / 2f, h - m);
            clip.quadTo(m, h * 0.86f, m, h * 0.52f);
            clip.close();
            cv.save();
            cv.clipPath(clip);
            cv.drawBitmap(artBmp, null, new android.graphics.RectF(0, 0, w, h), fill);
            cv.restore();
            return;
        }
        float m = 1.5f;
        Path shield = new Path();
        shield.moveTo(m, m);
        shield.lineTo(w - m, m);
        shield.lineTo(w - m, h * 0.52f);
        shield.quadTo(w - m, h * 0.86f, w / 2f, h - m);
        shield.quadTo(m, h * 0.86f, m, h * 0.52f);
        shield.close();
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(primary);
        cv.drawPath(shield, fill);
        // diagonal sash in the second colour
        cv.save();
        cv.clipPath(shield);
        Path sash = new Path();
        sash.moveTo(w * 0.52f, 0);
        sash.lineTo(w * 0.86f, 0);
        sash.lineTo(w * 0.30f, h);
        sash.lineTo(w * 0.02f, h);
        sash.close();
        fill.setColor(secondary);
        fill.setAlpha(150);
        cv.drawPath(sash, fill);
        // chest band + code
        fill.setAlpha(235);
        fill.setColor(0xFF0F172A);
        cv.drawRect(0, h * 0.34f, w, h * 0.62f, fill);
        cv.restore();
        fill.setStyle(Paint.Style.STROKE);
        fill.setColor(0xFFF1F5F9);
        fill.setAlpha(120);
        fill.setStrokeWidth(Ui.dp(getContext(), 1));
        cv.drawPath(shield, fill);
        txt.setTextSize(h * 0.24f);
        cv.drawText(code, w / 2f, h * 0.34f + h * 0.21f, txt);
    }
}
