package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import org.json.JSONArray;

/** Design Batch (v13, item 8): the player's last-5 form as a DRAWN
 *  two-row mini chart — runs bars (gold, green at 50+) on top and
 *  wickets bars (sky) below, read from the Batch C formB / formW
 *  arrays ("wkts/runs" strings). Replaces the hand-built row of sized
 *  Views plus the text-only spells line; the ▲/▼/● trend badge and the
 *  numbers line stay in TeamScreen as text companions. */
public class FormBarsView extends View {
    private final int[] runs;
    private final int[] wkts;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lab = new Paint(Paint.ANTI_ALIAS_FLAG);

    public FormBarsView(Context c, JSONArray formB, JSONArray formW) {
        super(c);
        int n = formB == null ? 0 : formB.length();
        runs = new int[n];
        for (int i = 0; i < n; i++) runs[i] = formB.optInt(i);
        int m = formW == null ? 0 : formW.length();
        wkts = new int[m];
        for (int i = 0; i < m; i++) {
            String s = formW.optString(i);
            int slash = s.indexOf('/');
            try {
                wkts[i] = Integer.parseInt((slash >= 0 ? s.substring(0, slash) : s).trim());
            } catch (Exception e) {
                wkts[i] = 0;
            }
        }
        lab.setColor(Ui.MUTED);
        lab.setTextSize(Ui.dp(c, 8));
        lab.setTextAlign(Paint.Align.CENTER);
    }

    public boolean hasData() { return runs.length > 0 || wkts.length > 0; }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(getContext(), 62));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float slot = Ui.dp(getContext(), 21);
        float base1 = Ui.dp(getContext(), 34); // runs baseline
        float base2 = Ui.dp(getContext(), 58); // wickets baseline
        int maxR = 50;
        for (int v : runs) maxR = Math.max(maxR, v);
        int maxW = 3;
        for (int v : wkts) maxW = Math.max(maxW, v);
        for (int i = 0; i < runs.length; i++) {
            float x = i * slot + Ui.dp(getContext(), 3);
            float bw = Ui.dp(getContext(), 13);
            float bh = Math.max(Ui.dp(getContext(), 2), Ui.dp(getContext(), 26) * runs[i] / (float) maxR);
            p.setColor(runs[i] >= 50 ? Ui.GREEN : Ui.GOLD);
            cv.drawRect(x, base1 - bh, x + bw, base1, p);
            cv.drawText(String.valueOf(runs[i]), x + bw / 2, base1 - bh - Ui.dp(getContext(), 2), lab);
        }
        for (int i = 0; i < wkts.length; i++) {
            float x = i * slot + Ui.dp(getContext(), 3);
            float bw = Ui.dp(getContext(), 13);
            float bh = Math.max(Ui.dp(getContext(), 2), Ui.dp(getContext(), 12) * wkts[i] / (float) maxW);
            p.setColor(0xFF38BDF8);
            cv.drawRect(x, base2 - bh, x + bw, base2, p);
            if (wkts[i] > 0) cv.drawText(String.valueOf(wkts[i]), x + bw / 2, base2 - bh - Ui.dp(getContext(), 1), lab);
        }
    }
}
