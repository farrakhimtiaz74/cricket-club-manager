package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class LeagueScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);
        // Batch H (idea 79): the full season calendar lives one tap away
        LinearLayout calCard = Ui.card(act);
        android.widget.Button calBtn = Ui.darkBtn(act, "📅 Season Calendar — every fixture by day");
        calBtn.setOnClickListener(v -> { act.calendarMode = true; act.render(); });
        calCard.addView(calBtn);
        root.addView(calCard);
        root.addView(tableCard(act, g, "Group A", g.groupA()));
        root.addView(tableCard(act, g, "Group B", g.groupB()));

        // Batch E (idea 45): Road to Playoffs — once Lahore are 3+ games in
        JSONObject qual = g.qualificationInfo();
        if (qual.optInt("played", 0) >= 3 || g.playoffPhase > 0) {
            LinearLayout rc = Ui.card(act);
            rc.addView(Ui.h2(act, "🛣 Road to Playoffs"));
            String grpName = "A";
            for (String t : g.groupB()) if (t.equals(g.userTeam)) grpName = "B";
            rc.addView(Ui.text(act, g.userTeam + ": " + qual.optInt("pos") + ordinalSuffix(qual.optInt("pos"))
                    + " in Group " + grpName + " · " + qual.optInt("pts") + " pts · " + qual.optInt("remaining")
                    + " match(es) left · max " + qual.optInt("maxPts") + " pts", 13, Ui.INK, true));
            rc.addView(Ui.text(act, qual.optString("line"), 13,
                    "qualified".equals(qual.optString("state")) ? Ui.GREEN
                            : "eliminated".equals(qual.optString("state")) ? Ui.RED : Ui.GOLD, false));
            root.addView(rc);
        }

        // Batch E (idea 41): the Playoffs section, once the bracket exists
        if (g.playoffFixtures.length() > 0) {
            LinearLayout pc = Ui.card(act);
            pc.addView(Ui.h2(act, "🏆 Playoffs"));
            if (!g.seasonChampion.isEmpty()) {
                pc.addView(Ui.text(act, "Champions: " + g.seasonChampion, 14, Ui.GOLD, true));
            }
            for (int i = 0; i < g.playoffFixtures.length(); i++) {
                JSONObject f = g.playoffFixtures.optJSONObject(i);
                if (f == null) continue;
                boolean userGame = g.involvesUser(f);
                String line = f.optString("stage") + " · ";
                if (f.optBoolean("played")) line += f.optString("summary");
                else line += f.optString("home") + " vs " + f.optString("away") + (userGame ? "  — YOUR MATCH (Hub)" : "");
                TextView t = Ui.text(act, line, 13, userGame ? Ui.GOLD : Ui.MUTED, userGame);
                t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
                pc.addView(t);
            }
            root.addView(pc);
        }

        // Batch F (idea 56): the One-Day Cup bracket, once it exists
        if (g.cupFixtures.length() > 0) {
            LinearLayout cc = Ui.card(act);
            cc.addView(Ui.h2(act, "🏆 One-Day Cup (50 overs)"));
            if (!g.cupChampion.isEmpty()) {
                cc.addView(Ui.text(act, "Cup winners: " + g.cupChampion, 14,
                        g.userTeam.equals(g.cupChampion) ? Ui.GOLD : Ui.INK, true));
            }
            for (int i = 0; i < g.cupFixtures.length(); i++) {
                JSONObject f = g.cupFixtures.optJSONObject(i);
                if (f == null) continue;
                boolean userGame = g.involvesUser(f);
                String line = f.optString("stage") + " · ";
                if (f.optBoolean("played")) line += f.optString("summary");
                else line += f.optString("home") + " vs " + f.optString("away") + (userGame ? "  — YOUR TIE (Hub)" : "");
                TextView t = Ui.text(act, line, 13, userGame ? Ui.GOLD : Ui.MUTED, userGame);
                t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
                cc.addView(t);
            }
            root.addView(cc);
        }

        // Batch E (idea 43): tournament leaderboards, ALL teams' players
        if (g.tournBook.length() > 0) {
            LinearLayout tc = Ui.card(act);
            tc.addView(Ui.h2(act, "📊 Tournament Leaders"));
            leaderLines(act, tc, g, "Most Runs", 0, 5);
            leaderLines(act, tc, g, "Most Wickets", 1, 5);
            leaderLines(act, tc, g, "Best Strike Rate (60+ balls)", 2, 3);
            leaderLines(act, tc, g, "Best Economy (6+ overs)", 3, 3);
            leaderLines(act, tc, g, "MVP Race", 4, 5);
            // Batch J (idea 98): the full tournament book as a spreadsheet file
            Button expT = Ui.darkBtn(act, "📤 Export Tournament Stats (CSV)");
            expT.setOnClickListener(v -> act.shareTextFile("tournament-stats.csv",
                    CsvExport.tournamentCsv(act.g), "text/csv"));
            tc.addView(expT);
            root.addView(tc);
        }

        // Batch E (idea 46): head-to-head history vs every opponent
        LinearLayout hc = Ui.card(act);
        hc.addView(Ui.h2(act, "⚔ Head-to-Head (all seasons)"));
        hc.addView(Ui.small(act, "Tap a team for the full record."));
        java.util.List<String> opps = new java.util.ArrayList<>();
        for (String t : g.allTeams()) if (!t.equals(g.userTeam)) opps.add(t);
        for (final String opp : opps) {
            JSONObject h = g.h2h.optJSONObject(opp);
            String line;
            if (h == null) {
                line = opp + " — no meetings yet";
            } else {
                line = opp + " — P" + h.optInt("p") + " · W" + h.optInt("w") + " · L" + h.optInt("l")
                        + (h.optString("last").isEmpty() ? "" : " · Last 5: " + h.optString("last"));
            }
            TextView t = Ui.text(act, line, 13, Ui.INK, false);
            t.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
            t.setOnClickListener(v -> {
                JSONObject hh = g.h2h.optJSONObject(opp);
                String msg = hh == null
                        ? g.userTeam + " have not faced " + opp + " yet."
                        : "Played " + hh.optInt("p") + " · Won " + hh.optInt("w") + " · Lost " + hh.optInt("l")
                        + (hh.optString("last").isEmpty() ? ""
                        : "\nLast 5 results (newest first): " + hh.optString("last"));
                new android.app.AlertDialog.Builder(act)
                        .setTitle(g.userTeam + " vs " + opp)
                        .setMessage(msg)
                        .setPositiveButton("Close", null)
                        .show();
            });
            hc.addView(t);
        }
        root.addView(hc);

        LinearLayout fx = Ui.card(act);
        fx.addView(Ui.h2(act, "Fixtures"));
        for (int i = 0; i < g.fixtures.length(); i++) {
            JSONObject f = g.fixtures.optJSONObject(i);
            if (f == null) continue;
            boolean userGame = g.involvesUser(f);
            String line;
            if (f.optBoolean("played")) {
                line = "Day " + f.optInt("day") + " · " + f.optString("summary");
            } else {
                Game.ensureFixtureMeta(f, g.season);
                line = "Day " + f.optInt("day") + " · " + f.optString("home") + " vs " + f.optString("away")
                        + " · " + f.optString("ground");
                if (g.isDerby(f)) line += " · 🔥 DERBY";
                if (f.optInt("day") == g.day) line += "  (today)";
            }
            TextView t = Ui.text(act, line, 13, userGame ? Ui.GOLD : Ui.MUTED, userGame);
            t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
            fx.addView(t);
        }
        root.addView(fx);
        return root;
    }

    private static View tableCard(final MainActivity act, final Game g, String title, String[] teams) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, title));
        card.addView(row(act, "Team", "P", "W", "L", "NRR", "PTS", true, false));
        List<String> sorted = g.sortedGroup(teams);
        for (String team : sorted) {
            JSONObject r = g.tables.optJSONObject(team);
            if (r == null) continue;
            boolean user = g.userTeam.equals(team);
            card.addView(row(act, g.shortFor(team) + "  " + team,
                    String.valueOf(r.optInt("p")), String.valueOf(r.optInt("w")),
                    String.valueOf(r.optInt("l")),
                    String.format(Locale.US, "%+.2f", g.nrr(team)),
                    String.valueOf(r.optInt("pts")), false, user));
        }
        return card;
    }

    /** Batch E (idea 43): one leaderboard block inside the Leaders card. */
    private static void leaderLines(MainActivity act, LinearLayout card, Game g,
                                    String title, int cat, int topN) {
        List<JSONObject> rows = g.tournLeaders(cat);
        if (rows.isEmpty()) return;
        card.addView(Ui.gold(act, title, 13));
        int n = Math.min(topN, rows.size());
        for (int i = 0; i < n; i++) {
            JSONObject r = rows.get(i);
            String val;
            switch (cat) {
                case 0: val = r.optInt("runs") + " runs (" + r.optInt("balls") + " balls)"; break;
                case 1: val = r.optInt("wkts") + " wkts"; break;
                case 2: val = String.format(Locale.US, "SR %.0f", r.optInt("balls") == 0 ? 0
                        : r.optInt("runs") * 100.0 / r.optInt("balls")); break;
                case 3: val = String.format(Locale.US, "Econ %.2f", r.optInt("bwBalls") == 0 ? 0
                        : r.optInt("conc") * 6.0 / r.optInt("bwBalls")); break;
                default: val = Game.mvpPoints(r) + " pts"; break;
            }
            boolean lahore = g.userTeam.equals(r.optString("team"));
            TextView t = Ui.text(act, (i + 1) + ". " + r.optString("name") + " (" + g.shortFor(r.optString("team"))
                    + ") — " + val, 13, lahore ? Ui.GOLD : Ui.INK, lahore);
            t.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 2));
            card.addView(t);
        }
    }

    private static String ordinalSuffix(int n) {
        if (n == 1) return "st";
        if (n == 2) return "nd";
        if (n == 3) return "rd";
        return "th";
    }

    private static View row(MainActivity act, String team, String p, String w, String l,
                            String nrr, String pts, boolean header, boolean highlight) {
        LinearLayout row = Ui.row(act);
        row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
        int color = header ? Ui.MUTED : highlight ? Ui.GOLD : Ui.INK;
        TextView t = Ui.text(act, team, 13, color, header || highlight);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(t);
        String[] cells = {p, w, l, nrr, pts};
        for (String c : cells) {
            TextView tv = Ui.text(act, c, 13, color, header || highlight);
            tv.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
            tv.setGravity(Gravity.END);
            row.addView(tv);
        }
        return row;
    }
}
