package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class LeagueScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);
        root.addView(tableCard(act, g, "Group A", Data.GROUP_A));
        root.addView(tableCard(act, g, "Group B", Data.GROUP_B));

        LinearLayout fx = Ui.card(act);
        fx.addView(Ui.h2(act, "Fixtures"));
        for (int i = 0; i < g.fixtures.length(); i++) {
            JSONObject f = g.fixtures.optJSONObject(i);
            if (f == null) continue;
            boolean userGame = Game.involvesUser(f);
            String line;
            if (f.optBoolean("played")) {
                line = "Day " + f.optInt("day") + " · " + f.optString("summary");
            } else {
                line = "Day " + f.optInt("day") + " · " + f.optString("home") + " vs " + f.optString("away");
                if (f.optInt("day") == g.day) line += "  (today)";
            }
            TextView t = Ui.text(act, line, 13, userGame ? Ui.GOLD : Ui.MUTED, userGame);
            t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
            fx.addView(t);
        }
        root.addView(fx);
        return root;
    }

    private static View tableCard(final MainActivity act, final Game g, String title, String[] teams) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, title));
        card.addView(row(act, "Team", "P", "W", "L", "NRR", "PTS", true, false));
        List<String> sorted = new ArrayList<>();
        Collections.addAll(sorted, teams);
        Collections.sort(sorted, (a, b) -> {
            JSONObject ra = g.tables.optJSONObject(a), rb = g.tables.optJSONObject(b);
            int pa = ra == null ? 0 : ra.optInt("pts"), pb = rb == null ? 0 : rb.optInt("pts");
            if (pb != pa) return pb - pa;
            return Double.compare(g.nrr(b), g.nrr(a));
        });
        for (String team : sorted) {
            JSONObject r = g.tables.optJSONObject(team);
            if (r == null) continue;
            boolean user = Data.USER_TEAM.equals(team);
            card.addView(row(act, Data.shortName(team) + "  " + team,
                    String.valueOf(r.optInt("p")), String.valueOf(r.optInt("w")),
                    String.valueOf(r.optInt("l")),
                    String.format(Locale.US, "%+.2f", g.nrr(team)),
                    String.valueOf(r.optInt("pts")), false, user));
        }
        return card;
    }

    private static View row(MainActivity act, String team, String p, String w, String l,
                            String nrr, String pts, boolean header, boolean highlight) {
        LinearLayout row = Ui.row(act);
        row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
        int color = header ? Ui.MUTED : highlight ? Ui.GOLD : Ui.INK;
        TextView t = Ui.text(act, team, 13, color, header || highlight);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(t);
        String[] cells = {p, w, l, nrr, pts};
        for (String c : cells) {
            TextView tv = Ui.text(act, c, 13, color, header || highlight);
            tv.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
            tv.setGravity(Gravity.END);
            row.addView(tv);
        }
        return row;
    }
}
