package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class LeagueScreen {
 public static View build(final MainActivity act) {
 final Game g = act.g;
 LinearLayout root = Ui.col(act);
 // Design Batch (item 6): matching section headers, League style
 root.addView(Ui.sectionHeader(act, "SEASON"));
 // v20.1 (item 4): the grass strip now CARRIES the season line —
 // v20 shipped it as an empty green band. The line is always true
 // (position comes from the live sorted group), so the strip is
 // never empty; if the texture fails, a deep-pitch band carries
 // the same text. Season · Day · club: position in Group.
 {
 JSONObject qi = g.qualificationInfo();
 String grpName = "A";
 for (String t : g.groupB()) if (t.equals(g.userTeam)) grpName = "B";
 String line = "Season " + g.season + " · Day " + g.day + " · " + g.userTeam + ": "
 + qi.optInt("pos", 1) + ordinalSuffix(qi.optInt("pos", 1)) + " in Group " + grpName;
 LinearLayout band = Ui.row(act);
 band.setGravity(Gravity.CENTER_VERTICAL);
 band.setPadding(Ui.dp(act, 12), 0, Ui.dp(act, 12), 0);
 android.graphics.Bitmap grassBmp = Art.bitmap(act, Art.TEX_GRASS, 720);
 if (grassBmp != null) {
 android.graphics.drawable.BitmapDrawable gd =
 new android.graphics.drawable.BitmapDrawable(act.getResources(), grassBmp);
 gd.setAlpha(120);
 gd.setGravity(Gravity.FILL);
 band.setBackground(new android.graphics.drawable.LayerDrawable(
 new android.graphics.drawable.Drawable[]{
 new android.graphics.drawable.ColorDrawable(Ui.PITCH_DEEP), gd}));
 } else {
 band.setBackgroundColor(Ui.PITCH_DEEP);
 }
 // v21 item 15: the original League emblem rides the season band
 android.graphics.Bitmap emb = Art.bitmapAlpha(act, Art.EMBLEM_LEAGUE, 96);
 if (emb != null) {
 android.widget.ImageView eiv = new android.widget.ImageView(act);
 eiv.setImageBitmap(emb);
 LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(Ui.dp(act, 24), Ui.dp(act, 24));
 elp.setMargins(0, 0, Ui.dp(act, 8), 0);
 eiv.setLayoutParams(elp);
 band.addView(eiv);
 }
 TextView lt = Ui.text(act, line, 12.5f, Ui.INK, true);
 lt.setSingleLine(true);
 lt.setEllipsize(android.text.TextUtils.TruncateAt.END);
 band.addView(lt);
 LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
 ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 34));
 blp.setMargins(0, 0, 0, Ui.dp(act, 10));
 band.setLayoutParams(blp);
 root.addView(band);
 }
 // Batch H (idea 79): the full season calendar lives one tap away
 LinearLayout calCard = Ui.card(act);
 android.widget.Button calBtn = Ui.darkBtn(act, "Season Calendar — every fixture by day");
 calBtn.setOnClickListener(v -> { act.calendarMode = true; act.render(); });
 calCard.addView(calBtn);
 root.addView(calCard);
 root.addView(Ui.sectionHeader(act, "LEAGUE TABLES"));
 root.addView(tableCard(act, g, "Group A", g.groupA()));
 root.addView(tableCard(act, g, "Group B", g.groupB()));

 // Batch E (idea 45): Road to Playoffs — once Lahore are 3+ games in
 JSONObject qual = g.qualificationInfo();
 if (qual.optInt("played", 0) >= 3 || g.playoffPhase > 0) {
 LinearLayout rc = Ui.card(act);
 rc.addView(Ui.h2(act, "Road to Playoffs"));
 String grpName = "A";
 for (String t : g.groupB()) if (t.equals(g.userTeam)) grpName = "B";
 rc.addView(Ui.text(act, g.userTeam + ": " + qual.optInt("pos") + ordinalSuffix(qual.optInt("pos"))
 + " in Group " + grpName + " · " + qual.optInt("pts") + " pts · " + qual.optInt("remaining")
 + " match(es) left · max " + qual.optInt("maxPts") + " pts", 13, Ui.INK, true));
 rc.addView(Ui.text(act, qual.optString("line"), 13,
 "qualified".equals(qual.optString("state")) ? Ui.GREEN
 : "eliminated".equals(qual.optString("state")) ? Ui.RED : Ui.GOLD, false));
 root.addView(rc);
 }

 // Batch E (idea 41): the Playoffs section, once the bracket exists
 if (g.playoffFixtures.length() > 0 || g.cupFixtures.length() > 0) {
 root.addView(Ui.sectionHeader(act, "KNOCKOUTS & CUP"));
 }
 if (g.playoffFixtures.length() > 0) {
 LinearLayout pc = Ui.card(act);
 pc.addView(Ui.h2(act, "Playoffs"));
 if (!g.seasonChampion.isEmpty()) {
 pc.addView(Ui.text(act, "Champions: " + g.seasonChampion, 14, Ui.GOLD, true));
 }
 for (int i = 0; i < g.playoffFixtures.length(); i++) {
 final JSONObject f = g.playoffFixtures.optJSONObject(i);
 if (f == null) continue;
 boolean userGame = g.involvesUser(f);
 String line = f.optString("stage") + " · ";
 if (f.optBoolean("played")) line += f.optString("summary");
 else line += f.optString("home") + " vs " + f.optString("away") + (userGame ? " — YOUR MATCH (Hub)" : "");
 TextView t = Ui.text(act, line, 13, userGame ? Ui.GOLD : Ui.MUTED, userGame);
 t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
 // P2 (suggestion 17): tap → the shared fixture sheet
 t.setOnClickListener(v -> CalendarScreen.fixtureSheet(act,
 sheetRow(g, f, f.optString("stage")), f.optInt("day")));
 pc.addView(t);
 }
 root.addView(pc);
 }

 // Batch F (idea 56): the One-Day Cup bracket, once it exists
 if (g.cupFixtures.length() > 0) {
 LinearLayout cc = Ui.card(act);
 // v21 item 15: the original Cup emblem beside the cup title
 {
 android.graphics.Bitmap cemb = Art.bitmapAlpha(act, Art.EMBLEM_CUP, 96);
 if (cemb != null) {
 LinearLayout trow = Ui.row(act);
 android.widget.ImageView civ = new android.widget.ImageView(act);
 civ.setImageBitmap(cemb);
 LinearLayout.LayoutParams clp2 = new LinearLayout.LayoutParams(Ui.dp(act, 26), Ui.dp(act, 29));
 clp2.setMargins(0, 0, Ui.dp(act, 8), 0);
 civ.setLayoutParams(clp2);
 trow.addView(civ);
 trow.addView(Ui.h2(act, "One-Day Cup (50 overs)"));
 cc.addView(trow);
 } else {
 cc.addView(Ui.h2(act, "One-Day Cup (50 overs)"));
 }
 }
 if (!g.cupChampion.isEmpty()) {
 cc.addView(Ui.text(act, "Cup winners: " + g.cupChampion, 14,
 g.userTeam.equals(g.cupChampion) ? Ui.GOLD : Ui.INK, true));
 }
 for (int i = 0; i < g.cupFixtures.length(); i++) {
 final JSONObject f = g.cupFixtures.optJSONObject(i);
 if (f == null) continue;
 boolean userGame = g.involvesUser(f);
 String line = f.optString("stage") + " · ";
 if (f.optBoolean("played")) line += f.optString("summary");
 else line += f.optString("home") + " vs " + f.optString("away") + (userGame ? " — YOUR TIE (Hub)" : "");
 TextView t = Ui.text(act, line, 13, userGame ? Ui.GOLD : Ui.MUTED, userGame);
 t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
 // P2 (suggestion 17): tap → the shared fixture sheet
 t.setOnClickListener(v -> CalendarScreen.fixtureSheet(act,
 sheetRow(g, f, "One-Day Cup · " + f.optString("stage")), f.optInt("day")));
 cc.addView(t);
 }
 root.addView(cc);
 }

 // Batch E (idea 43): tournament leaderboards, ALL teams' players
 if (g.tournBook.length() > 0) {
 root.addView(Ui.sectionHeader(act, "STATS & RECORDS"));
 LinearLayout tc = Ui.card(act);
 tc.addView(Ui.h2(act, "Tournament Leaders"));
 leaderLines(act, tc, g, "Most Runs", 0, 5);
 leaderLines(act, tc, g, "Most Wickets", 1, 5);
 leaderLines(act, tc, g, "Best Strike Rate (60+ balls)", 2, 3);
 leaderLines(act, tc, g, "Best Economy (6+ overs)", 3, 3);
 leaderLines(act, tc, g, "MVP Race", 4, 5);
 // v21 (deletion D5): the CSV export button is gone with the CSV exporter.
 root.addView(tc);
 }

 // Batch E (idea 46): head-to-head history vs every opponent
 if (g.tournBook.length() == 0) root.addView(Ui.sectionHeader(act, "STATS & RECORDS"));
 LinearLayout hc = Ui.card(act);
 hc.addView(Ui.h2(act, "Head-to-Head (all seasons)"));
 hc.addView(Ui.small(act, "Tap a team for the full record."));
 java.util.List<String> opps = new java.util.ArrayList<>();
 for (String t : g.allTeams()) if (!t.equals(g.userTeam)) opps.add(t);
 for (final String opp : opps) {
 JSONObject h = g.h2h.optJSONObject(opp);
 String line;
 if (h == null) {
 line = opp + " — no meetings yet";
 } else {
 line = opp + " — P" + h.optInt("p") + " · W" + h.optInt("w") + " · L" + h.optInt("l")
 + (h.optString("last").isEmpty() ? "" : " · Last 5: " + h.optString("last"));
 }
 TextView t = Ui.text(act, line, 13, Ui.INK, false);
 t.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
 t.setOnClickListener(v -> {
 JSONObject hh = g.h2h.optJSONObject(opp);
 String msg = hh == null
 ? g.userTeam + " have not faced " + opp + " yet."
 : "Played " + hh.optInt("p") + " · Won " + hh.optInt("w") + " · Lost " + hh.optInt("l")
 + (hh.optString("last").isEmpty() ? ""
 : "\nLast 5 results (newest first): " + hh.optString("last"));
 new android.app.AlertDialog.Builder(act)
 .setTitle(g.userTeam + " vs " + opp)
 .setMessage(msg)
 .setPositiveButton("Close", null)
 .show();
 });
 // Design Batch (item 9b): the opponent's crest leads the row
 LinearLayout hrow = Ui.row(act);
 hrow.addView(CrestView.forTeam(act, g, opp, 20));
 View hgap = new View(act);
 hgap.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 8), 1));
 hrow.addView(hgap);
 t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 hrow.addView(t);
 hc.addView(hrow);
 }
 root.addView(hc);

 root.addView(Ui.sectionHeader(act, "FIXTURES"));
 LinearLayout fx = Ui.card(act);
 fx.addView(Ui.h2(act, "Fixtures"));
 // P2 (suggestions 17/18): league fixtures are list rows — home
 // crest, the pairing, the result/ground line under it, a
 // right-aligned state — and every row taps into the shared
 // fixture sheet (the same one the Calendar uses).
 for (int i = 0; i < g.fixtures.length(); i++) {
 final JSONObject f = g.fixtures.optJSONObject(i);
 if (f == null) continue;
 boolean played = f.optBoolean("played");
 if (!played) Game.ensureFixtureMeta(f, g.season);
 String sub;
 if (played) {
 sub = f.optString("summary");
 } else {
 sub = "Day " + f.optInt("day") + " · " + f.optString("ground");
 if (g.isDerby(f)) sub += " · DERBY";
 if (f.optInt("day") == g.day) sub += " · today";
 }
 fx.addView(Ui.listRow(act, CrestView.forTeam(act, g, f.optString("home"), 24),
 g.shortFor(f.optString("home")) + " vs " + g.shortFor(f.optString("away")),
 sub, played ? "FT" : "DAY " + f.optInt("day"),
 v -> CalendarScreen.fixtureSheet(act, sheetRow(g, f, "T20 League"), f.optInt("day"))));
 }
 root.addView(fx);
 return root;
 }

 /** P2 (suggestion 17): a calendar-shaped row for the shared
 *  fixture sheet, built from any fixture object (league, playoff
 *  or cup — they all carry home/away/played/summary). */
 private static JSONObject sheetRow(Game g, JSONObject f, String tag) {
 JSONObject r = new JSONObject();
 try {
 r.put("tag", tag);
 r.put("home", f.optString("home"));
 r.put("away", f.optString("away"));
 r.put("user", g.involvesUser(f));
 r.put("played", f.optBoolean("played"));
 r.put("text", f.optBoolean("played") ? f.optString("summary")
 : f.optString("home") + " vs " + f.optString("away"));
 } catch (Exception ignored) {}
 return r;
 }

 private static View tableCard(final MainActivity act, final Game g, String title, String[] teams) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, title));
 card.addView(row(act, null, "Team", "P", "W", "L", "NRR", "PTS", true, false));
 List<String> sorted = g.sortedGroup(teams);
 // P4 (suggestion 38): movement vs the table as it stood before
 // the most recent round — replayed from the group fixtures by
 // Present (runtime only; empty until two rounds are in)
 final java.util.Map<String, Integer> move = Present.movement(g.fixtures, teams, sorted);
 final List<String> sortedF = sorted;
 // v21 item 9: table rows build through the RecycleList pool
 card.addView(RecycleList.build(act, sorted, 6, new RecycleList.Binder<String>() {
 @Override public View create(android.content.Context c) {
 return new android.widget.FrameLayout(c);
 }
 @Override public void bind(View row, String team, int index) {
 JSONObject r = g.tables.optJSONObject(team);
 android.widget.FrameLayout host = (android.widget.FrameLayout) row;
 host.removeAllViews();
 if (r != null) host.addView(tableRow(act, g, team, r, sortedF, move, g.userTeam.equals(team)));
 }
 }, null));
 return card;
 }

 /** P4 (suggestion 38): a table row with the movement marker beside
 *  the name (▲2 green / ▼1 red / ● muted, from Present.movementText)
 *  and the last-5 form dots under it (green W, red L, slate T —
 *  Present.formDots over the league fixtures). */
 private static View tableRow(MainActivity act, Game g, String team, JSONObject r,
 List<String> sorted, java.util.Map<String, Integer> move, boolean user) {
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
 int color = user ? Ui.GOLD : Ui.INK;
 row.addView(CrestView.forTeam(act, g, team, 18));
 View gap = new View(act);
 gap.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 7), 1));
 row.addView(gap);
 LinearLayout nameCol = Ui.col(act);
 nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 LinearLayout nameRow = Ui.row(act);
 TextView t = Ui.text(act, g.shortFor(team) + " " + team, 13, color, true);
 nameRow.addView(t);
 Integer mv = move.get(team);
 if (mv != null) {
 TextView mtv = Ui.text(act, " " + Present.movementText(mv), 11,
 mv > 0 ? Ui.GREEN : mv < 0 ? Ui.RED : Ui.MUTED, true);
 nameRow.addView(mtv);
 }
 nameCol.addView(nameRow);
 String dots = Present.formDots(g.fixtures, team);
 if (!dots.isEmpty()) {
 LinearLayout dRow = new LinearLayout(act);
 dRow.setOrientation(LinearLayout.HORIZONTAL);
 dRow.setPadding(0, Ui.dp(act, 3), 0, 0);
 for (int i = 0; i < dots.length(); i++) {
 char ch = dots.charAt(i);
 View d = new View(act);
 int dc = ch == 'W' ? Ui.GREEN : ch == 'L' ? Ui.RED : Ui.MUTED;
 d.setBackground(Ui.round(dc, 5, act));
 LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(Ui.dp(act, 9), Ui.dp(act, 9));
 dlp.setMargins(0, 0, Ui.dp(act, 3), 0);
 d.setLayoutParams(dlp);
 dRow.addView(d);
 }
 nameCol.addView(dRow);
 }
 row.addView(nameCol);
 String[] cells = {String.valueOf(r.optInt("p")), String.valueOf(r.optInt("w")),
 String.valueOf(r.optInt("l")),
 String.format(Locale.US, "%+.2f", g.nrr(team)),
 String.valueOf(r.optInt("pts"))};
 for (String c : cells) {
 TextView tv = Ui.display(act, c, 12.5f, color);
 tv.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
 tv.setGravity(Gravity.END);
 row.addView(tv);
 }
 return row;
 }

 /** Batch E (idea 43): one leaderboard block inside the Leaders card. */
 private static void leaderLines(MainActivity act, LinearLayout card, Game g,
 String title, int cat, int topN) {
 List<JSONObject> rows = g.tournLeaders(cat);
 if (rows.isEmpty()) return;
 card.addView(Ui.gold(act, title, 13));
 int n = Math.min(topN, rows.size());
 for (int i = 0; i < n; i++) {
 JSONObject r = rows.get(i);
 String val;
 switch (cat) {
 case 0: val = r.optInt("runs") + " runs (" + r.optInt("balls") + " balls)"; break;
 case 1: val = r.optInt("wkts") + " wkts"; break;
 case 2: val = String.format(Locale.US, "SR %.0f", r.optInt("balls") == 0 ? 0
 : r.optInt("runs") * 100.0 / r.optInt("balls")); break;
 case 3: val = String.format(Locale.US, "Econ %.2f", r.optInt("bwBalls") == 0 ? 0
 : r.optInt("conc") * 6.0 / r.optInt("bwBalls")); break;
 default: val = Game.mvpPoints(r) + " pts"; break;
 }
 boolean lahore = g.userTeam.equals(r.optString("team"));
 TextView t = Ui.text(act, (i + 1) + ". " + r.optString("name") + " (" + g.shortFor(r.optString("team"))
 + ") — " + val, 13, lahore ? Ui.GOLD : Ui.INK, lahore);
 t.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 2));
 card.addView(t);
 }
 }

 private static String ordinalSuffix(int n) {
 if (n == 1) return "st";
 if (n == 2) return "nd";
 if (n == 3) return "rd";
 return "th";
 }

 private static View row(MainActivity act, View crest, String team, String p, String w, String l,
 String nrr, String pts, boolean header, boolean highlight) {
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
 int color = header ? Ui.MUTED : highlight ? Ui.GOLD : Ui.INK;
 // Design Batch (item 9b): crest before the team name (data rows)
 if (crest != null) {
 row.addView(crest);
 View gap = new View(act);
 gap.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 7), 1));
 row.addView(gap);
 }
 TextView t = Ui.text(act, team, 13, color, header || highlight);
 t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(t);
 String[] cells = {p, w, l, nrr, pts};
 for (int ci = 0; ci < cells.length; ci++) {
 String c = cells[ci];
 // item 4: table numbers are display numerals, right-aligned
 TextView tv = Ui.display(act, c, 12.5f, color);
 tv.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
 tv.setGravity(Gravity.END);
 row.addView(tv);
 if (header && ci == 3) {
 // P5 (suggestion 44): the NRR header carries the info badge —
 // tap it for the plain-English run-rate explanation
 View badge = Ui.infoBadge(act, "NRR");
 LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
 Ui.dp(act, 17), Ui.dp(act, 17));
 blp.setMargins(Ui.dp(act, 3), 0, 0, 0);
 badge.setLayoutParams(blp);
 row.addView(badge);
 }
 }
 return row;
 }
}
