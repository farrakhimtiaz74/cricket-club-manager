package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/** Audio engine. v19 synthesized PCM at runtime; v20 moved to real
 *  produced OGG files with the synthesizer kept as a fallback; v21
 *  (deletion D2) finishes the job — the runtime synthesizer class is GONE and
 *  every sound is a file: the two loops that were still synthesized
 *  (rain patter, tension throb) were rendered to rain.ogg /
 *  tension.ogg by tools/make_assets21.py, and the sound-id constants
 *  plus the pure routing helpers that lived in the synthesizer now live
 *  here (same names, same values — call sites unchanged in spirit).
 *
 *  Voice (v21 item 2, replacing the deleted Android-TTS path D1):
 *  speak() runs the line through VoiceLine (pure) and plays the
 *  returned clip sequence on one MediaPlayer, completion-chained,
 *  at the Voice channel's gain. Lines the pack cannot speak stay
 *  silent. DEFAULT OFF (Settings.voiceOn), like the old toggle.
 *
 *  Every v19/v20 rule still applies:
 *   - lazy: nothing loads until the first sound is asked for;
 *   - safe: EVERY call is wrapped — audio never touches gameplay;
 *   - polite: STREAM_MUSIC everywhere; a silent/vibrate ringer
 *     means nothing is forced;
 *   - gated: Settings.audioGate (master, channels, Quiet Mode, the
 *     live-path rule) decides before anything plays;
 *   - a file that fails to load simply never plays — there is no
 *     fallback engine anymore, by design;
 *   - loops stop onPause (MainActivity), release onDestroy. */
public class SoundEngine {

    // ---- sound ids (absorbed from the deleted synthesizer; the
    // values are unchanged so every existing mapping still holds) ----
    public static final int BAT0 = 1, BAT1 = 2, BAT2 = 3, STUMPS = 4, PADS = 5;
    public static final int SWELL1 = 6, SWELL2 = 7, SWELL3 = 8, GROAN = 9, APPLAUSE = 10;
    public static final int STING_WICKET = 11, STING_WIN = 12, STING_TITLE = 13,
            STING_ACHIEVE = 14, STING_LEVELUP = 15;
    public static final int UI_CLICK = 16, UI_CONFIRM = 17, UI_BLOCKED = 18,
            BID_TICK = 19, GAVEL = 20, CASH = 21, WHISTLE = 22;

    /** Which mixer channel a sound belongs to. SWELL/GROAN/APPLAUSE
     *  are crowd; UI + auction ticks are UI; win/title/achieve
     *  stings ride the Music channel; everything else is Match. */
    public static int channelFor(int id) {
        switch (id) {
            case SWELL1: case SWELL2: case SWELL3: case GROAN: case APPLAUSE:
                return Settings.CH_CROWD;
            case UI_CLICK: case UI_CONFIRM: case UI_BLOCKED:
            case BID_TICK: case GAVEL: case CASH:
                return Settings.CH_UI;
            case STING_WIN: case STING_TITLE: case STING_ACHIEVE: case STING_LEVELUP:
                return Settings.CH_MUSIC;
            default:
                return Settings.CH_MATCH;
        }
    }

    /** The events Quiet Mode still lets through. */
    public static boolean isBigEvent(int id) {
        switch (id) {
            case BAT2: case STUMPS: case STING_WICKET:
            case SWELL2: case SWELL3: case GROAN:
            case STING_WIN: case STING_TITLE: case STING_LEVELUP:
                return true;
            default:
                return false;
        }
    }

    /** How hard a ball outcome hits: 0 soft, 1 firm, 2 boundary,
     *  -1 not a bat event. */
    public static int batWeightFor(String ball) {
        if (ball == null) return -1;
        switch (ball) {
            case "0": case "1": return 0;
            case "2": case "3": return 1;
            case "4": case "6": return 2;
            default: return -1;
        }
    }

    public static int batIdForWeight(int w) {
        return w == 0 ? BAT0 : w == 1 ? BAT1 : BAT2;
    }

    /** Dismissal flavour: 0 other, 1 bowled, 2 lbw, 3 run out. */
    public static int dismissalKind(String how) {
        if (how == null) return 0;
        String h = how.toLowerCase(java.util.Locale.ROOT);
        if (h.contains("run out")) return 3;
        if (h.contains("lbw")) return 2;
        if (h.startsWith("b ")) return 1;
        return 0;
    }

    // crowd bed kinds for setBed()
    public static final int BED_HOME = 0, BED_AWAY = 1, BED_DERBY = 2;
    private static final String[] BED_FILES = {"crowd_home.ogg", "crowd_away.ogg", "crowd_derby.ogg"};
    private static final String[] MUSIC_FILES = {null, "music_menu.ogg", "music_match.ogg"};

    /** Sound id -> asset file (the produced file for that sound). */
    private static String fileFor(int id) {
        switch (id) {
            case BAT0: return "sfx_bat_soft.ogg";
            case BAT1: return "sfx_bat_hard.ogg";
            case BAT2: return "sfx_bat_hard.ogg";
            case STUMPS: return "sfx_stumps.ogg";
            case PADS: return "sfx_pad.ogg";
            case SWELL1: return "sfx_cheer.ogg";
            case SWELL2: return "sfx_cheer_big.ogg";
            case SWELL3: return "sfx_cheer_big.ogg";
            case GROAN: return "sfx_groan.ogg";
            case APPLAUSE: return "sfx_applause.ogg";
            case STING_WICKET: return "sting_win.ogg";
            case STING_WIN: return "sting_win.ogg";
            case STING_TITLE: return "sting_title.ogg";
            case STING_ACHIEVE: return "sting_achievement.ogg";
            case STING_LEVELUP: return "sting_win.ogg";
            case UI_CLICK: return "ui_click.ogg";
            case UI_CONFIRM: return "ui_confirm.ogg";
            case UI_BLOCKED: return "ui_blocked.ogg";
            case BID_TICK: return "ui_click.ogg";
            case GAVEL: return "gavel.ogg";
            case CASH: return "cash.ogg";
            case WHISTLE: return "sfx_whistle.ogg";
            default: return null;
        }
    }

    private final Context ctx;
    private final Settings st;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long lastClickAt = 0, lastTickAt = 0;

    // ---- file playback state ----
    private SoundPool pool;
    private final Map<Integer, Integer> poolIds = new HashMap<>(); // sound id -> pool sound id
    private final Map<Integer, Boolean> poolReady = new HashMap<>();

    // ---- MediaPlayer loops ----
    private MediaPlayer bedPlayer;   private int bedFileKind = -1;
    private MediaPlayer musicPlayer; private int musicFileKind = 0;
    private MediaPlayer rainPlayer;
    private MediaPlayer tensionPlayer;

    // ---- voice pack playback ----
    private MediaPlayer voicePlayer;
    private final Queue<String> voiceQueue = new ArrayDeque<>();

    public SoundEngine(Context ctx, Settings st) {
        this.ctx = ctx;
        this.st = st;
    }

    // ---------------- gates (unchanged since v19) ----------------

    private boolean ringerOk() {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            return am == null || am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
        } catch (Exception e) {
            return false;
        }
    }

    /** Full gate for a one-shot on a live (in-match) path. */
    public boolean canPlayLive(int id) {
        return Settings.audioGate(st.soundOn(), st.quietMode(), true, true,
                st.channelVol(channelFor(id)), isBigEvent(id))
                && ringerOk();
    }

    /** Full gate for a UI-context one-shot (menus, buttons, auctions). */
    public boolean canPlayUi(int id) {
        return Settings.audioGate(st.soundOn(), st.quietMode(), false, true,
                st.channelVol(channelFor(id)), isBigEvent(id))
                && ringerOk();
    }

    private float gainFor(int id) {
        return Math.max(0f, Math.min(1f, st.channelPercent(channelFor(id)) / 100f));
    }

    private float loopGain(int channel, float level) {
        return Math.max(0f, Math.min(1f,
                st.channelPercent(channel) / 100f * level));
    }

    // ---------------- one-shots (files only) ----------------

    private SoundPool pool() {
        if (pool == null) {
            try {
                pool = new SoundPool(8, AudioManager.STREAM_MUSIC, 0);
                pool.setOnLoadCompleteListener((p, soundId, status) -> {
                    for (Map.Entry<Integer, Integer> e : poolIds.entrySet()) {
                        if (e.getValue() == soundId) {
                            poolReady.put(e.getKey(), status == 0);
                        }
                    }
                });
            } catch (Exception e) {
                pool = null;
            }
        }
        return pool;
    }

    private int poolIdFor(int id) {
        Integer have = poolIds.get(id);
        if (have != null) return have;
        String file = fileFor(id);
        if (file == null || pool() == null) return -1;
        try {
            AssetFileDescriptor afd = ctx.getAssets().openFd("audio/" + file);
            int sid = pool.load(afd, 1);
            afd.close();
            poolIds.put(id, sid);
            poolReady.put(id, false);
            return sid;
        } catch (Exception e) {
            return -1;
        }
    }

    /** Play a one-shot from a live path (match events). */
    public void playLive(int id) {
        if (canPlayLive(id)) fire(id, gainFor(id));
    }

    /** Play a one-shot from a UI path (buttons, signings, auctions). */
    public void playUi(int id) {
        if (canPlayUi(id)) fire(id, gainFor(id));
    }

    /** Play regardless of path, still gated on master/channel/quiet —
     *  for Settings test buttons and post-match moments. */
    public void playDirect(int id) {
        if (Settings.audioGate(st.soundOn(), st.quietMode(), false, true,
                st.channelVol(channelFor(id)), isBigEvent(id))
                && ringerOk()) {
            fire(id, gainFor(id));
        }
    }

    private void fire(int id, float gain) {
        if (gain <= 0.01f) return;
        int sid = poolIdFor(id);
        if (sid > 0 && Boolean.TRUE.equals(poolReady.get(id))) {
            try {
                pool.play(sid, gain, gain, 1, 0, 1.0f);
            } catch (Exception ignored) {
                // a failed play is silent — decoration only
            }
        }
        // still decoding or failed to load: drop it. There is no
        // synthesized fallback anymore (v21 D2) — a missing file
        // means silence for that sound, never a crash.
    }

    /** UI click, throttled so rapid sim tapping doesn't machine-gun. */
    public void uiClick() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastClickAt < 120) return;
        lastClickAt = now;
        playUi(UI_CLICK);
    }

    /** Bid tick, throttled for quick-bid loops. */
    public void bidTick() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastTickAt < 90) return;
        lastTickAt = now;
        playUi(BID_TICK);
    }

    // ---------------- loops (MediaPlayer files) ----------------

    private MediaPlayer startPlayer(String file, float gain) {
        try {
            MediaPlayer mp = new MediaPlayer();
            AssetFileDescriptor afd = ctx.getAssets().openFd("audio/" + file);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mp.setLooping(true);
            mp.setVolume(gain, gain);
            mp.prepare();
            mp.start();
            return mp;
        } catch (Exception e) {
            return null;
        }
    }

    private MediaPlayer stopPlayer(MediaPlayer mp) {
        if (mp == null) return null;
        try { mp.stop(); } catch (Exception ignored) {}
        try { mp.release(); } catch (Exception ignored) {}
        return null;
    }

    /** Crowd bed under a live match. kind: BED_HOME / BED_AWAY /
     *  BED_DERBY; level: home ~0.55, away ~0.35, derby ~0.7 (the
     *  level still scales the Crowd channel). */
    public void setBed(boolean on, int kind, float level) {
        if (!on || !st.soundOn()) {
            bedPlayer = stopPlayer(bedPlayer); bedFileKind = -1;
            return;
        }
        float g = loopGain(Settings.CH_CROWD, level);
        if (g <= 0.01f) return;
        if (bedPlayer != null && bedFileKind != kind) { bedPlayer = stopPlayer(bedPlayer); bedFileKind = -1; }
        if (bedPlayer == null) {
            if (!ringerOk()) return;
            bedPlayer = startPlayer(BED_FILES[kind], g);
            if (bedPlayer != null) bedFileKind = kind;
        } else {
            try { bedPlayer.setVolume(g, g); } catch (Exception ignored) {}
        }
    }

    /** Music: kind 0 off, 1 menu theme, 2 match bed. */
    public void setMusic(int kind) {
        if (kind == 0 || !st.soundOn()) {
            musicPlayer = stopPlayer(musicPlayer); musicFileKind = 0;
            return;
        }
        float level = kind == 1 ? 0.55f : 0.45f;
        float g = loopGain(Settings.CH_MUSIC, level);
        if (g <= 0.01f) return;
        if (musicPlayer != null && musicFileKind != kind) { musicPlayer = stopPlayer(musicPlayer); musicFileKind = 0; }
        if (musicPlayer == null) {
            if (!ringerOk()) return;
            musicPlayer = startPlayer(MUSIC_FILES[kind], g);
            if (musicPlayer != null) musicFileKind = kind;
        }
    }

    /** Rain patter loop (rain.ogg since v21 — it was the last
     *  synthesized bed). Rides the Crowd channel. */
    public void setRain(boolean on) {
        if (!on || !st.soundOn()) { rainPlayer = stopPlayer(rainPlayer); return; }
        if (rainPlayer == null) {
            if (!ringerOk()) return;
            float g = loopGain(Settings.CH_CROWD, 0.5f);
            if (g > 0.01f) rainPlayer = startPlayer("rain.ogg", g);
        }
    }

    /** A short rain burst for the moment a delay lands (the engine
     *  applies rain instantly, so the patter plays over the break and
     *  stops itself). */
    public void rainBurst() {
        setRain(true);
        ui.postDelayed(() -> setRain(false), 3500);
    }

    /** Last-overs tension throb (tension.ogg since v21). Rides the
     *  Match channel. */
    public void setTension(boolean on) {
        if (!on || !st.soundOn()) { tensionPlayer = stopPlayer(tensionPlayer); return; }
        if (tensionPlayer == null) {
            if (!ringerOk()) return;
            float g = loopGain(Settings.CH_MATCH, 0.4f);
            if (g > 0.01f) tensionPlayer = startPlayer("tension.ogg", g);
        }
    }

    public void stopLoops() {
        bedPlayer = stopPlayer(bedPlayer); bedFileKind = -1;
        musicPlayer = stopPlayer(musicPlayer); musicFileKind = 0;
        rainPlayer = stopPlayer(rainPlayer);
        tensionPlayer = stopPlayer(tensionPlayer);
        stopSpeaking();
    }

    // ---------------- voice pack (v21 item 2) ----------------

    /** Speak a score line with the bundled Voice Pack: the line is
     *  decomposed by VoiceLine into a clip sequence (numbers stitched
     *  from composable clips) and chained on one MediaPlayer at the
     *  Voice channel's gain. A line the pack cannot speak (unknown
     *  pattern, custom club name) is silently skipped. English lines
     *  only — Roman Urdu commentary has no voice, as before. */
    public void speak(final String text) {
        if (!st.voiceOn() || !st.soundOn() || !ringerOk()) return;
        if (st.channelVol(Settings.CH_VOICE) <= 0) return;
        try {
            List<String> clips = VoiceLine.clipsFor(text);
            if (clips.isEmpty()) return;
            stopSpeaking();
            voiceQueue.addAll(clips);
            playNextClip();
        } catch (Exception ignored) {}
    }

    private void playNextClip() {
        final String asset = voiceQueue.poll();
        if (asset == null) {
            voicePlayer = stopPlayer(voicePlayer);
            return;
        }
        try {
            if (voicePlayer == null) voicePlayer = new MediaPlayer();
            else voicePlayer.reset();
            AssetFileDescriptor afd = ctx.getAssets().openFd(asset);
            voicePlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            voicePlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            float v = Math.max(0f, Math.min(1f, st.channelPercent(Settings.CH_VOICE) / 100f));
            voicePlayer.setVolume(v, v);
            voicePlayer.setOnCompletionListener(mp -> playNextClip());
            voicePlayer.setOnErrorListener((mp, what, extra) -> {
                playNextClip();
                return true;
            });
            voicePlayer.prepare();
            voicePlayer.start();
        } catch (Exception e) {
            // a missing/corrupt clip ends this line, nothing more
            voiceQueue.clear();
            voicePlayer = stopPlayer(voicePlayer);
        }
    }

    public void stopSpeaking() {
        voiceQueue.clear();
        voicePlayer = stopPlayer(voicePlayer);
    }

    // ---------------- lifecycle ----------------

    public void release() {
        stopLoops();
        try { if (pool != null) { pool.release(); pool = null; } } catch (Exception ignored) {}
    }
}
