package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Audio Pack (v19) built this engine around runtime-synthesized PCM.
 *  Rich Media Edition (v20) upgrades it to REAL FILE playback: the
 *  produced OGG assets under assets/audio/ (see tools/make_assets.py)
 *  are played through a SoundPool (short SFX) and MediaPlayers
 *  (looping crowd beds + music). SoundSynth survives ONLY as the
 *  fallback: if a file fails to load or play, the v19 synthesized
 *  buffer for the same sound id takes over, so a bad asset can never
 *  silence or crash the game.
 *
 *  Every v19 rule still applies, unchanged:
 *   - lazy: nothing loads until the first sound is asked for;
 *   - safe: EVERY call is wrapped — audio never touches gameplay;
 *   - polite: STREAM_MUSIC everywhere; a silent/vibrate ringer means
 *     nothing is forced;
 *   - gated: Settings.audioGate (master, channels, Quiet Mode, the
 *     live-path rule) decides before anything plays;
 *   - loops stop onPause (MainActivity), release onDestroy.
 *  The two loops that have no file (rain patter, the last-overs
 *  tension throb) stay on the synthesized AudioTrack path. */
public class SoundEngine {

    private static final int MAX_ONESHOTS = 7;

    // crowd bed kinds for setBed()
    public static final int BED_HOME = 0, BED_AWAY = 1, BED_DERBY = 2;
    private static final String[] BED_FILES = {"crowd_home.ogg", "crowd_away.ogg", "crowd_derby.ogg"};
    private static final String[] MUSIC_FILES = {null, "music_menu.ogg", "music_match.ogg"};

    /** SoundSynth id -> asset file (the v20 production of that sound). */
    private static String fileFor(int id) {
        switch (id) {
            case SoundSynth.BAT0: return "sfx_bat_soft.ogg";
            case SoundSynth.BAT1: return "sfx_bat_hard.ogg";
            case SoundSynth.BAT2: return "sfx_bat_hard.ogg";
            case SoundSynth.STUMPS: return "sfx_stumps.ogg";
            case SoundSynth.PADS: return "sfx_pad.ogg";
            case SoundSynth.SWELL1: return "sfx_cheer.ogg";
            case SoundSynth.SWELL2: return "sfx_cheer_big.ogg";
            case SoundSynth.SWELL3: return "sfx_cheer_big.ogg";
            case SoundSynth.GROAN: return "sfx_groan.ogg";
            case SoundSynth.APPLAUSE: return "sfx_applause.ogg";
            case SoundSynth.STING_WICKET: return "sting_win.ogg";
            case SoundSynth.STING_WIN: return "sting_win.ogg";
            case SoundSynth.STING_TITLE: return "sting_title.ogg";
            case SoundSynth.STING_ACHIEVE: return "sting_achievement.ogg";
            case SoundSynth.STING_LEVELUP: return "sting_win.ogg";
            case SoundSynth.UI_CLICK: return "ui_click.ogg";
            case SoundSynth.UI_CONFIRM: return "ui_confirm.ogg";
            case SoundSynth.UI_BLOCKED: return "ui_blocked.ogg";
            case SoundSynth.BID_TICK: return "ui_click.ogg";
            case SoundSynth.GAVEL: return "gavel.ogg";
            case SoundSynth.CASH: return "cash.ogg";
            case SoundSynth.WHISTLE: return "sfx_whistle.ogg";
            default: return null;
        }
    }

    private final Context ctx;
    private final Settings st;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long lastClickAt = 0, lastTickAt = 0;

    // ---- file playback state ----
    private SoundPool pool;
    private final Map<Integer, Integer> poolIds = new HashMap<>(); // synth id -> pool sound id
    private final Map<Integer, Boolean> poolReady = new HashMap<>();
    private boolean filesBroken = false; // a file failed: synth takes over for the session

    // ---- synth fallback state (v19 machinery, kept for fallback) ----
    private final Map<Integer, short[]> cache = new HashMap<>();
    private int liveOneshots = 0;
    private AudioTrack rainTrack;
    private AudioTrack tensionTrack;
    private AudioTrack synthBedTrack;   private int synthBedKind = 0;
    private AudioTrack synthMusicTrack; private int synthMusicKind = 0;

    // ---- MediaPlayer loops ----
    private MediaPlayer bedPlayer;   private int bedFileKind = -1;
    private MediaPlayer musicPlayer; private int musicFileKind = 0;

    // TTS (Audio Pack suggestions 21-22): created only when toggled on
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String ttsPending = null;

    public SoundEngine(Context ctx, Settings st) {
        this.ctx = ctx;
        this.st = st;
    }

    // ---------------- gates (unchanged from v19) ----------------

    private boolean ringerOk() {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            return am == null || am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
        } catch (Exception e) {
            return false;
        }
    }

    /** Full gate for a one-shot on a live (in-match) path. */
    public boolean canPlayLive(int id) {
        return Settings.audioGate(st.soundOn(), st.quietMode(), true, true,
                st.channelVol(SoundSynth.channelFor(id)), SoundSynth.isBigEvent(id))
                && ringerOk();
    }

    /** Full gate for a UI-context one-shot (menus, buttons, auctions). */
    public boolean canPlayUi(int id) {
        return Settings.audioGate(st.soundOn(), st.quietMode(), false, true,
                st.channelVol(SoundSynth.channelFor(id)), SoundSynth.isBigEvent(id))
                && ringerOk();
    }

    private float gainFor(int id) {
        return Math.max(0f, Math.min(1f, st.channelPercent(SoundSynth.channelFor(id)) / 100f));
    }

    private float loopGain(int channel, float level) {
        return Math.max(0f, Math.min(1f,
                st.channelPercent(channel) / 100f * level));
    }

    // ---------------- one-shots: files first, synth fallback ---------

    private SoundPool pool() {
        if (pool == null) {
            try {
                pool = new SoundPool(8, AudioManager.STREAM_MUSIC, 0);
                pool.setOnLoadCompleteListener((p, soundId, status) -> {
                    for (Map.Entry<Integer, Integer> e : poolIds.entrySet()) {
                        if (e.getValue() == soundId) {
                            poolReady.put(e.getKey(), status == 0);
                            if (status != 0) filesBroken = true;
                        }
                    }
                });
            } catch (Exception e) {
                pool = null;
                filesBroken = true;
            }
        }
        return pool;
    }

    private int poolIdFor(int id) {
        Integer have = poolIds.get(id);
        if (have != null) return have;
        String file = fileFor(id);
        if (file == null || pool() == null) return -1;
        try {
            AssetFileDescriptor afd = ctx.getAssets().openFd("audio/" + file);
            int sid = pool.load(afd, 1);
            afd.close();
            poolIds.put(id, sid);
            poolReady.put(id, false);
            return sid;
        } catch (Exception e) {
            filesBroken = true;
            return -1;
        }
    }

    /** Play a one-shot from a live path (match events). */
    public void playLive(int id) {
        if (canPlayLive(id)) fire(id, gainFor(id));
    }

    /** Play a one-shot from a UI path (buttons, signings, auctions). */
    public void playUi(int id) {
        if (canPlayUi(id)) fire(id, gainFor(id));
    }

    /** Play regardless of path, still gated on master/channel/quiet —
     *  for Settings test buttons and post-match moments. */
    public void playDirect(int id) {
        if (Settings.audioGate(st.soundOn(), st.quietMode(), false, true,
                st.channelVol(SoundSynth.channelFor(id)), SoundSynth.isBigEvent(id))
                && ringerOk()) {
            fire(id, gainFor(id));
        }
    }

    private void fire(int id, float gain) {
        if (gain <= 0.01f) return;
        if (!filesBroken) {
            int sid = poolIdFor(id);
            if (sid > 0 && Boolean.TRUE.equals(poolReady.get(id))) {
                try {
                    if (pool.play(sid, gain, gain, 1, 0, 1.0f) != 0) return;
                } catch (Exception e) {
                    filesBroken = true;
                }
            } else if (sid > 0) {
                return; // still decoding — drop this one rather than double up with synth
            }
        }
        fireSynth(id, gain);
    }

    // ---- the v19 synthesized one-shot path (fallback only) ----

    private short[] buffer(int id) {
        short[] b = cache.get(id);
        if (b == null) {
            b = SoundSynth.generate(id);
            cache.put(id, b);
        }
        return b;
    }

    private void fireSynth(int id, float gain) {
        if (liveOneshots >= MAX_ONESHOTS || gain <= 0.01f) return;
        try {
            final short[] buf = buffer(id);
            final AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC,
                    SoundSynth.SR, android.media.AudioFormat.CHANNEL_OUT_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT, buf.length * 2, AudioTrack.MODE_STATIC);
            t.write(buf, 0, buf.length);
            t.setVolume(gain);
            liveOneshots++;
            t.setNotificationMarkerPosition(buf.length);
            t.setPlaybackPositionUpdateListener(new AudioTrack.OnPlaybackPositionUpdateListener() {
                @Override public void onMarkerReached(AudioTrack track) { releaseOne(t); }
                @Override public void onPeriodicNotification(AudioTrack track) {}
            });
            t.play();
        } catch (Exception ignored) {
            // audio is decoration — never let it touch the game
        }
    }

    private void releaseOne(AudioTrack t) {
        try { t.stop(); } catch (Exception ignored) {}
        try { t.release(); } catch (Exception ignored) {}
        liveOneshots = Math.max(0, liveOneshots - 1);
    }

    /** UI click, throttled so rapid sim tapping doesn't machine-gun. */
    public void uiClick() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastClickAt < 120) return;
        lastClickAt = now;
        playUi(SoundSynth.UI_CLICK);
    }

    /** Bid tick, throttled for quick-bid loops. */
    public void bidTick() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastTickAt < 90) return;
        lastTickAt = now;
        playUi(SoundSynth.BID_TICK);
    }

    // ---------------- loops: MediaPlayer files, synth fallback -------

    private MediaPlayer startPlayer(String file, float gain) {
        try {
            MediaPlayer mp = new MediaPlayer();
            AssetFileDescriptor afd = ctx.getAssets().openFd("audio/" + file);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mp.setLooping(true);
            mp.setVolume(gain, gain);
            mp.prepare();
            mp.start();
            return mp;
        } catch (Exception e) {
            filesBroken = true;
            return null;
        }
    }

    private MediaPlayer stopPlayer(MediaPlayer mp) {
        if (mp == null) return null;
        try { mp.stop(); } catch (Exception ignored) {}
        try { mp.release(); } catch (Exception ignored) {}
        return null;
    }

    /** Crowd bed under a live match. kind: BED_HOME / BED_AWAY /
     *  BED_DERBY; level: home ~0.55, away ~0.35, derby ~0.7 (the
     *  level still scales the Crowd channel, as in v19). */
    public void setBed(boolean on, int kind, float level) {
        if (!on || !st.soundOn()) {
            bedPlayer = stopPlayer(bedPlayer); bedFileKind = -1;
            synthBedTrack = stopSynthLoop(synthBedTrack); synthBedKind = 0;
            return;
        }
        float g = loopGain(Settings.CH_CROWD, level);
        if (g <= 0.01f) return;
        if (!filesBroken) {
            if (bedPlayer != null && bedFileKind != kind) { bedPlayer = stopPlayer(bedPlayer); bedFileKind = -1; }
            if (bedPlayer == null) {
                if (!ringerOk()) return;
                bedPlayer = startPlayer(BED_FILES[kind], g);
                if (bedPlayer != null) bedFileKind = kind;
            } else {
                try { bedPlayer.setVolume(g, g); } catch (Exception ignored) {}
            }
            if (bedPlayer != null) return;
        }
        // fallback: the v19 synthesized bed (derby gets its own recipe)
        int synthKind = kind == BED_DERBY ? SoundSynth.LOOP_BED_DERBY : SoundSynth.LOOP_BED;
        if (synthBedTrack != null && synthBedKind != synthKind) {
            synthBedTrack = stopSynthLoop(synthBedTrack); synthBedKind = 0;
        }
        if (synthBedTrack == null) {
            synthBedTrack = startSynthLoop(null, synthKind, Settings.CH_CROWD, level);
            if (synthBedTrack != null) synthBedKind = synthKind;
        } else {
            try { synthBedTrack.setVolume(loopGain(Settings.CH_CROWD, level)); } catch (Exception ignored) {}
        }
    }

    /** Music: kind 0 off, 1 menu theme, 2 match bed (file loops; the
     *  v19 synth beds are the fallback). */
    public void setMusic(int kind) {
        if (kind == 0 || !st.soundOn()) {
            musicPlayer = stopPlayer(musicPlayer); musicFileKind = 0;
            synthMusicTrack = stopSynthLoop(synthMusicTrack); synthMusicKind = 0;
            return;
        }
        float level = kind == 1 ? 0.55f : 0.45f;
        float g = loopGain(Settings.CH_MUSIC, level);
        if (g <= 0.01f) return;
        if (!filesBroken) {
            if (musicPlayer != null && musicFileKind != kind) { musicPlayer = stopPlayer(musicPlayer); musicFileKind = 0; }
            if (musicPlayer == null) {
                if (!ringerOk()) return;
                musicPlayer = startPlayer(MUSIC_FILES[kind], g);
                if (musicPlayer != null) musicFileKind = kind;
            }
            if (musicPlayer != null) return;
        }
        int synthId = kind == 1 ? SoundSynth.LOOP_MENU : SoundSynth.LOOP_MATCHBED;
        if (synthMusicTrack != null && synthMusicKind != kind) {
            synthMusicTrack = stopSynthLoop(synthMusicTrack); synthMusicKind = 0;
        }
        if (synthMusicTrack == null) {
            synthMusicTrack = startSynthLoop(null, synthId, Settings.CH_MUSIC, level);
            if (synthMusicTrack != null) synthMusicKind = kind;
        }
    }

    // ---- synthesized loops kept from v19: rain + tension have no
    // file (rain is a burst over a break; tension is a throb) ----

    private AudioTrack startSynthLoop(AudioTrack old, int id, int channel, float level) {
        if (!st.soundOn() || !ringerOk()) return old;
        float g = loopGain(channel, level);
        if (g <= 0.01f) return old;
        try {
            if (old != null) { old.setVolume(g); return old; }
            short[] buf = buffer(id);
            AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC,
                    SoundSynth.SR, android.media.AudioFormat.CHANNEL_OUT_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT, buf.length * 2, AudioTrack.MODE_STATIC);
            t.write(buf, 0, buf.length);
            t.setLoopPoints(0, buf.length, -1);
            t.setVolume(g);
            t.play();
            return t;
        } catch (Exception e) {
            return old;
        }
    }

    private AudioTrack stopSynthLoop(AudioTrack t) {
        if (t == null) return null;
        try { t.stop(); } catch (Exception ignored) {}
        try { t.release(); } catch (Exception ignored) {}
        return null;
    }

    public void setRain(boolean on) {
        if (!on || !st.soundOn()) { rainTrack = stopSynthLoop(rainTrack); return; }
        if (rainTrack == null) rainTrack = startSynthLoop(null, SoundSynth.LOOP_RAIN, Settings.CH_CROWD, 0.5f);
    }

    /** A short rain burst for the moment a delay lands (the engine
     *  applies rain instantly, so the patter plays over the break and
     *  stops itself). */
    public void rainBurst() {
        setRain(true);
        ui.postDelayed(() -> setRain(false), 3500);
    }

    public void setTension(boolean on) {
        if (!on || !st.soundOn()) { tensionTrack = stopSynthLoop(tensionTrack); return; }
        if (tensionTrack == null) tensionTrack = startSynthLoop(null, SoundSynth.LOOP_TENSION, Settings.CH_MATCH, 0.4f);
    }

    public void stopLoops() {
        bedPlayer = stopPlayer(bedPlayer); bedFileKind = -1;
        musicPlayer = stopPlayer(musicPlayer); musicFileKind = 0;
        synthBedTrack = stopSynthLoop(synthBedTrack); synthBedKind = 0;
        synthMusicTrack = stopSynthLoop(synthMusicTrack); synthMusicKind = 0;
        rainTrack = stopSynthLoop(rainTrack);
        tensionTrack = stopSynthLoop(tensionTrack);
        stopSpeaking();
    }

    // ---------------- voice (21-22, unchanged) ----------------

    /** Speak a score line. Lazily builds TTS only when the voice
     *  toggle is on; any failure is silent. English text — the phone's
     *  own TTS voice speaks it; Roman Urdu commentary has no voice. */
    public void speak(final String text) {
        if (!st.voiceOn() || !st.soundOn() || !ringerOk()) return;
        if (st.channelVol(Settings.CH_VOICE) <= 0) return;
        try {
            if (tts == null) {
                ttsPending = text;
                tts = new TextToSpeech(ctx, status -> {
                    if (status == TextToSpeech.SUCCESS) {
                        ttsReady = true;
                        try { tts.setLanguage(Locale.UK); } catch (Exception ignored) {}
                        if (ttsPending != null) {
                            String p = ttsPending; ttsPending = null;
                            doSpeak(p);
                        }
                    }
                });
                return;
            }
            if (ttsReady) doSpeak(text);
            else ttsPending = text;
        } catch (Exception ignored) {}
    }

    private void doSpeak(String text) {
        try {
            java.util.HashMap<String, String> p = new java.util.HashMap<>();
            p.put(TextToSpeech.Engine.KEY_PARAM_STREAM,
                    String.valueOf(AudioManager.STREAM_MUSIC));
            float v = Math.max(0f, Math.min(1f, st.channelPercent(Settings.CH_VOICE) / 100f));
            p.put(TextToSpeech.Engine.KEY_PARAM_VOLUME, String.valueOf(v));
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, p);
        } catch (Exception ignored) {}
    }

    public void stopSpeaking() {
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
    }

    // ---------------- lifecycle ----------------

    public void release() {
        stopLoops();
        try { if (pool != null) { pool.release(); pool = null; } } catch (Exception ignored) {}
        try { if (tts != null) { tts.shutdown(); tts = null; } } catch (Exception ignored) {}
        cache.clear();
    }
}
