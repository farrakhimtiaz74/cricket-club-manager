package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Audio Pack (v19): the Android playback side. SoundSynth (pure)
 *  generates every buffer; this class owns AudioTracks and the TTS
 *  voice. Design rules, all enforced here or in MainActivity:
 *   - lazy: nothing is created until the first sound is asked for;
 *   - safe: EVERY call is wrapped — an audio failure can never crash
 *     or even disturb gameplay;
 *   - polite: STREAM_MUSIC everywhere, and if the phone's ringer is
 *     on silent or vibrate, nothing is forced;
 *   - bounded: at most MAX_ONESHOTS one-shots alive at once, loop
 *     tracks are singletons per kind.
 *  One-shots are static AudioTracks that release themselves on their
 *  end marker. Loops (crowd bed, rain, music, tension) are static
 *  tracks with loop points, started/stopped by MainActivity's
 *  per-render audio sync. */
public class SoundEngine {

    private static final int MAX_ONESHOTS = 7;

    private final Context ctx;
    private final Settings st;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<Integer, short[]> cache = new HashMap<>();
    private int liveOneshots = 0;
    private long lastClickAt = 0, lastTickAt = 0;

    // loop singletons: kind -> track
    private AudioTrack bedTrack;    private int bedKind = 0;
    private AudioTrack rainTrack;
    private AudioTrack musicTrack;  private int musicKind = 0;
    private AudioTrack tensionTrack;

    // TTS (suggestions 21-22): created only when the toggle is on
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String ttsPending = null;

    public SoundEngine(Context ctx, Settings st) {
        this.ctx = ctx;
        this.st = st;
    }

    // ---------------- gates ----------------

    private boolean ringerOk() {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            return am == null || am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
        } catch (Exception e) {
            return false;
        }
    }

    /** Full gate for a one-shot on a live (in-match) path. */
    public boolean canPlayLive(int id) {
        return Settings.audioGate(st.soundOn(), st.quietMode(), true, true,
                st.channelVol(SoundSynth.channelFor(id)), SoundSynth.isBigEvent(id))
                && ringerOk();
    }

    /** Full gate for a UI-context one-shot (menus, buttons, auctions):
     *  no live-path requirement, everything else identical. */
    public boolean canPlayUi(int id) {
        return Settings.audioGate(st.soundOn(), st.quietMode(), false, true,
                st.channelVol(SoundSynth.channelFor(id)), SoundSynth.isBigEvent(id))
                && ringerOk();
    }

    private float gainFor(int id) {
        return Math.max(0f, Math.min(1f, st.channelPercent(SoundSynth.channelFor(id)) / 100f));
    }

    private float loopGain(int channel, float level) {
        return Math.max(0f, Math.min(1f,
                st.channelPercent(channel) / 100f * level));
    }

    // ---------------- one-shots ----------------

    private short[] buffer(int id) {
        short[] b = cache.get(id);
        if (b == null) {
            b = SoundSynth.generate(id);
            cache.put(id, b);
        }
        return b;
    }

    /** Play a one-shot from a live path (match events). */
    public void playLive(int id) {
        if (canPlayLive(id)) fire(id, gainFor(id));
    }

    /** Play a one-shot from a UI path (buttons, signings, auctions). */
    public void playUi(int id) {
        if (canPlayUi(id)) fire(id, gainFor(id));
    }

    /** Play regardless of path, still gated on master/channel/quiet —
     *  for Settings test buttons and post-match moments. */
    public void playDirect(int id) {
        if (Settings.audioGate(st.soundOn(), st.quietMode(), false, true,
                st.channelVol(SoundSynth.channelFor(id)), SoundSynth.isBigEvent(id))
                && ringerOk()) {
            fire(id, gainFor(id));
        }
    }

    private void fire(int id, float gain) {
        if (liveOneshots >= MAX_ONESHOTS || gain <= 0.01f) return;
        try {
            final short[] buf = buffer(id);
            final AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC,
                    SoundSynth.SR, android.media.AudioFormat.CHANNEL_OUT_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT, buf.length * 2, AudioTrack.MODE_STATIC);
            t.write(buf, 0, buf.length);
            t.setVolume(gain);
            liveOneshots++;
            t.setNotificationMarkerPosition(buf.length);
            t.setPlaybackPositionUpdateListener(new AudioTrack.OnPlaybackPositionUpdateListener() {
                @Override public void onMarkerReached(AudioTrack track) { releaseOne(t); }
                @Override public void onPeriodicNotification(AudioTrack track) {}
            });
            t.play();
        } catch (Exception ignored) {
            // audio is decoration — never let it touch the game
        }
    }

    private void releaseOne(AudioTrack t) {
        try { t.stop(); } catch (Exception ignored) {}
        try { t.release(); } catch (Exception ignored) {}
        liveOneshots = Math.max(0, liveOneshots - 1);
    }

    /** UI click, throttled so rapid sim tapping doesn't machine-gun. */
    public void uiClick() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastClickAt < 120) return;
        lastClickAt = now;
        playUi(SoundSynth.UI_CLICK);
    }

    /** Bid tick, throttled for quick-bid loops. */
    public void bidTick() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastTickAt < 90) return;
        lastTickAt = now;
        playUi(SoundSynth.BID_TICK);
    }

    // ---------------- loops ----------------

    private AudioTrack startLoop(AudioTrack old, int id, int channel, float level) {
        if (!st.soundOn() || !ringerOk()) return old;
        float g = loopGain(channel, level);
        if (g <= 0.01f) return old;
        try {
            if (old != null) { old.setVolume(g); return old; }
            short[] buf = buffer(id);
            AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC,
                    SoundSynth.SR, android.media.AudioFormat.CHANNEL_OUT_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT, buf.length * 2, AudioTrack.MODE_STATIC);
            t.write(buf, 0, buf.length);
            t.setLoopPoints(0, buf.length, -1);
            t.setVolume(g);
            t.play();
            return t;
        } catch (Exception e) {
            return old;
        }
    }

    private AudioTrack stopLoop(AudioTrack t) {
        if (t == null) return null;
        try { t.stop(); } catch (Exception ignored) {}
        try { t.release(); } catch (Exception ignored) {}
        return null;
    }

    /** Crowd bed under a live match. level: home ~0.55, away ~0.35,
     *  derby ~0.7. Quiet Mode keeps the bed (it is atmosphere, not an
     *  event) but the Crowd channel still governs it. */
    public void setBed(boolean on, boolean derby, float level) {
        int kind = derby ? SoundSynth.LOOP_BED_DERBY : SoundSynth.LOOP_BED;
        if (!on || !st.soundOn()) {
            bedTrack = stopLoop(bedTrack); bedKind = 0; return;
        }
        if (bedTrack != null && bedKind != kind) { bedTrack = stopLoop(bedTrack); bedKind = 0; }
        if (bedTrack == null) {
            bedTrack = startLoop(null, kind, Settings.CH_CROWD, level);
            if (bedTrack != null) bedKind = kind;
        } else {
            try { bedTrack.setVolume(loopGain(Settings.CH_CROWD, level)); } catch (Exception ignored) {}
        }
    }

    public void setRain(boolean on) {
        if (!on || !st.soundOn()) { rainTrack = stopLoop(rainTrack); return; }
        if (rainTrack == null) rainTrack = startLoop(null, SoundSynth.LOOP_RAIN, Settings.CH_CROWD, 0.5f);
    }

    /** A short rain burst for the moment a delay lands (the engine
     *  applies rain instantly, so the patter plays over the break and
     *  stops itself). */
    public void rainBurst() {
        setRain(true);
        ui.postDelayed(() -> setRain(false), 3500);
    }

    public void setTension(boolean on) {
        if (!on || !st.soundOn()) { tensionTrack = stopLoop(tensionTrack); return; }
        if (tensionTrack == null) tensionTrack = startLoop(null, SoundSynth.LOOP_TENSION, Settings.CH_MATCH, 0.4f);
    }

    /** Music: kind 0 off, 1 menu theme, 2 match bed. */
    public void setMusic(int kind) {
        if (kind == 0 || !st.soundOn()) {
            musicTrack = stopLoop(musicTrack); musicKind = 0; return;
        }
        int id = kind == 1 ? SoundSynth.LOOP_MENU : SoundSynth.LOOP_MATCHBED;
        if (musicTrack != null && musicKind != kind) { musicTrack = stopLoop(musicTrack); musicKind = 0; }
        if (musicTrack == null) {
            musicTrack = startLoop(null, id, Settings.CH_MUSIC, kind == 1 ? 0.55f : 0.45f);
            if (musicTrack != null) musicKind = kind;
        }
    }

    public void stopLoops() {
        bedTrack = stopLoop(bedTrack); bedKind = 0;
        rainTrack = stopLoop(rainTrack);
        musicTrack = stopLoop(musicTrack); musicKind = 0;
        tensionTrack = stopLoop(tensionTrack);
        stopSpeaking();
    }

    // ---------------- voice (21-22) ----------------

    /** Speak a score line. Lazily builds TTS only when the voice
     *  toggle is on; any failure is silent. English text — the phone's
     *  own TTS voice speaks it; Roman Urdu commentary has no voice. */
    public void speak(final String text) {
        if (!st.voiceOn() || !st.soundOn() || !ringerOk()) return;
        if (st.channelVol(Settings.CH_VOICE) <= 0) return;
        try {
            if (tts == null) {
                ttsPending = text;
                tts = new TextToSpeech(ctx, status -> {
                    if (status == TextToSpeech.SUCCESS) {
                        ttsReady = true;
                        try { tts.setLanguage(Locale.UK); } catch (Exception ignored) {}
                        if (ttsPending != null) {
                            String p = ttsPending; ttsPending = null;
                            doSpeak(p);
                        }
                    }
                });
                return;
            }
            if (ttsReady) doSpeak(text);
            else ttsPending = text;
        } catch (Exception ignored) {}
    }

    private void doSpeak(String text) {
        try {
            java.util.HashMap<String, String> p = new java.util.HashMap<>();
            p.put(TextToSpeech.Engine.KEY_PARAM_STREAM,
                    String.valueOf(AudioManager.STREAM_MUSIC));
            float v = Math.max(0f, Math.min(1f, st.channelPercent(Settings.CH_VOICE) / 100f));
            p.put(TextToSpeech.Engine.KEY_PARAM_VOLUME, String.valueOf(v));
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, p);
        } catch (Exception ignored) {}
    }

    public void stopSpeaking() {
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
    }

    // ---------------- lifecycle ----------------

    public void release() {
        stopLoops();
        try { if (tts != null) { tts.shutdown(); tts = null; } } catch (Exception ignored) {}
        cache.clear();
    }
}
