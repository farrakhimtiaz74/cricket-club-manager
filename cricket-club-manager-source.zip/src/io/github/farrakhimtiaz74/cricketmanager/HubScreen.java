package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

public class HubScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        // season status card
        LinearLayout status = Ui.card(act);
        status.addView(Ui.h2(act, "Season " + g.season + " · Day " + g.day + " of 24"));
        status.addView(Ui.small(act, "Lahore Qalandars · Club Cash " + g.cf + " CF · XI selected: " + g.xiCount() + "/11"));
        root.addView(status);

        // match card
        LinearLayout mc = Ui.card(act);
        if (g.match != null) {
            mc.addView(Ui.gold(act, "MATCH IN PROGRESS", 13));
            mc.addView(Ui.h2(act, "vs " + g.match.optString("opp")));
            mc.addView(Ui.small(act, "Your live match is waiting — jump back in."));
            Button resume = Ui.goldBtn(act, "Resume Match");
            resume.setOnClickListener(v -> { act.matchMode = true; act.render(); });
            mc.addView(resume);
        } else {
            JSONObject today = g.todaysUserFixture();
            JSONObject next = g.nextUserFixture();
            if (today != null) {
                final JSONObject f = today;
                mc.addView(Ui.gold(act, "MATCH DAY", 13));
                mc.addView(Ui.h2(act, "Lahore Qalandars vs " + g.opponentOf(f)));
                mc.addView(Ui.small(act, Data.USER_TEAM.equals(f.optString("home"))
                        ? "Home game at Gaddafi Stadium. Stadium gate bonus applies."
                        : "Away game — travel costs −" + Game.TRAVEL_COST + " CF. Win prize: 300 CF."));
                // v2 team-sheet validator gates BOTH Play and Sim on match day
                final java.util.List<String> problems = g.xiProblems();
                if (!problems.isEmpty()) {
                    mc.addView(Ui.text(act, "Team sheet blocked: " + problems.size() + " problem(s) — tap Play to see them.", 13, Ui.RED, true));
                }
                Button play = Ui.goldBtn(act, "Play Match");
                play.setOnClickListener(v -> {
                    if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                    act.startMatch(f);
                });
                mc.addView(play);
                Button sim = Ui.darkBtn(act, "Sim This Match");
                sim.setOnClickListener(v -> {
                    if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                    act.g.simFixture(f);
                    act.save();
                    act.toast("Match simulated");
                    act.render();
                });
                mc.addView(sim);
            } else if (next != null) {
                mc.addView(Ui.gold(act, "UPCOMING MATCH", 13));
                mc.addView(Ui.h2(act, "vs " + g.opponentOf(next)));
                mc.addView(Ui.small(act, "Scheduled for Day " + next.optInt("day") + ". Advance the days to reach it."));
            } else {
                mc.addView(Ui.gold(act, "SEASON COMPLETE", 13));
                mc.addView(Ui.h2(act, "All fixtures played"));
                mc.addView(Ui.small(act, "Advance Day to crown the champion and start Season " + (g.season + 1) + "."));
            }
        }
        root.addView(mc);

        // quick actions
        LinearLayout qa = Ui.card(act);
        qa.addView(Ui.h2(act, "Manager Actions"));
        Button adv = Ui.goldBtn(act, "Advance Day");
        adv.setOnClickListener(v -> {
            if (act.g.match != null) { act.toast("Finish the current match first"); return; }
            String msg = act.g.advanceDay();
            act.save();
            act.toast(msg);
            act.render();
        });
        qa.addView(adv);
        LinearLayout row = Ui.row(act);
        Button rec = Ui.darkBtn(act, "Recovery");
        rec.setOnClickListener(v -> {
            int gain = act.g.recovery();
            act.save();
            if (gain < 0) {
                act.toast("Not enough CF — a recovery session costs " + act.g.recoveryCost() + " CF");
            } else {
                act.toast("Stamina +" + gain + " · −" + act.g.recoveryCost() + " CF (Medical Lvl " + act.g.facilityLevel(1) + ")");
            }
            act.render();
        });
        Button talk = Ui.darkBtn(act, "Team Talk");
        talk.setOnClickListener(v -> {
            if (act.g.teamTalk()) { act.save(); act.toast("Set % boosted squad-wide"); }
            else act.toast("Already done today — one talk per day");
            act.render();
        });
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        rec.setLayoutParams(half);
        talk.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(rec);
        row.addView(talk);
        qa.addView(row);
        root.addView(qa);

        // news
        LinearLayout news = Ui.card(act);
        news.addView(Ui.h2(act, "Club News"));
        if (g.news.length() == 0) news.addView(Ui.small(act, "No news yet."));
        for (int i = 0; i < g.news.length(); i++) {
            TextView t = Ui.body(act, "•  " + g.news.optString(i));
            t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
            news.addView(t);
        }
        root.addView(news);
        return root;
    }
}
