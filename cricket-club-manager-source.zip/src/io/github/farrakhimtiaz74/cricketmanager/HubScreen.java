package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

public class HubScreen {
 public static View build(final MainActivity act) {
 final Game g = act.g;
 LinearLayout root = Ui.col(act);
 // Professional Pack P2 (suggestion 11): the Hub is a DASHBOARD
 // now, in a strict priority order — (1) Today strip, (2) Next
 // Match, (3) Squad Alert (only when something needs attention),
 // (4) Money snapshot. Everything else lives below the Manager
 // Actions or in its natural tab; the re-homing list is in the
 // BATCHLOG. The old season status card became this strip: its
 // CF/XI line moved (CF to the Money snapshot + header pill, the
 // XI count to the Squad Alert and the Team tab's pinned bar).
 LinearLayout todayCard = Ui.kitCard(act); // v21 item 12: the dashboard is composed through the Kit
 todayCard.addView(Ui.gold(act, "TODAY", 12));
 todayCard.addView(Ui.h2(act, g.playoffPhase > 0
 ? "Season " + g.season + " · Playoffs"
 : "Season " + g.season + " · Day " + g.day + " of 24"));
 todayCard.addView(Ui.small(act, "Objective: " + g.boardObjectiveText + " · Fans: " + g.fanMoodLabel()));
 // v20.1 (item 2): the Board/Fans meters are Ui.meterRow — the slim
 // shared component the HQ screen uses too. v20 put two bare
 // GaugeViews in 44dp-label rows with NO numbers anywhere on the
 // card; on device the bright capsules merged into one giant orange
 // blob. Now each meter is a slim 10dp track with its number + word
 // printed beside the label, above the bar.
 todayCard.addView(Ui.meterRow(act, "Board", g.boardConfidence, boardWord(g)));
 todayCard.addView(Ui.meterRow(act, "Fans", g.fanMood, g.fanMoodLabel()));
 if (g.hardcore) todayCard.addView(Ui.text(act, "HARDCORE — sack line " + g.sackThreshold()
 + " · mode rewards halved · no slot undo", 12, Ui.RED, true));
 todayCard.addView(Ui.small(act, "Difficulty: " + Game.DIFF_NAMES[g.difficulty]));
 g.ensureQuests();
 String ql = g.questLine();
 if (!ql.isEmpty()) todayCard.addView(Ui.small(act, ql));
 if (!g.campLine().isEmpty() && !g.campPending) todayCard.addView(Ui.small(act, g.campLine()));
 // Batch H (idea 74): the Coach's Corner card folds into the strip
 // as its one-line tip — same coachTip(), same daily cache
 todayCard.addView(Ui.text(act, "Coach: " + g.coachTip(), 13, Ui.INK, false));
 root.addView(todayCard);

 // match card
 LinearLayout mc = Ui.card(act);
 // Rich Media (v20): the card's art band, chosen by whichever branch
 // fills the card (1 = matchday pitch for a league match day / next
 // fixture, 2 = trophy art for our title ceremony) and inserted at
 // the top once the branch has run — one insertion point, no branch
 // code touched.
 int mcArt = 0;
 if (g.offseason > 0) {
 // Batch D: the calendar is frozen until Transfers is finished
 mc.addView(Ui.gold(act, g.offseason == 1 ? "OFF-SEASON — RETAIN & RENEW" : "OFF-SEASON — THE AUCTION", 13));
 mc.addView(Ui.h2(act, "Season " + g.season + " starts in Transfers"));
 mc.addView(Ui.small(act, g.offseason == 1
 ? "Confirm who stays, release who goes and renew the out-of-contract men — then the auction opens."
 : "Bid for new stars (or skip) and Season " + g.season + " fixtures unlock."));
 Button go = Ui.goldBtn(act, "Open Transfers");
 go.setOnClickListener(v -> { act.transfersMode = true; act.render(); });
 mc.addView(go);
 } else if (g.match != null) {
 mc.addView(Ui.gold(act, "MATCH IN PROGRESS", 13));
 mc.addView(Ui.h2(act, "vs " + g.match.optString("opp")));
 mc.addView(Ui.small(act, "Your live match is waiting — jump back in."));
 Button resume = Ui.goldBtn(act, "Resume Match");
 resume.setOnClickListener(v -> { act.matchMode = true; act.render(); });
 mc.addView(resume);
 } else if (g.cupPhase == 1) {
 // Batch F (idea 56): One-Day Cup week — the tie lives on the Hub
 JSONObject cf2 = g.pendingUserCup();
 if (cf2 != null) {
 final JSONObject f = cf2;
 Game.ensureFixtureMeta(f, g.season);
 mc.addView(Ui.gold(act, "ONE-DAY CUP — " + f.optString("stage").toUpperCase()
 + (g.isDerby(f) ? " · DERBY" : ""), 13));
 mc.addView(Ui.h2(act, g.userTeam + " vs " + g.opponentOf(f)));
 mc.addView(crestRow(act, g, g.opponentOf(f)));
 mc.addView(Ui.small(act, "50 overs a side at " + f.optString("ground")
 + " (" + Data.GROUND_CHARS[f.optInt("groundChar", 1)] + ") · Pitch: "
 + Data.PITCH_TYPES[f.optInt("pitch", 0)]
 + (f.optBoolean("evening") ? " · Day/Night (dew in the chase)" : " · Day game")
 + (g.userTeam.equals(f.optString("home"))
 ? " · Expected crowd ~" + g.expectedAttendance(f) + "%" : "")));
 if (g.userTeam.equals(f.optString("home"))) {
 mc.addView(Ui.text(act, g.ticketLine(f) + " (gate x" + g.ticketMultiplier() + ")", 13, Ui.GOLD, false));
 }
 mc.addView(Ui.text(act, "Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(f)), 13, Ui.RED, true));
 addAnalysis(act, mc, g, f); // Batch H (idea 75)
 final java.util.List<String> problems = g.xiProblems();
 if (!problems.isEmpty()) {
 mc.addView(Ui.text(act, "Team sheet blocked: " + problems.size() + " problem(s) — tap Play to see them.", 13, Ui.RED, true));
 }
 Button play = Ui.goldBtn(act, "Play Cup " + f.optString("stage"));
 play.setOnClickListener(v -> {
 if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
 act.startMatch(f);
 });
 mc.addView(play);
 Button sim = Ui.darkBtn(act, "Sim This Match");
 sim.setOnClickListener(v -> {
 if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
 act.g.simCupFixture(f);
 act.save();
 act.toast("Cup " + f.optString("stage") + " simulated");
 act.render();
 });
 mc.addView(sim);
 } else {
 mc.addView(Ui.gold(act, "ONE-DAY CUP", 13));
 mc.addView(Ui.h2(act, "Cup week in progress"));
 mc.addView(Ui.small(act, g.userTeam + " are out of the cup — follow the bracket in the League tab, or Advance Day to move it on."));
 for (int i = 0; i < g.cupFixtures.length(); i++) {
 JSONObject f = g.cupFixtures.optJSONObject(i);
 if (f != null && f.optBoolean("played")) mc.addView(Ui.small(act, "•  " + f.optString("summary")));
 }
 }
 } else if (g.playoffPhase > 0) {
 // Batch E (ideas 41/42): the knockout stage lives on the Hub
 if (g.playoffPhase == 2 && g.ceremony != null) {
 // ---- Trophy Ceremony (idea 42) ----
 mc.addView(Ui.gold(act, "TROPHY CEREMONY", 13));
 LinearLayout champRow = Ui.row(act);
 champRow.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
 champRow.addView(Icons.badge(act, Icons.TROPHY));
 champRow.addView(CrestView.forTeam(act, g, g.ceremony.optString("champion"), 34));
 champRow.addView(Icons.badge(act, Icons.TROPHY));
 mc.addView(champRow);
 mc.addView(Ui.h2(act, g.ceremony.optString("champion") + " — Season "
 + g.ceremony.optInt("season") + " Champions!"));
 mc.addView(Ui.small(act, g.ceremony.optString("finalSummary")));
 if (!g.ceremony.optString("potm").isEmpty()) {
 mc.addView(Ui.text(act, "Player of the Final: " + g.ceremony.optString("potm")
 + " — " + g.ceremony.optString("potmDesc"), 13, Ui.GOLD, true));
 }
 if (g.userTeam.equals(g.ceremony.optString("champion"))) {
 mcArt = 2; // Rich Media (v20): our title gets the trophy artwork band
 mc.addView(Ui.text(act, "The champions' prize is in the ledger — title No. "
 + g.career.optInt("titles") + " for " + g.userTeam + "!", 13, Ui.GREEN, true));
 } else if (g.userTeam.equals(g.ceremony.optString("runnerUp"))) {
 mc.addView(Ui.text(act, "Runners-up — +500 CF prize banked. So close.", 13, Ui.GOLD, true));
 }
 // Season Awards (idea 47) presented with the ceremony
 if (g.lastAwards != null && g.lastAwards.length() > 0) {
 mc.addView(Ui.h2(act, "Season Awards"));
 addAwardLine(mc, act, g, "goldenBat", "Golden Bat");
 addAwardLine(mc, act, g, "bestBowler", "Best Bowler");
 addAwardLine(mc, act, g, "mvp", "MVP of the Season");
 addAwardLine(mc, act, g, "emerging", "Emerging Player");
 }
 Button cont = Ui.goldBtn(act, "Continue to Off-Season");
 cont.setOnClickListener(v -> {
 act.g.acknowledgeCeremony();
 act.save();
 act.toast("Off-season opens on the next Advance Day");
 act.render();
 });
 mc.addView(cont);
 } else if (g.playoffPhase == 3) {
 mc.addView(Ui.gold(act, "SEASON COMPLETE", 13));
 mc.addView(Ui.h2(act, g.seasonChampion + " are champions"));
 mc.addView(Ui.small(act, "Advance Day to open the off-season — contracts, releases and the auction."));
 } else {
 JSONObject pf = g.pendingUserPlayoff();
 if (pf != null) {
 final JSONObject f = pf;
 mc.addView(Ui.gold(act, "PLAYOFF — " + f.optString("stage").toUpperCase(), 13));
 mc.addView(Ui.h2(act, g.userTeam + " vs " + g.opponentOf(f)));
 mc.addView(crestRow(act, g, g.opponentOf(f)));
 Game.ensureFixtureMeta(f, g.season);
 mc.addView(Ui.small(act, "Knockout cricket — the loser goes home. Pitch: "
 + Data.PITCH_TYPES[f.optInt("pitch", 0)]
 + (f.optBoolean("evening") ? " · Day/Night (dew in the chase)" : " · Day game")
 + " · Rain risk " + f.optInt("rain", 0) + "%"));
 mc.addView(Ui.text(act, "Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(f)), 13, Ui.RED, true));
 addAnalysis(act, mc, g, f); // Batch H (idea 75)
 // the same team-sheet validator gates Play and Sim here
 final java.util.List<String> problems = g.xiProblems();
 if (!problems.isEmpty()) {
 mc.addView(Ui.text(act, "Team sheet blocked: " + problems.size() + " problem(s) — tap Play to see them.", 13, Ui.RED, true));
 }
 Button play = Ui.goldBtn(act, "Play " + f.optString("stage"));
 play.setOnClickListener(v -> {
 if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
 act.startMatch(f);
 });
 mc.addView(play);
 Button sim = Ui.darkBtn(act, "Sim This Match");
 sim.setOnClickListener(v -> {
 if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
 act.g.simPlayoffFixture(f);
 act.save();
 act.toast(f.optString("stage") + " simulated");
 act.render();
 });
 mc.addView(sim);
 } else {
 mc.addView(Ui.gold(act, "PLAYOFFS", 13));
 mc.addView(Ui.h2(act, "Knockout stage in progress"));
 mc.addView(Ui.small(act, g.userTeam + " are not in this tie — follow the bracket in the League tab, or Advance Day to move it on."));
 for (int i = 0; i < g.playoffFixtures.length(); i++) {
 JSONObject f = g.playoffFixtures.optJSONObject(i);
 if (f != null && f.optBoolean("played")) mc.addView(Ui.small(act, "•  " + f.optString("summary")));
 }
 }
 }
 } else {
 JSONObject today = g.todaysUserFixture();
 JSONObject next = g.nextUserFixture();
 if (today != null) {
 final JSONObject f = today;
 Game.ensureFixtureMeta(f, g.season);
 mcArt = 1; // Rich Media (v20): match day wears the pitch artwork band
 // Batch F (idea 58): the derby gets its badge up front
 mc.addView(Ui.gold(act, g.isDerby(f) ? "MATCH DAY · DERBY" : "MATCH DAY", 13));
 mc.addView(Ui.h2(act, g.userTeam + " vs " + g.opponentOf(f)));
 mc.addView(crestRow(act, g, g.opponentOf(f)));
 mc.addView(Ui.small(act, g.userTeam.equals(f.optString("home"))
 ? "Home game at " + f.optString("ground") + " — expected crowd ~"
 + g.expectedAttendance(f) + "%. Gate receipts scale with the crowd."
 : "Away game at " + f.optString("ground") + " — travel costs −" + Game.TRAVEL_COST + " CF. Win prize: " + g.prize(300) + " CF."));
 // Batch G (idea 63): the ticket line rides every home match card
 if (g.userTeam.equals(f.optString("home"))) {
 mc.addView(Ui.text(act, g.ticketLine(f) + " (gate x" + g.ticketMultiplier() + ")", 13, Ui.GOLD, false));
 }
 if (g.isDerby(f)) {
 mc.addView(Ui.text(act, "DERBY — win prize boosted: " + g.prize(300) + " + " + (g.prize(300) / 2)
 + " CF derby bonus, and the ground will be packed.", 13, Ui.RED, true));
 }
 // Batch A (ideas 2–4) + Batch F (idea 59): conditions on the match-day card
 // v21 item 17: the conditions line gets the symbol set — weather
 // + pitch glyphs at the line's head, same drawn weight as the rest
 LinearLayout cond = Ui.row(act);
 cond.addView(Icons.weather(act, f.optInt("rain", 0)));
 cond.addView(Icons.badge(act, Icons.PITCH));
 TextView condT = Ui.small(act, "Pitch: " + Data.PITCH_TYPES[f.optInt("pitch", 0)]
 + " · Ground: " + Data.GROUND_CHARS[f.optInt("groundChar", 1)]
 + (f.optBoolean("evening") ? " · Day/Night (dew in the chase)" : " · Day game")
 + " · Rain risk " + f.optInt("rain", 0) + "%");
 LinearLayout.LayoutParams ctlp = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
 ctlp.setMargins(Ui.dp(act, 6), 0, 0, 0);
 condT.setLayoutParams(ctlp);
 cond.addView(condT);
 mc.addView(cond);
 // Batch B (idea 19): danger-man scouting line on the pre-match card
 mc.addView(Ui.text(act, "Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(f)), 13, Ui.RED, true));
 // Batch H (idea 75): pre-match analysis
 addAnalysis(act, mc, g, f);
 // v2 team-sheet validator gates BOTH Play and Sim on match day
 final java.util.List<String> problems = g.xiProblems();
 if (!problems.isEmpty()) {
 mc.addView(Ui.text(act, "Team sheet blocked: " + problems.size() + " problem(s) — tap Play to see them.", 13, Ui.RED, true));
 }
 Button play = Ui.goldBtn(act, "Play Match");
 play.setOnClickListener(v -> {
 if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
 act.startMatch(f);
 });
 mc.addView(play);
 Button sim = Ui.darkBtn(act, "Sim This Match");
 sim.setOnClickListener(v -> {
 if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
 act.g.simFixture(f);
 act.save();
 act.toast("Match simulated");
 act.render();
 });
 mc.addView(sim);
 } else if (next != null) {
 mcArt = 1; // Rich Media (v20): the next-match card gets the same band
 mc.addView(Ui.gold(act, "UPCOMING MATCH", 13));
 mc.addView(Ui.h2(act, "vs " + g.opponentOf(next)));
 mc.addView(crestRow(act, g, g.opponentOf(next)));
 mc.addView(Ui.small(act, "Scheduled for Day " + next.optInt("day")
 + (next.optString("ground").isEmpty() ? "" : " · " + next.optString("ground"))
 + ". Advance the days to reach it."));
 Game.ensureFixtureMeta(next, g.season);
 mc.addView(Ui.small(act, "Pitch: " + Data.PITCH_TYPES[next.optInt("pitch", 0)]
 + (next.optBoolean("evening") ? " · Day/Night" : " · Day game")
 + " · Rain risk " + next.optInt("rain", 0) + "%"));
 mc.addView(Ui.text(act, "Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(next)), 13, Ui.RED, true));
 // Batch H (idea 75): pre-match analysis for the upcoming game too
 addAnalysis(act, mc, g, next);
 } else {
 mc.addView(Ui.gold(act, "SEASON COMPLETE", 13));
 mc.addView(Ui.h2(act, "All fixtures played"));
 mc.addView(Ui.small(act, "Advance Day to crown the champion and start Season " + (g.season + 1) + "."));
 }
 }
 // Rich Media (v20): the art band itself — pitch art under a
 // blue-to-gold diagonal wash for match cards (the home club's
 // colour sweeping into gold, the reference apps' signature), or
 // the trophy art plain for a title. Any decode failure simply
 // leaves the flat card, exactly as v19 shipped it.
 if (mcArt > 0) {
 android.graphics.Bitmap artBmp = Art.bitmap(act, mcArt == 2 ? Art.TROPHY : Art.PITCH, 1080);
 if (artBmp != null) {
 android.widget.FrameLayout band = new android.widget.FrameLayout(act);
 android.widget.ImageView biv = new android.widget.ImageView(act);
 biv.setImageBitmap(artBmp);
 biv.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
 band.addView(biv, new android.widget.FrameLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
 if (mcArt == 1) {
 View wash = new View(act);
 int accentWash = (Design.accentFor(g) & 0x00FFFFFF) | 0x73000000; // v20.1 (item 6): the home club's OWN colour, richer — v20 blended it toward blue and dulled red clubs
 int goldWash = (Ui.GOLD & 0x00FFFFFF) | 0x59000000;
 android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
 android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
 new int[]{accentWash, goldWash});
 wash.setBackground(gd);
 band.addView(wash, new android.widget.FrameLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
 }
 View fade = new View(act);
 fade.setBackground(new android.graphics.drawable.GradientDrawable(
 android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
 new int[]{0x00000000, Ui.CARD}));
 band.addView(fade, new android.widget.FrameLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
 LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, mcArt == 2 ? 120 : 92));
 blp.setMargins(-Ui.dp(act, 14), -Ui.dp(act, 12), -Ui.dp(act, 14), Ui.dp(act, 10));
 band.setLayoutParams(blp);
 mc.addView(band, 0);
 }
 }
 root.addView(mc);

 // P2 (suggestion 11) block 3: SQUAD ALERT — rendered ONLY when
 // Game.hubAlerts() finds something (board warning, blocked team
 // sheet, injured/low-stamina starter, poach offer, pending press
 // conference). The old stand-alone board warning card folds in as
 // the first alert line; the press and poach DECISION cards follow
 // immediately, as part of the same attention block.
 java.util.List<String> alerts = g.hubAlerts();
 if (!alerts.isEmpty()) {
 LinearLayout al = Ui.card(act);
 al.addView(Ui.text(act, "NEEDS ATTENTION", 13, Ui.RED, true));
 for (String line : alerts) al.addView(Ui.body(act, "•  " + line));
 root.addView(al);
 }
 if (g.pressConf != null) root.addView(pressCard(act));
 if (g.poachOffer != null) root.addView(TransfersScreen.poachCard(act));

 // P2 (suggestion 11) block 4: MONEY SNAPSHOT — the balance, the
 // next wage hit (Game.weeklyWages is exactly what advanceDay
 // charges on Days 7/14/21) and the sponsor position, one glance.
 LinearLayout money = Ui.kitCard(act); // v21 Kit
 money.addView(Ui.h2(act, "Money"));
 LinearLayout mRow = Ui.row(act);
 mRow.addView(Icons.badge(act, Icons.COIN));
 TextView cfFig = Ui.display(act, g.cf + " CF", 20, Ui.GOLD);
 Anim.countUp(cfFig, 0, g.cf, v -> v + " CF"); // v21 item 7: the figure counts toward the balance
 mRow.addView(cfFig);
 money.addView(mRow);
 if (g.offseason > 0) {
 money.addView(Ui.small(act, "Wages pause in the off-season — the " + g.weeklyWages()
 + " CF/week bill resumes on Day 7 of Season " + g.season + "."));
 } else {
 money.addView(Ui.small(act, "Next wages: −" + g.weeklyWages() + " CF on Day " + g.nextWageDay()
 + " · wage days are 7, 14 and 21."));
 }
 money.addView(Ui.small(act, g.sponsorLine()));
 root.addView(money);

 // Batch J (idea 92): the What's New banner — shown while the
 // stored lastSeenVersion (app prefs) is behind this build
 if (Settings.shouldShowWhatsNew(act.settings.lastSeenVersion(), act.appVersionCode)) {
 LinearLayout wn = Ui.card(act);
 wn.addView(Ui.text(act, "UPDATED — v" + act.appVersionName + " is here!", 15, Ui.GOLD, true));
 wn.addView(Ui.small(act, "A cleaner, calmer, more professional look — see everything that changed in v" + act.appVersionName + ".")); // P1 diet
 Button see = Ui.goldBtn(act, "See What's New");
 see.setOnClickListener(v -> { act.whatsNewMode = true; act.render(); });
 wn.addView(see);
 Button later = Ui.darkBtn(act, "Not now");
 later.setOnClickListener(v -> { act.settings.setLastSeenVersion(act.appVersionCode); act.render(); });
 wn.addView(later);
 root.addView(wn);
 }

 // Design Batch (item 6): Manager Actions reorganised into the
 // five titled categories — every old action kept, none lost:
 // Advance Day stays the primary on top, then CLUB / MATCH
 // CENTRE / SQUAD / COMPETE / MORE groups.
 LinearLayout qa = Ui.kitCard(act); // v21 Kit
 qa.addView(Ui.h2(act, "Manager Actions"));
 Button adv = Ui.kitButton(act, "Advance Day", true, g);
 adv.setOnClickListener(v -> {
 if (act.g.match != null) { act.toast("Finish the current match first"); return; }
 String msg = act.g.advanceDay();
 act.save();
 act.toast(msg);
 act.render();
 });
 qa.addView(adv);

 qa.addView(Ui.sectionHeader(act, "CLUB"));
 LinearLayout crow = Ui.row(act);
 Button rec = Ui.darkBtn(act, "Recovery");
 rec.setOnClickListener(v -> {
 int gain = act.g.recovery();
 act.save();
 if (gain < 0) {
 act.toast("Not enough CF — a recovery session costs " + act.g.recoveryCost() + " CF");
 } else {
 act.toast("Stamina +" + gain + " · −" + act.g.recoveryCost() + " CF (Medical Lvl " + act.g.facilityLevel(1) + ")");
 }
 act.render();
 });
 Button talk = Ui.darkBtn(act, "Team Talk");
 talk.setOnClickListener(v -> {
 if (act.g.teamTalk()) { act.save(); act.toast("Set % boosted squad-wide"); }
 else act.toast("Already done today — one talk per day");
 act.render();
 });
 LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
 rec.setLayoutParams(half);
 talk.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 crow.addView(rec);
 crow.addView(talk);
 qa.addView(crow);
 Button hqGo = Ui.darkBtn(act, "Headquarters & Finances");
 hqGo.setOnClickListener(v -> { act.tab = 5; act.render(); });
 qa.addView(hqGo);

 qa.addView(Ui.sectionHeader(act, "MATCH CENTRE"));
 Button cal = Ui.darkBtn(act, "Season Calendar");
 cal.setOnClickListener(v -> { act.calendarMode = true; act.render(); });
 qa.addView(cal);

 qa.addView(Ui.sectionHeader(act, "SQUAD"));
 Button trGo = Ui.darkBtn(act, "Transfers & Contracts");
 trGo.setOnClickListener(v -> { act.transfersMode = true; act.render(); });
 qa.addView(trGo);
 Button xiGo = Ui.darkBtn(act, "Squad & Best XI (Team tab)");
 xiGo.setOnClickListener(v -> { act.tab = 1; act.render(); });
 qa.addView(xiGo);

 qa.addView(Ui.sectionHeader(act, "COMPETE"));
 Button modes = Ui.darkBtn(act, "Modes & Challenges");
 modes.setOnClickListener(v -> { act.modesMode = true; act.render(); });
 qa.addView(modes);
 Button lgGo = Ui.darkBtn(act, "League Tables (League tab)");
 lgGo.setOnClickListener(v -> { act.tab = 2; act.render(); });
 qa.addView(lgGo);

 qa.addView(Ui.sectionHeader(act, "MORE"));
 Button search = Ui.darkBtn(act, "Search Players, Teams, Fixtures");
 search.setOnClickListener(v -> { act.searchMode = true; act.render(); });
 qa.addView(search);
 Button setGo = Ui.darkBtn(act, "App Settings");
 setGo.setOnClickListener(v -> { act.settingsMode = true; act.render(); });
 qa.addView(setGo);
 Button wnGo = Ui.darkBtn(act, "What's New");
 wnGo.setOnClickListener(v -> { act.whatsNewMode = true; act.render(); });
 qa.addView(wnGo);
 // Rich Media (v20): the way back to the title screen
 Button menuGo = Ui.darkBtn(act, "Main Menu");
 menuGo.setOnClickListener(v -> { act.menuMode = true; act.render(); });
 qa.addView(menuGo);
 root.addView(qa);

 // Batch G (ideas 64/66): off-season business lives on the Hub too
 if (g.offseason > 0 && g.sponsorOffers.length() > 0) root.addView(HqScreen.sponsorCard(act));
 if (g.campPending) {
 View camp = HqScreen.campCard(act);
 if (camp != null) root.addView(camp);
 }

 // Batch H (idea 76): the finished season's review, during the off-season
 if (g.offseason > 0 && g.seasonHistory.length() > 0) {
 JSONObject lastSeason = g.seasonHistory.optJSONObject(0);
 java.util.List<String> review = g.seasonReviewLines(lastSeason);
 if (lastSeason != null && !review.isEmpty()) {
 LinearLayout rv = Ui.card(act);
 rv.addView(Ui.h2(act, "Season " + lastSeason.optInt("season") + " Review"));
 for (String line : review) rv.addView(Ui.body(act, line));
 root.addView(rv);
 }
 }

 // Batch H (idea 77): the last match's report — view or share it
 if (g.lastReport != null) {
 LinearLayout rep = Ui.card(act);
 rep.addView(Ui.h2(act, "Last Match Report"));
 rep.addView(Ui.body(act, g.reportText(g.lastReport)));
 Button viewCard = Ui.darkBtn(act, "View Report Card");
 viewCard.setOnClickListener(v -> act.showReportCard());
 rep.addView(viewCard);
 LinearLayout srow = Ui.row(act);
 Button shareImg = Ui.goldBtn(act, "Share Image");
 shareImg.setOnClickListener(v -> act.shareReportImage());
 Button shareTxt = Ui.darkBtn(act, "Share Text");
 shareTxt.setOnClickListener(v -> act.shareReportText());
 LinearLayout.LayoutParams sh = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
 shareImg.setLayoutParams(sh);
 shareTxt.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 srow.addView(shareImg);
 srow.addView(shareTxt);
 rep.addView(srow);
 root.addView(rep);
 }


 // news — Design Batch (item 10): the consistent empty state
 LinearLayout news = Ui.card(act);
 news.addView(Ui.h2(act, "Club News"));
 if (g.news.length() == 0) news.addView(Ui.emptyState(act, Icons.CONTRACT, "No news yet — play a match and the press will find you."));
 for (int i = 0; i < g.news.length(); i++) {
 TextView t = Ui.body(act, "•  " + g.news.optString(i));
 t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
 news.addView(t);
 }
 root.addView(news);

 // Batch H (idea 73): Fan Buzz — the supporters' own feed (the
 // card now always shows; empty gets the shared empty state)
 {
 LinearLayout buzz = Ui.card(act);
 buzz.addView(Ui.h2(act, "Fan Buzz"));
 if (g.fanPosts.length() == 0) {
 buzz.addView(Ui.emptyState(act, Icons.STAR, "The fans are quiet — for now. Results will get them talking."));
 }
 for (int i = 0; i < g.fanPosts.length(); i++) {
 JSONObject fp = g.fanPosts.optJSONObject(i);
 if (fp == null) continue;
 TextView who = Ui.text(act, fp.optString("name") + " " + fp.optString("handle"), 12, Ui.GOLD, true);
 who.setPadding(0, Ui.dp(act, 5), 0, 0);
 buzz.addView(who);
 buzz.addView(Ui.body(act, fp.optString("text")));
 }
 root.addView(buzz);
 }
 return root;
 }

 /** Design Batch (item 9b): the two crests either side of a "vs" —
 * the visual signature of every match-day card. */
 // v20.1 (item 2): a word for the board meter, in the fan label's
 // voice — the number is always printed too (Ui.meterRow).
 private static String boardWord(Game g) {
 int b = g.boardConfidence;
 return b >= 80 ? "Delighted" : b >= 60 ? "Confident" : b >= 40 ? "Watching"
 : b >= 25 ? "Worried" : "Furious";
 }

 // v20.1 (item 10): the versus header — each club gets its own
 // column: a LARGE crest (52dp, was 30), its name, and its last-5
 // form as W/L/T pills from the real fixture record
 // (Game.oppRecentForm covers league + playoffs + cup). A side
 // with no results yet shows "Season opener" — never invented form.
 private static View crestRow(MainActivity act, Game g, String oppTeam) {
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 2));
 row.addView(clubSide(act, g, g.userTeam));
 TextView vs = Ui.display(act, "VS", 13, Ui.GOLD);
 vs.setBackground(Ui.roundStroke(Ui.CARD2, Ui.GOLD, 12, act));
 vs.setPadding(Ui.dp(act, 8), Ui.dp(act, 4), Ui.dp(act, 8), Ui.dp(act, 4));
 LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
 vlp.setMargins(Ui.dp(act, 4), 0, Ui.dp(act, 4), 0);
 vs.setLayoutParams(vlp);
 row.addView(vs);
 row.addView(clubSide(act, g, oppTeam));
 return row;
 }

 private static View clubSide(MainActivity act, Game g, String team) {
 LinearLayout col = Ui.col(act);
 col.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
 col.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 col.addView(CrestView.forTeam(act, g, team, 52));
 TextView nm = Ui.text(act, team, 12.5f, Ui.INK, true);
 nm.setGravity(android.view.Gravity.CENTER);
 nm.setSingleLine(true);
 nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
 LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
 nlp.setMargins(0, Ui.dp(act, 4), 0, Ui.dp(act, 3));
 nm.setLayoutParams(nlp);
 col.addView(nm);
 String form = g.oppRecentForm(team);
 if (form == null || form.trim().isEmpty()) {
 col.addView(Ui.micro(act, "SEASON OPENER"));
 } else {
 LinearLayout pills = Ui.row(act);
 pills.setGravity(android.view.Gravity.CENTER);
 for (String tok : form.trim().split("\\s+")) {
 if (tok.isEmpty()) continue;
 int colr = "W".equals(tok) ? Ui.GREEN : "L".equals(tok) ? Ui.RED : Ui.MUTED;
 TextView pill = Ui.display(act, tok, 9, 0xFF0F172A);
 pill.setGravity(android.view.Gravity.CENTER);
 pill.setBackground(Ui.round(colr, 8, act));
 LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(Ui.dp(act, 16), Ui.dp(act, 16));
 plp.setMargins(Ui.dp(act, 2), 0, Ui.dp(act, 2), 0);
 pill.setLayoutParams(plp);
 pills.addView(pill);
 }
 col.addView(pills);
 }
 return col;
 }

 /** Batch H (idea 75): the analysis block shared by every match-day
 * card — opponent form, the key battle and the bookmaker's line. */
 private static void addAnalysis(MainActivity act, LinearLayout card, Game g, JSONObject f) {
 String opp = g.opponentOf(f);
 card.addView(Ui.gold(act, "MATCH ANALYSIS", 11));
 String form = g.oppRecentForm(opp);
 if (!form.isEmpty()) card.addView(Ui.small(act, opp + " form (last 5): " + form));
 String kb = g.keyBattleLine(opp);
 if (!kb.isEmpty()) card.addView(Ui.small(act, kb));
 card.addView(Ui.small(act, g.favouriteLine(f)));
 card.addView(MatchScreen.compareBlock(act, g, opp)); // Professional Pack P3 (suggestion 26)
 }

 /** Batch H (idea 71): the press-conference card. */
 private static View pressCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout pc = Ui.card(act);
 pc.addView(Ui.gold(act, "PRESS CONFERENCE — " + g.pressConf.optString("comp").toUpperCase(), 12));
 pc.addView(Ui.h2(act, "The press are waiting, gaffer"));
 pc.addView(Ui.body(act, "\"" + g.pressConf.optString("q") + "\""));
 String[] labels = {"Confident", "Balanced", "Fiery"};
 for (int i = 0; i < 3; i++) {
 final int choice = i;
 Button b = Ui.darkBtn(act, labels[i]); // P1: no gold in this card — three equal choices
 b.setOnClickListener(v -> {
 String out = act.g.answerPress(choice);
 act.save();
 if (!out.isEmpty()) act.toast(out);
 act.render();
 });
 pc.addView(b);
 }
 Button skip = Ui.darkBtn(act, "Skip press (no effects)");
 skip.setOnClickListener(v -> {
 act.g.answerPress(-1);
 act.save();
 act.render();
 });
 pc.addView(skip);
 return pc;
 }

 /** Batch E (idea 47): one awards line on the Trophy Ceremony card. */
 private static void addAwardLine(LinearLayout card, MainActivity act, Game g, String key, String label) {
 JSONObject a = g.lastAwards == null ? null : g.lastAwards.optJSONObject(key);
 if (a == null) return;
 card.addView(Ui.text(act, label + ": " + a.optString("name") + " (" + a.optString("team")
 + ") — " + a.optString("detail"), 13, Ui.GOLD, false));
 }
}
