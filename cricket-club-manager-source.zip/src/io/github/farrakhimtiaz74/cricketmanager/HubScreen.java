package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

public class HubScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        // season status card
        LinearLayout status = Ui.card(act);
        status.addView(Ui.h2(act, g.playoffPhase > 0
                ? "Season " + g.season + " · 🏆 Playoffs"
                : "Season " + g.season + " · Day " + g.day + " of 24"));
        status.addView(Ui.text(act, g.userTeam + " · Club Cash " + g.cf + " CF · XI selected: " + g.xiCount() + "/11",
                12, g.teamColor(), true));
        // Batch G (ideas 67/70): mini board/fan indicators + objective + camp
        status.addView(Ui.small(act, "Board " + g.boardConfidence + "/100 · Fans " + g.fanMood + "/100 (" + g.fanMoodLabel()
                + ") · Objective: " + g.boardObjectiveText));
        // Batch I (ideas 90/81/84): the hardcore badge + difficulty + the
        // live weekly quests, one compact line
        if (g.hardcore) status.addView(Ui.text(act, "☠ HARDCORE — sack line " + g.sackThreshold()
                + " · mode rewards halved · no slot undo", 12, Ui.RED, true));
        status.addView(Ui.small(act, "Difficulty: " + Game.DIFF_NAMES[g.difficulty]));
        g.ensureQuests();
        String ql = g.questLine();
        if (!ql.isEmpty()) status.addView(Ui.small(act, ql));
        if (!g.campLine().isEmpty() && !g.campPending) status.addView(Ui.small(act, g.campLine()));
        root.addView(status);

        // Batch J (idea 92): the What's New banner — shown while the
        // stored lastSeenVersion (app prefs) is behind this build
        if (Settings.shouldShowWhatsNew(act.settings.lastSeenVersion(), act.appVersionCode)) {
            LinearLayout wn = Ui.card(act);
            wn.addView(Ui.text(act, "🆕 UPDATED — v" + act.appVersionName + " is here!", 15, Ui.GOLD, true));
            wn.addView(Ui.small(act, "The 100-update mega-batch is complete: sync codes, Roman Urdu commentary,"
                    + " sounds, search, CSV exports and more — see everything that's new."));
            Button see = Ui.goldBtn(act, "See What's New");
            see.setOnClickListener(v -> { act.whatsNewMode = true; act.render(); });
            wn.addView(see);
            Button later = Ui.darkBtn(act, "Not now");
            later.setOnClickListener(v -> { act.settings.setLastSeenVersion(act.appVersionCode); act.render(); });
            wn.addView(later);
            root.addView(wn);
        }

        // Batch G (idea 68): the sack warning is impossible to miss
        if (g.boardWarning()) {
            LinearLayout warn = Ui.card(act);
            warn.addView(Ui.text(act, "⚠ THE BOARD IS LOSING PATIENCE…", 15, Ui.RED, true));
            warn.addView(Ui.small(act, "Board confidence is " + g.boardConfidence + "/100. End the season under "
                    + g.sackThreshold() + " and you are SACKED. Win matches — starting now."));
            root.addView(warn);
        }

        // Batch G (ideas 64/66): off-season business lives on the Hub too
        if (g.offseason > 0 && g.sponsorOffers.length() > 0) root.addView(HqScreen.sponsorCard(act));
        if (g.campPending) {
            View camp = HqScreen.campCard(act);
            if (camp != null) root.addView(camp);
        }

        // Batch D: a live poach offer gets a decision card right here
        if (g.poachOffer != null) root.addView(TransfersScreen.poachCard(act));

        // match card
        LinearLayout mc = Ui.card(act);
        if (g.offseason > 0) {
            // Batch D: the calendar is frozen until Transfers is finished
            mc.addView(Ui.gold(act, g.offseason == 1 ? "OFF-SEASON — RETAIN & RENEW" : "OFF-SEASON — THE AUCTION", 13));
            mc.addView(Ui.h2(act, "Season " + g.season + " starts in Transfers"));
            mc.addView(Ui.small(act, g.offseason == 1
                    ? "Confirm who stays, release who goes and renew the out-of-contract men — then the auction opens."
                    : "Bid for new stars (or skip) and Season " + g.season + " fixtures unlock."));
            Button go = Ui.goldBtn(act, "Open Transfers");
            go.setOnClickListener(v -> { act.transfersMode = true; act.render(); });
            mc.addView(go);
        } else if (g.match != null) {
            mc.addView(Ui.gold(act, "MATCH IN PROGRESS", 13));
            mc.addView(Ui.h2(act, "vs " + g.match.optString("opp")));
            mc.addView(Ui.small(act, "Your live match is waiting — jump back in."));
            Button resume = Ui.goldBtn(act, "Resume Match");
            resume.setOnClickListener(v -> { act.matchMode = true; act.render(); });
            mc.addView(resume);
        } else if (g.cupPhase == 1) {
            // Batch F (idea 56): One-Day Cup week — the tie lives on the Hub
            JSONObject cf2 = g.pendingUserCup();
            if (cf2 != null) {
                final JSONObject f = cf2;
                Game.ensureFixtureMeta(f, g.season);
                mc.addView(Ui.gold(act, "🏆 ONE-DAY CUP — " + f.optString("stage").toUpperCase()
                        + (g.isDerby(f) ? " · 🔥 DERBY" : ""), 13));
                mc.addView(Ui.h2(act, g.userTeam + " vs " + g.opponentOf(f)));
                mc.addView(Ui.small(act, "50 overs a side at " + f.optString("ground")
                        + " (" + Data.GROUND_CHARS[f.optInt("groundChar", 1)] + ") · Pitch: "
                        + Data.PITCH_TYPES[f.optInt("pitch", 0)]
                        + (f.optBoolean("evening") ? " · Day/Night (dew in the chase)" : " · Day game")
                        + (g.userTeam.equals(f.optString("home"))
                            ? " · Expected crowd ~" + g.expectedAttendance(f) + "%" : "")));
                if (g.userTeam.equals(f.optString("home"))) {
                    mc.addView(Ui.text(act, "🎟 " + g.ticketLine(f) + " (gate x" + g.ticketMultiplier() + ")", 13, Ui.GOLD, false));
                }
                mc.addView(Ui.text(act, "⚠ Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(f)), 13, Ui.RED, true));
                addAnalysis(act, mc, g, f); // Batch H (idea 75)
                addPrediction(act, mc, g, f); // Batch I (idea 86)
                final java.util.List<String> problems = g.xiProblems();
                if (!problems.isEmpty()) {
                    mc.addView(Ui.text(act, "Team sheet blocked: " + problems.size() + " problem(s) — tap Play to see them.", 13, Ui.RED, true));
                }
                Button play = Ui.goldBtn(act, "Play Cup " + f.optString("stage"));
                play.setOnClickListener(v -> {
                    if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                    act.startMatch(f);
                });
                mc.addView(play);
                Button sim = Ui.darkBtn(act, "Sim This Match");
                sim.setOnClickListener(v -> {
                    if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                    act.g.simCupFixture(f);
                    act.save();
                    act.toast("Cup " + f.optString("stage") + " simulated");
                    act.render();
                });
                mc.addView(sim);
            } else {
                mc.addView(Ui.gold(act, "🏆 ONE-DAY CUP", 13));
                mc.addView(Ui.h2(act, "Cup week in progress"));
                mc.addView(Ui.small(act, g.userTeam + " are out of the cup — follow the bracket in the League tab, or Advance Day to move it on."));
                for (int i = 0; i < g.cupFixtures.length(); i++) {
                    JSONObject f = g.cupFixtures.optJSONObject(i);
                    if (f != null && f.optBoolean("played")) mc.addView(Ui.small(act, "• " + f.optString("summary")));
                }
            }
        } else if (g.playoffPhase > 0) {
            // Batch E (ideas 41/42): the knockout stage lives on the Hub
            if (g.playoffPhase == 2 && g.ceremony != null) {
                // ---- Trophy Ceremony (idea 42) ----
                mc.addView(Ui.gold(act, "🏆 TROPHY CEREMONY", 13));
                mc.addView(Ui.h2(act, g.ceremony.optString("champion") + " — Season "
                        + g.ceremony.optInt("season") + " Champions!"));
                mc.addView(Ui.small(act, g.ceremony.optString("finalSummary")));
                if (!g.ceremony.optString("potm").isEmpty()) {
                    mc.addView(Ui.text(act, "Player of the Final: " + g.ceremony.optString("potm")
                            + " — " + g.ceremony.optString("potmDesc"), 13, Ui.GOLD, true));
                }
                if (g.userTeam.equals(g.ceremony.optString("champion"))) {
                    mc.addView(Ui.text(act, "🏆 The champions' prize is in the ledger — title No. "
                            + g.career.optInt("titles") + " for " + g.userTeam + "!", 13, Ui.GREEN, true));
                } else if (g.userTeam.equals(g.ceremony.optString("runnerUp"))) {
                    mc.addView(Ui.text(act, "Runners-up — +500 CF prize banked. So close.", 13, Ui.GOLD, true));
                }
                // Season Awards (idea 47) presented with the ceremony
                if (g.lastAwards != null && g.lastAwards.length() > 0) {
                    mc.addView(Ui.h2(act, "🏅 Season Awards"));
                    addAwardLine(mc, act, g, "goldenBat", "Golden Bat");
                    addAwardLine(mc, act, g, "bestBowler", "Best Bowler");
                    addAwardLine(mc, act, g, "mvp", "MVP of the Season");
                    addAwardLine(mc, act, g, "emerging", "Emerging Player");
                }
                Button cont = Ui.goldBtn(act, "Continue to Off-Season");
                cont.setOnClickListener(v -> {
                    act.g.acknowledgeCeremony();
                    act.save();
                    act.toast("Off-season opens on the next Advance Day");
                    act.render();
                });
                mc.addView(cont);
            } else if (g.playoffPhase == 3) {
                mc.addView(Ui.gold(act, "SEASON COMPLETE", 13));
                mc.addView(Ui.h2(act, g.seasonChampion + " are champions"));
                mc.addView(Ui.small(act, "Advance Day to open the off-season — contracts, releases and the auction."));
            } else {
                JSONObject pf = g.pendingUserPlayoff();
                if (pf != null) {
                    final JSONObject f = pf;
                    mc.addView(Ui.gold(act, "🏆 PLAYOFF — " + f.optString("stage").toUpperCase(), 13));
                    mc.addView(Ui.h2(act, g.userTeam + " vs " + g.opponentOf(f)));
                    Game.ensureFixtureMeta(f, g.season);
                    mc.addView(Ui.small(act, "Knockout cricket — the loser goes home. Pitch: "
                            + Data.PITCH_TYPES[f.optInt("pitch", 0)]
                            + (f.optBoolean("evening") ? " · Day/Night (dew in the chase)" : " · Day game")
                            + " · Rain risk " + f.optInt("rain", 0) + "%"));
                    mc.addView(Ui.text(act, "⚠ Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(f)), 13, Ui.RED, true));
                    addAnalysis(act, mc, g, f); // Batch H (idea 75)
                addPrediction(act, mc, g, f); // Batch I (idea 86)
                    // the same team-sheet validator gates Play and Sim here
                    final java.util.List<String> problems = g.xiProblems();
                    if (!problems.isEmpty()) {
                        mc.addView(Ui.text(act, "Team sheet blocked: " + problems.size() + " problem(s) — tap Play to see them.", 13, Ui.RED, true));
                    }
                    Button play = Ui.goldBtn(act, "Play " + f.optString("stage"));
                    play.setOnClickListener(v -> {
                        if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                        act.startMatch(f);
                    });
                    mc.addView(play);
                    Button sim = Ui.darkBtn(act, "Sim This Match");
                    sim.setOnClickListener(v -> {
                        if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                        act.g.simPlayoffFixture(f);
                        act.save();
                        act.toast(f.optString("stage") + " simulated");
                        act.render();
                    });
                    mc.addView(sim);
                } else {
                    mc.addView(Ui.gold(act, "🏆 PLAYOFFS", 13));
                    mc.addView(Ui.h2(act, "Knockout stage in progress"));
                    mc.addView(Ui.small(act, g.userTeam + " are not in this tie — follow the bracket in the League tab, or Advance Day to move it on."));
                    for (int i = 0; i < g.playoffFixtures.length(); i++) {
                        JSONObject f = g.playoffFixtures.optJSONObject(i);
                        if (f != null && f.optBoolean("played")) mc.addView(Ui.small(act, "• " + f.optString("summary")));
                    }
                }
            }
        } else {
            JSONObject today = g.todaysUserFixture();
            JSONObject next = g.nextUserFixture();
            if (today != null) {
                final JSONObject f = today;
                Game.ensureFixtureMeta(f, g.season);
                // Batch F (idea 58): the derby gets its badge up front
                mc.addView(Ui.gold(act, g.isDerby(f) ? "MATCH DAY · 🔥 DERBY" : "MATCH DAY", 13));
                mc.addView(Ui.h2(act, g.userTeam + " vs " + g.opponentOf(f)));
                mc.addView(Ui.small(act, g.userTeam.equals(f.optString("home"))
                        ? "Home game at " + f.optString("ground") + " — expected crowd ~"
                            + g.expectedAttendance(f) + "%. Gate receipts scale with the crowd."
                        : "Away game at " + f.optString("ground") + " — travel costs −" + Game.TRAVEL_COST + " CF. Win prize: " + g.prize(300) + " CF."));
                // Batch G (idea 63): the ticket line rides every home match card
                if (g.userTeam.equals(f.optString("home"))) {
                    mc.addView(Ui.text(act, "🎟 " + g.ticketLine(f) + " (gate x" + g.ticketMultiplier() + ")", 13, Ui.GOLD, false));
                }
                if (g.isDerby(f)) {
                    mc.addView(Ui.text(act, "🔥 DERBY — win prize boosted: " + g.prize(300) + " + " + (g.prize(300) / 2)
                            + " CF derby bonus, and the ground will be packed.", 13, Ui.RED, true));
                }
                // Batch A (ideas 2–4) + Batch F (idea 59): conditions on the match-day card
                mc.addView(Ui.small(act, "Pitch: " + Data.PITCH_TYPES[f.optInt("pitch", 0)]
                        + " · Ground: " + Data.GROUND_CHARS[f.optInt("groundChar", 1)]
                        + (f.optBoolean("evening") ? " · Day/Night (dew in the chase)" : " · Day game")
                        + " · Rain risk " + f.optInt("rain", 0) + "%"));
                // Batch B (idea 19): danger-man scouting line on the pre-match card
                mc.addView(Ui.text(act, "⚠ Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(f)), 13, Ui.RED, true));
                // Batch H (idea 75): pre-match analysis
                addAnalysis(act, mc, g, f);
                addPrediction(act, mc, g, f); // Batch I (idea 86)
                // v2 team-sheet validator gates BOTH Play and Sim on match day
                final java.util.List<String> problems = g.xiProblems();
                if (!problems.isEmpty()) {
                    mc.addView(Ui.text(act, "Team sheet blocked: " + problems.size() + " problem(s) — tap Play to see them.", 13, Ui.RED, true));
                }
                Button play = Ui.goldBtn(act, "Play Match");
                play.setOnClickListener(v -> {
                    if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                    act.startMatch(f);
                });
                mc.addView(play);
                Button sim = Ui.darkBtn(act, "Sim This Match");
                sim.setOnClickListener(v -> {
                    if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                    act.g.simFixture(f);
                    act.save();
                    act.toast("Match simulated");
                    act.render();
                });
                mc.addView(sim);
            } else if (next != null) {
                mc.addView(Ui.gold(act, "UPCOMING MATCH", 13));
                mc.addView(Ui.h2(act, "vs " + g.opponentOf(next)));
                mc.addView(Ui.small(act, "Scheduled for Day " + next.optInt("day") + ". Advance the days to reach it."));
                Game.ensureFixtureMeta(next, g.season);
                mc.addView(Ui.small(act, "Pitch: " + Data.PITCH_TYPES[next.optInt("pitch", 0)]
                        + (next.optBoolean("evening") ? " · Day/Night" : " · Day game")
                        + " · Rain risk " + next.optInt("rain", 0) + "%"));
                mc.addView(Ui.text(act, "⚠ Danger man: " + MatchEngine.dangerManLine(act.g, g.opponentOf(next)), 13, Ui.RED, true));
                // Batch H (idea 75): pre-match analysis for the upcoming game too
                addAnalysis(act, mc, g, next);
            } else {
                mc.addView(Ui.gold(act, "SEASON COMPLETE", 13));
                mc.addView(Ui.h2(act, "All fixtures played"));
                mc.addView(Ui.small(act, "Advance Day to crown the champion and start Season " + (g.season + 1) + "."));
            }
        }
        root.addView(mc);

        // Batch H (idea 71): a pending press conference — answer it or skip;
        // advancing a day lets it expire quietly
        if (g.pressConf != null) root.addView(pressCard(act));

        // Batch H (idea 74): Coach's Corner — one real tip for today
        LinearLayout coach = Ui.card(act);
        coach.addView(Ui.h2(act, "🧢 Coach's Corner"));
        coach.addView(Ui.body(act, g.coachTip()));
        root.addView(coach);

        // Batch H (idea 76): the finished season's review, during the off-season
        if (g.offseason > 0 && g.seasonHistory.length() > 0) {
            JSONObject lastSeason = g.seasonHistory.optJSONObject(0);
            java.util.List<String> review = g.seasonReviewLines(lastSeason);
            if (lastSeason != null && !review.isEmpty()) {
                LinearLayout rv = Ui.card(act);
                rv.addView(Ui.h2(act, "📋 Season " + lastSeason.optInt("season") + " Review"));
                for (String line : review) rv.addView(Ui.body(act, line));
                // Batch I (idea 89): the season's result code rides the review
                rv.addView(Ui.small(act, "🧾 " + g.seasonResultCode() + "  (copy it in Profile)"));
                root.addView(rv);
            }
        }

        // Batch H (idea 77): the last match's report — view or share it
        if (g.lastReport != null) {
            LinearLayout rep = Ui.card(act);
            rep.addView(Ui.h2(act, "🏏 Last Match Report"));
            rep.addView(Ui.body(act, g.reportText(g.lastReport)));
            Button viewCard = Ui.darkBtn(act, "🖼 View Report Card");
            viewCard.setOnClickListener(v -> act.showReportCard());
            rep.addView(viewCard);
            LinearLayout srow = Ui.row(act);
            Button shareImg = Ui.goldBtn(act, "📤 Share Image");
            shareImg.setOnClickListener(v -> act.shareReportImage());
            Button shareTxt = Ui.darkBtn(act, "Share Text");
            shareTxt.setOnClickListener(v -> act.shareReportText());
            LinearLayout.LayoutParams sh = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            shareImg.setLayoutParams(sh);
            shareTxt.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            srow.addView(shareImg);
            srow.addView(shareTxt);
            rep.addView(srow);
            root.addView(rep);
        }

        // quick actions
        LinearLayout qa = Ui.card(act);
        qa.addView(Ui.h2(act, "Manager Actions"));
        Button adv = Ui.goldBtn(act, "Advance Day");
        adv.setOnClickListener(v -> {
            if (act.g.match != null) { act.toast("Finish the current match first"); return; }
            String msg = act.g.advanceDay();
            act.save();
            act.toast(msg);
            act.render();
        });
        qa.addView(adv);
        LinearLayout row = Ui.row(act);
        Button rec = Ui.darkBtn(act, "Recovery");
        rec.setOnClickListener(v -> {
            int gain = act.g.recovery();
            act.save();
            if (gain < 0) {
                act.toast("Not enough CF — a recovery session costs " + act.g.recoveryCost() + " CF");
            } else {
                act.toast("Stamina +" + gain + " · −" + act.g.recoveryCost() + " CF (Medical Lvl " + act.g.facilityLevel(1) + ")");
            }
            act.render();
        });
        Button talk = Ui.darkBtn(act, "Team Talk");
        talk.setOnClickListener(v -> {
            if (act.g.teamTalk()) { act.save(); act.toast("Set % boosted squad-wide"); }
            else act.toast("Already done today — one talk per day");
            act.render();
        });
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        rec.setLayoutParams(half);
        talk.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(rec);
        row.addView(talk);
        qa.addView(row);
        // Batch H (idea 79): the season calendar
        Button cal = Ui.darkBtn(act, "📅 Season Calendar");
        cal.setOnClickListener(v -> { act.calendarMode = true; act.render(); });
        qa.addView(cal);
        // Batch I (ideas 81–90): the Modes & Challenges sub-screen
        Button modes = Ui.darkBtn(act, "🎮 Modes & Challenges");
        modes.setOnClickListener(v -> { act.modesMode = true; act.render(); });
        qa.addView(modes);
        // Batch J (idea 97): global search over players, clubs, fixtures
        Button search = Ui.darkBtn(act, "🔍 Search Players, Teams, Fixtures");
        search.setOnClickListener(v -> { act.searchMode = true; act.render(); });
        qa.addView(search);
        root.addView(qa);

        // news
        LinearLayout news = Ui.card(act);
        news.addView(Ui.h2(act, "Club News"));
        if (g.news.length() == 0) news.addView(Ui.small(act, "No news yet."));
        for (int i = 0; i < g.news.length(); i++) {
            TextView t = Ui.body(act, "•  " + g.news.optString(i));
            t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
            news.addView(t);
        }
        root.addView(news);

        // Batch H (idea 73): Fan Buzz — the supporters' own feed
        if (g.fanPosts.length() > 0) {
            LinearLayout buzz = Ui.card(act);
            buzz.addView(Ui.h2(act, "📣 Fan Buzz"));
            for (int i = 0; i < g.fanPosts.length(); i++) {
                JSONObject fp = g.fanPosts.optJSONObject(i);
                if (fp == null) continue;
                TextView who = Ui.text(act, fp.optString("name") + "  " + fp.optString("handle"), 12, Ui.GOLD, true);
                who.setPadding(0, Ui.dp(act, 5), 0, 0);
                buzz.addView(who);
                buzz.addView(Ui.body(act, fp.optString("text")));
            }
            root.addView(buzz);
        }
        return root;
    }

    /** Batch I (idea 86): the prediction game on every match-day card —
     *  two optional picks (winner + top scorer), the pundit's own picks
     *  for flavour, and the running record. Picks write straight into
     *  Game.prediction and lock when the match starts (from then on the
     *  Hub shows the in-progress card instead of the match-day card). */
    private static void addPrediction(final MainActivity act, LinearLayout card, final Game g, JSONObject f) {
        final JSONObject p = g.ensurePrediction(f);
        if (p == null) return;
        card.addView(Ui.gold(act, "🔮 PREDICTION GAME (OPTIONAL)", 11));
        card.addView(Ui.small(act, "The pundit backs " + p.optString("punditWinner")
                + " · top scorer " + p.optString("punditScorer")
                + ". Beat him: both picks right pays +60 CF, the winner alone +15 CF."));
        LinearLayout wrow = Ui.row(act);
        final String wp = p.optString("winnerPick");
        Button w1 = Ui.chip(act, g.shortFor(g.userTeam), g.userTeam.equals(wp));
        w1.setOnClickListener(v -> { try { p.put("winnerPick", g.userTeam); } catch (Exception ignored) {} act.save(); act.render(); });
        Button w2 = Ui.chip(act, g.shortFor(p.optString("opp")), p.optString("opp").equals(wp));
        w2.setOnClickListener(v -> { try { p.put("winnerPick", p.optString("opp")); } catch (Exception ignored) {} act.save(); act.render(); });
        wrow.addView(w1);
        wrow.addView(w2);
        card.addView(wrow);
        org.json.JSONArray names = p.optJSONArray("names");
        if (names != null) {
            String sp = p.optString("scorerPick");
            for (int i = 0; i < names.length(); i += 2) {
                LinearLayout srow = Ui.row(act);
                for (int j = i; j < Math.min(i + 2, names.length()); j++) {
                    final String nm = names.optString(j);
                    Button c = Ui.chip(act, nm, nm.equals(sp));
                    c.setOnClickListener(v -> { try { p.put("scorerPick", nm); } catch (Exception ignored) {} act.save(); act.render(); });
                    srow.addView(c);
                }
                card.addView(srow);
            }
        }
        if (!wp.isEmpty()) {
            card.addView(Ui.small(act, "Your picks: winner — " + wp
                    + (p.optString("scorerPick").isEmpty() ? " · top scorer: not picked"
                            : " · top scorer — " + p.optString("scorerPick"))
                    + " · Record: " + g.predSettled + " settled, " + g.predBoth + " perfect."));
        }
    }

    /** Batch H (idea 75): the analysis block shared by every match-day
     *  card — opponent form, the key battle and the bookmaker's line. */
    private static void addAnalysis(MainActivity act, LinearLayout card, Game g, JSONObject f) {
        String opp = g.opponentOf(f);
        card.addView(Ui.gold(act, "📋 MATCH ANALYSIS", 11));
        String form = g.oppRecentForm(opp);
        if (!form.isEmpty()) card.addView(Ui.small(act, opp + " form (last 5): " + form));
        String kb = g.keyBattleLine(opp);
        if (!kb.isEmpty()) card.addView(Ui.small(act, kb));
        card.addView(Ui.small(act, "📊 " + g.favouriteLine(f)));
    }

    /** Batch H (idea 71): the press-conference card. */
    private static View pressCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout pc = Ui.card(act);
        pc.addView(Ui.gold(act, "🎙 PRESS CONFERENCE — " + g.pressConf.optString("comp").toUpperCase(), 12));
        pc.addView(Ui.h2(act, "The press are waiting, gaffer"));
        pc.addView(Ui.body(act, "\"" + g.pressConf.optString("q") + "\""));
        String[] labels = {"💪 Confident", "😐 Balanced", "🔥 Fiery"};
        for (int i = 0; i < 3; i++) {
            final int choice = i;
            Button b = i == 1 ? Ui.darkBtn(act, labels[i]) : Ui.goldBtn(act, labels[i]);
            b.setOnClickListener(v -> {
                String out = act.g.answerPress(choice);
                act.save();
                if (!out.isEmpty()) act.toast(out);
                act.render();
            });
            pc.addView(b);
        }
        Button skip = Ui.darkBtn(act, "Skip press (no effects)");
        skip.setOnClickListener(v -> {
            act.g.answerPress(-1);
            act.save();
            act.render();
        });
        pc.addView(skip);
        return pc;
    }

    /** Batch E (idea 47): one awards line on the Trophy Ceremony card. */
    private static void addAwardLine(LinearLayout card, MainActivity act, Game g, String key, String label) {
        JSONObject a = g.lastAwards == null ? null : g.lastAwards.optJSONObject(key);
        if (a == null) return;
        card.addView(Ui.text(act, label + ": " + a.optString("name") + " (" + a.optString("team")
                + ") — " + a.optString("detail"), 13, Ui.GOLD, false));
    }
}
