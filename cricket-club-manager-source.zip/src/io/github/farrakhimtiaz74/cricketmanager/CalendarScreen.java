package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/** Batch H (idea 79): the season calendar — every fixture of the season
 *  (league, playoffs, cup) grouped by day, results for played ties, the
 *  user's ties in gold, transfer-window days marked. Data comes from
 *  Game.calendarDays() so the screen stays a pure renderer. */
public class CalendarScreen {

    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);
        LinearLayout head = Ui.card(act);
        head.addView(Ui.h2(act, "📅 Season " + g.season + " Calendar"));
        head.addView(Ui.text(act, "Every fixture of the season — your matches in gold. "
                + "Days " + Game.WINDOW_OPEN_DAY + "–" + Game.WINDOW_CLOSE_DAY + " are the transfer window.", 13, Ui.MUTED, false));
        android.widget.Button close = Ui.darkBtn(act, "✖ Close calendar");
        close.setOnClickListener(v -> { act.calendarMode = false; act.render(); });
        head.addView(close);
        root.addView(head);

        JSONArray days = g.calendarDays();
        for (int i = 0; i < days.length(); i++) {
            JSONObject d = days.optJSONObject(i);
            if (d == null) continue;
            int dayNo = d.optInt("day");
            JSONArray rows = d.optJSONArray("rows");
            LinearLayout card = Ui.card(act);
            String title = "Day " + dayNo;
            if (dayNo == g.day && g.offseason == 0) title += " · TODAY";
            card.addView(Ui.h2(act, title));
            if (rows == null || rows.length() == 0) {
                card.addView(Ui.text(act, "Rest day — no fixtures.", 13, Ui.MUTED, false));
            } else {
                for (int j = 0; j < rows.length(); j++) {
                    JSONObject r = rows.optJSONObject(j);
                    if (r == null) continue;
                    boolean user = r.optBoolean("user");
                    TextView tag = Ui.text(act, r.optString("tag"), 11, Ui.GOLD, true);
                    tag.setPadding(0, Ui.dp(act, 5), 0, 0);
                    card.addView(tag);
                    card.addView(Ui.text(act, r.optString("text"), 13,
                            user ? Ui.GOLD : r.optBoolean("played") ? Ui.INK : Ui.MUTED, user));
                }
            }
            root.addView(card);
        }
        return root;
    }
}
