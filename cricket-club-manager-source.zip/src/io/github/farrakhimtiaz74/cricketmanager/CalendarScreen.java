package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/** Batch H (idea 79): the season calendar — every fixture of the season
 * (league, playoffs, cup) grouped by day, results for played ties, the
 * user's ties in gold, transfer-window days marked. Data comes from
 * Game.calendarDays() so the screen stays a pure renderer. */
public class CalendarScreen {

 public static View build(final MainActivity act) {
 final Game g = act.g;
 LinearLayout root = Ui.col(act);
 // P2 (suggestions 13/19): the standard sub-screen header — the
 // window-days context rides as its subtitle
 root.addView(Ui.subHeader(act, "Season " + g.season + " Calendar",
 "Every fixture by day · Days " + Game.WINDOW_OPEN_DAY + "–" + Game.WINDOW_CLOSE_DAY + " are the transfer window",
 v -> { act.calendarMode = false; act.render(); }));
 root.addView(Ui.small(act, "Your matches are in gold — tap any fixture for its sheet."));

 // P4 (suggestion 40): while the off-season runs, the calendar
 // leads with the phase in progress — the days below belong to
 // the season just finished / about to start
 if (g.offseason > 0) {
 LinearLayout ph = Ui.card(act);
 ph.addView(Ui.gold(act, "OFF-SEASON — " + (g.offseason == 1 ? "RETAIN & RENEW" : "THE AUCTION"), 13));
 ph.addView(Ui.small(act, g.offseason == 1
 ? "Phase 1: keep, release and renew your squad in Transfers — confirming the squad opens the auction."
 : "Phase 2: the auction is live in Transfers. Finish it (or skip) to start Season " + g.season + "."));
 root.addView(ph);
 }

 JSONArray days = g.calendarDays();
 int curWeek = 0;
 for (int i = 0; i < days.length(); i++) {
 JSONObject d = days.optJSONObject(i);
 if (d == null) continue;
 int dayNo = d.optInt("day");
 // P4 (suggestion 40): fixtures group under WEEK headers
 // (Week 1 = Days 1–7, Week 2 = Days 8–14…)
 int wk = Present.weekOfDay(dayNo);
 if (wk != curWeek) {
 curWeek = wk;
 int wStart = (wk - 1) * 7 + 1;
 root.addView(Ui.sectionHeader(act, "WEEK " + wk + " — DAYS " + wStart + "–" + (wStart + 6)));
 }
 JSONArray rows = d.optJSONArray("rows");
 // P4: a gold marker line rides on the current day group
 if (dayNo == g.day && g.offseason == 0) {
 LinearLayout mark = Ui.row(act);
 View bar = new View(act);
 bar.setBackgroundColor(Ui.GOLD);
 bar.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 3), Ui.dp(act, 16)));
 mark.addView(bar);
 TextView mt = Ui.text(act, "  TODAY — DAY " + dayNo, 12, Ui.GOLD, true);
 mark.addView(mt);
 mark.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 4));
 root.addView(mark);
 }
 LinearLayout card = Ui.card(act);
 String title = "Day " + dayNo;
 if (dayNo == g.day && g.offseason == 0) title += " · TODAY";
 card.addView(Ui.h2(act, title));
 if (rows == null || rows.length() == 0) {
 card.addView(Ui.emptyState(act, Icons.CONTRACT, "Rest day — no fixtures."));
 } else {
 for (int j = 0; j < rows.length(); j++) {
 final JSONObject r = rows.optJSONObject(j);
 if (r == null) continue;
 boolean user = r.optBoolean("user");
 View left = !r.optString("home").isEmpty()
 ? (View) CrestView.forTeam(act, g, r.optString("home"), 24)
 : (View) Icons.badge(act, Icons.CONTRACT);
 final int fDay = dayNo;
 card.addView(Ui.listRow(act, left, r.optString("text"), cleanTag(r.optString("tag")),
 r.optBoolean("played") ? "FT" : dayNo == g.day ? "TODAY" : user ? "YOURS" : "",
 v -> fixtureSheet(act, r, fDay)));
 // P4 (suggestion 40): the competition as a colour chip
 card.addView(compChip(act, r.optString("tag")));
 }
 }
 root.addView(card);
 }
 return root;
 }

 /** P4 (suggestion 40): the stored window marker tag carries an
 *  emoji from Batch H's data builder — the calendar presents the
 *  plain word (P1: no emoji in UI chrome). */
 private static String cleanTag(String tag) {
 return tag.replace("🛒 ", "").replace("🛒", "").trim();
 }

 /** P4 (suggestion 40): a small competition chip — League slate
 *  with gold text, Cup green, Playoff deep gold, Window pitch,
 *  everything else grey — coloured by Present.compKind. */
 private static View compChip(MainActivity act, String tag) {
 String kind = Present.compKind(tag);
 String label = "WINDOW".equals(kind) ? "TRANSFER WINDOW"
 : "CUP".equals(kind) ? "50-OVER CUP"
 : "PLAYOFF".equals(kind) ? "PLAYOFF"
 : "LEAGUE".equals(kind) ? "T20 LEAGUE"
 : "FRIENDLY".equals(kind) ? "FRIENDLY" : "FIXTURE";
 int bg, fg;
 switch (kind) {
 case "CUP": bg = Ui.PITCH; fg = 0xFFBBF7D0; break;
 case "PLAYOFF": bg = Ui.GOLD_DEEP; fg = 0xFFFFFBEB; break;
 case "WINDOW": bg = Ui.PITCH_DEEP; fg = 0xFFBBF7D0; break;
 case "LEAGUE": bg = Ui.CARD2; fg = Ui.GOLD; break;
 default: bg = Ui.CARD2; fg = Ui.MUTED; break;
 }
 LinearLayout wrap = Ui.row(act);
 TextView chip = Ui.text(act, label, 9.5f, fg, true);
 chip.setBackground(Ui.round(bg, 8, act));
 chip.setPadding(Ui.dp(act, 7), Ui.dp(act, 2), Ui.dp(act, 7), Ui.dp(act, 2));
 LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
 android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
 clp.setMargins(Ui.dp(act, 40), 0, 0, Ui.dp(act, 4));
 chip.setLayoutParams(clp);
 wrap.addView(chip);
 return wrap;
 }

 /** Design Batch (item 5): the fixture bottom sheet — crests, the
 * competition, the day, the state of play, and how to reach the
 * match when it's the user's and it's live.
 * P2 (suggestion 17): public — the League tab's fixture, playoff
 * and cup rows open this exact sheet with a calendar-shaped row. */
 public static void fixtureSheet(final MainActivity act, JSONObject r, int dayNo) {
 final Game g = act.g;
 LinearLayout sheet = Ui.col(act);
 LinearLayout crests = Ui.row(act);
 crests.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
 if (!r.optString("home").isEmpty()) {
 crests.addView(CrestView.forTeam(act, g, r.optString("home"), 38));
 crests.addView(Ui.text(act, " vs ", 14, Ui.MUTED, true));
 crests.addView(CrestView.forTeam(act, g, r.optString("away"), 38));
 sheet.addView(crests);
 }
 sheet.addView(Ui.h2(act, r.optString("home").isEmpty()
 ? r.optString("tag") : r.optString("home") + " vs " + r.optString("away")));
 sheet.addView(Ui.gold(act, r.optString("tag").toUpperCase() + " · DAY " + dayNo + " · SEASON " + g.season, 12));
 sheet.addView(Ui.body(act, r.optString("text")));
 sheet.addView(Ui.small(act, r.optBoolean("played")
 ? "Played — the result stands in the League tab."
 : r.optBoolean("user")
 ? (dayNo == g.day ? "It's match day — play it from the Hub." : "Coming up — Advance Day on the Hub to reach it.")
 : "Not your fixture — Advance Day sims it with the rest of the round."));
 android.widget.Button close = Ui.darkBtn(act, "Close"); // P1
 close.setOnClickListener(v -> act.hideSheet());
 sheet.addView(close);
 act.showSheet(sheet);
 }
}
