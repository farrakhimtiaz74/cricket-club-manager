package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Random;

public class MatchScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        final JSONObject m = g.match;
        LinearLayout root = Ui.col(act);
        if (m == null) {
            root.addView(Ui.body(act, "No match in progress."));
            return root;
        }
        String phase = m.optString("phase");

        // top bar: fixture + exit
        LinearLayout top = Ui.row(act);
        TextView title = Ui.text(act, act.g.shortFor(act.g.userTeam) + " vs " + act.g.shortFor(m.optString("opp"))
                + " · " + (m.optBoolean("cup") ? "One-Day Cup · 50 ov"
                        : m.optBoolean("playoff") ? m.optString("stageName") + " · T20" : "T20")
                + (m.optBoolean("derby") ? " · 🔥 DERBY" : "")
                // Batch I: friendlies are labelled so they never read as season matches
                + (m.optInt("friendly") == 1 ? " · 🎯 Daily Challenge"
                        : m.optInt("friendly") == 2 ? " · 🎬 " + Game.SCENARIO_TITLES[Math.max(0, Math.min(3, m.optInt("scenarioId", 0)))] : ""), 16, Ui.INK, true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        top.addView(title);
        Button exit = Ui.chip(act, "Save & Exit", false);
        exit.setOnClickListener(v -> { act.matchMode = false; act.tab = 0; act.save(); act.render(); });
        top.addView(exit);
        root.addView(top);

        if ("toss".equals(phase)) {
            root.addView(tossView(act, m));
            root.addView(commCard(act, m));
            return root;
        }
        if ("break".equals(phase)) {
            // v2 innings break: the match pauses here until the manager starts the chase
            LinearLayout card = Ui.card(act);
            card.addView(Ui.gold(act, "INNINGS BREAK", 13));
            card.addView(Ui.h2(act, m.optString("inn1Summary")));
            card.addView(Ui.body(act, "Target: " + m.optInt("target") + " for "
                    + (act.g.userTeam.equals(m.optString("inn1BatTeam")) ? m.optString("opp") : act.g.userTeam) + "."));
            // Batch A (idea 5): predictor at the break judges the set total vs par
            card.addView(Ui.small(act, "Win Predictor — " + act.g.userTeam + " " + MatchEngine.winPredictor(act.g) + "% to win from here."));
            // Batch I: friendlies skip the stamina regen (no season effects)
            card.addView(Ui.small(act, m.optInt("friendly") > 0
                    ? "Friendly rules: no stamina or morale changes — the season squad is untouched by this match."
                    : "Both sides catch their breath — your XI recovered +"
                    + Game.BREAK_REGEN + " stamina at the break."));
            // Batch B (idea 11): the chase is a new innings — Powerplay plans
            // for innings 2 can still be changed here, before it starts
            addPpPickers(act, m, card, true);
            card.addView(Ui.small(act, "Bowling in the chase? Your 20-over rotation plan auto-fills when the innings starts — edit any over from the plan card once play begins."));
            Button chase = Ui.goldBtn(act, "Start the Chase");
            chase.setOnClickListener(v -> { MatchEngine.startChase(act.g); act.save(); act.render(); });
            card.addView(chase);
            root.addView(card);
            root.addView(manhattanCard(act, "Manhattan — Innings 1 (runs per over)", m.optJSONArray("inn1OverRuns")));
            root.addView(scorecard(act, m));
            root.addView(extrasCard(act, "Innings 1", m.optJSONArray("inn1Parts"), m.optJSONArray("inn1Fow")));
            root.addView(commCard(act, m));
            return root;
        }
        if ("superbreak".equals(phase)) {
            // Batch A (idea 1): between Super Over stages — the match is tied
            LinearLayout card = Ui.card(act);
            card.addView(Ui.gold(act, "SUPER OVER", 13));
            int stage = m.optInt("superStage", 1);
            if (stage == 1) {
                String first = act.g.userTeam.equals(m.optString("inn1BatTeam")) ? m.optString("opp") : act.g.userTeam;
                card.addView(Ui.h2(act, "Scores level — Super Over decides it!"));
                card.addView(Ui.body(act, first + " bat first in the Super Over: 6 balls, 2 wickets."));
            } else {
                card.addView(Ui.h2(act, act.g.shortFor(m.optString("super1BatTeam")) + " posted "
                        + m.optInt("super1Runs") + "/" + m.optInt("super1Wkts")));
                String second = act.g.userTeam.equals(m.optString("super1BatTeam")) ? m.optString("opp") : act.g.userTeam;
                card.addView(Ui.body(act, second + " need " + (m.optInt("super1Runs") + 1) + " from 6 balls to win the match."));
            }
            Button go = Ui.goldBtn(act, stage == 1 ? "Start the Super Over" : "Start the Chase — Super Over");
            go.setOnClickListener(v -> { MatchEngine.startSuperStage(act.g, stage); act.save(); act.render(); });
            card.addView(go);
            root.addView(card);
            root.addView(commCard(act, m));
            return root;
        }
        if ("done".equals(phase)) {
            LinearLayout card = Ui.card(act);
            card.addView(Ui.gold(act, "FULL TIME", 13));
            card.addView(Ui.h2(act, m.optString("result")));
            if (m.optBoolean("superPlayed")) {
                card.addView(Ui.text(act, "⚡ " + m.optString("superSummary"), 14, Ui.GOLD, true));
            }
            if (m.has("potm")) {
                // Batch A (idea 8): Player of the Match announcement
                // Batch I: a friendly's POTM is display-only (no +25 CF)
                card.addView(Ui.text(act, "🏆 Player of the Match: " + m.optString("potm")
                        + " — " + m.optString("potmDesc")
                        + (m.optBoolean("potmUser") && m.optInt("friendly") == 0 ? "  (+25 CF bonus)" : ""), 14, Ui.INK, true));
            }
            // Batch I: a friendly's full-time line is its mode note — the
            // season text below would be a lie (nothing was added anywhere)
            if (m.optInt("friendly") > 0) {
                card.addView(Ui.text(act, m.optString("friendlyNote"), 14, Ui.GOLD, true));
            } else {
                card.addView(Ui.small(act, m.optBoolean("userWon")
                        ? "Victory! Prize CF, points and morale have been added."
                        : "Defeat. Appearance CF added — check the League tab for the table."));
            }
            // Batch H (ideas 77/71): share the report, and face the press
            // Batch I: not for friendlies (no report is built for them)
            if (act.g.lastReport != null && m.optInt("friendly") == 0) {
                LinearLayout srow2 = Ui.row(act);
                Button shareImg = Ui.goldBtn(act, "📤 Share Report");
                shareImg.setOnClickListener(v -> act.shareReportImage());
                Button shareTxt = Ui.darkBtn(act, "Share Text");
                shareTxt.setOnClickListener(v -> act.shareReportText());
                LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                shareImg.setLayoutParams(hp);
                shareTxt.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                srow2.addView(shareImg);
                srow2.addView(shareTxt);
                card.addView(srow2);
                Button viewCard = Ui.darkBtn(act, "🖼 View Report Card");
                viewCard.setOnClickListener(v -> act.showReportCard());
                card.addView(viewCard);
            }
            if (act.g.pressConf != null) {
                card.addView(Ui.gold(act, "🎙 PRESS CONFERENCE", 12));
                card.addView(Ui.body(act, "\"" + act.g.pressConf.optString("q") + "\""));
                String[] plabels = {"💪 Confident", "😐 Balanced", "🔥 Fiery"};
                for (int pi = 0; pi < 3; pi++) {
                    final int choice = pi;
                    Button pb = pi == 1 ? Ui.darkBtn(act, plabels[pi]) : Ui.goldBtn(act, plabels[pi]);
                    pb.setOnClickListener(v -> {
                        String out = act.g.answerPress(choice);
                        act.save();
                        if (!out.isEmpty()) act.toast(out);
                        act.render();
                    });
                    card.addView(pb);
                }
                Button pskip = Ui.darkBtn(act, "Skip press (answer on the Hub later)");
                pskip.setOnClickListener(v -> act.render());
                card.addView(pskip);
            }
            Button back = Ui.goldBtn(act, "Back to Hub");
            back.setOnClickListener(v -> {
                act.g.match = null;
                act.matchMode = false;
                act.tab = 0;
                act.save();
                act.render();
            });
            card.addView(back);
            root.addView(card);
            root.addView(manhattanCard(act, "Manhattan — Innings 1", m.optJSONArray("inn1OverRuns")));
            root.addView(manhattanCard(act, "Manhattan — Innings 2",
                    m.has("inn2OverRuns") ? m.optJSONArray("inn2OverRuns") : m.optJSONArray("overRuns")));
            root.addView(scorecard(act, m));
            root.addView(extrasCard(act, "Innings 1", m.optJSONArray("inn1Parts"), m.optJSONArray("inn1Fow")));
            root.addView(extrasCard(act, "Innings 2",
                    m.has("inn2Parts") ? m.optJSONArray("inn2Parts") : m.optJSONArray("parts"),
                    m.has("inn2Fow") ? m.optJSONArray("inn2Fow") : m.optJSONArray("fow")));
            root.addView(commCard(act, m));
            return root;
        }

        // ---- live play ----
        root.addView(scoreHeader(act, m));
        // Batch E (idea 44): "As It Stands" — the live group table with this
        // match's provisional result applied (group-stage matches only)
        // Batch I: never for friendlies — they don't touch the table
        if (!m.optBoolean("playoff") && m.optInt("friendly") == 0) root.addView(asItStandsCard(act, m));
        // Batch B (idea 14): a wicket fell on Lahore's watch — the innings
        // parks here until the manager picks who walks in next
        if (m.optBoolean("awaitBat")) {
            root.addView(nextBatterCard(act, m));
            root.addView(commCard(act, m));
            return root;
        }
        root.addView(tactics(act, m));

        LinearLayout controls = Ui.card(act);
        // Batch A (idea 10): match speed — staged sim pacing at 1x/2x, or Instant
        controls.addView(Ui.small(act, "Match speed (applies to Sim + Highlights):"));
        LinearLayout srow = new LinearLayout(act);
        srow.setOrientation(LinearLayout.HORIZONTAL);
        final String[] speedNames = {"Instant", "1x", "2x"};
        final int[] speedVals = {0, 1, 2};
        for (int i = 0; i < speedNames.length; i++) {
            final int sv = speedVals[i];
            Button c = Ui.chip(act, speedNames[i], act.g.speed == sv);
            c.setOnClickListener(v -> { act.g.speed = sv; act.save(); act.render(); });
            srow.addView(c);
        }
        controls.addView(srow);
        // Batch J (idea 95): Reduce Animations pins every sim to Instant
        if (act.settings != null && act.settings.reduceAnim()) {
            controls.addView(Ui.small(act, "⚙️ Reduce Animations is ON (Settings) — sims run Instant whatever the speed above says."));
        }
        if (act.autoMode != null) {
            Button stop = Ui.goldBtn(act, "⏸ Stop Auto-Sim");
            stop.setOnClickListener(v -> { act.stopAuto(); act.render(); });
            controls.addView(stop);
        }
        Button ball = Ui.goldBtn(act, "Bowl Ball");
        ball.setOnClickListener(v -> {
            act.stopAuto();
            String phaseBefore = act.g.match.optString("phase"); // Batch J (idea 94): jingle check
            MatchEngine.bowlBall(act.g);
            if (act.g.match.optString("phase").equals("done") && !"done".equals(phaseBefore)) {
                act.playEndJingle(act.g.userTeam.equals(act.g.match.optString("winnerTeam")));
            } else {
                act.playBallSound(true);
            }
            act.save();
            act.render();
        });
        controls.addView(ball);
        LinearLayout row = Ui.row(act);
        Button simOver = Ui.darkBtn(act, "Sim Over");
        simOver.setOnClickListener(v -> simTapped(act, "over"));
        Button simInn = Ui.darkBtn(act, "Sim Innings");
        simInn.setOnClickListener(v -> simTapped(act, "innings"));
        Button simMatch = Ui.darkBtn(act, "Sim Match");
        simMatch.setOnClickListener(v -> simTapped(act, "match"));
        LinearLayout.LayoutParams third = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        simOver.setLayoutParams(third);
        simInn.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        simMatch.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(simOver);
        row.addView(simInn);
        row.addView(simMatch);
        controls.addView(row);
        // Batch A (idea 9): Highlights — skip the quiet balls, stop on every key ball
        Button hl = Ui.darkBtn(act, "▶ Highlights — Next Key Ball");
        hl.setOnClickListener(v -> { act.stopAuto(); highlightsStep(act); });
        controls.addView(hl);
        controls.addView(Ui.small(act, "Highlights fast-plays through dot/singles balls and stops on every wicket, four and six. Tap again for the next one."));
        root.addView(controls);

        // Batch B cards: coach tip + rotation plan while bowling, match-ups always
        View coach = coachCard(act, m);
        if (coach != null) root.addView(coach);
        View rot = rotationCard(act, m);
        if (rot != null) root.addView(rot);
        root.addView(matchupCard(act, m));

        root.addView(scorecard(act, m));
        root.addView(commCard(act, m));
        return root;
    }

    /** Batch E (idea 44): collapsible live group table. The provisional
     *  rows apply the current score as if the match ended this ball —
     *  points for the result as it stands, NRR from the runs/balls so far. */
    private static View asItStandsCard(final MainActivity act, final JSONObject m) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        LinearLayout head = Ui.row(act);
        TextView t = Ui.text(act, "📊 Group A — As It Stands", 14, Ui.GOLD, true);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        head.addView(t);
        Button toggle = Ui.chip(act, act.showAsItStands ? "Hide" : "Show", act.showAsItStands);
        toggle.setOnClickListener(v -> { act.showAsItStands = !act.showAsItStands; act.render(); });
        head.addView(toggle);
        card.addView(head);
        if (act.showAsItStands) {
            card.addView(Ui.small(act, "Live projection — this match counted as finished at the current score."));
            java.util.List<JSONObject> rows = g.provisionalRows(m);
            for (int i = 0; i < rows.size(); i++) {
                JSONObject r = rows.get(i);
                boolean user = act.g.userTeam.equals(r.optString("team"));
                card.addView(Ui.text(act, (i + 1) + ". " + act.g.shortFor(r.optString("team"))
                        + " — P" + r.optInt("p") + " W" + r.optInt("w") + " L" + r.optInt("l")
                        + " · " + r.optInt("pts") + " pts · NRR "
                        + String.format(Locale.US, "%+.2f", r.optDouble("nrr")),
                        13, user ? Ui.GOLD : Ui.INK, user));
            }
        }
        return card;
    }

    // ---------------- Batch A helpers ----------------

    /** Sim buttons honour the speed setting (idea 10): Instant resolves
     *  synchronously (the v2 behaviour); 1x/2x stage the same sim through
     *  MainActivity's auto-play loop, and tapping again stops it. */
    private static void simTapped(MainActivity act, String mode) {
        // Batch J (idea 95): Reduce Animations forces the Instant path
        if (Settings.effectiveSpeed(act.g.speed, act.settings != null && act.settings.reduceAnim()) == 0) {
            act.stopAuto();
            // Batch B (idea 14): Instant sims fall back to the batting order
            // for next-man-in, so they never stall on the picker
            try { act.g.match.put("autoNextBat", true); } catch (Exception ignored) {}
            if ("over".equals(mode)) MatchEngine.simOver(act.g);
            else if ("innings".equals(mode)) MatchEngine.simInnings(act.g);
            else MatchEngine.simMatch(act.g);
            try { act.g.match.put("autoNextBat", false); } catch (Exception ignored) {}
            act.save();
            act.render();
        } else {
            act.startAuto(mode);
        }
    }

    /** Idea 9 — Highlights: fast-play quiet balls until the next KEY ball
     *  (wicket, four or six), then stop on that state for the user to read.
     *  Always terminates at the innings break, superbreak and full time
     *  because every phase change exits the loop. */
    private static void highlightsStep(MainActivity act) {
        JSONObject m = act.g.match;
        int inn = m.optInt("inn");
        int guard = 0;
        while (guard++ < 150) {
            MatchEngine.bowlBall(act.g);
            if (!"play".equals(m.optString("phase"))) break;
            if (m.optBoolean("awaitBat")) break; // Batch B: stop for the next-batter pick
            if (m.optInt("inn") != inn && m.optInt("balls") == 0) break; // safety net
            JSONArray lb = m.optJSONArray("lastBalls");
            String last = lb != null && lb.length() > 0 ? lb.optString(lb.length() - 1) : "";
            if ("W".equals(last) || "4".equals(last) || "6".equals(last)) break;
        }
        // Batch J (idea 94): Highlights is a LIVE path — the key ball it
        // stops on gets its sound (or the jingle if the match just ended)
        if ("done".equals(m.optString("phase"))) {
            act.playEndJingle(act.g.userTeam.equals(m.optString("winnerTeam")));
        } else {
            act.playBallSound(true);
        }
        act.save();
        act.render();
    }

    /** Idea 6 — Manhattan chart card. */
    private static View manhattanCard(MainActivity act, String title, JSONArray overRuns) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, title));
        if (overRuns == null || overRuns.length() == 0) {
            card.addView(Ui.small(act, "No overs bowled yet."));
        } else {
            card.addView(new ManhattanView(act, overRuns));
            card.addView(Ui.small(act, "Over number along the bottom, runs in each over on the bars."));
        }
        return card;
    }

    /** Idea 7 — partnerships + fall of wickets card for one innings. */
    private static View extrasCard(MainActivity act, String title, JSONArray parts, JSONArray fow) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, title + " — Partnerships & Fall of Wickets"));
        try {
        if (fow != null) {
            for (int i = 0; i < fow.length(); i++) {
                JSONObject f = fow.getJSONObject(i);
                card.addView(Ui.body(act, f.optInt("wkts") + "-" + f.optInt("score")
                        + "  (" + f.optString("name") + ", " + f.optString("over") + " ov)"));
            }
        }
        if (parts != null && parts.length() > 0) {
            card.addView(Ui.spacer(act, 6));
            card.addView(Ui.small(act, "Partnerships"));
            for (int i = 0; i < parts.length(); i++) {
                JSONObject p = parts.getJSONObject(i);
                card.addView(Ui.body(act, p.optString("pair") + " — " + p.optInt("runs")
                        + " (" + p.optInt("balls") + " balls)" + (p.optBoolean("unbroken") ? " *" : "")));
            }
        } else if (fow == null || fow.length() == 0) {
            card.addView(Ui.small(act, "No wickets have fallen yet."));
        }
        } catch (Exception ignored) {}
        return card;
    }

    // ---------------- toss ----------------

    /** v2 field-setting picker + Batch B (idea 17) named presets with a dot
     *  map — used at the toss and again live while bowling. Chips wrap in
     *  rows of three so nothing clips on a phone. */
    private static void addFieldPicker(final MainActivity act, final JSONObject m, LinearLayout into) {
        into.addView(Ui.small(act, "Field setting / preset (applies when you bowl):"));
        LinearLayout row = null;
        for (int i = 0; i < MatchEngine.FIELD.length; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(act);
                row.setOrientation(LinearLayout.HORIZONTAL);
                into.addView(row);
            }
            final int idx = i;
            Button c = Ui.chip(act, MatchEngine.FIELD[i], m.optInt("field", 1) == i);
            c.setOnClickListener(v -> {
                try { m.put("field", idx); } catch (Exception ignored) {}
                act.save();
                act.render();
            });
            row.addView(c);
        }
        into.addView(new FieldMapView(act, m.optInt("field", 1)));
        into.addView(Ui.small(act, "Gold dots are fielders, white is the keeper. Attacking presets hunt wickets but leak boundaries; defensive presets save boundaries but wickets dry up."));
    }

    /** Batch B (idea 11): Powerplay plan pickers. Editable before an innings
     *  starts (toss, break, or ball 0); read-only once the innings is moving. */
    private static void addPpPickers(final MainActivity act, final JSONObject m, LinearLayout into, boolean editable) {
        into.addView(Ui.spacer(act, 6));
        into.addView(Ui.text(act, "Powerplay plans — overs 1–6", 14, Ui.INK, true));
        if (!editable) {
            into.addView(Ui.body(act, "Batting PP: " + MatchEngine.PP_BAT[m.optInt("ppBat", 1)]
                    + "  ·  Bowling PP: " + MatchEngine.PP_BOWL[m.optInt("ppBowl", 1)]));
            into.addView(Ui.small(act, "Plans lock once an innings starts — change them at the toss or the innings break."));
            return;
        }
        into.addView(Ui.small(act, "Batting Powerplay (when you bat):"));
        LinearLayout r1 = new LinearLayout(act);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MatchEngine.PP_BAT.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, MatchEngine.PP_BAT[i], m.optInt("ppBat", 1) == i);
            c.setOnClickListener(v -> {
                try { m.put("ppBat", idx); } catch (Exception ignored) {}
                act.save(); act.render();
            });
            r1.addView(c);
        }
        into.addView(r1);
        into.addView(Ui.small(act, "Bowling Powerplay (when you bowl):"));
        LinearLayout r2 = new LinearLayout(act);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MatchEngine.PP_BOWL.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, MatchEngine.PP_BOWL[i], m.optInt("ppBowl", 1) == i);
            c.setOnClickListener(v -> {
                try { m.put("ppBowl", idx); } catch (Exception ignored) {}
                act.save(); act.render();
            });
            r2.addView(c);
        }
        into.addView(r2);
        into.addView(Ui.small(act, "Attacking PP: faster scoring, more wickets. Safe: protect wickets / dry up runs."));
    }

    private static View tossView(final MainActivity act, final JSONObject m) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.gold(act, "THE TOSS", 13));
        // Batch A (ideas 3 & 4): the pitch report and conditions, up front
        int pitch = m.optInt("pitch", 0);
        card.addView(Ui.text(act, "Pitch: " + Data.PITCH_TYPES[pitch]
                + (m.optBoolean("evening") ? "  ·  Day/Night" : "  ·  Day game"), 15, Ui.INK, true));
        card.addView(Ui.small(act, Data.PITCH_DESC[pitch]
                + " Rain risk: " + m.optInt("rainRisk") + "%."
                + (m.optBoolean("evening") ? " Dew is expected in the chase — bowling second gets harder." : "")));
        // Batch B (idea 19): the opposition danger man, flagged before a ball is bowled
        card.addView(Ui.text(act, "⚠ Danger man: " + MatchEngine.dangerManLine(act.g, m.optString("opp")), 13, Ui.RED, true));
        addFieldPicker(act, m, card);
        // Batch B (idea 11): Powerplay plans are set here, before innings 1
        addPpPickers(act, m, card, true);
        if (!m.optBoolean("tossDone")) {
            card.addView(Ui.h2(act, "Call the coin"));
            card.addView(Ui.small(act, "Win the toss and choose to bat or bowl first."));
            LinearLayout row = Ui.row(act);
            Button heads = Ui.goldBtn(act, "Heads");
            heads.setOnClickListener(v -> doToss(act, m, true));
            Button tails = Ui.goldBtn(act, "Tails");
            tails.setOnClickListener(v -> doToss(act, m, false));
            heads.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            tails.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(heads);
            row.addView(tails);
            card.addView(row);
        } else {
            card.addView(Ui.h2(act, "You won the toss!"));
            card.addView(Ui.small(act, "What will " + act.g.userTeam + " do first?"));
            Button bat = Ui.goldBtn(act, "Bat First");
            bat.setOnClickListener(v -> { MatchEngine.beginInnings1(act.g, true); act.save(); act.render(); });
            Button bowl = Ui.darkBtn(act, "Bowl First");
            bowl.setOnClickListener(v -> { MatchEngine.beginInnings1(act.g, false); act.save(); act.render(); });
            card.addView(bat);
            card.addView(bowl);
        }
        return card;
    }

    private static void doToss(MainActivity act, JSONObject m, boolean calledHeads) {
        try {
            boolean heads = new Random().nextBoolean();
            boolean userWon = heads == calledHeads;
            MatchEngine.addComm(act.g, "Coin lands " + (heads ? "HEADS" : "TAILS") + " — " +
                    (userWon ? act.g.userTeam + " win the toss!" : m.optString("opp") + " win the toss."));
            if (userWon) {
                m.put("tossDone", true);
            } else {
                boolean oppBats = new Random().nextDouble() < 0.6;
                MatchEngine.addComm(act.g, m.optString("opp") + " choose to " + (oppBats ? "bat" : "bowl") + " first.");
                MatchEngine.beginInnings1(act.g, !oppBats);
            }
            act.save();
            act.render();
        } catch (Exception ignored) {}
    }

    // ---------------- live header ----------------

    private static View scoreHeader(MainActivity act, JSONObject m) {
        LinearLayout card = Ui.card(act);
        try {
            String batTeam = m.getString("batTeam");
            int runs = m.optInt("runs"), wkts = m.optInt("wkts"), balls = m.optInt("balls");
            boolean superMode = m.optBoolean("superMode");
            card.addView(Ui.text(act, superMode
                    ? "⚡ SUPER OVER · " + m.getString("bowlTeam") + " bowling"
                    : (m.optInt("inn") == 1 ? "Innings 1" : "Innings 2") +
                    " · " + m.getString("bowlTeam") + " bowling", 12, Ui.MUTED, false));
            LinearLayout row = Ui.row(act);
            TextView score = Ui.text(act, act.g.shortFor(batTeam) + "  " + runs + "/" + wkts, 28, Ui.INK, true);
            score.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(score);
            row.addView(Ui.gold(act, MatchEngine.oversStrFull(balls) + " ov", 18));
            card.addView(row);
            double crr = MatchEngine.crr(act.g);
            StringBuilder info = new StringBuilder();
            info.append(String.format(Locale.US, "CRR %.2f", crr));
            if (superMode) {
                if (m.optInt("target", 0) > 0) {
                    int need = m.optInt("target") - runs;
                    int rem = Math.max(0, m.optInt("ballsLimit", 6) - balls);
                    info.append("  ·  Need ").append(Math.max(0, need)).append(" off ").append(rem).append(" to win the Super Over");
                } else {
                    info.append("  ·  Super Over — set a total (6 balls, 2 wickets)");
                }
            } else if (m.optInt("inn") == 1) {
                info.append("  ·  Projected ").append(MatchEngine.projected(act.g));
            } else {
                int need = m.optInt("target") - runs;
                int rem = m.optInt("ballsLimit", 120) - balls; // Batch A: rain-cut aware
                double req = rem > 0 ? need * 6.0 / rem : 0;
                info.append("  ·  Target ").append(m.optInt("target"));
                info.append("  ·  Need ").append(Math.max(0, need)).append(" off ").append(Math.max(0, rem));
                info.append(String.format(Locale.US, "  ·  Req %.2f", req));
                int par = MatchEngine.dlsPar(act.g);
                info.append("  ·  DLS par ").append(par)
                    .append(runs >= par ? " (ahead)" : " (behind)");
            }
            card.addView(Ui.text(act, info.toString(), 13, Ui.MUTED, false));

            // Batch A (idea 2): the rain revision, pinned to the score header
            if (m.optBoolean("rainDone") && m.has("rainNote")) {
                card.addView(Ui.text(act, "🌧 " + m.optString("rainNote"), 13, Ui.GOLD, true));
            }
            // Batch A (idea 4): dew reminder during an evening chase
            if (!superMode && m.optInt("inn") == 2 && m.optBoolean("evening")) {
                card.addView(Ui.small(act, "Day/night game — dew is about, the ball is skidding on and bowling is harder."));
            }
            // Batch A (idea 5): live win predictor for Lahore
            int wp = MatchEngine.winPredictor(act.g);
            LinearLayout wrow = Ui.row(act);
            TextView wlab = Ui.text(act, "Win Predictor — " + act.g.shortFor(act.g.userTeam) + " " + wp + "%", 13, Ui.INK, true);
            wrow.addView(wlab);
            card.addView(wrow);
            card.addView(Ui.bar(act, wp, Ui.GOLD));

            // current pair + bowler
            JSONArray bat = m.getJSONArray("batCard");
            JSONObject striker = bat.getJSONObject(m.optInt("striker"));
            JSONObject non = bat.getJSONObject(m.optInt("nonStriker"));
            card.addView(Ui.body(act, striker.getString("name") + "*  " + striker.optInt("runs") + " (" + striker.optInt("balls") + ")"));
            card.addView(Ui.body(act, non.getString("name") + "  " + non.optInt("runs") + " (" + non.optInt("balls") + ")"));
            JSONArray bowl = m.getJSONArray("bowlCard");
            JSONObject bowler = bowl.getJSONObject(m.optInt("curBowler"));
            card.addView(Ui.small(act, "Bowling: " + bowler.getString("name") + "  " +
                    MatchEngine.oversStrFull(bowler.optInt("balls")) + "-" + bowler.optInt("runs") + "-" + bowler.optInt("wkts")));

            // last balls chips
            JSONArray lb = m.optJSONArray("lastBalls");
            if (lb != null && lb.length() > 0) {
                LinearLayout chips = Ui.row(act);
                for (int i = 0; i < lb.length(); i++) {
                    String s = lb.getString(i);
                    TextView chip = Ui.text(act, s, 12,
                            "W".equals(s) ? android.graphics.Color.WHITE : Ui.INK, true);
                    int bg = "W".equals(s) ? Ui.RED : ("4".equals(s) || "6".equals(s)) ? Ui.GOLD : Ui.CARD2;
                    chip.setBackground(Ui.round(bg, 9, act));
                    chip.setGravity(Gravity.CENTER);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(act, 26), Ui.dp(act, 26));
                    lp.setMargins(0, Ui.dp(act, 6), Ui.dp(act, 5), 0);
                    chip.setLayoutParams(lp);
                    chips.addView(chip);
                }
                card.addView(chips);
            }
        } catch (Exception ignored) {}
        return card;
    }

    private static View tactics(final MainActivity act, final JSONObject m) {
        LinearLayout card = Ui.card(act);
        boolean userBatting = act.g.userTeam.equals(m.optString("batTeam"));
        card.addView(Ui.h2(act, "Tactics — " + (userBatting ? "batting approach" : "bowling plan")));
        card.addView(Ui.small(act, userBatting
                ? "Attack/Slog score faster but risk wickets. Defend protects wickets."
                : "Your field plan: aggressive plans take wickets but leak boundaries."));
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MatchEngine.TACTICS.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, MatchEngine.TACTICS[i], m.optInt("tactic", 1) == i);
            c.setOnClickListener(v -> {
                try { m.put("tactic", idx); } catch (Exception ignored) {}
                act.save();
                act.render();
            });
            row.addView(c);
        }
        card.addView(row);
        LinearLayout row2 = new LinearLayout(act);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MatchEngine.RUNNING.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, MatchEngine.RUNNING[i], m.optInt("running", 1) == i);
            c.setOnClickListener(v -> {
                try { m.put("running", idx); } catch (Exception ignored) {}
                act.save();
                act.render();
            });
            row2.addView(c);
        }
        card.addView(row2);

        // Batch B (idea 11): Powerplay plans — editable only before the
        // innings starts (ball 0), read-only after that
        addPpPickers(act, m, card, m.optInt("balls") == 0);

        // v2 finer controls — the whole match screen scrolls, and these controls
        // stack vertically, so no button is ever clipped off a phone screen
        if (userBatting) {
            card.addView(Ui.spacer(act, 6));
            card.addView(Ui.text(act, "Shield a batter", 14, Ui.INK, true));
            card.addView(Ui.small(act, "A shielded batter faces fewer balls and is much harder to dismiss — protect a set batter or a tail-ender."));
            String shield = m.optString("shield", "");
            Button none = Ui.chip(act, "No shield", shield.isEmpty());
            none.setOnClickListener(v -> {
                try { m.put("shield", ""); } catch (Exception ignored) {}
                act.save(); act.render();
            });
            card.addView(none);
            try {
                JSONArray bat = m.getJSONArray("batCard");
                for (int i = 0; i < bat.length(); i++) {
                    JSONObject b = bat.getJSONObject(i);
                    if (b.optBoolean("out")) continue;
                    final String name = b.getString("name");
                    Button c = Ui.chip(act, "🛡 " + name, name.equals(shield));
                    c.setOnClickListener(v -> {
                        try { m.put("shield", name); } catch (Exception ignored) {}
                        act.save(); act.render();
                    });
                    card.addView(c);
                }
            } catch (Exception ignored) {}
        } else {
            card.addView(Ui.spacer(act, 6));
            addFieldPicker(act, m, card);
            // Batch B (idea 20): a bowling plan against the man on strike —
            // it lives until he is dismissed or the manager changes it
            try {
                JSONArray bat = m.getJSONArray("batCard");
                final String strikerName = bat.getJSONObject(m.optInt("striker")).optString("name");
                card.addView(Ui.spacer(act, 6));
                card.addView(Ui.text(act, "Bowling plan vs " + strikerName, 14, Ui.INK, true));
                String planFor = m.optString("batPlanFor", "");
                int plan = m.optInt("batPlan", 0);
                if (!planFor.isEmpty() && !planFor.equals(strikerName) && plan > 0) {
                    card.addView(Ui.small(act, "Plan active vs " + planFor + ": " + MatchEngine.BAT_PLANS[plan]
                            + " (it bites when he is on strike). Pick below to re-target it at " + strikerName + "."));
                }
                int active = planFor.equals(strikerName) ? plan : 0;
                LinearLayout pr = null;
                for (int i = 0; i < MatchEngine.BAT_PLANS.length; i++) {
                    if (i % 3 == 0) {
                        pr = new LinearLayout(act);
                        pr.setOrientation(LinearLayout.HORIZONTAL);
                        card.addView(pr);
                    }
                    final int idx = i;
                    Button c = Ui.chip(act, MatchEngine.BAT_PLANS[i], active == i);
                    c.setOnClickListener(v -> {
                        try {
                            m.put("batPlan", idx);
                            m.put("batPlanFor", idx == 0 ? "" : strikerName);
                        } catch (Exception ignored) {}
                        act.save(); act.render();
                    });
                    pr.addView(c);
                }
                card.addView(Ui.small(act, "Yorkers strangle scoring · Short Stuff buys wickets but can be hooked · Outside Off starves and tempts the edge · Straight & Full attacks the stumps."));
            } catch (Exception ignored) {}
        }

        // Batch B (idea 18): the once-per-innings pep talk
        card.addView(Ui.spacer(act, 8));
        String seg = MatchEngine.pepSegment(m);
        if (seg.equals(m.optString("pepKey", ""))) {
            card.addView(Ui.small(act, "🗣 Pep talk used this innings"
                    + (seg.equals(m.optString("pepBoostKey", "")) && m.optInt("balls") < m.optInt("pepBoostUntil", -1)
                        ? " — the boost is live for the next few balls." : ".")));
        } else {
            Button pep = Ui.darkBtn(act, "🗣 Pep Talk — fire up the side (once per innings)");
            pep.setOnClickListener(v -> {
                act.stopAuto();
                String msg = MatchEngine.pepTalk(act.g);
                if (msg != null) act.toast("Pep talk delivered — boost live for two overs");
                act.save(); act.render();
            });
            card.addView(pep);
            card.addView(Ui.small(act, "Best used around the 10-over mark: two overs of extra intent, plus a Set lift for the men in the middle."));
        }
        return card;
    }

    // ---------------- Batch B cards ----------------

    /** Idea 14: the next-batter picker. Every unused, not-out card is a tap. */
    private static View nextBatterCard(final MainActivity act, final JSONObject m) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.gold(act, "WICKET DOWN — WHO COMES IN NEXT?", 13));
        card.addView(Ui.small(act, "The innings waits for your call. Pick the next batter:"));
        try {
            JSONArray bat = m.getJSONArray("batCard");
            for (int i = 0; i < bat.length(); i++) {
                JSONObject b = bat.getJSONObject(i);
                if (b.optBoolean("out") || b.optBoolean("in")) continue;
                final int idx = i;
                Button c = Ui.darkBtn(act, b.optString("name") + "  ·  Bat " + b.optInt("bat"));
                c.setOnClickListener(v -> {
                    act.stopAuto();
                    if (MatchEngine.chooseNextBatter(act.g, idx)) {
                        act.save(); act.render();
                    } else {
                        act.toast("That batter can't come in");
                    }
                });
                card.addView(c);
            }
        } catch (Exception ignored) {}
        return card;
    }

    /** Idea 15: the assistant coach's tip, with a one-tap Apply when the tip
     *  names a bowler for the next over. Bowling innings only. */
    private static View coachCard(final MainActivity act, final JSONObject m) {
        String[] tip = MatchEngine.coachSuggestion(act.g);
        if (tip == null) return null;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.gold(act, "🧢 ASSISTANT COACH", 13));
        card.addView(Ui.body(act, tip[0]));
        final int bowlIdx = Integer.parseInt(tip[1]);
        if (bowlIdx >= 0) {
            int balls = m.optInt("balls");
            final int nextOver = balls % 6 == 0 ? balls / 6 : balls / 6 + 1;
            Button apply = Ui.goldBtn(act, "Apply — bowl him in over " + (nextOver + 1));
            apply.setOnClickListener(v -> {
                String err = MatchEngine.setRotationOver(act.g, nextOver, bowlIdx);
                if (err != null) act.toast(err);
                act.save(); act.render();
            });
            card.addView(apply);
        }
        return card;
    }

    /** Ideas 12 & 13: the 20-over bowling plan. Bowled overs are summarised
     *  from the actual record; upcoming overs are tappable, death overs
     *  (17–20) are ⭐-marked. Lahore bowling innings only. */
    private static View rotationCard(final MainActivity act, final JSONObject m) {
        if (act.g.userTeam.equals(m.optString("batTeam")) || m.optBoolean("superMode")) return null;
        MatchEngine.ensureRotation(act.g);
        JSONArray rot = m.optJSONArray("rotation");
        int totalOvers = m.optInt("ballsLimit", 120) / 6;
        if (rot == null || rot.length() != totalOvers) return null;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "Bowling Plan — Overs 1–" + totalOvers));
        try {
            JSONArray ob = m.optJSONArray("overBowlers");
            if (ob != null && ob.length() > 0) {
                StringBuilder sb = new StringBuilder("Bowled: ");
                for (int i = 0; i < ob.length(); i++) {
                    if (i > 0) sb.append(" · ");
                    sb.append(i + 1).append(" ").append(lastName(ob.optString(i)));
                }
                card.addView(Ui.small(act, sb.toString()));
            }
            JSONArray bowl = m.getJSONArray("bowlCard");
            int fe = MatchEngine.firstEditableOver(act.g);
            int maxOver = m.optInt("ballsLimit", 120) / 6;
            if (fe >= maxOver) {
                card.addView(Ui.small(act, "Innings nearly done — no overs left to plan."));
                return card;
            }
            card.addView(Ui.small(act, "Tap an over to change its bowler. Max " + (totalOvers / 5) + " overs each, no back-to-back overs."));
            for (int ov = fe; ov < maxOver; ov++) {
                final int overIdx = ov;
                int bi = rot.optInt(ov, -1);
                String bname = bi >= 0 && bi < bowl.length()
                        ? bowl.getJSONObject(bi).optString("name") : "—";
                boolean death = ov >= maxOver - 4;
                Button row = Ui.chip(act, "Ov " + (ov + 1) + (death ? " ⭐ DEATH" : "") + ": " + bname, death);
                row.setOnClickListener(v -> showBowlerPicker(act, m, overIdx));
                card.addView(row);
            }
        } catch (Exception ignored) {}
        return card;
    }

    private static String lastName(String full) {
        int sp = full.lastIndexOf(' ');
        return sp > 0 ? full.substring(sp + 1) : full;
    }

    /** Bowler picker dialog for one planned over (rotation editor). */
    private static void showBowlerPicker(final MainActivity act, final JSONObject m, final int overIdx) {
        try {
            final JSONArray bowl = m.getJSONArray("bowlCard");
            JSONArray rot = m.optJSONArray("rotation");
            int planned = rot != null ? rot.optInt(overIdx, -1) : -1;
            String[] names = new String[bowl.length()];
            for (int i = 0; i < bowl.length(); i++) {
                JSONObject b = bowl.getJSONObject(i);
                names[i] = b.optString("name") + " — Bowl " + b.optInt("bowl")
                        + " · " + MatchEngine.oversStrFull(b.optInt("balls")) + " ov bowled"
                        + (i == planned ? "  ✓ planned" : "");
            }
            new android.app.AlertDialog.Builder(act)
                    .setTitle("Over " + (overIdx + 1) + (overIdx >= m.optInt("ballsLimit", 120) / 6 - 4 ? " ⭐ (death over)" : "") + " — who bowls?")
                    .setItems(names, (d, which) -> {
                        String err = MatchEngine.setRotationOver(act.g, overIdx, which);
                        if (err != null) act.toast(err);
                        act.save(); act.render();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } catch (Exception ignored) {}
    }

    /** Idea 16: batter-vs-bowler records from this innings' tracked balls —
     *  the current pair against the current bowler, plus the striker's full
     *  list against every bowler used so far. */
    private static View matchupCard(MainActivity act, JSONObject m) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "Match-Ups — this innings"));
        try {
            JSONArray mu = m.optJSONArray("matchups");
            JSONArray bat = m.getJSONArray("batCard");
            JSONArray bowl = m.getJSONArray("bowlCard");
            JSONObject striker = bat.getJSONObject(m.optInt("striker"));
            JSONObject non = bat.getJSONObject(m.optInt("nonStriker"));
            JSONObject bowler = bowl.getJSONObject(m.optInt("curBowler"));
            if (mu == null || mu.length() == 0) {
                card.addView(Ui.small(act, "No balls bowled yet — match-ups build ball by ball."));
                return card;
            }
            card.addView(muLine(act, mu, striker, bowler));
            card.addView(muLine(act, mu, non, bowler));
            card.addView(Ui.spacer(act, 4));
            card.addView(Ui.small(act, striker.optString("name") + " against every bowler so far:"));
            boolean any = false;
            for (int i = 0; i < mu.length(); i++) {
                JSONObject x = mu.getJSONObject(i);
                if (!x.optString("bat").equals(striker.optString("name"))) continue;
                if (x.optString("bowl").equals(bowler.optString("name"))) continue;
                card.addView(Ui.body(act, "vs " + x.optString("bowl") + " — " + x.optInt("runs")
                        + " off " + x.optInt("balls") + (x.optInt("outs") > 0 ? " · out " + x.optInt("outs") + "×" : "")));
                any = true;
            }
            if (!any) card.addView(Ui.small(act, "Only faced " + bowler.optString("name") + " so far."));
        } catch (Exception ignored) {}
        return card;
    }

    private static View muLine(MainActivity act, JSONArray mu, JSONObject batter, JSONObject bowler) {
        JSONObject x = MatchEngine.matchup(mu, batter.optString("name"), bowler.optString("name"));
        if (x == null) {
            return Ui.body(act, batter.optString("name") + " vs " + bowler.optString("name") + " — yet to face him");
        }
        return Ui.body(act, batter.optString("name") + " vs " + bowler.optString("name") + " — "
                + x.optInt("runs") + " off " + x.optInt("balls")
                + (x.optInt("outs") > 0 ? " · dismissed " + x.optInt("outs") + "×" : " · unbeaten duel"));
    }

    // ---------------- scorecard + commentary ----------------

    private static View scorecard(MainActivity act, JSONObject m) {
        LinearLayout card = Ui.card(act);
        try {
            card.addView(Ui.h2(act, "Scorecard — " + m.getString("batTeam")));
            if (m.optInt("inn") == 2 && m.has("inn1Summary")) {
                card.addView(Ui.small(act, "Innings 1: " + m.getString("inn1Summary") + " · Target " + m.optInt("target")));
            }
            JSONArray bat = m.getJSONArray("batCard");
            int striker = m.optInt("striker"), non = m.optInt("nonStriker"), nextIn = m.optInt("nextIn");
            for (int i = 0; i < bat.length(); i++) {
                JSONObject b = bat.getJSONObject(i);
                String status;
                if (b.optBoolean("out")) status = b.optString("how");
                else if (i == striker || i == non) status = "not out";
                // Batch B: the "in" flag is the crease record; nextIn stays as
                // the fallback for saves written before it existed
                else if (b.has("in") ? !b.optBoolean("in") : i >= nextIn) status = "yet to bat";
                else status = "not out";
                if ("yet to bat".equals(status)) {
                    card.addView(Ui.small(act, b.getString("name") + " — yet to bat"));
                } else {
                    card.addView(Ui.body(act, b.getString("name") + (i == striker ? "*" : "") +
                            "  " + b.optInt("runs") + " (" + b.optInt("balls") + ")  ·  " + status));
                }
            }
            card.addView(Ui.spacer(act, 6));
            card.addView(Ui.small(act, "Bowling"));
            JSONArray bowl = m.getJSONArray("bowlCard");
            for (int i = 0; i < bowl.length(); i++) {
                JSONObject b = bowl.getJSONObject(i);
                card.addView(Ui.body(act, b.getString("name") + "  " +
                        MatchEngine.oversStrFull(b.optInt("balls")) + " ov · " +
                        b.optInt("runs") + " runs · " + b.optInt("wkts") + " wkts"));
            }
        } catch (Exception ignored) {}
        return card;
    }

    private static View commCard(MainActivity act, JSONObject m) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "Commentary"));
        JSONArray comm = m.optJSONArray("comm");
        if (comm == null || comm.length() == 0) {
            card.addView(Ui.small(act, "Commentary will appear here ball by ball."));
        } else {
            for (int i = 0; i < comm.length(); i++) {
                TextView t = Ui.text(act, comm.optString(i), 13, i == 0 ? Ui.INK : Ui.MUTED, false);
                t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
                card.addView(t);
            }
        }
        return card;
    }
}
