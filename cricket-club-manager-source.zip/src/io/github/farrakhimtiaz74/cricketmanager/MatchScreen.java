package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Random;

public class MatchScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        final JSONObject m = g.match;
        LinearLayout root = Ui.col(act);
        if (m == null) {
            root.addView(Ui.body(act, "No match in progress."));
            return root;
        }
        String phase = m.optString("phase");

        // top bar: fixture + exit
        LinearLayout top = Ui.row(act);
        TextView title = Ui.text(act, "Lahore vs " + Data.shortName(m.optString("opp")) + " · T20", 16, Ui.INK, true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        top.addView(title);
        Button exit = Ui.chip(act, "Save & Exit", false);
        exit.setOnClickListener(v -> { act.matchMode = false; act.tab = 0; act.save(); act.render(); });
        top.addView(exit);
        root.addView(top);

        if ("toss".equals(phase)) {
            root.addView(tossView(act, m));
            root.addView(commCard(act, m));
            return root;
        }
        if ("done".equals(phase)) {
            LinearLayout card = Ui.card(act);
            card.addView(Ui.gold(act, "FULL TIME", 13));
            card.addView(Ui.h2(act, m.optString("result")));
            card.addView(Ui.small(act, m.optBoolean("userWon")
                    ? "Victory! Prize CF, points and morale have been added."
                    : "Defeat. Appearance CF added — check the League tab for the table."));
            Button back = Ui.goldBtn(act, "Back to Hub");
            back.setOnClickListener(v -> {
                act.g.match = null;
                act.matchMode = false;
                act.tab = 0;
                act.save();
                act.render();
            });
            card.addView(back);
            root.addView(card);
            root.addView(scorecard(act, m));
            root.addView(commCard(act, m));
            return root;
        }

        // ---- live play ----
        root.addView(scoreHeader(act, m));
        root.addView(tactics(act, m));

        LinearLayout controls = Ui.card(act);
        Button ball = Ui.goldBtn(act, "Bowl Ball");
        ball.setOnClickListener(v -> { MatchEngine.bowlBall(act.g); act.save(); act.render(); });
        controls.addView(ball);
        LinearLayout row = Ui.row(act);
        Button simOver = Ui.darkBtn(act, "Sim Over");
        simOver.setOnClickListener(v -> { MatchEngine.simOver(act.g); act.save(); act.render(); });
        Button simInn = Ui.darkBtn(act, "Sim Innings");
        simInn.setOnClickListener(v -> { MatchEngine.simInnings(act.g); act.save(); act.render(); });
        Button simMatch = Ui.darkBtn(act, "Sim Match");
        simMatch.setOnClickListener(v -> { MatchEngine.simMatch(act.g); act.save(); act.render(); });
        LinearLayout.LayoutParams third = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        simOver.setLayoutParams(third);
        simInn.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        simMatch.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(simOver);
        row.addView(simInn);
        row.addView(simMatch);
        controls.addView(row);
        root.addView(controls);

        root.addView(scorecard(act, m));
        root.addView(commCard(act, m));
        return root;
    }

    // ---------------- toss ----------------

    private static View tossView(final MainActivity act, final JSONObject m) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.gold(act, "THE TOSS", 13));
        if (!m.optBoolean("tossDone")) {
            card.addView(Ui.h2(act, "Call the coin"));
            card.addView(Ui.small(act, "Win the toss and choose to bat or bowl first."));
            LinearLayout row = Ui.row(act);
            Button heads = Ui.goldBtn(act, "Heads");
            heads.setOnClickListener(v -> doToss(act, m, true));
            Button tails = Ui.goldBtn(act, "Tails");
            tails.setOnClickListener(v -> doToss(act, m, false));
            heads.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            tails.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(heads);
            row.addView(tails);
            card.addView(row);
        } else {
            card.addView(Ui.h2(act, "You won the toss!"));
            card.addView(Ui.small(act, "What will Lahore do first?"));
            Button bat = Ui.goldBtn(act, "Bat First");
            bat.setOnClickListener(v -> { MatchEngine.beginInnings1(act.g, true); act.save(); act.render(); });
            Button bowl = Ui.darkBtn(act, "Bowl First");
            bowl.setOnClickListener(v -> { MatchEngine.beginInnings1(act.g, false); act.save(); act.render(); });
            card.addView(bat);
            card.addView(bowl);
        }
        return card;
    }

    private static void doToss(MainActivity act, JSONObject m, boolean calledHeads) {
        try {
            boolean heads = new Random().nextBoolean();
            boolean userWon = heads == calledHeads;
            MatchEngine.addComm(act.g, "Coin lands " + (heads ? "HEADS" : "TAILS") + " — " +
                    (userWon ? "Lahore win the toss!" : m.optString("opp") + " win the toss."));
            if (userWon) {
                m.put("tossDone", true);
            } else {
                boolean oppBats = new Random().nextDouble() < 0.6;
                MatchEngine.addComm(act.g, m.optString("opp") + " choose to " + (oppBats ? "bat" : "bowl") + " first.");
                MatchEngine.beginInnings1(act.g, !oppBats);
            }
            act.save();
            act.render();
        } catch (Exception ignored) {}
    }

    // ---------------- live header ----------------

    private static View scoreHeader(MainActivity act, JSONObject m) {
        LinearLayout card = Ui.card(act);
        try {
            String batTeam = m.getString("batTeam");
            int runs = m.optInt("runs"), wkts = m.optInt("wkts"), balls = m.optInt("balls");
            card.addView(Ui.text(act, (m.optInt("inn") == 1 ? "Innings 1" : "Innings 2") +
                    " · " + m.getString("bowlTeam") + " bowling", 12, Ui.MUTED, false));
            LinearLayout row = Ui.row(act);
            TextView score = Ui.text(act, Data.shortName(batTeam) + "  " + runs + "/" + wkts, 28, Ui.INK, true);
            score.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(score);
            row.addView(Ui.gold(act, MatchEngine.oversStrFull(balls) + " ov", 18));
            card.addView(row);
            double crr = MatchEngine.crr(act.g);
            StringBuilder info = new StringBuilder();
            info.append(String.format(Locale.US, "CRR %.2f", crr));
            if (m.optInt("inn") == 1) {
                info.append("  ·  Projected ").append(MatchEngine.projected(act.g));
            } else {
                int need = m.optInt("target") - runs;
                int rem = 120 - balls;
                double req = rem > 0 ? need * 6.0 / rem : 0;
                info.append("  ·  Target ").append(m.optInt("target"));
                info.append("  ·  Need ").append(Math.max(0, need)).append(" off ").append(Math.max(0, rem));
                info.append(String.format(Locale.US, "  ·  Req %.2f", req));
                int par = MatchEngine.dlsPar(act.g);
                info.append("  ·  DLS par ").append(par)
                    .append(runs >= par ? " (ahead)" : " (behind)");
            }
            card.addView(Ui.text(act, info.toString(), 13, Ui.MUTED, false));

            // current pair + bowler
            JSONArray bat = m.getJSONArray("batCard");
            JSONObject striker = bat.getJSONObject(m.optInt("striker"));
            JSONObject non = bat.getJSONObject(m.optInt("nonStriker"));
            card.addView(Ui.body(act, striker.getString("name") + "*  " + striker.optInt("runs") + " (" + striker.optInt("balls") + ")"));
            card.addView(Ui.body(act, non.getString("name") + "  " + non.optInt("runs") + " (" + non.optInt("balls") + ")"));
            JSONArray bowl = m.getJSONArray("bowlCard");
            JSONObject bowler = bowl.getJSONObject(m.optInt("curBowler"));
            card.addView(Ui.small(act, "Bowling: " + bowler.getString("name") + "  " +
                    MatchEngine.oversStrFull(bowler.optInt("balls")) + "-" + bowler.optInt("runs") + "-" + bowler.optInt("wkts")));

            // last balls chips
            JSONArray lb = m.optJSONArray("lastBalls");
            if (lb != null && lb.length() > 0) {
                LinearLayout chips = Ui.row(act);
                for (int i = 0; i < lb.length(); i++) {
                    String s = lb.getString(i);
                    TextView chip = Ui.text(act, s, 12,
                            "W".equals(s) ? android.graphics.Color.WHITE : Ui.INK, true);
                    int bg = "W".equals(s) ? Ui.RED : ("4".equals(s) || "6".equals(s)) ? Ui.GOLD : Ui.CARD2;
                    chip.setBackground(Ui.round(bg, 9, act));
                    chip.setGravity(Gravity.CENTER);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(act, 26), Ui.dp(act, 26));
                    lp.setMargins(0, Ui.dp(act, 6), Ui.dp(act, 5), 0);
                    chip.setLayoutParams(lp);
                    chips.addView(chip);
                }
                card.addView(chips);
            }
        } catch (Exception ignored) {}
        return card;
    }

    private static View tactics(final MainActivity act, final JSONObject m) {
        LinearLayout card = Ui.card(act);
        boolean userBatting = Data.USER_TEAM.equals(m.optString("batTeam"));
        card.addView(Ui.h2(act, "Tactics — " + (userBatting ? "batting approach" : "bowling plan")));
        card.addView(Ui.small(act, userBatting
                ? "Attack/Slog score faster but risk wickets. Defend protects wickets."
                : "Your field plan: aggressive plans take wickets but leak boundaries."));
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MatchEngine.TACTICS.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, MatchEngine.TACTICS[i], m.optInt("tactic", 1) == i);
            c.setOnClickListener(v -> {
                try { m.put("tactic", idx); } catch (Exception ignored) {}
                act.save();
                act.render();
            });
            row.addView(c);
        }
        card.addView(row);
        LinearLayout row2 = new LinearLayout(act);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MatchEngine.RUNNING.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, MatchEngine.RUNNING[i], m.optInt("running", 1) == i);
            c.setOnClickListener(v -> {
                try { m.put("running", idx); } catch (Exception ignored) {}
                act.save();
                act.render();
            });
            row2.addView(c);
        }
        card.addView(row2);
        return card;
    }

    // ---------------- scorecard + commentary ----------------

    private static View scorecard(MainActivity act, JSONObject m) {
        LinearLayout card = Ui.card(act);
        try {
            card.addView(Ui.h2(act, "Scorecard — " + m.getString("batTeam")));
            if (m.optInt("inn") == 2 && m.has("inn1Summary")) {
                card.addView(Ui.small(act, "Innings 1: " + m.getString("inn1Summary") + " · Target " + m.optInt("target")));
            }
            JSONArray bat = m.getJSONArray("batCard");
            int striker = m.optInt("striker"), non = m.optInt("nonStriker"), nextIn = m.optInt("nextIn");
            for (int i = 0; i < bat.length(); i++) {
                JSONObject b = bat.getJSONObject(i);
                String status;
                if (b.optBoolean("out")) status = b.optString("how");
                else if (i == striker || i == non) status = "not out";
                else if (i >= nextIn) status = "yet to bat";
                else status = "not out";
                if ("yet to bat".equals(status)) {
                    card.addView(Ui.small(act, b.getString("name") + " — yet to bat"));
                } else {
                    card.addView(Ui.body(act, b.getString("name") + (i == striker ? "*" : "") +
                            "  " + b.optInt("runs") + " (" + b.optInt("balls") + ")  ·  " + status));
                }
            }
            card.addView(Ui.spacer(act, 6));
            card.addView(Ui.small(act, "Bowling"));
            JSONArray bowl = m.getJSONArray("bowlCard");
            for (int i = 0; i < bowl.length(); i++) {
                JSONObject b = bowl.getJSONObject(i);
                card.addView(Ui.body(act, b.getString("name") + "  " +
                        MatchEngine.oversStrFull(b.optInt("balls")) + " ov · " +
                        b.optInt("runs") + " runs · " + b.optInt("wkts") + " wkts"));
            }
        } catch (Exception ignored) {}
        return card;
    }

    private static View commCard(MainActivity act, JSONObject m) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "Commentary"));
        JSONArray comm = m.optJSONArray("comm");
        if (comm == null || comm.length() == 0) {
            card.addView(Ui.small(act, "Commentary will appear here ball by ball."));
        } else {
            for (int i = 0; i < comm.length(); i++) {
                TextView t = Ui.text(act, comm.optString(i), 13, i == 0 ? Ui.INK : Ui.MUTED, false);
                t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
                card.addView(t);
            }
        }
        return card;
    }
}
