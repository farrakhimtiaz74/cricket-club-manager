package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Random;

public class MatchScreen {
 // Professional Pack P3 (suggestion 30): render-to-render state for
 // the phase fade and the newest-ball chip pop (never persisted)
 private static String lastPhase = null;
 private static String lastMatchKey = null;
 private static int lastPopKey = 0;

 public static View build(final MainActivity act) {
 final Game g = act.g;
 final JSONObject m = g.match;
 LinearLayout root = Ui.col(act);
 if (m == null) {
 root.addView(Ui.body(act, "No match in progress."));
 return root;
 }
 String phase = m.optString("phase");
 // Professional Pack P3 (suggestion 30): a phase change (toss to
 // play to break to full time) earns one longer, quiet fade; renders
 // inside a phase keep the standard snappy transition, and Reduce
 // Animations skips this entirely
 String matchKey = m.optInt("fixtureDay") + "|" + m.optString("opp") + "|" + m.optInt("friendly");
 if (act.animOk() && lastPhase != null && matchKey.equals(lastMatchKey) && !phase.equals(lastPhase)) {
 root.setAlpha(0.25f);
 root.animate().alpha(1f).setDuration(340).start();
 }
 lastPhase = phase;
 lastMatchKey = matchKey;


 // top bar: fixture + exit — Design Batch: the two club crests
 // flank the fixture line
 LinearLayout top = Ui.row(act);
 top.addView(CrestView.forTeam(act, act.g, act.g.userTeam, 24));
 View crestGap = new View(act);
 crestGap.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 8), 1));
 top.addView(crestGap);
 TextView title = Ui.text(act, act.g.shortFor(act.g.userTeam) + " vs " + act.g.shortFor(m.optString("opp"))
 + " · " + (m.optBoolean("cup") ? "One-Day Cup · 50 ov"
 : m.optBoolean("playoff") ? m.optString("stageName") + " · T20" : "T20")
 + (m.optBoolean("derby") ? " · DERBY" : "")
 // Batch I: friendlies are labelled so they never read as season matches
 + (m.optInt("friendly") == 1 ? " · Daily Challenge"
 : m.optInt("friendly") == 2 ? " · " + Game.SCENARIO_TITLES[Math.max(0, Math.min(3, m.optInt("scenarioId", 0)))] : ""), 16, Ui.INK, true);
 title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 top.addView(title);
 Button exit = Ui.chip(act, "Save & Exit", false);
 exit.setOnClickListener(v -> { act.matchMode = false; act.tab = 0; act.save(); act.render(); });
 top.addView(exit);
 root.addView(top);

 if ("toss".equals(phase)) {
 root.addView(tossView(act, m));
 root.addView(commCard(act, m));
 return root;
 }
 if ("break".equals(phase)) {
 // v2 innings break: the match pauses here until the manager starts the chase
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "INNINGS BREAK", 13));
 card.addView(Ui.h2(act, m.optString("inn1Summary")));
 card.addView(Ui.body(act, "Target: " + m.optInt("target") + " for "
 + (act.g.userTeam.equals(m.optString("inn1BatTeam")) ? m.optString("opp") : act.g.userTeam) + "."));
 // Batch A (idea 5): predictor at the break judges the set total vs par
 card.addView(Ui.small(act, "Win Predictor — " + act.g.userTeam + " " + MatchEngine.winPredictor(act.g) + "% to win from here."));
 // Batch I: friendlies skip the stamina regen (no season effects)
 card.addView(Ui.small(act, m.optInt("friendly") > 0
 ? "Friendly rules: no stamina or morale changes — the season squad is untouched by this match."
 : "Both sides catch their breath — your XI recovered +"
 + Game.BREAK_REGEN + " stamina at the break."));
 // Batch B (idea 11): the chase is a new innings — Powerplay plans
 // for innings 2 can still be changed here, before it starts
 addPpPickers(act, m, card, true);
 card.addView(Ui.small(act, "Bowling in the chase? Your 20-over rotation plan auto-fills when the innings starts — edit any over from the plan card once play begins."));
 Button chase = Ui.goldBtn(act, "Start the Chase");
 chase.setOnClickListener(v -> { MatchEngine.startChase(act.g); act.save(); act.render(); });
 card.addView(chase);
 root.addView(card);
 root.addView(manhattanCard(act, "Manhattan — Innings 1 (runs per over)", m.optJSONArray("inn1OverRuns")));
 root.addView(timelineCard(act, "Timeline \u2014 Innings 1", m.optJSONArray("inn1OverRuns"), m.optJSONArray("inn1Fow"), m.optJSONArray("lastBalls"), m.optInt("inn1Balls")));
 View brGraph = graphCard(act, m, "Win Predictor \u2014 Innings 1");
 if (brGraph != null) root.addView(brGraph);

 root.addView(scorecard(act, m));
 root.addView(extrasCard(act, "Innings 1", m.optJSONArray("inn1Parts"), m.optJSONArray("inn1Fow")));
 root.addView(commCard(act, m));
 return root;
 }
 if ("superbreak".equals(phase)) {
 // Batch A (idea 1): between Super Over stages — the match is tied
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "SUPER OVER", 13));
 int stage = m.optInt("superStage", 1);
 if (stage == 1) {
 String first = act.g.userTeam.equals(m.optString("inn1BatTeam")) ? m.optString("opp") : act.g.userTeam;
 card.addView(Ui.h2(act, "Scores level — Super Over decides it!"));
 card.addView(Ui.body(act, first + " bat first in the Super Over: 6 balls, 2 wickets."));
 } else {
 card.addView(Ui.h2(act, act.g.shortFor(m.optString("super1BatTeam")) + " posted "
 + m.optInt("super1Runs") + "/" + m.optInt("super1Wkts")));
 String second = act.g.userTeam.equals(m.optString("super1BatTeam")) ? m.optString("opp") : act.g.userTeam;
 card.addView(Ui.body(act, second + " need " + (m.optInt("super1Runs") + 1) + " from 6 balls to win the match."));
 }
 Button go = Ui.goldBtn(act, stage == 1 ? "Start the Super Over" : "Start the Chase — Super Over");
 go.setOnClickListener(v -> { MatchEngine.startSuperStage(act.g, stage); act.save(); act.render(); });
 card.addView(go);
 root.addView(card);
 root.addView(commCard(act, m));
 return root;
 }
 if ("done".equals(phase)) {
 root.addView(infographic(act, m)); // P3 (suggestion 28): the summary leads
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "FULL TIME", 13));
 // Batch I: a friendly's full-time line is its mode note — the
 // season text below would be a lie (nothing was added anywhere)
 if (m.optInt("friendly") > 0) {
 card.addView(Ui.text(act, m.optString("friendlyNote"), 14, Ui.GOLD, true));
 } else {
 card.addView(Ui.small(act, m.optBoolean("userWon")
 ? "Victory! Prize CF, points and morale have been added."
 : "Defeat. Appearance CF added — check the League tab for the table."));
 }
 // Batch H (ideas 77/71): share the report, and face the press
 // Batch I: not for friendlies (no report is built for them)
 if (act.g.lastReport != null && m.optInt("friendly") == 0) {
 LinearLayout srow2 = Ui.row(act);
 Button shareImg = Ui.goldBtn(act, "Share Report");
 shareImg.setOnClickListener(v -> act.shareReportImage());
 Button shareTxt = Ui.darkBtn(act, "Share Text");
 shareTxt.setOnClickListener(v -> act.shareReportText());
 LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
 shareImg.setLayoutParams(hp);
 shareTxt.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 srow2.addView(shareImg);
 srow2.addView(shareTxt);
 card.addView(srow2);
 Button viewCard = Ui.darkBtn(act, "View Report Card");
 viewCard.setOnClickListener(v -> act.showReportCard());
 card.addView(viewCard);
 }
 if (act.g.pressConf != null) {
 card.addView(Ui.gold(act, "PRESS CONFERENCE", 12));
 card.addView(Ui.body(act, "\"" + act.g.pressConf.optString("q") + "\""));
 String[] plabels = {"Confident", "Balanced", "Fiery"};
 for (int pi = 0; pi < 3; pi++) {
 final int choice = pi;
 Button pb = Ui.darkBtn(act, plabels[pi]); // P1: equal choices, no gold
 pb.setOnClickListener(v -> {
 String out = act.g.answerPress(choice);
 act.save();
 if (!out.isEmpty()) act.toast(out);
 act.render();
 });
 card.addView(pb);
 }
 Button pskip = Ui.darkBtn(act, "Skip press (answer on the Hub later)");
 pskip.setOnClickListener(v -> act.render());
 card.addView(pskip);
 }
 Button back = Ui.goldBtn(act, "Back to Hub");
 back.setOnClickListener(v -> {
 act.g.match = null;
 act.matchMode = false;
 act.tab = 0;
 act.save();
 act.render();
 });
 card.addView(back);
 root.addView(card);
 root.addView(manhattanCard(act, "Manhattan — Innings 1", m.optJSONArray("inn1OverRuns")));
 root.addView(manhattanCard(act, "Manhattan — Innings 2",
 m.has("inn2OverRuns") ? m.optJSONArray("inn2OverRuns") : m.optJSONArray("overRuns")));
 root.addView(scorecard(act, m));
 root.addView(extrasCard(act, "Innings 1", m.optJSONArray("inn1Parts"), m.optJSONArray("inn1Fow")));
 root.addView(extrasCard(act, "Innings 2",
 m.has("inn2Parts") ? m.optJSONArray("inn2Parts") : m.optJSONArray("parts"),
 m.has("inn2Fow") ? m.optJSONArray("inn2Fow") : m.optJSONArray("fow")));
 root.addView(timelineCard(act, "Timeline \u2014 Innings 1", m.optJSONArray("inn1OverRuns"), m.optJSONArray("inn1Fow"), null, m.optInt("inn1Balls")));
 root.addView(timelineCard(act, "Timeline \u2014 Innings 2",
 m.has("inn2OverRuns") ? m.optJSONArray("inn2OverRuns") : m.optJSONArray("overRuns"),
 m.has("inn2Fow") ? m.optJSONArray("inn2Fow") : m.optJSONArray("fow"),
 m.optBoolean("superPlayed") ? null : m.optJSONArray("lastBalls"),
 m.has("inn2Balls") ? m.optInt("inn2Balls") : m.optInt("balls")));
 View ftGraph = graphCard(act, m, "Win Predictor \u2014 the story of the match");
 if (ftGraph != null) root.addView(ftGraph);

 root.addView(commCard(act, m));
 return root;
 }

 // ---- live play ----
 // Design Batch (item 7a): the sticky score bug lives OUTSIDE the
 // scroll (MainActivity.bugSlot), refreshed on every render
 act.setBug(scoreBug(act, m));
 root.addView(scoreHeader(act, m));
 // Batch E (idea 44): "As It Stands" — the live group table with this
 // match's provisional result applied (group-stage matches only)
 // Batch I: never for friendlies — they don't touch the table
 if (!m.optBoolean("playoff") && m.optInt("friendly") == 0) root.addView(asItStandsCard(act, m));
 // Batch B (idea 14): a wicket fell on Lahore's watch — the innings
 // parks here until the manager picks who walks in next
 if (m.optBoolean("awaitBat")) {
 root.addView(nextBatterCard(act, m));
 root.addView(commCard(act, m));
 return root;
 }
 root.addView(tactics(act, m));


 // P2 (suggestion 20): the PINNED control bar — parked in
 // MainActivity's action slot (below the scroll, above the nav),
 // so Bowl Ball and the sims are reachable however far the
 // scorecard/commentary has scrolled. While an auto-sim runs it
 // carries Stop instead. Same handlers as the controls card.
 LinearLayout pin = new LinearLayout(act);
 pin.setOrientation(LinearLayout.HORIZONTAL);
 pin.setGravity(android.view.Gravity.CENTER_VERTICAL);
 pin.setBackgroundColor(Ui.CARD);
 pin.setPadding(Ui.dp(act, 14), Ui.dp(act, 6), Ui.dp(act, 14), Ui.dp(act, 6));
 if (act.autoMode != null) {
 Button pStop = Ui.darkBtn(act, "Stop Auto-Sim");
 pStop.setOnClickListener(v -> { act.stopAuto(); act.render(); });
 pStop.setLayoutParams(new LinearLayout.LayoutParams(0, Ui.dp(act, 44), 1));
 pin.addView(pStop);
 View as = segmented(act, new String[]{"Inst", "1x", "2x"},
 act.g.speed == 0 ? 0 : act.g.speed == 2 ? 2 : 1,
 idx -> { act.g.speed = idx == 0 ? 0 : idx == 2 ? 2 : 1; act.save(); act.render(); });
 LinearLayout.LayoutParams asp = new LinearLayout.LayoutParams(0, Ui.dp(act, 44), 1.1f);
 asp.setMargins(Ui.dp(act, 6), 0, 0, 0);
 as.setLayoutParams(asp);
 pin.addView(as);
 } else {
 Button pBall = Ui.goldBtn(act, "Bowl Ball");
 pBall.setOnClickListener(v -> {
 act.stopAuto();
 String phaseBefore2 = act.g.match.optString("phase");
 MatchEngine.bowlBall(act.g);
 if (act.g.match.optString("phase").equals("done") && !"done".equals(phaseBefore2)) {
 act.playEndJingle(act.g.userTeam.equals(act.g.match.optString("winnerTeam")));
 } else {
 act.playBallSound(true);
 }
 act.save();
 act.render();
 });
 Button pOver = Ui.darkBtn(act, "Sim Over");
 pOver.setOnClickListener(v -> simTapped(act, "over"));
 pBall.setLayoutParams(new LinearLayout.LayoutParams(0, Ui.dp(act, 44), 1.25f));
 pOver.setLayoutParams(new LinearLayout.LayoutParams(0, Ui.dp(act, 44), 1));
 pin.addView(pBall);
 pin.addView(pOver);
 View ss = segmented(act, new String[]{"Inst", "1x", "2x"},
 act.g.speed == 0 ? 0 : act.g.speed == 2 ? 2 : 1,
 idx -> { act.g.speed = idx == 0 ? 0 : idx == 2 ? 2 : 1; act.save(); act.render(); });
 LinearLayout.LayoutParams ssp = new LinearLayout.LayoutParams(0, Ui.dp(act, 44), 1.35f);
 ssp.setMargins(Ui.dp(act, 6), 0, 0, 0);
 ss.setLayoutParams(ssp);
 pin.addView(ss);
 Button pMore = Ui.darkBtn(act, "More");
 pMore.setOnClickListener(v -> showMoreSheet(act));
 LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, Ui.dp(act, 44), 0.8f);
 mp.setMargins(Ui.dp(act, 6), 0, 0, 0);
 pMore.setLayoutParams(mp);
 pin.addView(pMore);
 }
 act.parkActionBar(pin);


 // Batch B cards: coach tip + rotation plan while bowling, match-ups always
 View coach = coachCard(act, m);
 if (coach != null) root.addView(coach);
 View rot = rotationCard(act, m);
 if (rot != null) root.addView(rot);
 root.addView(matchupCard(act, m));

 root.addView(scorecard(act, m));
 root.addView(timelineCard(act, "Timeline \u2014 this innings", m.optJSONArray("overRuns"), m.optJSONArray("fow"), m.optJSONArray("lastBalls"), m.optInt("balls")));
 root.addView(commCard(act, m));
 return root;
 }

 /** Batch E (idea 44): collapsible live group table. The provisional
 * rows apply the current score as if the match ended this ball —
 * points for the result as it stands, NRR from the runs/balls so far. */
 private static View asItStandsCard(final MainActivity act, final JSONObject m) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 LinearLayout head = Ui.row(act);
 TextView t = Ui.text(act, "Group A — As It Stands", 14, Ui.GOLD, true);
 t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 head.addView(t);
 Button toggle = Ui.chip(act, act.showAsItStands ? "Hide" : "Show", act.showAsItStands);
 toggle.setOnClickListener(v -> { act.showAsItStands = !act.showAsItStands; act.render(); });
 head.addView(toggle);
 card.addView(head);
 if (act.showAsItStands) {
 card.addView(Ui.small(act, "Live projection — this match counted as finished at the current score."));
 java.util.List<JSONObject> rows = g.provisionalRows(m);
 for (int i = 0; i < rows.size(); i++) {
 JSONObject r = rows.get(i);
 boolean user = act.g.userTeam.equals(r.optString("team"));
 card.addView(Ui.text(act, (i + 1) + ". " + act.g.shortFor(r.optString("team"))
 + " — P" + r.optInt("p") + "W" + r.optInt("w") + "L" + r.optInt("l")
 + " · " + r.optInt("pts") + " pts · NRR "
 + String.format(Locale.US, "%+.2f", r.optDouble("nrr")),
 13, user ? Ui.GOLD : Ui.INK, user));
 }
 }
 return card;
 }

 // ---------------- Design Batch (v13, item 7): score bug + ball chips ----

 /** Item 7a: the sticky broadcast score bug — batting code + score,
 * overs, CRR, and (in a chase) target / needed / RRR. Built fresh
 * on every render, so ball-by-ball, staged sim and Instant sim all
 * leave it correct. */
 private static View scoreBug(MainActivity act, JSONObject m) {
 // Professional Pack P3 (suggestion 21): the bug is broadcast-grade
 // now - score + format on the top line, the pair at the crease and
 // the bowler under it, and the last-12-balls strip along the bottom
 LinearLayout bug = new LinearLayout(act);
 bug.setOrientation(LinearLayout.VERTICAL);
 bug.setBackground(Ui.roundStroke(Ui.CARD, Ui.GOLD, 0, act));
 bug.setPadding(Ui.dp(act, 12), Ui.dp(act, 7), Ui.dp(act, 12), Ui.dp(act, 7));
 try {
 String batTeam = m.getString("batTeam");
 int runs = m.optInt("runs"), wkts = m.optInt("wkts"), balls = m.optInt("balls");
 boolean superMode = m.optBoolean("superMode");
 int limit = m.optInt("ballsLimit", 120);
 LinearLayout row1 = Ui.row(act);
 row1.setGravity(Gravity.CENTER_VERTICAL);
 TextView score = Ui.display(act, act.g.shortFor(batTeam) + " " + runs + "/" + wkts, 17, Ui.INK);
 score.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row1.addView(score);
 StringBuilder info = new StringBuilder();
 if (superMode) {
 info.append("SUPER OVER \u00b7 ").append(balls).append("/6 balls");
 if (m.optInt("target", 0) > 0) {
 info.append(" \u00b7 Need ").append(Math.max(0, m.optInt("target") - runs))
 .append(" off ").append(Math.max(0, 6 - balls));
 }
 } else {
 info.append(MatchEngine.oversStrFull(balls)).append("/").append(limit / 6).append(" ov \u00b7 CRR ")
 .append(String.format(Locale.US, "%.2f", MatchEngine.crr(act.g)));
 if (m.optInt("inn") == 2) {
 int need = m.optInt("target") - runs;
 int rem = Math.max(0, limit - balls);
 info.append(" \u00b7 Need ").append(Math.max(0, need)).append(" off ").append(rem)
 .append(" \u00b7 RRR ").append(String.format(Locale.US, "%.2f", rem > 0 ? need * 6.0 / rem : 0));
 } else {
 info.append(" \u00b7 Proj ").append(MatchEngine.projected(act.g));
 }
 }
 row1.addView(Ui.text(act, info.toString(), 12, Ui.MUTED, false));
 bug.addView(row1);
 // the pair at the crease + the bowler (suggestion 21)
 JSONArray bat = m.optJSONArray("batCard");
 JSONArray bowl = m.optJSONArray("bowlCard");
 if (bat != null && bowl != null) {
 JSONObject st = bat.getJSONObject(m.optInt("striker"));
 JSONObject ns = bat.getJSONObject(m.optInt("nonStriker"));
 JSONObject bw = bowl.getJSONObject(m.optInt("curBowler"));
 bug.addView(Ui.text(act, lastName(st.getString("name")) + "* " + st.optInt("runs") + " (" + st.optInt("balls") + ")"
 + " \u00b7 " + lastName(ns.getString("name")) + " " + ns.optInt("runs") + " (" + ns.optInt("balls") + ")"
 + "   \u00b7   " + lastName(bw.getString("name")) + " " + MatchEngine.oversStrFull(bw.optInt("balls"))
 + "-" + bw.optInt("runs") + "-" + bw.optInt("wkts"), 11.5f, Ui.MUTED, false));
 }
 // last-12-balls strip (suggestion 21)
 JSONArray lb = m.optJSONArray("lastBalls");
 if (lb != null && lb.length() > 0) bug.addView(chipsStrip(act, lb, 0, lb.length()));
 } catch (Exception ignored) {}
 return bug;
 }

 /** One horizontal strip of outcome chips for a slice of lastBalls. */
 private static LinearLayout chipsStrip(MainActivity act, JSONArray lb, int from, int to) {
 LinearLayout chips = Ui.row(act);
 try {
 for (int i = from; i < to; i++) {
 String s = lb.getString(i);
 TextView chip = Ui.text(act, s, 12, Design.ballChipTextColor(s), true);
 chip.setBackground(Ui.round(Design.ballChipColor(s), 9, act));
 chip.setGravity(Gravity.CENTER);
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(act, 26), Ui.dp(act, 26));
 lp.setMargins(0, Ui.dp(act, 3), Ui.dp(act, 5), 0);
 chip.setLayoutParams(lp);
 chips.addView(chip);
 }
 } catch (Exception ignored) {}
 return chips;
 }


 /** Item 7b: one labelled row of outcome chips for a slice of lastBalls. */
 private static View chipRow(MainActivity act, JSONArray lb, int from, int to, String label) {
 LinearLayout wrap = Ui.col(act);
 TextView lab = Ui.micro(act, label);
 lab.setPadding(0, Ui.dp(act, 6), 0, 0);
 wrap.addView(lab);
 LinearLayout chips = chipsStrip(act, lb, from, to);
 wrap.addView(chips);
 // Professional Pack P3 (suggestion 30): the newest ball's chip pops
 // once when it lands - keyed on the ball itself, so tactic taps and
 // other re-renders never replay it, and Reduce Animations skips it
 try {
 if (act.animOk() && to == lb.length() && to > from) {
 int key = (lb.getString(to - 1) + "|" + to + "|" + lb.length()).hashCode();
 if (key != lastPopKey) {
 lastPopKey = key;
 View newest = chips.getChildAt(chips.getChildCount() - 1);
 if (newest != null) {
 newest.setScaleX(1.4f);
 newest.setScaleY(1.4f);
 newest.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
 }
 }
 }
 } catch (Exception ignored) {}
 return wrap;
 }

 // ---------------- Professional Pack P3 helpers ----------------

 private interface SegPick { void pick(int idx); }

 /** Suggestion 24: a segmented control row - equal-width segments,
  *  the selected one filled gold, the rest slate outline. selected
  *  may be -1 (nothing selected, for split rows). */
 private static View segmented(MainActivity act, String[] labels, int selected, SegPick l) {
 LinearLayout row = new LinearLayout(act);
 row.setOrientation(LinearLayout.HORIZONTAL);
 row.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 2));
 for (int i = 0; i < labels.length; i++) {
 final int idx = i;
 Button b = new Button(act);
 b.setText(labels[i]);
 b.setTextSize(Ui.scale(12.5f));
 b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
 b.setAllCaps(false);
 boolean sel = idx == selected;
 b.setTextColor(sel ? 0xFF0F172A : Ui.MUTED);
 b.setBackground(sel ? Ui.round(Ui.GOLD, Ui.R_BTN, act) : Ui.roundStroke(Ui.CARD, Ui.LINE, Ui.R_BTN, act));
 b.setMinWidth(0);
 b.setMinimumWidth(0);
 b.setPadding(0, 0, 0, 0);
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(act, 40), 1);
 lp.setMargins(0, 0, i < labels.length - 1 ? Ui.dp(act, 5) : 0, 0);
 b.setLayoutParams(lp);
 b.setOnClickListener(v -> l.pick(idx));
 row.addView(b);
 }
 return row;
 }

 /** Suggestion 24: six powerplay-over cells coloured by plan intent -
  *  Attacking gold, Balanced slate, Safe green. */
 private static View ppStrip(MainActivity act, int plan) {
 LinearLayout row = Ui.row(act);
 int colr = plan == 0 ? Ui.GOLD : plan == 2 ? Ui.GREEN : 0xFF64748B;
 for (int i = 0; i < 6; i++) {
 View cell = new View(act);
 cell.setBackground(Ui.round(colr, 4, act));
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(act, 10), 1);
 lp.setMargins(0, Ui.dp(act, 2), i < 5 ? Ui.dp(act, 4) : 0, Ui.dp(act, 4));
 cell.setLayoutParams(lp);
 row.addView(cell);
 }
 return row;
 }

 /** Suggestion 24: the rotation plan as a mini grid - one cell per
  *  over (rows of ten), the planned bowler's initials inside, coloured
  *  by phase: powerplay gold-dark, death red-dark, middle slate.
  *  Bowled overs are dimmed. */
 private static View planStrip(MainActivity act, JSONObject m, JSONArray rot, JSONArray bowl) {
 LinearLayout box = Ui.col(act);
 try {
 int total = rot.length();
 int balls = m.optInt("balls");
 for (int start = 0; start < total; start += 10) {
 LinearLayout row = Ui.row(act);
 for (int ov = start; ov < Math.min(start + 10, total); ov++) {
 int bi = rot.optInt(ov, -1);
 String ini = bi >= 0 && bi < bowl.length()
 ? Design.initials(bowl.getJSONObject(bi).optString("name")) : "\u00b7\u00b7";
 int colr = ov < 6 ? 0xFFB45309 : ov >= total - 4 ? 0xFFB91C1C : Ui.CARD2;
 boolean bowled = (ov + 1) * 6 <= balls;
 TextView cell = Ui.text(act, ini, 8.5f, bowled ? Ui.MUTED : Ui.INK, true);
 cell.setGravity(Gravity.CENTER);
 cell.setBackground(Ui.round(bowled ? Ui.CARD : colr, 5, act));
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(act, 22), 1);
 lp.setMargins(0, Ui.dp(act, 2), Ui.dp(act, 3), 0);
 cell.setLayoutParams(lp);
 row.addView(cell);
 }
 box.addView(row);
 }
 } catch (Exception ignored) {}
 return box;
 }

 /** Suggestion 22: the innings timeline card - one row per over from
  *  MatchCentre.timeline: real ball chips where the engine still
  *  stores them (the last 12 balls), otherwise an honest aggregate
  *  (the over's runs as one chip + a wicket chip per fall, with the
  *  fallen batter's initials), and the over's runs/wkts at the end. */
 private static View timelineCard(MainActivity act, String title, JSONArray overRuns, JSONArray fow,
 JSONArray lastBalls, int ballsBowled) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, title));
 JSONArray overs = MatchCentre.timeline(overRuns, fow, lastBalls, ballsBowled);
 if (overs.length() == 0) {
 card.addView(Ui.small(act, "No overs bowled yet."));
 return card;
 }
 try {
 for (int i = 0; i < overs.length(); i++) {
 JSONObject ov = overs.getJSONObject(i);
 LinearLayout row = Ui.row(act);
 row.setGravity(Gravity.CENTER_VERTICAL);
 row.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 2));
 TextView lab = Ui.micro(act, "Ov " + ov.optInt("over"));
 lab.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 34), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(lab);
 LinearLayout chips = Ui.row(act);
 chips.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 JSONArray balls = ov.optJSONArray("balls");
 int shown = 0;
 if (balls != null) {
 for (int j = 0; j < balls.length(); j++) {
 String s = balls.optString(j);
 if (s.isEmpty()) continue; // a bowled ball whose outcome scrolled off
 TextView chip = Ui.text(act, s, 11, Design.ballChipTextColor(s), true);
 chip.setBackground(Ui.round(Design.ballChipColor(s), 7, act));
 chip.setGravity(Gravity.CENTER);
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(act, 23), Ui.dp(act, 23));
 lp.setMargins(0, 0, Ui.dp(act, 3), 0);
 chip.setLayoutParams(lp);
 chips.addView(chip);
 shown++;
 }
 }
 if (shown == 0) {
 // aggregate over: one runs chip carries the over's total
 TextView agg = Ui.text(act, ov.optInt("runs") + "", 11, Ui.INK, true);
 agg.setBackground(Ui.round(Ui.CARD2, 7, act));
 agg.setGravity(Gravity.CENTER);
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(act, 34), Ui.dp(act, 23));
 lp.setMargins(0, 0, Ui.dp(act, 3), 0);
 agg.setLayoutParams(lp);
 chips.addView(agg);
 }
 // wicket chips: bigger, red, the fallen batter's initials
 JSONArray names = ov.optJSONArray("names");
 if (names != null) {
 for (int j = 0; j < names.length(); j++) {
 TextView w = Ui.text(act, "W " + Design.initials(names.optString(j)), 10, 0xFFF1F5F9, true);
 w.setBackground(Ui.round(0xFFEF4444, 7, act));
 w.setGravity(Gravity.CENTER);
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(act, 40), Ui.dp(act, 23));
 lp.setMargins(0, 0, Ui.dp(act, 3), 0);
 w.setLayoutParams(lp);
 chips.addView(w);
 }
 }
 row.addView(chips);
 TextView sum = Ui.display(act, ov.optInt("runs") + "/" + ov.optInt("wkts"), 12, Ui.MUTED);
 sum.setGravity(Gravity.RIGHT);
 sum.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(sum);
 card.addView(row);
 }
 if (lastBalls == null) {
 card.addView(Ui.small(act, "Ball-by-ball chips are kept for the latest innings; earlier overs show their runs and wickets."));
 }
 } catch (Exception ignored) {}
 return card;
 }

 /** Suggestion 25: the win-% graph card, wherever a series exists. */
 private static View graphCard(MainActivity act, JSONObject m, String title) {
 int[] gs = MatchCentre.toIntArray(MatchCentre.graphSeries(m));
 if (gs.length < 2) return null;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, title));
 card.addView(new WinGraphView(act, gs, Design.accentFor(act.g)));
 card.addView(Ui.small(act, "Win % after each over - gold is " + act.g.userTeam + "."));
 return card;
 }

 /** Suggestion 26: the head-to-head comparison block - five split
  *  measures from the two real squads (MatchCentre.comparison), the
  *  stronger side's number in gold. Shared by the Hub analysis card
  *  and the match screen's toss view. */
 public static View compareBlock(MainActivity act, Game g, String opp) {
 LinearLayout box = Ui.col(act);
 try {
 JSONArray rows = MatchCentre.comparison(g, opp);
 if (rows.length() == 0) return box;
 box.addView(Ui.gold(act, "HEAD TO HEAD", 11));
 String uCode = g.shortFor(g.userTeam), oCode = g.shortFor(opp);
 int uCol = Design.accentFor(g), oCol = Design.colorForTeam(g, opp);
 for (int i = 0; i < rows.length(); i++) {
 JSONObject r = rows.getJSONObject(i);
 int us = r.optInt("us"), them = r.optInt("them");
 LinearLayout head = Ui.row(act);
 TextView lab = Ui.text(act, r.optString("label"), 12.5f, Ui.INK, true);
 lab.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 head.addView(lab);
 head.addView(Ui.display(act, uCode + " " + us, 12, us > them ? Ui.GOLD : Ui.MUTED));
 TextView mid = Ui.text(act, "  \u00b7  ", 12, Ui.MUTED, false);
 head.addView(mid);
 head.addView(Ui.display(act, oCode + " " + them, 12, them > us ? Ui.GOLD : Ui.MUTED));
 box.addView(head);
 LinearLayout bars = Ui.row(act);
 LinearLayout bl = new LinearLayout(act);
 bl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 bl.addView(Ui.bar(act, us, uCol));
 LinearLayout br = new LinearLayout(act);
 LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
 brp.setMargins(Ui.dp(act, 6), 0, 0, 0);
 br.setLayoutParams(brp);
 br.addView(Ui.bar(act, them, oCol));
 bars.addView(bl);
 bars.addView(br);
 box.addView(bars);
 }
 } catch (Exception ignored) {}
 return box;
 }


 // ---------------- Batch A helpers ----------------

 /** Sim buttons honour the speed setting (idea 10): Instant resolves
 * synchronously (the v2 behaviour); 1x/2x stage the same sim through
 * MainActivity's auto-play loop, and tapping again stops it. */
 /** Suggestion 29: the rest of the sim controls live in the sheet
  *  behind the pinned bar's More button - Sim Innings, Sim Match and
  *  Highlights - so the bar itself stays slim. Stop Auto-Sim stays in
  *  the bar itself while a staged sim runs (always reachable). */
 private static void showMoreSheet(final MainActivity act) {
 LinearLayout col = Ui.col(act);
 col.addView(Ui.h2(act, "Sim controls"));
 Button si = Ui.darkBtn(act, "Sim Innings");
 si.setOnClickListener(v -> { act.hideSheet(); simTapped(act, "innings"); });
 col.addView(si);
 Button sm = Ui.darkBtn(act, "Sim Match");
 sm.setOnClickListener(v -> { act.hideSheet(); simTapped(act, "match"); });
 col.addView(sm);
 Button hl = Ui.darkBtn(act, "Highlights \u2014 Next Key Ball");
 hl.setOnClickListener(v -> { act.hideSheet(); act.stopAuto(); highlightsStep(act); });
 col.addView(hl);
 col.addView(Ui.small(act, "Speed (Instant / 1x / 2x) lives in the control bar. Highlights fast-plays the quiet balls and stops on every wicket, four and six."));
 act.showSheet(col);
 }


 private static void simTapped(MainActivity act, String mode) {
 // Batch J (idea 95): Reduce Animations forces the Instant path
 if (Settings.effectiveSpeed(act.g.speed, act.settings != null && act.settings.reduceAnim()) == 0) {
 act.stopAuto();
 // Batch B (idea 14): Instant sims fall back to the batting order
 // for next-man-in, so they never stall on the picker
 try { act.g.match.put("autoNextBat", true); } catch (Exception ignored) {}
 if ("over".equals(mode)) MatchEngine.simOver(act.g);
 else if ("innings".equals(mode)) MatchEngine.simInnings(act.g);
 else MatchEngine.simMatch(act.g);
 try { act.g.match.put("autoNextBat", false); } catch (Exception ignored) {}
 act.save();
 act.render();
 } else {
 act.startAuto(mode);
 }
 }

 /** Idea 9 — Highlights: fast-play quiet balls until the next KEY ball
 * (wicket, four or six), then stop on that state for the user to read.
 * Always terminates at the innings break, superbreak and full time
 * because every phase change exits the loop. */
 private static void highlightsStep(MainActivity act) {
 JSONObject m = act.g.match;
 int inn = m.optInt("inn");
 int guard = 0;
 while (guard++ < 150) {
 MatchEngine.bowlBall(act.g);
 if (!"play".equals(m.optString("phase"))) break;
 if (m.optBoolean("awaitBat")) break; // Batch B: stop for the next-batter pick
 if (m.optInt("inn") != inn && m.optInt("balls") == 0) break; // safety net
 JSONArray lb = m.optJSONArray("lastBalls");
 String last = lb != null && lb.length() > 0 ? lb.optString(lb.length() - 1) : "";
 if ("W".equals(last) || "4".equals(last) || "6".equals(last)) break;
 }
 // Batch J (idea 94): Highlights is a LIVE path — the key ball it
 // stops on gets its sound (or the jingle if the match just ended)
 if ("done".equals(m.optString("phase"))) {
 act.playEndJingle(act.g.userTeam.equals(m.optString("winnerTeam")));
 } else {
 act.playBallSound(true);
 }
 act.save();
 act.render();
 }

 /** Idea 6 — Manhattan chart card. */
 private static View manhattanCard(MainActivity act, String title, JSONArray overRuns) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, title));
 if (overRuns == null || overRuns.length() == 0) {
 card.addView(Ui.small(act, "No overs bowled yet."));
 } else {
 card.addView(new ManhattanView(act, overRuns));
 card.addView(Ui.small(act, "Over number along the bottom, runs in each over on the bars."));
 }
 return card;
 }

 /** Idea 7 — partnerships + fall of wickets card for one innings. */
 private static View extrasCard(MainActivity act, String title, JSONArray parts, JSONArray fow) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, title + " — Partnerships & Fall of Wickets"));
 try {
 if (fow != null) {
 for (int i = 0; i < fow.length(); i++) {
 JSONObject f = fow.getJSONObject(i);
 card.addView(Ui.body(act, f.optInt("wkts") + "-" + f.optInt("score")
 + " (" + f.optString("name") + ", " + f.optString("over") + " ov)"));
 }
 }
 if (parts != null && parts.length() > 0) {
 card.addView(Ui.spacer(act, 6));
 card.addView(Ui.small(act, "Partnerships"));
 for (int i = 0; i < parts.length(); i++) {
 JSONObject p = parts.getJSONObject(i);
 card.addView(Ui.body(act, p.optString("pair") + " — " + p.optInt("runs")
 + " (" + p.optInt("balls") + " balls)" + (p.optBoolean("unbroken") ? " *" : "")));
 }
 } else if (fow == null || fow.length() == 0) {
 card.addView(Ui.small(act, "No wickets have fallen yet."));
 }
 } catch (Exception ignored) {}
 return card;
 }

 // ---------------- toss ----------------

 /** v2 field-setting picker + Batch B (idea 17) named presets with a dot
 * map — used at the toss and again live while bowling. Chips wrap in
 * rows of three so nothing clips on a phone. */
 private static void addFieldPicker(final MainActivity act, final JSONObject m, LinearLayout into) {
 // Professional Pack P3 (suggestion 24): presets as segmented rows,
 //  the map titled with the active preset, dots labelled by role
 into.addView(Ui.small(act, "Field setting / preset (applies when you bowl):"));
 int field = m.optInt("field", 1);
 into.addView(segmented(act, new String[]{MatchEngine.FIELD[0], MatchEngine.FIELD[1], MatchEngine.FIELD[2]},
 field < 3 ? field : -1, idx -> {
 try { m.put("field", idx); } catch (Exception ignored) {}
 act.save();
 act.render();
 }));
 into.addView(segmented(act, new String[]{MatchEngine.FIELD[3], MatchEngine.FIELD[4], MatchEngine.FIELD[5]},
 field >= 3 ? field - 3 : -1, idx -> {
 try { m.put("field", idx + 3); } catch (Exception ignored) {}
 act.save();
 act.render();
 }));
 into.addView(Ui.text(act, "Field \u2014 " + MatchEngine.FIELD[field], 13, Ui.GOLD, true));
 into.addView(new FieldMapView(act, field));
 into.addView(Ui.small(act, "Gold dots are fielders (WK = keeper, B = bowler), each labelled with its position. Attacking presets hunt wickets but leak boundaries; defensive presets save boundaries but wickets dry up."));
 }


 /** Batch B (idea 11): Powerplay plan pickers. Editable before an innings
 * starts (toss, break, or ball 0); read-only once the innings is moving. */
 private static void addPpPickers(final MainActivity act, final JSONObject m, LinearLayout into, boolean editable) {
 // Professional Pack P3 (suggestion 24): segmented rows + an intent
 //  strip under each plan (gold Attacking, slate Balanced, green Safe)
 into.addView(Ui.spacer(act, 6));
 into.addView(Ui.text(act, "Powerplay plans \u2014 overs 1\u20136", 14, Ui.INK, true));
 if (!editable) {
 into.addView(Ui.body(act, "Batting PP: " + MatchEngine.PP_BAT[m.optInt("ppBat", 1)]
 + " \u00b7 Bowling PP: " + MatchEngine.PP_BOWL[m.optInt("ppBowl", 1)]));
 into.addView(Ui.small(act, "Plans lock once an innings starts \u2014 change them at the toss or the innings break."));
 return;
 }
 into.addView(Ui.small(act, "Batting Powerplay (when you bat):"));
 into.addView(segmented(act, MatchEngine.PP_BAT, m.optInt("ppBat", 1), idx -> {
 try { m.put("ppBat", idx); } catch (Exception ignored) {}
 act.save(); act.render();
 }));
 into.addView(ppStrip(act, m.optInt("ppBat", 1)));
 into.addView(Ui.small(act, "Bowling Powerplay (when you bowl):"));
 into.addView(segmented(act, MatchEngine.PP_BOWL, m.optInt("ppBowl", 1), idx -> {
 try { m.put("ppBowl", idx); } catch (Exception ignored) {}
 act.save(); act.render();
 }));
 into.addView(ppStrip(act, m.optInt("ppBowl", 1)));
 into.addView(Ui.small(act, "Attacking PP: faster scoring, more wickets. Safe: protect wickets / dry up runs."));
 }


 private static View tossView(final MainActivity act, final JSONObject m) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "THE TOSS", 13));
 // Batch A (ideas 3 & 4): the pitch report and conditions, up front
 int pitch = m.optInt("pitch", 0);
 card.addView(Ui.text(act, "Pitch: " + Data.PITCH_TYPES[pitch]
 + (m.optBoolean("evening") ? " · Day/Night" : " · Day game"), 15, Ui.INK, true));
 card.addView(Ui.small(act, Data.PITCH_DESC[pitch]
 + "Rain risk: " + m.optInt("rainRisk") + "%."
 + (m.optBoolean("evening") ? "Dew is expected in the chase — bowling second gets harder." : "")));
 // Batch B (idea 19): the opposition danger man, flagged before a ball is bowled
 card.addView(Ui.text(act, "Danger man: " + MatchEngine.dangerManLine(act.g, m.optString("opp")), 13, Ui.RED, true));
 card.addView(compareBlock(act, act.g, m.optString("opp"))); // P3 (suggestion 26)
 addFieldPicker(act, m, card);
 // Batch B (idea 11): Powerplay plans are set here, before innings 1
 addPpPickers(act, m, card, true);
 if (!m.optBoolean("tossDone")) {
 card.addView(Ui.h2(act, "Call the coin"));
 card.addView(Ui.small(act, "Win the toss and choose to bat or bowl first."));
 LinearLayout row = Ui.row(act);
 Button heads = Ui.darkBtn(act, "Heads"); // P1
 heads.setOnClickListener(v -> doToss(act, m, true));
 Button tails = Ui.darkBtn(act, "Tails"); // P1
 tails.setOnClickListener(v -> doToss(act, m, false));
 heads.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 tails.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(heads);
 row.addView(tails);
 card.addView(row);
 } else {
 card.addView(Ui.h2(act, "You won the toss!"));
 card.addView(Ui.small(act, "What will " + act.g.userTeam + " do first?"));
 Button bat = Ui.goldBtn(act, "Bat First");
 bat.setOnClickListener(v -> { MatchEngine.beginInnings1(act.g, true); act.save(); act.render(); });
 Button bowl = Ui.darkBtn(act, "Bowl First");
 bowl.setOnClickListener(v -> { MatchEngine.beginInnings1(act.g, false); act.save(); act.render(); });
 card.addView(bat);
 card.addView(bowl);
 }
 return card;
 }

 private static void doToss(MainActivity act, JSONObject m, boolean calledHeads) {
 try {
 boolean heads = new Random().nextBoolean();
 boolean userWon = heads == calledHeads;
 MatchEngine.addComm(act.g, "Coin lands " + (heads ? "HEADS" : "TAILS") + " — " +
 (userWon ? act.g.userTeam + " win the toss!" : m.optString("opp") + " win the toss."));
 if (userWon) {
 m.put("tossDone", true);
 } else {
 boolean oppBats = new Random().nextDouble() < 0.6;
 MatchEngine.addComm(act.g, m.optString("opp") + " choose to " + (oppBats ? "bat" : "bowl") + " first.");
 MatchEngine.beginInnings1(act.g, !oppBats);
 }
 act.save();
 act.render();
 } catch (Exception ignored) {}
 }

 // ---------------- live header ----------------

 private static View scoreHeader(MainActivity act, JSONObject m) {
 LinearLayout card = Ui.card(act);
 try {
 String batTeam = m.getString("batTeam");
 int runs = m.optInt("runs"), wkts = m.optInt("wkts"), balls = m.optInt("balls");
 boolean superMode = m.optBoolean("superMode");
 card.addView(Ui.text(act, superMode
 ? "SUPER OVER · " + m.getString("bowlTeam") + " bowling"
 : (m.optInt("inn") == 1 ? "Innings 1" : "Innings 2") +
 " · " + m.getString("bowlTeam") + " bowling", 12, Ui.MUTED, false));
 LinearLayout row = Ui.row(act);
 TextView score = Ui.text(act, act.g.shortFor(batTeam) + " " + runs + "/" + wkts, 28, Ui.INK, true);
 score.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(score);
 row.addView(Ui.gold(act, MatchEngine.oversStrFull(balls) + " ov", 18));
 card.addView(row);
 double crr = MatchEngine.crr(act.g);
 StringBuilder info = new StringBuilder();
 info.append(String.format(Locale.US, "CRR %.2f", crr));
 if (superMode) {
 if (m.optInt("target", 0) > 0) {
 int need = m.optInt("target") - runs;
 int rem = Math.max(0, m.optInt("ballsLimit", 6) - balls);
 info.append(" · Need ").append(Math.max(0, need)).append(" off ").append(rem).append(" to win the Super Over");
 } else {
 info.append(" · Super Over — set a total (6 balls, 2 wickets)");
 }
 } else if (m.optInt("inn") == 1) {
 info.append(" · Projected ").append(MatchEngine.projected(act.g));
 } else {
 int need = m.optInt("target") - runs;
 int rem = m.optInt("ballsLimit", 120) - balls; // Batch A: rain-cut aware
 double req = rem > 0 ? need * 6.0 / rem : 0;
 info.append(" · Target ").append(m.optInt("target"));
 info.append(" · Need ").append(Math.max(0, need)).append(" off ").append(Math.max(0, rem));
 info.append(String.format(Locale.US, " · Req %.2f", req));
 int par = MatchEngine.dlsPar(act.g);
 info.append(" · DLS par ").append(par)
 .append(runs >= par ? " (ahead)" : " (behind)");
 }
 card.addView(Ui.text(act, info.toString(), 13, Ui.MUTED, false));

 // P5 (suggestion 44): the rate terms get info chips here in the
 // analysis card (the sticky score bug is too tight for them);
 // DLS joins whenever its par score is on this card or rain has
 // already cut the match
 LinearLayout termRow = Ui.row(act);
 termRow.addView(Ui.infoChip(act, "CRR"));
 View gap1 = new View(act);
 gap1.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 10), 1));
 termRow.addView(gap1);
 termRow.addView(Ui.infoChip(act, "RRR"));
 if ((m.optInt("inn") == 2 && !superMode) || m.optBoolean("rainDone")) {
 View gap2 = new View(act);
 gap2.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 10), 1));
 termRow.addView(gap2);
 termRow.addView(Ui.infoChip(act, "DLS"));
 }
 card.addView(termRow);

 // Batch A (idea 2): the rain revision, pinned to the score header
 if (m.optBoolean("rainDone") && m.has("rainNote")) {
 card.addView(Ui.text(act, m.optString("rainNote"), 13, Ui.GOLD, true));
 }
 // Batch A (idea 4): dew reminder during an evening chase
 if (!superMode && m.optInt("inn") == 2 && m.optBoolean("evening")) {
 card.addView(Ui.small(act, "Day/night game — dew is about, the ball is skidding on and bowling is harder."));
 }
 // Batch A (idea 5): live win predictor for Lahore
 int wp = MatchEngine.winPredictor(act.g);
 LinearLayout wrow = Ui.row(act);
 TextView wlab = Ui.text(act, "Win Predictor — " + act.g.shortFor(act.g.userTeam) + " " + wp + "%", 13, Ui.INK, true);
 wrow.addView(wlab);
 card.addView(wrow);
 card.addView(Ui.bar(act, wp, Ui.GOLD));
 // Design Batch (item 7c): the momentum bar — the same split,
 // drawn, in both clubs' colours
 card.addView(new MomentumView(act, act.g.shortFor(act.g.userTeam), act.g.shortFor(m.optString("opp")),
 wp, Design.accentFor(act.g), Design.colorForTeam(act.g, m.optString("opp"))));
 int[] gsLive = MatchCentre.toIntArray(MatchCentre.graphSeries(m));
 if (gsLive.length >= 2) card.addView(new WinGraphView(act, gsLive, Design.accentFor(act.g)));

 // current pair + bowler
 JSONArray bat = m.getJSONArray("batCard");
 JSONObject striker = bat.getJSONObject(m.optInt("striker"));
 JSONObject non = bat.getJSONObject(m.optInt("nonStriker"));
 card.addView(Ui.body(act, striker.getString("name") + "* " + striker.optInt("runs") + " (" + striker.optInt("balls") + ")"));
 card.addView(Ui.body(act, non.getString("name") + " " + non.optInt("runs") + " (" + non.optInt("balls") + ")"));
 JSONArray bowl = m.getJSONArray("bowlCard");
 JSONObject bowler = bowl.getJSONObject(m.optInt("curBowler"));
 card.addView(Ui.small(act, "Bowling: " + bowler.getString("name") + " " +
 MatchEngine.oversStrFull(bowler.optInt("balls")) + "-" + bowler.optInt("runs") + "-" + bowler.optInt("wkts")));

 // Design Batch (item 7b): ball chips grouped by over — the
 // current over (or the one just completed) plus the previous
 // over, coloured by outcome via Design.ballChipColor
 JSONArray lb = m.optJSONArray("lastBalls");
 if (lb != null && lb.length() > 0) {
 int cur = Design.currentOverCount(balls, lb.length());
 int prevFrom = Math.max(0, lb.length() - cur - 6);
 int curFrom = lb.length() - cur;
 if (curFrom > prevFrom) {
 card.addView(chipRow(act, lb, prevFrom, curFrom, "Previous over"));
 }
 card.addView(chipRow(act, lb, curFrom, lb.length(),
 balls % 6 == 0 && balls > 0 ? "Just completed" : "This over"));
 }
 } catch (Exception ignored) {}
 return card;
 }

 private static View tactics(final MainActivity act, final JSONObject m) {
 LinearLayout card = Ui.card(act);
 boolean userBatting = act.g.userTeam.equals(m.optString("batTeam"));
 card.addView(Ui.h2(act, "Tactics — " + (userBatting ? "batting approach" : "bowling plan")));
 card.addView(Ui.small(act, userBatting
 ? "Attack/Slog score faster but risk wickets. Defend protects wickets."
 : "Your field plan: aggressive plans take wickets but leak boundaries."));
 card.addView(segmented(act, MatchEngine.TACTICS, m.optInt("tactic", 1), idx -> {
 try { m.put("tactic", idx); } catch (Exception ignored) {}
 act.save();
 act.render();
 }));
 card.addView(segmented(act, MatchEngine.RUNNING, m.optInt("running", 1), idx -> {
 try { m.put("running", idx); } catch (Exception ignored) {}
 act.save();
 act.render();
 }));

 // Batch B (idea 11): Powerplay plans — editable only before the
 // innings starts (ball 0), read-only after that
 addPpPickers(act, m, card, m.optInt("balls") == 0);

 // v2 finer controls — the whole match screen scrolls, and these controls
 // stack vertically, so no button is ever clipped off a phone screen
 if (userBatting) {
 card.addView(Ui.spacer(act, 6));
 card.addView(Ui.text(act, "Shield a batter", 14, Ui.INK, true));
 card.addView(Ui.small(act, "A shielded batter faces fewer balls and is much harder to dismiss — protect a set batter or a tail-ender."));
 String shield = m.optString("shield", "");
 Button none = Ui.chip(act, "No shield", shield.isEmpty());
 none.setOnClickListener(v -> {
 try { m.put("shield", ""); } catch (Exception ignored) {}
 act.save(); act.render();
 });
 card.addView(none);
 try {
 JSONArray bat = m.getJSONArray("batCard");
 for (int i = 0; i < bat.length(); i++) {
 JSONObject b = bat.getJSONObject(i);
 if (b.optBoolean("out")) continue;
 final String name = b.getString("name");
 Button c = Ui.chip(act, name, name.equals(shield));
 c.setOnClickListener(v -> {
 try { m.put("shield", name); } catch (Exception ignored) {}
 act.save(); act.render();
 });
 card.addView(c);
 }
 } catch (Exception ignored) {}
 } else {
 card.addView(Ui.spacer(act, 6));
 addFieldPicker(act, m, card);
 // Batch B (idea 20): a bowling plan against the man on strike —
 // it lives until he is dismissed or the manager changes it
 try {
 JSONArray bat = m.getJSONArray("batCard");
 final String strikerName = bat.getJSONObject(m.optInt("striker")).optString("name");
 card.addView(Ui.spacer(act, 6));
 card.addView(Ui.text(act, "Bowling plan vs " + strikerName, 14, Ui.INK, true));
 String planFor = m.optString("batPlanFor", "");
 int plan = m.optInt("batPlan", 0);
 if (!planFor.isEmpty() && !planFor.equals(strikerName) && plan > 0) {
 card.addView(Ui.small(act, "Plan active vs " + planFor + ": " + MatchEngine.BAT_PLANS[plan]
 + " (it bites when he is on strike). Pick below to re-target it at " + strikerName + "."));
 }
 int active = planFor.equals(strikerName) ? plan : 0;
 card.addView(segmented(act, new String[]{MatchEngine.BAT_PLANS[0], MatchEngine.BAT_PLANS[1], MatchEngine.BAT_PLANS[2]},
 active <= 2 ? active : -1, idx -> {
 try {
 m.put("batPlan", idx);
 m.put("batPlanFor", idx == 0 ? "" : strikerName);
 } catch (Exception ignored) {}
 act.save(); act.render();
 }));
 card.addView(segmented(act, new String[]{MatchEngine.BAT_PLANS[3], MatchEngine.BAT_PLANS[4]},
 active >= 3 ? active - 3 : -1, idx -> {
 try {
 m.put("batPlan", idx + 3);
 m.put("batPlanFor", strikerName);
 } catch (Exception ignored) {}
 act.save(); act.render();
 }));
 card.addView(Ui.small(act, "Yorkers strangle scoring · Short Stuff buys wickets but can be hooked · Outside Off starves and tempts the edge · Straight & Full attacks the stumps."));
 } catch (Exception ignored) {}
 }

 // Batch B (idea 18): the once-per-innings pep talk
 card.addView(Ui.spacer(act, 8));
 String seg = MatchEngine.pepSegment(m);
 if (seg.equals(m.optString("pepKey", ""))) {
 card.addView(Ui.small(act, "Pep talk used this innings"
 + (seg.equals(m.optString("pepBoostKey", "")) && m.optInt("balls") < m.optInt("pepBoostUntil", -1)
 ? " — the boost is live for the next few balls." : ".")));
 } else {
 Button pep = Ui.darkBtn(act, "Pep Talk — fire up the side (once per innings)");
 pep.setOnClickListener(v -> {
 act.stopAuto();
 String msg = MatchEngine.pepTalk(act.g);
 if (msg != null) act.toast("Pep talk delivered — boost live for two overs");
 act.save(); act.render();
 });
 card.addView(pep);
 card.addView(Ui.small(act, "Best used around the 10-over mark: two overs of extra intent, plus a Set lift for the men in the middle."));
 }
 return card;
 }

 // ---------------- Batch B cards ----------------

 /** Idea 14: the next-batter picker. Every unused, not-out card is a tap. */
 private static View nextBatterCard(final MainActivity act, final JSONObject m) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "WICKET DOWN — WHO COMES IN NEXT?", 13));
 card.addView(Ui.small(act, "The innings waits for your call. Pick the next batter:"));
 try {
 JSONArray bat = m.getJSONArray("batCard");
 for (int i = 0; i < bat.length(); i++) {
 JSONObject b = bat.getJSONObject(i);
 if (b.optBoolean("out") || b.optBoolean("in")) continue;
 final int idx = i;
 Button c = Ui.darkBtn(act, b.optString("name") + " · Bat " + b.optInt("bat"));
 c.setOnClickListener(v -> {
 act.stopAuto();
 if (MatchEngine.chooseNextBatter(act.g, idx)) {
 act.save(); act.render();
 } else {
 act.toast("That batter can't come in");
 }
 });
 card.addView(c);
 }
 } catch (Exception ignored) {}
 return card;
 }

 /** Idea 15: the assistant coach's tip, with a one-tap Apply when the tip
 * names a bowler for the next over. Bowling innings only. */
 private static View coachCard(final MainActivity act, final JSONObject m) {
 String[] tip = MatchEngine.coachSuggestion(act.g);
 if (tip == null) return null;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "ASSISTANT COACH", 13));
 card.addView(Ui.body(act, tip[0]));
 final int bowlIdx = Integer.parseInt(tip[1]);
 if (bowlIdx >= 0) {
 int balls = m.optInt("balls");
 final int nextOver = balls % 6 == 0 ? balls / 6 : balls / 6 + 1;
 Button apply = Ui.goldBtn(act, "Apply — bowl him in over " + (nextOver + 1));
 apply.setOnClickListener(v -> {
 String err = MatchEngine.setRotationOver(act.g, nextOver, bowlIdx);
 if (err != null) act.toast(err);
 act.save(); act.render();
 });
 card.addView(apply);
 }
 return card;
 }

 /** Ideas 12 & 13: the 20-over bowling plan. Bowled overs are summarised
 * from the actual record; upcoming overs are tappable, death overs
 * (17–20) are -marked. Lahore bowling innings only. */
 private static View rotationCard(final MainActivity act, final JSONObject m) {
 if (act.g.userTeam.equals(m.optString("batTeam")) || m.optBoolean("superMode")) return null;
 MatchEngine.ensureRotation(act.g);
 JSONArray rot = m.optJSONArray("rotation");
 int totalOvers = m.optInt("ballsLimit", 120) / 6;
 if (rot == null || rot.length() != totalOvers) return null;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Bowling Plan — Overs 1–" + totalOvers));
 try {
 JSONArray ob = m.optJSONArray("overBowlers");
 if (ob != null && ob.length() > 0) {
 StringBuilder sb = new StringBuilder("Bowled: ");
 for (int i = 0; i < ob.length(); i++) {
 if (i > 0) sb.append(" · ");
 sb.append(i + 1).append(" ").append(lastName(ob.optString(i)));
 }
 card.addView(Ui.small(act, sb.toString()));
 }
 JSONArray bowl = m.getJSONArray("bowlCard");
 card.addView(planStrip(act, m, rot, bowl)); // P3 (suggestion 24): the plan as a grid
 int fe = MatchEngine.firstEditableOver(act.g);
 int maxOver = m.optInt("ballsLimit", 120) / 6;
 if (fe >= maxOver) {
 card.addView(Ui.small(act, "Innings nearly done — no overs left to plan."));
 return card;
 }
 card.addView(Ui.small(act, "Tap an over to change its bowler. Max " + (totalOvers / 5) + " overs each, no back-to-back overs."));
 for (int ov = fe; ov < maxOver; ov++) {
 final int overIdx = ov;
 int bi = rot.optInt(ov, -1);
 String bname = bi >= 0 && bi < bowl.length()
 ? bowl.getJSONObject(bi).optString("name") : "—";
 boolean death = ov >= maxOver - 4;
 Button row = Ui.chip(act, "Ov " + (ov + 1) + (death ? " DEATH" : "") + ": " + bname, death);
 row.setOnClickListener(v -> showBowlerPicker(act, m, overIdx));
 card.addView(row);
 }
 } catch (Exception ignored) {}
 return card;
 }

 private static String lastName(String full) {
 int sp = full.lastIndexOf(' ');
 return sp > 0 ? full.substring(sp + 1) : full;
 }

 /** Bowler picker dialog for one planned over (rotation editor). */
 private static void showBowlerPicker(final MainActivity act, final JSONObject m, final int overIdx) {
 try {
 final JSONArray bowl = m.getJSONArray("bowlCard");
 JSONArray rot = m.optJSONArray("rotation");
 int planned = rot != null ? rot.optInt(overIdx, -1) : -1;
 String[] names = new String[bowl.length()];
 for (int i = 0; i < bowl.length(); i++) {
 JSONObject b = bowl.getJSONObject(i);
 names[i] = b.optString("name") + " — Bowl " + b.optInt("bowl")
 + " · " + MatchEngine.oversStrFull(b.optInt("balls")) + " ov bowled"
 + (i == planned ? " planned" : "");
 }
 new android.app.AlertDialog.Builder(act)
 .setTitle("Over " + (overIdx + 1) + (overIdx >= m.optInt("ballsLimit", 120) / 6 - 4 ? " (death over)" : "") + " — who bowls?")
 .setItems(names, (d, which) -> {
 String err = MatchEngine.setRotationOver(act.g, overIdx, which);
 if (err != null) act.toast(err);
 act.save(); act.render();
 })
 .setNegativeButton("Cancel", null)
 .show();
 } catch (Exception ignored) {}
 }

 /** Idea 16: batter-vs-bowler records from this innings' tracked balls —
 * the current pair against the current bowler, plus the striker's full
 * list against every bowler used so far. */
 private static View matchupCard(MainActivity act, JSONObject m) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Match-Ups — this innings"));
 try {
 JSONArray mu = m.optJSONArray("matchups");
 JSONArray bat = m.getJSONArray("batCard");
 JSONArray bowl = m.getJSONArray("bowlCard");
 JSONObject striker = bat.getJSONObject(m.optInt("striker"));
 JSONObject non = bat.getJSONObject(m.optInt("nonStriker"));
 JSONObject bowler = bowl.getJSONObject(m.optInt("curBowler"));
 if (mu == null || mu.length() == 0) {
 card.addView(Ui.small(act, "No balls bowled yet — match-ups build ball by ball."));
 return card;
 }
 card.addView(muLine(act, mu, striker, bowler));
 card.addView(muLine(act, mu, non, bowler));
 card.addView(Ui.spacer(act, 4));
 card.addView(Ui.small(act, striker.optString("name") + " against every bowler so far:"));
 boolean any = false;
 for (int i = 0; i < mu.length(); i++) {
 JSONObject x = mu.getJSONObject(i);
 if (!x.optString("bat").equals(striker.optString("name"))) continue;
 if (x.optString("bowl").equals(bowler.optString("name"))) continue;
 card.addView(Ui.body(act, "vs " + x.optString("bowl") + " — " + x.optInt("runs")
 + " off " + x.optInt("balls") + (x.optInt("outs") > 0 ? " · out " + x.optInt("outs") + "×" : "")));
 any = true;
 }
 if (!any) card.addView(Ui.small(act, "Only faced " + bowler.optString("name") + " so far."));
 } catch (Exception ignored) {}
 return card;
 }

 private static View muLine(MainActivity act, JSONArray mu, JSONObject batter, JSONObject bowler) {
 JSONObject x = MatchEngine.matchup(mu, batter.optString("name"), bowler.optString("name"));
 if (x == null) {
 return Ui.body(act, batter.optString("name") + " vs " + bowler.optString("name") + " — yet to face him");
 }
 return Ui.body(act, batter.optString("name") + " vs " + bowler.optString("name") + " — "
 + x.optInt("runs") + " off " + x.optInt("balls")
 + (x.optInt("outs") > 0 ? " · dismissed " + x.optInt("outs") + "×" : " · unbeaten duel"));
 }

 // ---------------- Professional Pack P3: full-time infographic ----

 /** Suggestion 28: the full-time lead panel - big result, Player of
  *  the Match with avatar + tier, the turning point, top performers
  *  and the win-% graph. The detailed cards follow below it. */
 private static View infographic(MainActivity act, JSONObject m) {
 Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "MATCH SUMMARY", 12));
 card.addView(Ui.h2(act, m.optString("result")));
 if (m.optBoolean("superPlayed")) {
 card.addView(Ui.text(act, m.optString("superSummary"), 14, Ui.GOLD, true));
 }
 if (m.has("potm")) {
 String name = m.optString("potm");
 LinearLayout row = Ui.row(act);
 row.setGravity(Gravity.CENTER_VERTICAL);
 row.addView(new AvatarView(act, name, roleFor(act, m, name), 42));
 LinearLayout col = Ui.col(act);
 LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
 cp.setMargins(Ui.dp(act, 10), 0, 0, 0);
 col.setLayoutParams(cp);
 col.addView(Ui.micro(act, "PLAYER OF THE MATCH"));
 col.addView(Ui.text(act, name, 15, Ui.INK, true));
 col.addView(Ui.small(act, m.optString("potmDesc")
 + (m.optBoolean("potmUser") && m.optInt("friendly") == 0 ? " \u00b7 +25 CF bonus" : "")));
 int rt = cardRating(act, m, name);
 TextView tier = Ui.text(act, Design.tierName(rt) + " tier", 11, Design.tierColor(rt), true);
 col.addView(tier);
 row.addView(col);
 card.addView(row);
 }
 card.addView(Ui.text(act, turningPointLine(act, m), 13, Ui.GOLD, true));
 try {
 JSONObject tp = MatchCentre.topPerformers(m);
 JSONArray bats = tp.optJSONArray("bats");
 if (bats != null && bats.length() > 0) {
 StringBuilder sb = new StringBuilder("Top scorers: ");
 for (int i = 0; i < bats.length(); i++) {
 JSONObject b = bats.getJSONObject(i);
 if (i > 0) sb.append(" \u00b7 ");
 sb.append(b.optString("name")).append(" ").append(b.optInt("runs"))
 .append(" (").append(b.optInt("balls")).append(")");
 }
 card.addView(Ui.small(act, sb.toString()));
 }
 JSONObject bw = tp.optJSONObject("bowl");
 if (bw != null) {
 card.addView(Ui.small(act, "Best bowling: " + bw.optString("name") + " " + bw.optInt("wkts")
 + "/" + bw.optInt("runs") + " \u00b7 " + MatchEngine.oversStrFull(bw.optInt("balls")) + " ov"));
 }
 } catch (Exception ignored) {}
 int[] gs = MatchCentre.toIntArray(MatchCentre.graphSeries(m));
 if (gs.length >= 2) {
 card.addView(new WinGraphView(act, gs, Design.accentFor(g)));
 card.addView(Ui.micro(act, "WIN % BY OVER \u2014 " + g.shortFor(g.userTeam)));
 }
 return card;
 }

 /** Suggestion 28: the turning point - the biggest recorded win-%
  *  swing (MatchCentre.turningPoint); when no series exists, the
  *  plainly-labelled fallback is the match's standout event, and if
  *  there is none of those either, the card says so. */
 private static String turningPointLine(MainActivity act, JSONObject m) {
 try {
 JSONArray i2 = m.optJSONArray("inn2Wp");
 JSONObject tp = MatchCentre.turningPoint(m.optJSONArray("inn1Wp"),
 i2 != null && i2.length() > 0 ? i2 : m.optJSONArray("wpSeries"));
 if (tp != null && tp.optInt("swing") >= 8) {
 return "Turning point: over " + tp.optInt("over") + " of "
 + (tp.optInt("inn") == 1 ? "the first innings" : "the chase")
 + " \u2014 " + act.g.shortFor(act.g.userTeam) + " win chance swung "
 + tp.optInt("from") + "% to " + tp.optInt("to") + "%.";
 }
 JSONArray[] batCards = {m.optJSONArray("inn1BatCard"), m.optJSONArray("batCard")};
 for (JSONArray c : batCards) {
 if (c == null) continue;
 for (int i = 0; i < c.length(); i++) {
 JSONObject b = c.getJSONObject(i);
 if (b.optInt("runs") >= 100) {
 return "Turning point: " + b.optString("name") + "'s hundred \u2014 "
 + b.optInt("runs") + " off " + b.optInt("balls") + ".";
 }
 }
 }
 JSONArray[] bowlCards = {m.optJSONArray("inn1BowlCard"), m.optJSONArray("bowlCard")};
 for (JSONArray c : bowlCards) {
 if (c == null) continue;
 for (int i = 0; i < c.length(); i++) {
 JSONObject b = c.getJSONObject(i);
 if (b.optInt("wkts") >= 5) {
 return "Turning point: " + b.optString("name") + "'s five-for \u2014 "
 + b.optInt("wkts") + "/" + b.optInt("runs") + ".";
 }
 }
 }
 JSONArray[] fows = {m.optJSONArray("inn1Fow"), m.optJSONArray("fow")};
 for (JSONArray f : fows) {
 if (f == null) continue;
 java.util.HashMap<Integer, Integer> per = new java.util.HashMap<>();
 for (int i = 0; i < f.length(); i++) {
 int oi = MatchCentre.fowOverIndex(f.getJSONObject(i).optString("over"));
 int n = per.containsKey(oi) ? per.get(oi) + 1 : 1;
 per.put(oi, n);
 if (n >= 3) return "Turning point: the over-" + (oi + 1) + " collapse \u2014 three wickets in one over.";
 }
 }
 } catch (Exception ignored) {}
 return "Turning point: no single swing stood out \u2014 small margins all game.";
 }

 /** A player's role for avatar tinting: the user's squad first, then
  *  the opponent's Data squad, then a neutral default. */
 private static String roleFor(MainActivity act, JSONObject m, String name) {
 for (int i = 0; i < act.g.players.length(); i++) {
 JSONObject p = act.g.player(i);
 if (name.equals(p.optString("name"))) return p.optString("role");
 }
 Object[][] rows = Data.squadFor(m.optString("opp"));
 if (rows != null) {
 for (Object[] r : rows) if (name.equals(r[0])) return (String) r[1];
 }
 return "Bat";
 }

 /** A rating for tier framing, from the match cards themselves. */
 private static int cardRating(MainActivity act, JSONObject m, String name) {
 JSONArray[] cards = {m.optJSONArray("batCard"), m.optJSONArray("inn1BatCard")};
 for (JSONArray c : cards) {
 if (c == null) continue;
 try {
 for (int i = 0; i < c.length(); i++) {
 JSONObject b = c.getJSONObject(i);
 if (name.equals(b.optString("name"))) {
 String role = roleFor(act, m, name);
 int bat = b.optInt("bat"), bowl = b.optInt("bowl");
 if ("Bowl".equals(role)) return (int) (bowl * 0.85 + bat * 0.15);
 if ("WK".equals(role)) return (int) (bat * 0.9 + bowl * 0.1) + 2;
 if ("AR".equals(role)) return (bat + bowl) / 2 + 3;
 return (int) (bat * 0.85 + bowl * 0.15);
 }
 }
 } catch (Exception ignored) {}
 }
 return 70;
 }


 // ---------------- scorecard + commentary ----------------

 private static View scorecard(MainActivity act, JSONObject m) {
 // Professional Pack P3 (suggestion 27): pro tables - fixed header
 // rows, right-aligned display numerals, zebra rows, the not-out
 // pair in gold, and bowling in O-M-R-W-Econ order (maidens derived
 // from overBowlers + overRuns - see MatchCentre.maidensFor)
 LinearLayout card = Ui.card(act);
 try {
 card.addView(Ui.h2(act, "Scorecard \u2014 " + m.getString("batTeam")));
 if (m.optInt("inn") == 2 && m.has("inn1Summary")) {
 card.addView(Ui.small(act, "Innings 1: " + m.getString("inn1Summary") + " \u00b7 Target " + m.optInt("target")));
 }
 card.addView(tableHead(act, "BATTER", new String[]{"R", "B"}, new int[]{38, 38}));
 JSONArray bat = m.getJSONArray("batCard");
 int striker = m.optInt("striker"), non = m.optInt("nonStriker"), nextIn = m.optInt("nextIn");
 int rowIdx = 0;
 for (int i = 0; i < bat.length(); i++) {
 JSONObject b = bat.getJSONObject(i);
 String status;
 if (b.optBoolean("out")) status = b.optString("how");
 else if (i == striker || i == non) status = "not out";
 else if (b.has("in") ? !b.optBoolean("in") : i >= nextIn) status = "yet to bat";
 else status = "not out";
 if ("yet to bat".equals(status)) {
 card.addView(Ui.small(act, b.getString("name") + " \u2014 yet to bat"));
 continue;
 }
 boolean atCrease = i == striker || i == non;
 LinearLayout row = Ui.row(act);
 row.setGravity(Gravity.CENTER_VERTICAL);
 row.setPadding(Ui.dp(act, 6), Ui.dp(act, 4), Ui.dp(act, 6), Ui.dp(act, 4));
 if (rowIdx % 2 == 1) row.setBackground(Ui.round(Ui.CARD2, 6, act));
 LinearLayout nameCol = Ui.col(act);
 nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 nameCol.addView(Ui.text(act, b.getString("name") + (atCrease ? " *" : ""), 13.5f,
 atCrease ? Ui.GOLD : Ui.INK, atCrease));
 nameCol.addView(Ui.text(act, status, 11, Ui.MUTED, false));
 row.addView(nameCol);
 TextView rv = Ui.display(act, b.optInt("runs") + "", 15, Ui.INK);
 rv.setGravity(Gravity.RIGHT);
 rv.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 38), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(rv);
 TextView bv = Ui.display(act, b.optInt("balls") + "", 12, Ui.MUTED);
 bv.setGravity(Gravity.RIGHT);
 bv.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 38), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(bv);
 card.addView(row);
 rowIdx++;
 }
 card.addView(Ui.spacer(act, 6));
 card.addView(tableHead(act, "BOWLER", new String[]{"O", "M", "R", "W", "ECON"}, new int[]{34, 22, 34, 28, 46}));
 JSONArray bowl = m.getJSONArray("bowlCard");
 for (int i = 0; i < bowl.length(); i++) {
 JSONObject b = bowl.getJSONObject(i);
 LinearLayout row = Ui.row(act);
 row.setGravity(Gravity.CENTER_VERTICAL);
 row.setPadding(Ui.dp(act, 6), Ui.dp(act, 4), Ui.dp(act, 6), Ui.dp(act, 4));
 if (i % 2 == 1) row.setBackground(Ui.round(Ui.CARD2, 6, act));
 TextView nm = Ui.text(act, b.getString("name"), 13, Ui.INK, false);
 nm.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(nm);
 int balls = b.optInt("balls");
 int mdns = m.optBoolean("superPlayed") ? -1
 : MatchCentre.maidensFor(m.optJSONArray("overBowlers"), m.optJSONArray("overRuns"), b.getString("name"));
 String[] cells = {
 MatchEngine.oversStrFull(balls),
 mdns < 0 ? "\u2013" : mdns + "",
 b.optInt("runs") + "",
 b.optInt("wkts") + "",
 balls > 0 ? String.format(Locale.US, "%.2f", b.optInt("runs") * 6.0 / balls) : "\u2013"};
 int[] widths = {34, 22, 34, 28, 46};
 for (int c = 0; c < cells.length; c++) {
 TextView v = Ui.display(act, cells[c], 12, c == 3 ? Ui.INK : Ui.MUTED);
 v.setGravity(Gravity.RIGHT);
 v.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, widths[c]), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(v);
 }
 card.addView(row);
 }
 } catch (Exception ignored) {}
 return card;
 }

 /** Suggestion 27: a fixed table header row - label left, numeric
  *  column titles right-aligned over their columns. */
 private static View tableHead(MainActivity act, String label, String[] cols, int[] widths) {
 LinearLayout row = Ui.row(act);
 row.setPadding(Ui.dp(act, 6), Ui.dp(act, 2), Ui.dp(act, 6), Ui.dp(act, 2));
 TextView lab = Ui.micro(act, label);
 lab.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(lab);
 for (int i = 0; i < cols.length; i++) {
 TextView v = Ui.micro(act, cols[i]);
 v.setGravity(Gravity.RIGHT);
 v.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, widths[i]), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(v);
 }
 return row;
 }


 private static View commCard(MainActivity act, JSONObject m) {
 // Professional Pack P3 (suggestion 23): commentary grouped under
 // over headers, oldest first like a real text feed; key balls
 // (from the engine's commEv tags) become event rows with a colour
 // chip, quiet balls stay compact single lines. Roman Urdu lines
 // ride the same data, untouched.
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Commentary"));
 JSONArray comm = m.optJSONArray("comm");
 if (comm == null || comm.length() == 0) {
 card.addView(Ui.small(act, "Commentary will appear here ball by ball."));
 return card;
 }
 JSONArray ev = m.optJSONArray("commEv");
 String curHeader = null;
 for (int i = comm.length() - 1; i >= 0; i--) {
 String line = comm.optString(i);
 String e = ev != null && i < ev.length() ? ev.optString(i) : "";
 int over = commOver(line);
 String header = over >= 0 ? "OVER " + (over + 1) : (curHeader == null ? "MATCH" : curHeader);
 if (!header.equals(curHeader)) {
 TextView h = Ui.micro(act, header);
 h.setTextColor(Ui.GOLD);
 h.setPadding(0, Ui.dp(act, 9), 0, Ui.dp(act, 2));
 card.addView(h);
 curHeader = header;
 }
 if (!e.isEmpty()) {
 LinearLayout row = Ui.row(act);
 row.setGravity(Gravity.CENTER_VERTICAL);
 row.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 2));
 TextView chip = Ui.text(act, e, 11, "4".equals(e) || "M".equals(e) ? 0xFF0F172A : 0xFFF1F5F9, true);
 chip.setBackground(Ui.round("M".equals(e) ? Ui.GOLD : Design.ballChipColor(e), 7, act));
 chip.setGravity(Gravity.CENTER);
 LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(Ui.dp(act, 24), Ui.dp(act, 24));
 clp.setMargins(0, 0, Ui.dp(act, 8), 0);
 chip.setLayoutParams(clp);
 row.addView(chip);
 TextView t = Ui.text(act, line, 13, Ui.INK, false);
 t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(t);
 card.addView(row);
 } else {
 TextView t = Ui.text(act, line, 12.5f, Ui.MUTED, false);
 t.setPadding(0, Ui.dp(act, 1), 0, Ui.dp(act, 1));
 card.addView(t);
 }
 }
 return card;
 }

 /** The 0-based over a commentary ball line belongs to, from its
  *  "12.3 \u2014 " prefix (oversStr of balls-1); -1 for non-ball lines. */
 private static int commOver(String line) {
 try {
 int dot = line.indexOf('.');
 if (dot <= 0 || dot > 3) return -1;
 for (int i = 0; i < dot; i++) if (!Character.isDigit(line.charAt(i))) return -1;
 int sp = line.indexOf(' ', dot);
 if (sp < 0) return -1;
 String ballPart = line.substring(dot + 1, sp);
 if (ballPart.length() != 1 || !Character.isDigit(ballPart.charAt(0))) return -1;
 return Integer.parseInt(line.substring(0, dot));
 } catch (Exception e) { return -1; }
 }
}
