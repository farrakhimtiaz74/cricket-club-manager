package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class WorldScreen {
 public static View build(final MainActivity act) {
 LinearLayout root = Ui.col(act);
 // P2 (suggestion 14): the category headers lead the tab's groups
 root.addView(Ui.sectionHeader(act, "RANKINGS"));

 LinearLayout fmtRow = new LinearLayout(act);
 fmtRow.setOrientation(LinearLayout.HORIZONTAL);
 for (int i = 0; i < Data.FORMATS.length; i++) {
 final int idx = i;
 Button c = Ui.chip(act, Data.FORMATS[i], act.worldFormat == i);
 c.setOnClickListener(v -> { act.worldFormat = idx; act.render(); });
 fmtRow.addView(c);
 }
 root.addView(fmtRow);

 LinearLayout catRow = new LinearLayout(act);
 catRow.setOrientation(LinearLayout.HORIZONTAL);
 for (int i = 0; i < Data.CATEGORIES.length; i++) {
 final int idx = i;
 Button c = Ui.chip(act, Data.CATEGORIES[i], act.worldCat == i);
 c.setOnClickListener(v -> { act.worldCat = idx; act.render(); });
 catRow.addView(c);
 }
 root.addView(catRow);

 // Batch F (idea 54): the T20I tables are LIVE in this career — they
 // drift at every rollover with tournament results, and each row
 // shows its movement vs last season. Other formats stay a snapshot.
 boolean live = act.worldFormat == 0;
 LinearLayout players = Ui.card(act);
 players.addView(Ui.h2(act, Data.FORMATS[act.worldFormat] + " — Top " + Data.CATEGORIES[act.worldCat] + " Players"));
 if (live && act.worldCat == 0) {
 for (int i = 0; i < act.g.worldBat.length(); i++) {
 org.json.JSONObject e = act.g.worldBat.optJSONObject(i);
 if (e == null) continue;
 players.addView(rankRow(act, i + 1, e.optString("name"), e.optString("tag"),
 String.valueOf(e.optInt("pts")), Game.rankMove(e.optInt("prev", i + 1), i + 1)));
 }
 } else if (live && act.worldCat == 1) {
 for (int i = 0; i < act.g.worldBowl.length(); i++) {
 org.json.JSONObject e = act.g.worldBowl.optJSONObject(i);
 if (e == null) continue;
 players.addView(rankRow(act, i + 1, e.optString("name"), e.optString("tag"),
 String.valueOf(e.optInt("pts")), Game.rankMove(e.optInt("prev", i + 1), i + 1)));
 }
 } else {
 String[][] rows = Data.worldPlayers(act.worldFormat, act.worldCat);
 for (int i = 0; i < rows.length; i++) {
 players.addView(rankRow(act, i + 1, rows[i][0], rows[i][1], rows[i][2]));
 }
 }
 root.addView(players);

 LinearLayout nations = Ui.card(act);
 nations.addView(Ui.h2(act, Data.FORMATS[act.worldFormat] + " — Team Rankings"));
 if (live) {
 for (int i = 0; i < act.g.worldNations.length(); i++) {
 org.json.JSONObject e = act.g.worldNations.optJSONObject(i);
 if (e == null) continue;
 boolean pak = "Pakistan".equals(e.optString("name"));
 nations.addView(rankRow(act, i + 1, e.optString("name"), pak ? " your nation" : "nation",
 String.valueOf(e.optInt("pts")), Game.rankMove(e.optInt("prev", i + 1), i + 1)));
 }
 } else {
 String[][] ns = Data.worldNations(act.worldFormat);
 for (int i = 0; i < ns.length; i++) {
 boolean pak = "Pakistan".equals(ns[i][0]);
 nations.addView(rankRow(act, i + 1, ns[i][0], pak ? " your nation" : "nation", ns[i][1]));
 }
 }
 root.addView(nations);

 // v2 watchlist: league stars — a WATCHLIST alert lands in Hub news
 // when a watched player scores a century or takes 5 wickets in any match
 root.addView(Ui.sectionHeader(act, "WATCHLIST"));
 LinearLayout stars = Ui.card(act);
 stars.addView(Ui.h2(act, "League Stars — Watchlist"));
 stars.addView(Ui.small(act, "Star a player to get an inbox alert for his century or 5-wicket haul. Your own squad is watchable from the Team tab."));
 for (String[] s : Data.OPP_STARS) {
 final String name = s[0];
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
 LinearLayout col = Ui.col(act);
 col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 col.addView(Ui.text(act, name, 15, Ui.INK, true));
 col.addView(Ui.small(act, s[1]));
 row.addView(col);
 Button w = Ui.chip(act, act.g.isWatched(name) ? "Watching" : "Watch", act.g.isWatched(name));
 w.setOnClickListener(v -> {
 act.g.toggleWatch(name);
 act.save();
 act.render();
 });
 row.addView(w);
 stars.addView(row);
 }
 root.addView(stars);
 root.addView(Ui.small(act, act.worldFormat == 0
 ? "T20I rankings are LIVE in this career (Season " + act.g.season + "): points drift every "
 + "season — the nations of the Golden Bat / Best Bowler winners and the champion captain gain most. "
 + "▲▼ shows movement vs last season."
 : "This format's rankings are a static snapshot for this season's world game."));
 return root;
 }

 private static View rankRow(MainActivity act, int rank, String name, String tag, String rating) {
 return rankRow(act, rank, name, tag, rating, null);
 }

 /** Batch F (idea 54): movement vs last season rides at the row's right edge. */
 private static View rankRow(MainActivity act, int rank, String name, String tag, String rating, String move) {
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 5), 0, Ui.dp(act, 5));
 TextView r = Ui.gold(act, "#" + rank, 15);
 r.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(r);
 LinearLayout col = Ui.col(act);
 col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 col.addView(Ui.text(act, name, 15, Ui.INK, true));
 col.addView(Ui.small(act, tag));
 row.addView(col);
 if (move != null && !"—".equals(move)) {
 TextView mv = Ui.text(act, move, 13, move.startsWith("▲") ? Ui.GREEN : Ui.RED, true);
 mv.setPadding(0, 0, Ui.dp(act, 10), 0);
 row.addView(mv);
 }
 TextView val = Ui.text(act, rating, 15, Ui.INK, true);
 val.setGravity(Gravity.END);
 row.addView(val);
 return row;
 }
}
