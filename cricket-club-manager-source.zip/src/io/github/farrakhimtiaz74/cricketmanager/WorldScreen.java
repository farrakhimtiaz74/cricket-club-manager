package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class WorldScreen {
    public static View build(final MainActivity act) {
        LinearLayout root = Ui.col(act);

        LinearLayout fmtRow = new LinearLayout(act);
        fmtRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Data.FORMATS.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, Data.FORMATS[i], act.worldFormat == i);
            c.setOnClickListener(v -> { act.worldFormat = idx; act.render(); });
            fmtRow.addView(c);
        }
        root.addView(fmtRow);

        LinearLayout catRow = new LinearLayout(act);
        catRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Data.CATEGORIES.length; i++) {
            final int idx = i;
            Button c = Ui.chip(act, Data.CATEGORIES[i], act.worldCat == i);
            c.setOnClickListener(v -> { act.worldCat = idx; act.render(); });
            catRow.addView(c);
        }
        root.addView(catRow);

        LinearLayout players = Ui.card(act);
        players.addView(Ui.h2(act, Data.FORMATS[act.worldFormat] + " — Top " + Data.CATEGORIES[act.worldCat] + " Players"));
        String[][] rows = Data.worldPlayers(act.worldFormat, act.worldCat);
        for (int i = 0; i < rows.length; i++) {
            players.addView(rankRow(act, i + 1, rows[i][0], rows[i][1], rows[i][2]));
        }
        root.addView(players);

        LinearLayout nations = Ui.card(act);
        nations.addView(Ui.h2(act, Data.FORMATS[act.worldFormat] + " — Team Rankings"));
        String[][] ns = Data.worldNations(act.worldFormat);
        for (int i = 0; i < ns.length; i++) {
            boolean pak = "Pakistan".equals(ns[i][0]);
            nations.addView(rankRow(act, i + 1, ns[i][0], pak ? "★ your nation" : "nation", ns[i][1]));
        }
        root.addView(nations);
        root.addView(Ui.small(act, "Rankings are a static snapshot for this season's world game."));
        return root;
    }

    private static View rankRow(MainActivity act, int rank, String name, String tag, String rating) {
        LinearLayout row = Ui.row(act);
        row.setPadding(0, Ui.dp(act, 5), 0, Ui.dp(act, 5));
        TextView r = Ui.gold(act, "#" + rank, 15);
        r.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(r);
        LinearLayout col = Ui.col(act);
        col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        col.addView(Ui.text(act, name, 15, Ui.INK, true));
        col.addView(Ui.small(act, tag));
        row.addView(col);
        TextView val = Ui.text(act, rating, 15, Ui.INK, true);
        val.setGravity(Gravity.END);
        row.addView(val);
        return row;
    }
}
