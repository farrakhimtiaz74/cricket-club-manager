package io.github.farrakhimtiaz74.cricketmanager;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class WorldScreen {
 public static View build(final MainActivity act) {
 LinearLayout root = Ui.col(act);
 // P2 (suggestion 14): the category headers lead the tab's groups
 root.addView(Ui.sectionHeader(act, "RANKINGS"));
 // v20.1 (item 4): the grass strip now CARRIES content — your
 // club's best-ranked player in the live T20I tables (Batting
 // first, then Bowling), or the moving-rankings note when none of
 // your squad is ranked yet. Never an empty band.
 {
 final Game g = act.g;
 String best = null;
 for (int i = 0; i < g.worldBat.length() && best == null; i++) {
 org.json.JSONObject e = g.worldBat.optJSONObject(i);
 if (e != null && g.playerByName(e.optString("name")) != null) {
 best = e.optString("name") + " · #" + (i + 1) + " T20I Batting";
 }
 }
 for (int i = 0; i < g.worldBowl.length() && best == null; i++) {
 org.json.JSONObject e = g.worldBowl.optJSONObject(i);
 if (e != null && g.playerByName(e.optString("name")) != null) {
 best = e.optString("name") + " · #" + (i + 1) + " T20I Bowling";
 }
 }
 String line = best != null ? "Your club's best: " + best
 : "T20I rankings are live — they move every season";
 LinearLayout band = Ui.row(act);
 band.setGravity(Gravity.CENTER_VERTICAL);
 band.setPadding(Ui.dp(act, 12), 0, Ui.dp(act, 12), 0);
 android.graphics.Bitmap grassBmp = Art.bitmap(act, Art.TEX_GRASS, 720);
 if (grassBmp != null) {
 android.graphics.drawable.BitmapDrawable gd =
 new android.graphics.drawable.BitmapDrawable(act.getResources(), grassBmp);
 gd.setAlpha(120);
 gd.setGravity(Gravity.FILL);
 band.setBackground(new android.graphics.drawable.LayerDrawable(
 new android.graphics.drawable.Drawable[]{
 new android.graphics.drawable.ColorDrawable(Ui.PITCH_DEEP), gd}));
 } else {
 band.setBackgroundColor(Ui.PITCH_DEEP);
 }
 TextView lt = Ui.text(act, line, 12.5f, Ui.INK, true);
 lt.setSingleLine(true);
 lt.setEllipsize(android.text.TextUtils.TruncateAt.END);
 band.addView(lt);
 LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
 ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 34));
 blp.setMargins(0, 0, 0, Ui.dp(act, 10));
 band.setLayoutParams(blp);
 root.addView(band);
 }

 // v20.1 (item 8): the format and category switches are proper
 // SEGMENTED controls now (one rounded track each, selected segment
 // filled gold) — the loose pill rows are gone.
 root.addView(Ui.segmented(act, Data.FORMATS, act.worldFormat,
 i -> { act.worldFormat = i; act.render(); }));
 root.addView(Ui.segmented(act, Data.CATEGORIES, act.worldCat,
 i -> { act.worldCat = i; act.render(); }));

 // Batch F (idea 54): the T20I tables are LIVE in this career — they
 // drift at every rollover with tournament results, and each row
 // shows its movement vs last season. Other formats stay a snapshot.
 boolean live = act.worldFormat == 0;
 LinearLayout players = Ui.card(act);
 players.addView(Ui.h2(act, Data.FORMATS[act.worldFormat] + " — Top " + Data.CATEGORIES[act.worldCat] + " Players"));
 // v21 item 9: both rankings build through the RecycleList pool —
 // rows are {rank, name, tag, rating, move} tuples bound on demand
 final java.util.List<String[]> prow = new java.util.ArrayList<>();
 if (live && act.worldCat == 0) {
 for (int i = 0; i < act.g.worldBat.length(); i++) {
 org.json.JSONObject e = act.g.worldBat.optJSONObject(i);
 if (e == null) continue;
 prow.add(new String[]{String.valueOf(i + 1), e.optString("name"), e.optString("tag"),
 String.valueOf(e.optInt("pts")), Game.rankMove(e.optInt("prev", i + 1), i + 1)});
 }
 } else if (live && act.worldCat == 1) {
 for (int i = 0; i < act.g.worldBowl.length(); i++) {
 org.json.JSONObject e = act.g.worldBowl.optJSONObject(i);
 if (e == null) continue;
 prow.add(new String[]{String.valueOf(i + 1), e.optString("name"), e.optString("tag"),
 String.valueOf(e.optInt("pts")), Game.rankMove(e.optInt("prev", i + 1), i + 1)});
 }
 } else {
 String[][] rows = Data.worldPlayers(act.worldFormat, act.worldCat);
 for (int i = 0; i < rows.length; i++) {
 prow.add(new String[]{String.valueOf(i + 1), rows[i][0], rows[i][1], rows[i][2], null});
 }
 }
 players.addView(rankList(act, prow));
 root.addView(players);

 LinearLayout nations = Ui.card(act);
 nations.addView(Ui.h2(act, Data.FORMATS[act.worldFormat] + " — Team Rankings"));
 final java.util.List<String[]> nrow = new java.util.ArrayList<>();
 if (live) {
 for (int i = 0; i < act.g.worldNations.length(); i++) {
 org.json.JSONObject e = act.g.worldNations.optJSONObject(i);
 if (e == null) continue;
 boolean pak = "Pakistan".equals(e.optString("name"));
 nrow.add(new String[]{String.valueOf(i + 1), e.optString("name"), pak ? " your nation" : "nation",
 String.valueOf(e.optInt("pts")), Game.rankMove(e.optInt("prev", i + 1), i + 1)});
 }
 } else {
 String[][] ns = Data.worldNations(act.worldFormat);
 for (int i = 0; i < ns.length; i++) {
 boolean pak = "Pakistan".equals(ns[i][0]);
 nrow.add(new String[]{String.valueOf(i + 1), ns[i][0], pak ? " your nation" : "nation", ns[i][1], null});
 }
 }
 nations.addView(rankList(act, nrow));
 root.addView(nations);

 // v2 watchlist: league stars — a WATCHLIST alert lands in Hub news
 // when a watched player scores a century or takes 5 wickets in any match
 root.addView(Ui.sectionHeader(act, "WATCHLIST"));
 LinearLayout stars = Ui.card(act);
 stars.addView(Ui.h2(act, "League Stars — Watchlist"));
 stars.addView(Ui.small(act, "Star a player to get an inbox alert for his century or 5-wicket haul. Your own squad is watchable from the Team tab."));
 for (String[] s : Data.OPP_STARS) {
 final String name = s[0];
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
 LinearLayout col = Ui.col(act);
 col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 col.addView(Ui.text(act, name, 15, Ui.INK, true));
 col.addView(Ui.small(act, s[1]));
 row.addView(col);
 Button w = Ui.chip(act, act.g.isWatched(name) ? "Watching" : "Watch", act.g.isWatched(name));
 w.setOnClickListener(v -> {
 act.g.toggleWatch(name);
 act.save();
 act.render();
 });
 row.addView(w);
 stars.addView(row);
 }
 root.addView(stars);
 root.addView(Ui.small(act, act.worldFormat == 0
 ? "T20I rankings are LIVE in this career (Season " + act.g.season + "): points drift every "
 + "season — the nations of the Golden Bat / Best Bowler winners and the champion captain gain most. "
 + "▲▼ shows movement vs last season."
 : "This format's rankings are a static snapshot for this season's world game."));
 return root;
 }

 /** v21 item 9: a rankings list bound through the RecycleList pool
 *  (rows arrive as {rank, name, tag, rating, move} tuples). */
 private static View rankList(final MainActivity act, java.util.List<String[]> rows) {
 return RecycleList.build(act, rows, 10, new RecycleList.Binder<String[]>() {
 @Override public View create(android.content.Context c) {
 return new android.widget.FrameLayout(c);
 }
 @Override public void bind(View row, String[] r, int index) {
 android.widget.FrameLayout host = (android.widget.FrameLayout) row;
 host.removeAllViews();
 host.addView(rankRow(act, Integer.parseInt(r[0]), r[1], r[2], r[3], r[4]));
 }
 }, "Show more");
 }

 private static View rankRow(MainActivity act, int rank, String name, String tag, String rating) {
 return rankRow(act, rank, name, tag, rating, null);
 }

 /** Batch F (idea 54): movement vs last season rides at the row's right edge. */
 private static View rankRow(MainActivity act, int rank, String name, String tag, String rating, String move) {
 LinearLayout row = Ui.row(act);
 row.setPadding(0, Ui.dp(act, 5), 0, Ui.dp(act, 5));
 TextView r = Ui.gold(act, "#" + rank, 15);
 r.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 40), ViewGroup.LayoutParams.WRAP_CONTENT));
 row.addView(r);
 // v20.1 (item 8): the drawn flag chip — player rows key off the
 // tag (already a nation code), nation rows off the full name;
 // Design.nationCode resolves both, "" simply shows no flag.
 String flagCode = Design.nationCode(tag);
 if (flagCode.isEmpty()) flagCode = Design.nationCode(name);
 if (!flagCode.isEmpty()) {
 // v21 item 16: the ACCURATE flag artwork (PIL-rendered with the
 // real colours/geometry) replaces the simplified drawn chip;
 // the drawn Icons.flag stays as the decode-failure fallback.
 android.graphics.Bitmap fb = Art.bitmap(act, Art.flagAsset(flagCode), 120);
 if (fb != null) {
 android.widget.ImageView fiv = new android.widget.ImageView(act);
 fiv.setImageBitmap(fb);
 LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(Ui.dp(act, 30), Ui.dp(act, 20));
 flp.setMargins(0, 0, Ui.dp(act, 8), 0);
 fiv.setLayoutParams(flp);
 row.addView(fiv);
 } else {
 row.addView(Icons.flag(act, flagCode));
 }
 }
 LinearLayout col = Ui.col(act);
 col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 col.addView(Ui.text(act, name, 15, Ui.INK, true));
 col.addView(Ui.small(act, tag));
 row.addView(col);
 if (move != null && !"—".equals(move)) {
 TextView mv = Ui.text(act, move, 13, move.startsWith("▲") ? Ui.GREEN : Ui.RED, true);
 mv.setPadding(0, 0, Ui.dp(act, 10), 0);
 row.addView(mv);
 }
 TextView val = Ui.display(act, rating, 15, Ui.INK); // v20.1 (item 11): rankings points in the display face
 val.setGravity(Gravity.END);
 row.addView(val);
 return row;
 }
}
