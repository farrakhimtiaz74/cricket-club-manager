package io.github.farrakhimtiaz74.cricketmanager;

/** Design Batch (v13): the PURE half of the design system — club
 *  colours, rating tiers, role tints, ball-chip colour mapping, gauge
 *  clamping and momentum maths. Deliberately free of every android.*
 *  import (raw ARGB int literals instead of Color.rgb) so the whole
 *  class runs on the desktop test harness exactly like Settings /
 *  SyncCode / CsvExport do. The Android half (drawables, views) lives
 *  in Ui / Icons / the *View classes and only READS these values. */
public class Design {

    // ---------------- item 2/9: club colours (primary, secondary) ----
    // Two colours per club, used by the header tint, crests, momentum
    // bar and confetti. Lahore defaults to the app's gold + Qalandar
    // green; a custom club uses its own picked colour (Game.teamColor).

    public static final int GOLD = 0xFFF59E0B;

    public static int[] clubColors(String team) {
        if (team == null) return new int[]{GOLD, 0xFF16A34A};
        switch (team) {
            case "Lahore Qalandars":   return new int[]{0xFFF59E0B, 0xFF16A34A}; // gold / green
            case "Karachi Kings":      return new int[]{0xFF2563EB, 0xFFF59E0B}; // royal blue / gold
            case "Islamabad United":   return new int[]{0xFFDC2626, 0xFFF97316}; // red / orange
            case "Multan Sultans":     return new int[]{0xFF0D9488, 0xFF84CC16}; // teal / lime
            case "Peshawar Zalmi":     return new int[]{0xFFFACC15, 0xFF334155}; // yellow / charcoal
            case "Quetta Gladiators":  return new int[]{0xFF7C3AED, 0xFFF59E0B}; // purple / gold
            case "Sialkot Stallions":  return new int[]{0xFF9F1239, 0xFFC0C6CE}; // maroon / silver
            case "Hyderabad Hawks":    return new int[]{0xFF16A34A, 0xFFFACC15}; // green / yellow
            default:                   return new int[]{GOLD, 0xFF16A34A};       // custom / unknown
        }
    }

    public static int clubPrimary(String team) { return clubColors(team)[0]; }
    public static int clubSecondary(String team) { return clubColors(team)[1]; }

    /** The accent for a career: a custom club's picked colour wins,
     *  otherwise the club's primary. Matches Game.teamColor()'s custom
     *  rule so header chip and tint never disagree. */
    public static int accentFor(Game g) {
        if (g == null) return GOLD;
        if (g.customTeam) return g.teamColor();
        return clubPrimary(g.userTeam);
    }

    /** Accent for any team in a fixture (crests / momentum / calendar):
     *  the user's custom club resolves to its picked colour. */
    public static int colorForTeam(Game g, String team) {
        if (g != null && g.customTeam && team != null && team.equals(g.userTeam)) return g.teamColor();
        return clubPrimary(team);
    }

    public static int secondaryForTeam(Game g, String team) {
        if (g != null && g.customTeam && team != null && team.equals(g.userTeam)) {
            // a custom club has ONE picked colour; pair it with slate
            return 0xFF1E293B;
        }
        return clubSecondary(team);
    }

    // ---------------- item 9: rating tiers ----------------
    // Bronze <70 · Silver 70–77 · Gold 78–84 · Elite 85+

    public static final String[] TIER_NAMES = {"Bronze", "Silver", "Gold", "Elite"};
    public static final int[] TIER_COLORS = {0xFFB07A4F, 0xFFC0C6CE, 0xFFF59E0B, 0xFF38E1C6};

    public static int tierFor(int rating) {
        if (rating >= 85) return 3;
        if (rating >= 78) return 2;
        if (rating >= 70) return 1;
        return 0;
    }

    public static String tierName(int rating) { return TIER_NAMES[tierFor(rating)]; }
    public static int tierColor(int rating) { return TIER_COLORS[tierFor(rating)]; }

    // ---------------- item 9: role tints for the initials discs ------
    // Bat gold · Bowl sky · AR violet · WK orange

    public static int roleColor(String role) {
        if (role == null) return 0xFF64748B;
        switch (role) {
            case "Bat": return 0xFFB45309;  // deep gold (white initials stay readable)
            case "Bowl": return 0xFF0369A1; // sky
            case "AR": return 0xFF6D28D9;   // violet
            case "WK": return 0xFFC2410C;   // orange
            default: return 0xFF64748B;     // slate
        }
    }

    /** "Shaheen Shah Afridi" → "SA"; one-word names take two letters. */
    public static String initials(String name) {
        if (name == null || name.trim().isEmpty()) return "?";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) {
            String w = parts[0];
            return w.substring(0, Math.min(2, w.length())).toUpperCase();
        }
        return ("" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
    }

    // ---------------- item 7: ball-chip colour mapping --------------
    // 4 → gold fill · 6 → green fill · W → red fill · 0 → dark slate ·
    // scoring shots (1/2/3/5) → light slate. Text flips to dark ink on
    // the gold fill only; everything else reads white/pale.

    public static int ballChipColor(String ball) {
        if (ball == null) return 0xFF475569;
        switch (ball) {
            case "W": return 0xFFEF4444;
            case "6": return 0xFF22C55E;
            case "4": return 0xFFF59E0B;
            case "0": return 0xFF334155;
            default: return 0xFF64748B; // 1, 2, 3, 5 and anything else
        }
    }

    public static int ballChipTextColor(String ball) {
        return "4".equals(ball) ? 0xFF0F172A : 0xFFF1F5F9;
    }

    /** Balls of the CURRENT over visible in lastBalls (which keeps the
     *  last 12): if the over just completed (balls % 6 == 0) the finished
     *  over still counts as "current" until the next over's first ball. */
    public static int currentOverCount(int ballsBowled, int stored) {
        if (stored <= 0) return 0;
        int rem = ballsBowled % 6;
        if (rem == 0 && ballsBowled > 0) rem = 6;
        return Math.min(rem, stored);
    }

    // ---------------- item 8: gauges & momentum ----------------------

    public static int clamp100(int v) { return v < 0 ? 0 : v > 100 ? 100 : v; }

    /** v20.1 (item 12b): the gauge fill width in px for a value —
     *  pure maths, clamped on BOTH ends (value via clamp100, result
     *  within [0, trackW]) so no gauge on any screen can ever draw
     *  past its track again (the Hub blob bars). GaugeView.onDraw is
     *  the only caller; the desktop tests hit this directly. */
    public static int gaugeFillWidth(int trackW, int value) {
        if (trackW <= 0) return 0;
        return (int) ((long) trackW * clamp100(value) / 100);
    }

    /** v20.1 (item 8): the flag code for a rankings row — accepts a
     *  nation code ("PAK") or a full nation name ("Pakistan") and
     *  returns the canonical code the drawn FlagView keys off;
     *  "" for anything unknown (the row then simply shows no flag). */
    public static String nationCode(String tagOrName) {
        if (tagOrName == null) return "";
        switch (tagOrName.trim()) {
            case "AUS": case "Australia": return "AUS";
            case "IND": case "India": return "IND";
            case "ENG": case "England": return "ENG";
            case "PAK": case "Pakistan": return "PAK";
            case "WI": case "West Indies": return "WI";
            case "SL": case "Sri Lanka": return "SL";
            case "AFG": case "Afghanistan": return "AFG";
            case "ZIM": case "Zimbabwe": return "ZIM";
            case "IRE": case "Ireland": return "IRE";
            case "NZ": case "New Zealand": return "NZ";
            case "SA": case "South Africa": return "SA";
            case "BAN": case "Bangladesh": return "BAN";
            default: return "";
        }
    }

    /** Gauge fill colour by value: red under 25, amber under 50, gold
     *  under 75, green at the top — the board/fans read at a glance. */
    public static int gaugeColor(int v) {
        int x = clamp100(v);
        if (x < 25) return 0xFFEF4444;
        if (x < 50) return 0xFFF97316;
        if (x < 75) return 0xFFF59E0B;
        return 0xFF22C55E;
    }

    /** The momentum bar split IS the win predictor, clamped — the drawn
     *  bar can never disagree with the printed percentage. */
    public static int momentumSplit(int winPct) { return clamp100(winPct); }
}
