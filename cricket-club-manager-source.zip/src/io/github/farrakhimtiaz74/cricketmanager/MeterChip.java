package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Professional Pack P4 (suggestion 34): a labelled meter — the word
 *  and the number ride BESIDE the drawn gauge, never under it, so
 *  colour is never the only signal (the v12.1 lesson: a red stamina
 *  bar at 100% fitness read as danger). One row: micro label, the
 *  gauge, then "72 · Fresh" in display type. */
public class MeterChip extends LinearLayout {

    public MeterChip(Context c, String label, int value, String word) {
        super(c);
        setOrientation(HORIZONTAL);
        setGravity(android.view.Gravity.CENTER_VERTICAL);
        int v = Design.clamp100(value);
        TextView lab = Ui.micro(c, label.toUpperCase());
        LayoutParams llp = new LayoutParams(Ui.dp(c, 62), ViewGroup.LayoutParams.WRAP_CONTENT);
        lab.setLayoutParams(llp);
        addView(lab);
        LinearLayout gw = new LinearLayout(c);
        gw.setLayoutParams(new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        gw.addView(new GaugeView(c, v));
        addView(gw);
        TextView val = Ui.display(c, v + (word == null || word.isEmpty() ? "" : " · " + word), 11.5f,
                Design.gaugeColor(v));
        LayoutParams vlp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        vlp.setMargins(Ui.dp(c, 8), 0, 0, 0);
        val.setLayoutParams(vlp);
        addView(val);
        setPadding(0, Ui.dp(c, 2), 0, Ui.dp(c, 2));
    }
}
