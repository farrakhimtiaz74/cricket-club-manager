package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Whole game state + season engine. Serialised as one JSON string in SharedPreferences.
 *  v2 additions: overseas flags, rested players, team-sheet validator, watchlist,
 *  and a Club Cash ledger — EVERY CF movement goes through ledgerCf() so the
 *  ledger entries always sum to the balance change.
 *
 *  ============================ BATCHLOG ============================
 *  Batch A (v3, ideas 1–10 — Match Engine) added, ON TOP of v2:
 *   1 Super Over for tied matches (MatchEngine: superMode / superbreak phase)
 *   2 Rain interruptions in the chase with simplified-DLS revised targets
 *     (per-match pre-rolled rainAtBall, persisted in the match JSON)
 *   3 Pitch per fixture (Flat/Green/Dry/Turning) — deterministic via
 *     ensureFixtureMeta() so v2 saves generate the same pitches; engine
 *     modifiers live in MatchEngine.bowlBall
 *   4 Dew factor on evening fixtures (fixture "evening" flag) in the chase
 *   5 Live win predictor — MatchEngine.winPredictor() (0–100 for the user)
 *   6 Manhattan chart — per-over runs tracked as "overRuns" per innings,
 *     drawn by ManhattanView on break / full-time screens
 *   7 Partnerships + fall of wickets — "parts" / "fow" arrays per innings
 *   8 Player of the Match at full time (+25 CF ledger bonus for a Lahore
 *     winner) + potmHistory (new Game field, capped 20)
 *   9 Highlights stepping (MatchScreen: skip quiet balls, stop on W/4/6)
 *  10 Match speed 1x/2x/Instant — Game.speed (persisted), auto-play pacing
 *     lives in MainActivity.startAuto(); Instant = old synchronous sims.
 *  New Game fields: speed, potmHistory. New fixture fields: pitch,
 *  evening, rain (all defaulted by ensureFixtureMeta on load — v2 careers
 *  are never wiped). New match fields: pitch, evening, rainRisk, rainAtBall,
 *  rainDone, rainNote, ballsLimit, wktsLimit, parts, fow, overRuns (+inn1*
 *  copies), superMode, superStage, super1Runs, superTarget, superSummary,
 *  superWinnerTeam, potm, potmDesc, potmUser.
 *
 *  Batch B (v4, ideas 11–20 — Tactics & Match Day) added, ON TOP of Batch A:
 *  11 Powerplay plans — match fields ppBat / ppBowl (0 Attacking, 1 Balanced,
 *     2 Safe), engine modifiers in overs 1–6 of the side they govern; set at
 *     the toss / innings break / ball 0, read-only while an innings runs.
 *  12 Death-overs plan + 13 rotation planner, UNIFIED as one match field
 *     "rotation": a 20-int array of bowlCard indices, auto-filled at innings
 *     setup by MatchEngine.buildRotation (rating order, ≤4 overs each, no
 *     back-to-back), editable live for un-bowled overs via setRotationOver
 *     (rotationError states why a change is illegal); overs 17–20 are the ⭐
 *     death tail of the same plan. pickBowler consults the plan first and
 *     falls back to the old scan when the planned man is spent/illegal.
 *     "overBowlers" records who actually bowled each over (+inn1 copies).
 *  14 Next-batter choice — card flag "in" (has batted; openers start true,
 *     migration rebuilds it from nextIn). A wicket with Lahore batting parks
 *     the innings on match field awaitBat (striker stays on the dismissed
 *     man; no strike swap at over-end while parked) until
 *     MatchEngine.chooseNextBatter() picks any unused card. Sim loops,
 *     Highlights and the staged auto-player all stop on awaitBat; Instant
 *     sims set autoNextBat=true around the sim so the order is automatic.
 *  15 Assistant coach — MatchEngine.coachSuggestion() derives a tip from
 *     state (tear / new batter / turning pitch / leaky bowler / rotation)
 *     and returns a bowler index that rotationError already approves, so
 *     the UI Apply writes it into the plan for the next over.
 *  16 Match-ups — match field "matchups": [{bat, bowl, balls, runs, outs}]
 *     updated every ball (run outs not credited as bowler outs), +inn1 copy.
 *  17 Field presets — FIELD is now 6 entries: 0–2 keep v2 weights, adding
 *     3 Slips Attack, 4 Ring Field, 5 Boundary Riders (weights in bowlBall);
 *     FieldMapView draws the 11-dot map for the selected preset.
 *  18 Pep talk — once per segment (pepSegment = inn + super stage), match
 *     fields pepKey / pepBoostKey / pepBoostUntil (balls + 12) / pepSide
 *     (1 bat, 2 bowl); boost modifies weights while live, and the men in the
 *     middle (or the current bowler) get +3 Set in Game.players.
 *  19 Danger man — MatchEngine.dangerManName/Line pick the opponent XI's
 *     highest-rated player (best of bat/bowl) with a threat line; shown on
 *     the Hub pre-match cards and the toss screen.
 *  20 Per-batter bowling plan — match fields batPlan (0 none, 1 Yorkers,
 *     2 Short Stuff, 3 Outside Off, 4 Straight & Full) + batPlanFor (target
 *     name). Live only while the target is on strike; clears when he is
 *     dismissed; commentary name-checks it ~25% of balls while active.
 *  Migration: MatchEngine.migrateMatch defaults all Batch B match fields
 *  (v3 saves resume untouched careers); rotation rebuilds lazily through
 *  ensureRotation with already-bowled overs seeded from the bowlCard.
 *
 *  Batch C (v5, ideas 21–30 — Squad & Players) added, ON TOP of Batch B:
 *  Player objects gain Batch C meta via ensurePlayerMeta() (called by
 *  fresh(), fromJson migration and prospect creation — fills ONLY missing
 *  fields, so a v4 career keeps everything and gains defaults):
 *    age / pot — Data.ageFor / Data.potFor (deterministic by name)
 *    morale 0–100 (default 70) — moraleMod(name) = clamp((morale−70)/10,
 *      −3..+3) feeds MatchEngine's effective bat/bowl ratings
 *    injured (days left, 0 = fit) / injType — rolled in onUserMatchFinished
 *      (so live AND simmed user matches can injure), heal 1/day in
 *      advanceDay, days cut by Medical Centre level; injured players are
 *      removed from the XI and xiProblems() flags them like rested
 *    tags — Data.tagsFor list, read live by MatchEngine (Finisher / Anchor
 *      / Powerplay Specialist / Death Bowler / Spin Option / Pace Battery
 *      situational weights; Safe Hands lifts run-out chance)
 *    ss / cs — season & career stats objects (see emptyStats): m, inn,
 *      runs, balls, hs, f50, f100, outs, bwBalls, wkts, conc, bestW,
 *      bestR, f3, f5. StatsBook.recordMatch fills them from the finished
 *      innings cards at full time (Super Over cards excluded — restored
 *      inn2 cards are used); simmed user fixtures credit the generated
 *      top-scorer / best-bowler via StatsBook.recordSimStandouts.
 *    formB (last-5 batting runs, ints) / formW (last-5 "wkts/runs"
 *      strings) — spark bars + StatsBook.formTrend on the player card
 *    miles — achieved milestone keys (runs500, runs1000, wkts50, wkts100,
 *      matches50, tons5, fivefors2); StatsBook posts Hub news on crossing
 *    bench — consecutive matches not picked (drives morale drift)
 *  26 Captain — Game.captain (name, persisted, default Shaheen Afridi);
 *     setCaptain: old captain −5 morale, new +8; captain in the bowling
 *     side's XI gives the attack wW ×1.03; Team tab warns when the captain
 *     is not in the XI (validator itself does not require him).
 *  27 Best XI — pickBestXI(pitch): scores rating + stamina + morale + form
 *     (+pitch bonus: spinners on Turning, pace on Green), then greedily
 *     fills a validator-legal XI (WK first, 5+ bowling options, ≤4
 *     overseas, no rested/injured).
 *  Rollover (Batch C): ages +1, ratings drift toward POT under 27 and
 *  decline 33+, season stats reset (career kept), injuries cleared.
 *
 *  Batch D (v6, ideas 31–40 — Transfers & Contracts) added, ON TOP of Batch C:
 *  Player objects gain: contract (seasons left incl. current, 1–3;
 *  Data.contractFor deterministic default), wage (weekly CF, wageFor =
 *  max(2, rating²/900) ≈ 102 CF/week for the whole starting squad),
 *  loanOut / loanIn flags — all filled by ensurePlayerMeta, so a v5 save
 *  migrates cleanly and is NEVER trapped: new Game fields default to an
 *  in-season state (offseason 0, no auction) and the off-season phase only
 *  starts at the NEXT rollover.
 *  OFF-SEASON PHASE (Game.offseason): rollover now ends in phase 1
 *  (retain / release free, renew out-of-contract men) instead of going
 *  straight to fixtures; advanceDay() refuses to move while offseason > 0
 *  and Hub swaps the match card for a Transfers prompt, so the phase can
 *  never be skipped or dead-end play. confirmOffseason() moves every
 *  un-renewed out-of-contract player into `departed`, then beginAuction()
 *  opens phase 2. End phase 2 (lots done or Skip) → offseason 0.
 *   31 Auction — pool ~10 (departed + 3 star lots + generated names),
 *     base = max(40, (rating−55)·6); turn-based rounds: user bids
 *     (capped by CF and the 22-man squad cap), one AI counter-raise per
 *     round from 3 budgeted rivals (valuation rolled per lot at open,
 *     persisted in the auction JSON — closing the app mid-auction resumes
 *     the exact lot/bid/leader). All money via ledgerCf.
 *   32 Release — free in phase 1 (player → departed → auction pool);
 *     25 CF settlement in the mid-season window; blocked under 11 men.
 *   33 Mid-season window — Days 13–15 (half the 24 fixtures gone), max 2
 *     signings off windowList (4 listings from rival XIs at set prices).
 *   34 Contracts — tick at rollover; hitting 1 posts the final-year
 *     warning, hitting 0 parks the man in phase 1: renew (fee
 *     max(15, rating−50) × years, 1–3 seasons) or he leaves for free.
 *   35 Wages — charged on Days 7/14/21 after sponsor income lands;
 *     short-pay charges what CF allows, warns, and a second straight
 *     short week costs the whole squad −3 morale (streak then resets).
 *     Loaned-OUT men are paid by their host club; loaned-IN men are free.
 *   36 Loans — loan OUT any man aged ≤23 for the rest of the season
 *     (LOAN badge, unselectable, returns at rollover with a main-skill
 *     boost instead of normal development + morale +8); loan IN one
 *     youngster (30 CF fee, no wage) during a window / the off-season.
 *   37 Free agents — faPool of 6 generated names, signable any time for
 *     max(30, (rating−55)·3); one name rotates out every 4th day.
 *   38 Rumours — rolled on Advance Day (16%, 45% in a window); the
 *     TRUE-leaning kind names a real final-year / low-morale man and the
 *     same eligibility drives actual poach offers (idea 40).
 *   39 Scouting — 40 CF per report (ledgered): reveals exact POT (others
 *     show a deterministic ± range via potRange), grade A–D + verdict,
 *     persisted per name in `scouted`. Own squad always shows exact POT.
 *   40 Poaching — a man with morale < 35 in his final contract year can
 *     draw a rival offer on window days (fee max(60, (rating−45)·4)):
 *     Accept = leaves + CF in, Reject = morale −5, ignore 3 days = the
 *     offer lapses with no penalty. Never blocks anything.
 *  New Game fields: faPool, scouted, auction, departed, offseason,
 *  windowSeason, windowSigns, windowList, loanList, poachOffer,
 *  wageShortStreak. SQUAD_CAP = 22 enforced at every signing point.
 *
 *  Batch E (v7, ideas 41–50 — League & Season) added, ON TOP of Batch D:
 *  THE BIG CHANGE: "champion = points leader" is GONE. The season now runs
 *  group stage (Days 1–24) → PLAYOFFS → Final → ceremony → the existing
 *  Batch D off-season. Game.playoffPhase drives it inside advanceDay():
 *    0 group stage · 1 playoffs live · 2 ceremony pending · 3 acknowledged
 *  (the next advanceDay then calls rolloverSeason, which keeps its legacy
 *  points-leader crowning ONLY as a fallback when seasonChampion is empty).
 *  41 Playoffs — playoffFixtures (stage/home/away/played/summary/winner +
 *     standouts): Qualifier A1 v B1, Eliminator 1 A2 v B2, Eliminator 2
 *     (Q loser v E1 winner), Final. User ties are REAL matches: MatchEngine
 *     matches carry playoff/stageName and finishMatch writes back into
 *     playoffFixtures WITHOUT touching the group tables; non-user ties are
 *     quick-simmed by simPlayoffFixture; progressPlayoffs() drives the
 *     bracket and can never trap the manager (Advance Day board-sims a
 *     pending user tie, exactly like a skipped league fixture).
 *  42 Ceremony — finalizePlayoffs() sets seasonChampion/seasonRunnerUp +
 *     a `ceremony` object; a Lahore title pays 1500 CF and increments
 *     career.titles THERE (rollover must not pay twice), a runners-up
 *     finish pays 500. Hub shows the ceremony card; Continue →
 *     acknowledgeCeremony() (phase 3).
 *  43 Tournament book — `tournBook`: name → {team,runs,balls,outs,f50,
 *     f100,bwBalls,wkts,conc,f3,f5} for ALL teams. Live user matches feed
 *     it from the full innings cards (recordTournMatch, same events as
 *     StatsBook, so Lahore totals match the squad's `ss` exactly);
 *     quick sims feed it their generated standout only (top bat / best
 *     bowler, same approximations StatsBook uses). League tab shows Most
 *     Runs / Wickets / SR / Economy / MVP (mvpPoints = runs + 25·wkts
 *     + 5·f50 + 10·f100 + 4·f3 + 10·f5).
 *  44 As It Stands — Game.provisionalRows(m) clones Lahore's group table
 *     and applies the live match as if it ended now; MatchScreen toggles
 *     it during group matches (MainActivity.showAsItStands).
 *  45 Road to Playoffs — Game.qualificationInfo(): points-only bounds
 *     (qualified when ≤1 rival can still reach Lahore's current points,
 *     eliminated when ≥2 rivals are already beyond Lahore's maximum,
 *     else the minimum wins that guarantee top two) — shown in League
 *     once Lahore have played 3+ group games.
 *  46 Head-to-head — `h2h`: team → {p,w,l,last(5, newest first)} vs
 *     Lahore, updated in applyResultDecided + playoff results, kept
 *     across seasons, shown in the League tab.
 *  47 Awards — computeAwards() at the Final: Golden Bat, Best Bowler
 *     (economy tiebreak), MVP, Emerging Player (MVP points, age ≤ 23,
 *     only Data.hasAge names so defaults can't sneak in). A Lahore winner
 *     earns +15 CF per award ("Season award bonus"). Stored in lastAwards.
 *  48 Records — `records` book (highTotal, bigWinRuns, bigWinWkts,
 *     highScore, bestBowl, fastest50, mostRunsSeason, mostWktsSeason),
 *     updated from live cards in finishMatch (MatchEngine now stamps
 *     "balls50" on a bat card when a man crosses fifty — the exact
 *     fastest-fifty measure) and from sim standouts where figures exist;
 *     season records judged at captureSeasonHistory.
 *  49 Hall of Fame — `hof`: title entries (season, captain, Final POTM)
 *     when Lahore lift the trophy, plus Lahore Legends: removePlayer()
 *     parks any man with 50+ career matches / 1,000+ runs / 50+ wickets
 *     in `pendingLegends`; finishAuction/skipAuction induct him if he is
 *     still gone (a rebought man is simply dropped from the list).
 *  50 Season history — captureSeasonHistory() runs at the TOP of
 *     rolloverSeason (before stats/tables reset): {season, champion,
 *     runnerUp, lahoreGroup/Pos/P/W/L, topScorer, topWkts, awards} into
 *     `seasonHistory` (newest first, cap 30), then the Batch E per-season
 *     state (playoffPhase, fixtures, champion, tournBook, lastAwards)
 *     resets at the foot of rollover. History starts with the first
 *     rollover played on v7 — pre-v7 seasons are not reconstructed.
 *  Migration: every Batch E field defaults empty/0 in fromJson, so a v6
 *  save — mid-season OR already sitting in its off-season — loads intact
 *  and simply meets the playoffs at its next group-stage finish.
 *  Later batches: read this block, keep these fields migrating forward.
 *
 *  Batch F (v8, ideas 51–60 — Teams & World) added, ON TOP of Batch E:
 *  51 Choose your team — Game.userTeam (default "Lahore Qalandars") is now
 *     THE managed club everywhere: Data.USER_TEAM survives only as the
 *     default constant. freshForTeam(team) builds a career from
 *     Data.squadFor(team) (full named 18s for all 8 clubs, each with a
 *     validator-legal default XI + named captain); starting CF scales
 *     with club strength (1000 + (strength-82)*50). The picker lives in
 *     MainActivity.pickerMode (first launch / Profile reset). Groups,
 *     tables, prizes, H2H, awards, HoF and news all key off userTeam;
 *     groupA()/groupB() substitute a custom club for Lahore's slot.
 *  52 Custom team — freshCustom(name, code, colour): takes LAHORE'S slot
 *     and rebrands Lahore's squad (players keep their names — the robust
 *     route, documented in the batch report). customCode drives
 *     shortFor(); customColor tints the header CF chip + Hub club line.
 *  53 Opponent depth — aiXiObjects(team): a legal XI (WK, 5+ bowling
 *     options, <=4 overseas) picked from the full 18, minus injured men
 *     (aiInj: 10% roll after each AI match, 2–5 days, ticked daily), with
 *     0–2 form-hash rotation swaps. Cached per team on a
 *     season/day/played stamp; namesFor + the live engine + danger-man
 *     all read it, playoffs and cup included.
 *  54 Dynamic World rankings — worldNations / worldBat / worldBowl
 *     (T20I only; other formats stay static) seeded from Data's tables,
 *     drifted at rollover: small random walk + boosts for the nations of
 *     the Golden Bat / Best Bowler winners (+6) and the champion
 *     captain (+4). prev = last season's rank, World tab shows ▲▼.
 *  55 International call-ups — pickCallups() at rollover takes 1–3 of
 *     the top-5 rated men (rating >= 72) away for the off-season
 *     (badge in the Team tab); resolveCallups() runs when the auction
 *     closes the off-season: 55% In Form (+10 morale, +6 Set), 33%
 *     Fatigued (stamina 50–60), 12% Fatigued + a 2–4 day knock.
 *  56 One-Day Cup — from Season 2: cupPhase/cupFixtures mirror the
 *     playoff machinery but run in the gap BETWEEN the group stage and
 *     the playoffs (least invasive calendar change). 8-team cross-group
 *     knockout (QF/SF/Final), REAL 50-over matches: the engine takes
 *     ballsLimit from the fixture (300), bowler cap = limit/5 (10
 *     overs), powerplay = first 10 overs, stamina drain 20. Winner:
 *     +1000 CF via ledger, career.cups + 1, HoF "cup" entry; runner-up
 *     +300. Cup matches do NOT feed the T20 tournament book / records
 *     (documented), but DO credit squad season stats + POTM + H2H.
 *  57 Home advantage + crowd — expectedAttendance(f): Stadium level,
 *     recent form, opponent size, derby and cup bumps, clamped 15–97%.
 *     Gate receipts REPLACE the old flat 40 x level bonus: gate =
 *     att% x (150 + 90 x Stadium level), ledgered with the ground name.
 *     Home edge in the engine: +1 effective bat/bowl for user players
 *     in home matches (MatchEngine.bowlBall, documented there).
 *  58 Derby — Data.rivalOf(userTeam) (custom inherits Karachi via the
 *     Lahore slot): DERBY badge on Hub/League cards, one hype news item
 *     per fixture (fixture "hype" flag), +18 attendance points, and a
 *     +150 CF "Derby win bonus" (50% of the win prize) on a derby win.
 *  59 Grounds — ensureFixtureMeta now also stamps ground/groundChar
 *     from the HOME team (Data.groundName/groundChar): High-scoring /
 *     Balanced / Bowler-friendly, a small engine modifier on top of the
 *     pitch type; shown on Hub/League/match cards; homeGroundLine()
 *     reflects the Stadium level.
 *  60 Rename players — renamePlayer(old, new) in the Team detail view:
 *     migrates the player object, captain, watchlist, tournBook key,
 *     scouted key, records player fields, HoF name/captain/potm,
 *     pendingLegends, potmHistory prefixes, season-history scorer
 *     strings, lastAwards, callups, poachOffer, and every name inside a
 *     live match (cards, FoW, partnerships, match-ups, shield, plan).
 *     Season/career stats live ON the player object, so they follow
 *     automatically — the classic key-migration trap is handled above.
 *  Migration: a v7 save gains userTeam=Lahore, no custom club, empty AI
 *  injuries, world state seeded from the static tables (prev = current
 *  rank, so no phantom movement), no call-ups, cupPhase 0 (the cup
 *  simply starts at its next group-stage finish when season >= 2).
 *
 *  ================= BATCH G (v9) — HQ, STAFF & MONEY (ideas 61–70) =====
 *  61 Staff — staff {role -> {name,rating,wage}} + staffCandidates
 *     (3 per role, regenerated every season). Roles: Head Coach,
 *     Batting Coach, Bowling Coach, Physio, Scout. Signing fee = 2x the
 *     weekly wage (ledgered); firing is free; staff wages fold into the
 *     ONE weekly wages line (the ledger entry also stores the split).
 *     Effects: Head Coach — Team Talk morale +6 (not +4) and, at 85+,
 *     the morale effect cap rises +3 -> +4; Batting/Bowling Coach — a
 *     deterministic per-player +1 effective rating in matches, the
 *     share of the squad covered scaling with the coach's rating;
 *     Physio — injury chance x(1 - rating/250), injury length scaled
 *     down, 85+ heals 2 days per day, Recovery sessions gain more;
 *     Scout — scouting fee discounted, unscouted POT ranges narrow,
 *     and free agents who join the pool while he is employed get a
 *     small quality lift. At rollover a staffer rated 88+ has a 12%
 *     chance of being poached (news; the role falls vacant).
 *  62 Facilities to Level 10 — Data.FACILITY_MAX 5 -> 10; the upgrade
 *     cost stays base x current level all the way up. Every effect
 *     formula already reads the level (gate base, recovery, injury
 *     trim, commercial income) and extends; the Academy prospect now
 *     also gains +(level-2) quality (plus the L7 manager perk).
 *     HQ cards show 10 pips, a tier name (Basic/Good/Excellent/World
 *     Class) and numeric current/next benefits (facilityBenefit()).
 *  63 Ticket pricing — ticketTier 0..4 (Cheap/Standard/Premium/
 *     Expensive/Premium Plus), gate multipliers x0.8/1.0/1.2/1.4/1.6
 *     and attendance shifts +4/0/-5/-10/-15 in expectedAttendance();
 *     gateFor() applies the multiplier (and the L4 +5% perk). Shown
 *     on home match cards; changing tier moves Fan Mood (idea 70).
 *  64 Sponsorship deals — at rollover, sponsorOffers holds 3 deals
 *     (fictional brand, lump at signing + weekly on Days 7/14/21, one
 *     objective: playoffs +300 / title +600 / three 200+ totals +150).
 *     chooseSponsor(0..2) picks one, chooseSponsor(3) is the safe
 *     "No sponsor" board grant (50 lump + 5/week, no objective). If
 *     the auction closes with no pick, the board grant is auto-taken
 *     so the season is never sponsor-less. RECONCILIATION: the deals
 *     REPLACE the old flat sponsor — while sponsorLegacy is true (v8
 *     saves mid-season, and brand-new careers until their first
 *     rollover) the Commercial Centre keeps paying the OLD 25 x level
 *     every 3 days as "sponsor income"; once deals are live the
 *     Commercial Centre drops to 10 x level every 3 days as plain
 *     commercial income and the sponsor deal is the main sponsor
 *     money (a mid-table deal ~= 240 lump + 54 weekly + objective
 *     chance, versus ~200/season of old L1 flat sponsor).
 *  65 Merchandise — after every HOME user match, merchandiseFor()
 *     pays 10..60 CF (attendance, top-3 star power, win/derby bonus,
 *     Ecstatic fans +25%) through the ledger as "Merchandise".
 *  66 Training camp — rollover sets campPending; the manager picks
 *     Batting/Bowling/Fitness/Fielding for 100 CF (or Skip, free)
 *     from the Hub/HQ before Day 1; advancing a day with the choice
 *     still open auto-skips it (never a trap). Batting/Bowling give
 *     +1 effective discipline ratings for the first 8 user matches;
 *     Fitness sets the squad to full stamina at once and halves
 *     injury chance while day <= 12; Fielding lifts run-out chance
 *     while day <= 12. campMatchesUsed counts user matches.
 *  67 Board confidence — boardConfidence 0..100 (start 70): win +2,
 *     loss -3, derby win +4 extra, title +20, cup win +12, playoff
 *     qualification +8, missing playoffs -8, bottom of group -10,
 *     sponsor objective +5, short-paid wages -6, season objective
 *     met +10 / missed -10 (met also pays +200 CF). The board sets
 *     boardObjective at rollover from squad strength (title /
 *     playoffs / avoid bottom); it is judged at the NEXT rollover
 *     BEFORE the tables reset (evaluateBoardSeasonEnd()).
 *  68 Job security — dropping under 25 posts a warning news and an
 *     HQ/Hub banner; ending a season under 10 sets sacked=true and
 *     rollover stops there: MainActivity shows the Sacked summary
 *     (seasons/titles/record) whose only button starts a new career
 *     at the team picker. Calibration: from 70, six losses (-18),
 *     missing the playoffs (-8), bottom place (-10) and a missed
 *     objective (-10) lands on 24 — warned, NOT sacked; a second
 *     identical season goes under 10 and the sack fires.
 *  69 Manager XP — managerXp: match +2, win +10, playoff win +25,
 *     trophy +100, player award +5, sponsor objective +15. Levels
 *     use XP_THRESHOLDS (150, then +175/+200/...). Automatic perks:
 *     L2 Training upgrades -10%, L3 one free scout per season,
 *     L4 gate +5%, L5 Team Talk +2 extra morale, L6 auction AI max
 *     bids x0.92, L7 academy quality +1, L8 wages -5%, L9 +10 board
 *     confidence each new season, L10 Legend badge + 500 CF (paid
 *     once, when the level is actually crossed). Profile shows the
 *     XP bar, level and the perk list.
 *  70 Fan mood — fanMood 0..100 (start 65): win +3, loss -2, derby
 *     win +6 total, star signing (85+) +4, title +15, a 3rd straight
 *     loss (and each one after) -4 extra, ticket changes per idea 63.
 *     Mood 80+ adds +8 attendance, under 35 takes -10; mood 85+
 *     lifts merchandise 25%. Labels Furious/Unhappy/Content/Happy/
 *     Ecstatic (fanMoodLabel()).
 *  FINANCES — financeTotals() categorises THIS season's ledger by
 *     reason (prizes/gate/merch/sponsor/wages/transfers/upgrades/
 *     other) and also reports the player/staff wage split stored on
 *     the wage entries; the categories sum to the season ledger sum.
 *  Migration: a v8 save gains vacant staff + fresh candidates,
 *     Standard tickets, sponsorLegacy=true (old flat sponsor until
 *     its next rollover), board 70, fans 65, manager XP = 10 x
 *     career wins already on the books, no camp pending, not sacked.
 *
 *  ================= BATCH H (v10) — NEWS & IMMERSION (71–80) =====
 *  71 Press conferences: every user match builds a match CONTEXT in
 *     onUserMatchFinished (scores, star, feats, margin class) — live
 *     innings cards are scanned in code (POTM is computed AFTER this
 *     hook, so Game reads the cards itself; sims read their standout
 *     fields, and sim fixtures now also store r1/w1/r2/w2). After a
 *     DERBY, a playoff/cup tie, a final, or ANY match with a century
 *     or a 5-for, a press conference is pending (pressConf) and its
 *     card sits on the Hub (also answerable from the full-time
 *     screen). answerPress(): Confident win fans +2/board +1,
 *     Confident loss fans -1/board -1 (backfires), Balanced morale
 *     +1 squad-wide, Fiery fans +2, board -1 AND pressBoost = 1 —
 *     MatchEngine.startMatch stamps pressAggro on the NEXT match
 *     only (consumed once) and the user's first-powerplay balls
 *     swing harder (w4 x1.10, w6 x1.12, wW x1.06). The chosen line
 *     is quoted in the news ("Manager: '...'"). Skip = no effects;
 *     advancing a day with one pending expires it silently.
 *  72 Headlines: genHeadline(ctx) — 19 context templates (routes,
 *     chases, thrillers, derby delight/pain, champions, knockouts,
 *     tons, five-fors, collapses, fortress/away wins, near misses,
 *     two generic wins, two generic losses). The first applicable
 *     template whose id != lastHeadlineTpl is used, so the same
 *     template never leads twice in a row. Posted to the news after
 *     EVERY user match with the result summary beneath it.
 *  73 Fan Buzz: fanPosts (newest first, cap 30) rendered as its own
 *     Hub section. 2–4 posts after each user match from 8 fictional
 *     Pakistani fan personas; the sentiment bucket (ecstatic/happy/
 *     mixed/angry) is picked from the result class + fanMood. Extra
 *     posts for star signings and sack warnings; ~30% chance of one
 *     ambient post on quiet days. Pure flavour, no effects.
 *  74 Coach's Corner: coachTip() — ONE tip per day from real state,
 *     priority order: board warning, poaching offer, injured starter,
 *     tired starter (<40 stamina), Turning pitch vs <2 spinners in
 *     the XI, final-year contract, 3+ players morale <40, open
 *     transfer window, cash <200 CF, next danger man. Cached for
 *     the day; rotated against yesterday's tip key so it never says
 *     the same thing two days running; default "squad looks sharp".
 *  75 Pre-match analysis: oppRecentForm() derives a club's last-5
 *     W/L string from played fixtures (winner field, else the
 *     summary tail), keyBattleLine() pits the user's best bat
 *     against the opponent's best bowler by real ratings, and
 *     preMatchWinPct() turns team strengths into the favourite line
 *     — rendered on the Hub match-day and next-fixture cards
 *     alongside the existing pitch / ground / danger-man lines.
 *  76 Season review: captureSeasonHistory EXTENDS the same history
 *     entry with best player (most MVP points among the user squad),
 *     biggest user win / best innings / best bowling of the season
 *     (tracked from the match contexts: seasonBigWin / seasonBestBat
 *     / seasonBestBowl / seasonFanMoment), the fan moment (highest-
 *     scoring user match, derbies weighted) and the finances
 *     (financeTotals net + biggest in/out ledger lines of the
 *     season). Shown as a card on the off-season Hub and under the
 *     Profile history entry; pre-v10 entries render without it.
 *  77 Match report: lastReport holds the last finished user match's
 *     report data (teams, scores, result, POTM — patched in by
 *     MatchEngine through noteLivePotm() once it is computed — top
 *     bat/bowl lines, ground, competition). ReportCard draws it to
 *     a Bitmap with Canvas (dark slate + gold) and the card is
 *     viewable in-app (dialog; also on the full-time screen) and
 *     shareable two ways: IMAGE via ACTION_SEND through a tiny
 *     hand-written framework ContentProvider (ShareProvider:
 *     exported=false, grantUriPermissions, serves ONLY cache-dir
 *     PNGs) — stock FileProvider needs androidx, which this pure-
 *     framework build does not carry; a provider entry is NOT a
 *     permission, so the APK still declares ZERO permissions —
 *     and formatted TEXT via ACTION_SEND text/plain (reportText())
 *     as the guaranteed fallback if anything in the image path
 *     fails on a device.
 *  78 Trophy cabinet: trophyCabinetLines() renders every honour
 *     from seasonHistory + hof + career counters — NO duplicated
 *     storage: each league title with its Final opponent, each cup
 *     win, and the "Titles: X · Cups: Y" summary; Profile section.
 *  79 Season calendar: calendarDays() merges league + playoff + cup
 *     fixtures into day-ordered rows (competition tags, results for
 *     played ties, user ties flagged, transfer-window markers on
 *     Days 13–15); CalendarScreen lists them grouped by day,
 *     reachable from the Hub and the League tab.
 *  80 Rival managers: Data.managerFor() names a fictional gaffer for
 *     all 8 clubs. maybeRivalPreQuote() (called from advanceDay's
 *     derby hype, beginPlayoffs and onPlayoffMatchFinished) posts
 *     the rival gaffer's pre-match talk before a derby or a playoff
 *     tie vs the rival — confident when his side leads the table,
 *     dismissive of a struggling user, respectful otherwise — and
 *     the batch-H post-match flow adds his reaction quote (gracious
 *     in defeat / gloating in victory).
 *  Migration: a v9 save gains empty fanPosts, no pending conference,
 *     no boost, headline counter -1, no report, default tip state
 *     and empty season-review trackers. Nothing is wiped; press
 *     conferences only ever trigger for matches finished after the
 *     update, and season reviews only extend future history entries.
 *
 *  ================= BATCH I (v11) — MODES & CHALLENGES (81–90) =====
 *  ModesScreen is the front door (Hub → Manager Actions), career slots
 *  live in Profile. Nothing in this batch touches the main career save
 *  except where an idea says so (87 loads, 90's flag).
 *  81 Difficulty — Game.difficulty (0 Casual / 1 Manager / 2 Legend),
 *     picked on the team picker (MainActivity.pickerDifficulty), changeable
 *     ONLY in the off-season via setDifficulty(). ONE helper set drives
 *     every system: aiDelta() (-4/0/+4) bends AI cards in live matches
 *     (MatchEngine.setupInnings) and simStrength() in every quick-sim;
 *     prize(base) scales match/title/cup prizes x1.25/1.0/x0.85;
 *     weeklyWages() scales the bill x0.8/1.0/x1.15; boardDeltaFor()
 *     inside adjustBoardConfidence() halves negative deltas on Casual
 *     and cuts them x4/3 on Legend (a Legend match loss is -4);
 *     addManagerXp() pays x1.25 on Legend; auctionOpenLot() rolls AI
 *     valuations x1.15 on Legend (the L6 perk still calms them first).
 *  82 Daily challenge + 83 Scenarios ride ONE "friendly" flag on the
 *     match JSON (friendly: 1 = challenge, 2 = scenario): finishMatch
 *     short-circuits for friendlies BEFORE any table/stat/records/
 *     morale/stamina hook — no appearances, no StatsBook, no POTM
 *     money (a quiet display-only POTM), no AI injuries, no watchlist;
 *     Game.finishFriendly() then pays the mode reward only (challenge
 *     +75 once per real calendar date — the attempt is consumed at
 *     LAUNCH into lastChallengeDate and the win is paid against the
 *     match's stored challengeDate vs challengePaidDate, so it cannot
 *     be farmed; scenario +50 the FIRST win per scenario). The innings-
 *     break stamina regen is also skipped for friendlies: a friendly
 *     leaves the season squad exactly as it found it.
 *  83 Scenarios — MatchEngine.injectScenario() builds the scripted
 *     state through the engine's own structures (setupInnings +
 *     fabricateInnings fills legal cards/FoW/parts/over-runs; the Super
 *     Over decider parks on the normal superbreak phase). Completion
 *     + best margin per scenario id live in Game.scenarios.
 *  84 Weekly quests — weeks are Days 1–7 / 8–14 / 15–21 of a season
 *     (questWeekOf); 3 quests per week, generated deterministically in
 *     ensureQuests() (called on load, on Advance Day and when the Modes
 *     screen opens). Progress is judged per MATCH from the fixture's
 *     own day, so cup/playoff ties (all after Day 24) and quick-simmed
 *     later weeks never leak into a live week — the quest set belongs
 *     to league weeks only. +40 CF per quest at completion, ledgered.
 *  85 Achievements — ACH table (15 badges) + Game.achievements
 *     (key -> {season, day}); unlockAchievement() posts news + 10 XP.
 *     Hooks: win/title/cup/derby/streak/home counters in
 *     onUserMatchFinished + the finalize/rollover paths, player-stat
 *     badges via checkPlayerAchievements() (called after StatsBook in
 *     finishMatch, so live centuries/5-fors land the same night),
 *     Super Over Hero in finishMatch itself, Big Spender via
 *     noteTransferSpend() at every signing point, Loyal + Survivor
 *     judged at rollover before the slate resets. Per career.
 *  86 Prediction game — one pending Game.prediction per user tie
 *     (predKeyFor: L<day> / P<stage> / C<day>), offered on the Hub
 *     match-day cards with the pundit's own picks; settles inside
 *     onUserMatchFinished from the Batch H match context (live top
 *     scorer scanned from the cards, ties count as right) — both
 *     picks +60 CF, winner only +15 CF, all ledgered; record kept in
 *     predSettled / predWins / predBoth.
 *  87 Career slots — Slots.java (pure logic over a key-value store):
 *     slot_1..3 + autoslot + hardcore_record keys ride in the SAME
 *     SharedPreferences file as state_v1, so Profile Reset (which
 *     removes only state_v1) never touches them. Loading a slot backs
 *     the live career into autoslot first (unless hardcore) and arms
 *     Game.undoArmed; playing any season match spends the undo.
 *  88 Quick Season — Game.quickSeason() sims every remaining group
 *     fixture through simFixture (validator-gated by the caller, the
 *     same blocked dialog as match day), then hands over to the cup
 *     (Season 2+) or the playoffs exactly like advanceDay does. It
 *     never plays a knockout, a ceremony or the off-season, and the
 *     mid-season window days pass simmed (documented simplification).
 *  89 Result codes — seasonResultCode() reads seasonHistory[0];
 *     careerResultCode() summarises the whole reign; Profile shows
 *     both with Copy buttons (ClipboardManager, no permission).
 *  90 Hardcore — Game.hardcore (picker toggle, or Profile at a season
 *     start via canEnableHardcore()): sackThreshold() 20 (vs 10) with
 *     board warnings from <40, mode rewards halved (modeReward()),
 *     slot undo-load disabled, and the sack is counted ONCE into the
 *     persistent Slots hardcore_record (attempts / best season /
 *     title) by MainActivity when the sacked screen first renders —
 *     the record survives every career clear. Badge on Hub/Profile.
 *  Migration: a v10 save gains difficulty = Manager, hardcore off,
 *  empty challenge/scenario/quest/prediction state (quests generate
 *  for the current week on first load when Days 1–21), empty slots,
 *  and achievements start locked EXCEPT the four honest retro-grants
 *  (First Win / First Title / Cup Winner / Legend Manager) when the
 *  career counters already prove them — granted silently (no XP).
 *
 *  Batch J (v12, ideas 91–100 — App & QoL) added, ON TOP of v11. THE
 *  FINAL BATCH: the career save gains NOTHING — every new setting is
 *  APP-level and lives in a separate SharedPreferences file
 *  (ccm_settings, the pure Settings class over a Kv adapter in
 *  MainActivity), so career resets, slot loads and sync imports can
 *  never wipe them. New pure classes: Settings, SyncCode, CsvExport,
 *  SearchIndex; new screens: SettingsScreen, WhatsNewScreen,
 *  SearchScreen.
 *  91 Career backup export/import — Settings → Backup & Sync: Export
 *     writes the full save JSON as cricket-club-manager-career.json
 *     through the share sheet (ShareProvider now also serves
 *     cache/share/ for .json/.csv/.txt, path policy unchanged);
 *     Import accepts a sync code (100) OR the raw .json text pasted,
 *     validates (SyncCode.validateCareerJson: squad present, season
 *     ≥ 1, career object, userTeam is a league club unless the save
 *     is a custom team), confirms, then loads EXACTLY like a slot
 *     load — current career auto-backed-up to the autoslot first,
 *     one undo until a season match is played, no undo for hardcore
 *     either way; slot_1..3 and hardcore_record are never touched.
 *     (A SAF file picker was skipped deliberately: paste covers the
 *     file path via any text app, and the framework app stays
 *     single-Activity with zero new machinery.)
 *  92 What's New — WhatsNewScreen: the whole mega-batch grouped by
 *     version (v3–v12, v12 listed fully). Show-once via
 *     Settings.lastSeenVersion in ccm_settings: Hub shows the banner
 *     while stored < running versionCode (Settings.shouldShowWhatsNew;
 *     a stored version ahead never re-shows); "Not now" and the
 *     screen's Got-it both store the current code. Also reachable any
 *     time from Profile and Settings.
 *  93 Roman Urdu commentary — Settings.commLang (0 English / 1 Roman
 *     Urdu, in ccm_settings so it survives resets). MatchEngine gains
 *     the urduComm static flag (pushed by MainActivity at launch and
 *     on toggle) and UR pools for dot/single/two/four/six/wicket plus
 *     Urdu milestone ("…run mukammal!") and same-over wicket-cluster
 *     lines ("Isi over mein dusri wicket…", overWkts counter reset in
 *     the over-complete block); pickComm swaps pools inside bowlBall,
 *     so live play, staged sims and Highlights all speak it — scores,
 *     over summaries, results and other fixtures stay English.
 *  94 Sound effects — Settings.soundOn (default ON) + volume
 *     (Low/Med/High → ToneGenerator 30/60/100 on the music stream).
 *     MainActivity.playTone/playBallSound/playEndJingle: tick on runs,
 *     ACK on a four, PROMPT on a six, SUP_ERROR buzz on a wicket, a
 *     two-tone jingle on a win. Synthesized tones only — no audio
 *     files, no permissions, every call try/caught silent. The gate
 *     (Settings.soundPlays) fires ONLY on live paths: Bowl Ball taps,
 *     staged auto steps, Highlights steps, full time. Instant sims
 *     pass livePath=false and stay silent.
 *  95 Big Text + Reduce Animations — Settings.bigText drives
 *     Ui.TEXT_SCALE (Settings.textScale: 1.0 / 1.25) inside Ui.text()
 *     and the gold/dark/chip factories + the bottom nav; set before
 *     first render and re-applied + re-rendered on toggle. Reduce
 *     Animations (Settings.reduceAnim): Settings.effectiveSpeed
 *     forces Game.speed to Instant inside MatchScreen.simTapped, the
 *     speed card says so, and Highlights — a synchronous key-ball loop
 *     with no staging by design — already jumps key-to-key; no other
 *     animation machinery exists in the app to settle.
 *  96 Settings screen — SettingsScreen (from Profile): display &
 *     motion (95), sound toggle + volume + test (94), commentary
 *     language (93) + the Batch A match-speed default (edits the
 *     career's Game.speed, where the engine reads it), Backup & Sync
 *     (91/100), What's New (92), the safe reset (the exact Profile
 *     flow, factored into MainActivity.resetCareerToPicker — clears
 *     only state_v1), and the About block (99).
 *  97 Global search — SearchScreen + the pure SearchIndex: substring
 *     match (2+ chars) over the user's squad (tap → Team detail), AI
 *     squads and World stars (tap → info), the 8 clubs (strength,
 *     ground, rival, H2H — tap → info) and every league/cup/playoff
 *     fixture incl. by "day N" (tap → Season Calendar). Entry on the
 *     Hub's Manager Actions card. No new storage.
 *  98 CSV export — CsvExport builds (a) the tournament book (all
 *     teams, MVP order: runs/balls/outs/50s/100s/wkts/econ/MVP pts)
 *     and (b) the user's squad season stats from the Batch C ss
 *     objects; RFC-4180 quoting on every cell. Buttons in the League
 *     Tournament Leaders card and the Team header card; shared as
 *     files via shareTextFile (provider stream + text payload,
 *     text-only share as fallback).
 *  99 ADAPTED: the original idea was PWA install polish for the WEB
 *     version — Farrakh directed all 100 into the APP, and a native
 *     APK has no PWA install, so the in-app equivalent shipped:
 *     launcher label/icon verified (appName "Cricket Club Manager",
 *     icon present at all five densities 48–192), a new appShortName
 *     string "CCM" for the home screen, the existing top bar as the
 *     launch header, and a full About This App block in Settings
 *     (name, versionName/versionCode read live from PackageManager,
 *     package, offline/zero-permissions note, "Built for Farrakh").
 *  100 Sync-code transfer — SyncCode: the career JSON GZIP-compressed
 *     and Base64-armoured (hand-rolled codec: java.util.Base64 needs
 *     API 26, minSdk is 21) behind the "CCM1:" prefix. Get Sync Code
 *     shows it in a selectable card with its length + a keep-it-private
 *     warning, Copy (clipboard) and Share-as-file buttons. Decode
 *     ignores pasted line breaks and rejects junk with plain-English
 *     errors; a 16 MB gunzip cap guards against crafted codes. This
 *     one mechanism powers idea 91's import as well.
 *  Migration: NONE for the career — a v11 save loads byte-identical;
 *  app settings simply default on first v12 launch (English, sounds
 *  on at Med, normal text, animations on, What's New unseen).
 *
 *  ================= MEGA-BATCH COMPLETE (2026-11-13) =================
 *  All 100 approved updates shipped in the native app, Batches A–J,
 *  versions 3.0 → 12.0: A Match Engine (1–10), B Tactics (11–20),
 *  C Squad & Players (21–30), D Transfers & Contracts (31–40),
 *  E League & Season (41–50), F Teams & World (51–60), G Club
 *  Business (61–70), H Media & Fans (71–80), I Game Modes (81–90),
 *  J App & QoL (91–100). Every batch kept the same rules: pure
 *  framework Java, fully offline, ZERO permissions, the v2 team-sheet
 *  validator gating match day, and every Club Cash movement through
 *  ledgerCf() so the ledger always sums to the balance. The web game
 *  stays frozen at patch v2 by Farrakh's direction — all 100 went
 *  into this app. Career saves migrated forward through every batch;
 *  the native career remains separate from the web career.
 *
 *  ================= DESIGN BATCH (v13) =================
 *  PRESENTATION ONLY — approved as 10 design changes after the 100.
 *  No gameplay logic, engine numbers, save shape or tab structure
 *  changed; a v12.1 save loads byte-identical (asserted in tests).
 *  The pure half is Design.java (NO android imports, desktop-tested):
 *  club colours, rating tiers, role tints, ball-chip mapping, gauge
 *  clamping, momentum split. The drawn half is Icons / CrestView /
 *  AvatarView / GaugeView / MomentumView / BarChartView /
 *  FormBarsView / ConfettiView.
 *   1 Design system — Ui holds the tokens (colours incl. GOLD_BRIGHT /
 *     GOLD_DEEP / PITCH, radii R_CARD 16 / R_BTN 12 / R_CHIP 20,
 *     spacing SP1–4) and every factory (card / goldBtn / darkBtn /
 *     chip) draws from them; all screens already route through the
 *     factories, so the migration is total by construction.
 *   2 Stadium Night — MainActivity's header is a gradient band
 *     (pitch-green deep → slate, blended 22% toward the club accent)
 *     with a 2dp gold rule and the club crest; gold-foil gradient is
 *     reserved for primary buttons + trophy elements; the accent
 *     follows Design.accentFor (custom colour wins, else club
 *     primary; Lahore = gold).
 *   3 Icons — Icons.BadgeView draws all 8 symbols on Canvas (captain
 *     medallion, injury cross, rest crescent, overseas globe, star,
 *     contract page, trophy, CF coin) — zero font glyphs; status text
 *     labels stay beside them (player-card cluster + HQ cash row +
 *     ceremony + empty states).
 *   4 Typography — Ui type scale (display = bold MONOSPACE numerals
 *     for CF pill / score bug / ratings / table numbers; h1/h2/body/
 *     small/micro), table cells right-aligned display style; every
 *     size still flows through scale() so Big Text multiplies all.
 *   5 Layering — Ui.cardBg is a LayerDrawable (gradient face + LINE
 *     stroke over a darker base offset 2dp = soft shadow) + real
 *     elevation with a rounded outline; Ui.sectionHeader bands group
 *     long screens; MainActivity.showSheet is a slide-up BOTTOM
 *     SHEET overlay in the root FrameLayout (dim + grab handle) —
 *     used for Search player quick-view and Calendar fixture taps
 *     (a true BottomSheetDialog needs the design library this
 *     framework build deliberately lacks).
 *   6 Categories — Hub Manager Actions regrouped under CLUB /
 *     MATCH CENTRE / SQUAD / COMPETE / MORE headers (Advance Day
 *     stays primary on top; Recovery/Team Talk/HQ under CLUB,
 *     Calendar under MATCH CENTRE, Transfers + Team under SQUAD,
 *     Modes + League under COMPETE, Search/Settings/What's New
 *     under MORE — no action lost, none duplicated); League and
 *     Profile carry the same sectionHeader system.
 *   7 Broadcast match screen — (a) sticky score bug in
 *     MainActivity.bugSlot OUTSIDE the ScrollView (code + score,
 *     overs, CRR, chase target/need/RRR or projected), refreshed
 *     every render so staged and Instant sims end correct; (b) ball
 *     chips grouped Previous over / This over with Design's colour
 *     map (4 gold, 6 green, W red, 0 dark slate, runs light slate);
 *     (c) MomentumView split at winPredictor % in both clubs'
 *     colours under the predictor bar.
 *   8 Drawn charts — GaugeView (gradient fill + value marker)
 *     replaces the ▓░ ASCII meters for Board/Fans (HQ + Hub mini
 *     gauges + Profile XP); BarChartView draws the 8 Finances
 *     categories from financeTotals(); FormBarsView draws last-5
 *     runs AND wickets bars from formB/formW (▲/▼/● badge stays).
 *   9 Identity — AvatarView initials discs tinted by role (Bat deep
 *     gold, Bowl sky, AR violet, WK orange) on cards + detail +
 *     search sheet; CrestView shields (club colours + sash + code)
 *     in the header, league table rows, H2H rows, Hub match-day
 *     cards, MatchScreen top bar and calendar user fixtures (rows
 *     gained runtime home/away fields in calendarDays — NOT saved);
 *     rating-tier frame strip + tier label on player cards/detail
 *     (Bronze <70, Silver 70–77, Gold 78–84, Elite 85+).
 *  10 Motion & feedback — render() fades/slides content 170ms,
 *     gold/dark buttons carry StateListDrawable pressed states,
 *     ConfettiView (~70 pieces, gold + accent + white, 1.5s,
 *     non-blocking, removed after) fires once per honour when the
 *     Hub shows our trophy ceremony or the League tab our cup win;
 *     Ui.emptyState (drawn icon + line) covers news, Fan Buzz,
 *     history, records, Hall of Fame, trophy cabinet, season
 *     history and calendar rest days. ALL motion gates on
 *     MainActivity.animOk() = !Settings.reduceAnim.
 *  What's New gained the v13 group (show-once keys off versionCode
 *  14, so it fires on upgrade by itself). build.sh: 14 / "13.0".
 *
 *  ================= PROFESSIONAL PACK P1 (v14) =================
 *  PRESENTATION ONLY — the DISCIPLINE pass over the v13 system, from
 *  Farrakh's "absolute bazaar" verdict: too many cards shouting, too
 *  many gold buttons, too much text. No gameplay, save or tab change.
 *   1 Spacing grid — Ui gains SP5 24 / SP6 32; card() bottom margin
 *     SP3 → SP4 and sectionHeader rule gap SP2 → SP3, app-wide.
 *   2 Palette — audited: no Color.rgb exists outside Ui/Design/the
 *     drawn views; semantic colours only (green good, red danger,
 *     gold primary) — unchanged by construction, now stated as law.
 *   3 One card style — audited every screen incl. Transfers, Modes,
 *     Calendar, Search, Settings, WhatsNew, MatchScreen, ceremony:
 *     zero hand-rolled card panels; the only non-card backgrounds
 *     are functional tokens (CF pill, ball chips, tier strips,
 *     swatches, sheet grab handle, nav pill).
 *   4 Emoji out of UI chrome — 215 pictographs stripped from the 15
 *     screen/slot files (headers, buttons, labels, chips, dialogs);
 *     statuses ride on the v13 drawn Icons + words. KEPT as content,
 *     deliberately: generated news/headlines/Fan Buzz posts, match
 *     commentary, the shareable report text + ReportCard image,
 *     milestone/achievement news — the game's voice, not its chrome.
 *     ▲/▼/● (v12.1) and the ●/○ facility pips stay: geometric shapes
 *     that render on the phone font, not emoji.
 *   5 Lockup + splash — crest+name lockup now identical in the main
 *     header, Picker club cards (crest added), the Sacked screen
 *     (crest added) and Settings About (crest + tagline added); the
 *     ceremony already carried it. MainActivity.showSplash: crest +
 *     app name + "Manage. Win. Lift the trophy." for ~900ms on cold
 *     start, a view swap in the root frame, skipped entirely when
 *     Reduce Animations is on.
 *   6 Typography — worst offenders fixed with 7/9 below: HQ staff and
 *     sponsor/camp cards lost their stacked gold bold button lines;
 *     body copy stays non-bold (Ui.body), headings h1/h2 only.
 *   7 Text diet — Hub status card no longer prints Board/Fans numbers
 *     as text AND gauges (objective + fan label kept, numbers live on
 *     the gauges); the What's New banner is one line; Team cards drop
 *     the Overseas/Final-year ICONS that duplicated the sub-line word
 *     for word. Every effect number a player needs was KEPT.
 *   8 Max-3 / whitespace — card + section gaps above; Team cards now
 *     show at most the captain/injured/rested/watching icon cluster.
 *   9 Button discipline — Ui.dangerBtn added (red outline). Gold is
 *     now ONE per card: demoted to darkBtn — Hub + MatchScreen press
 *     answers (were 2 gold), toss Heads/Tails (2 gold), Stop Auto-Sim,
 *     HQ sponsor Sign buttons ×3, camp focus buttons ×4, staff Hire
 *     (loop), Transfers window Buy + free-agent Sign (loops inside
 *     one card), Team Add-to-XI toggles, Picker Manage ×8, Calendar
 *     sheet Close. Danger style: Reset Career (Profile + Settings),
 *     Release player ×2, Release staff. Call-site counts: Hub 10→9
 *     (its press card rendered 2 golds from 1 site — now 0), HQ 5→2,
 *     MatchScreen 11→7, Transfers 5→3, Team 2→1, Picker 2→1,
 *     Calendar 1→0. Remaining golds are each their card's primary
 *     (Play/Bowl Ball, Advance Day, facility Upgrade, auction Bid…).
 *  10 Dialogs/toasts — convention stated + enforced: confirm dialogs
 *     are "Cancel" + a verb (Picker's "Back" → "Cancel" was the only
 *     outlier), dismiss-only dialogs say "Close"; toasts audited —
 *     all short single-line outcomes. Empty states were v13's.
 *  What's New gained the v14 group (show-once keys off versionCode
 *  15). NOTE: the automated emoji strip also normalised multiple
 *  spaces file-wide in the 15 migrated files (indentation inside
 *  them is single-spaced now — cosmetic in source only, and every
 *  merged suffix literal it produced — " CF", " XP", " TIER",
 *  " OF ", " Calendar", " Champions!", " Review", " Legends",
 *  " Players", " DEATH" — was found by audit and restored).
 *  build.sh: 15 / "14.0".
 *
 *  ================= PROFESSIONAL PACK P2 (v15) =================
 *  PRESENTATION / NAVIGATION STRUCTURE ONLY — layout, layers and
 *  categories (suggestions 11–20). No gameplay logic, no save
 *  change (round-trip asserted byte-identical), 6 tabs unchanged.
 *  The load-bearing addition is in MainActivity: TWO new slots in
 *  the root column — stickySlot (between bugSlot and ScrollView)
 *  and actionSlot (between ScrollView and the bottom nav).
 *  render() clears both; screens re-park their bars on every build,
 *  so parked UI always reflects post-action state.
 *  11 Hub dashboard — strict order: (1) TODAY strip (season/day,
 *     objective, board + fan gauges, difficulty/hardcore/quests/
 *     camp lines, and the Coach's Corner tip folded in as a
 *     one-liner), (2) Next Match card (unchanged), (3) SQUAD ALERT
 *     — a "NEEDS ATTENTION" card rendered ONLY when the new pure
 *     Game.hubAlerts() returns lines (board warning, blocked team
 *     sheet in-season, injured starter, stamina<40 starter, poach
 *     offer, pending press conference), with the press and poach
 *     DECISION cards immediately after it, (4) MONEY snapshot (CF,
 *     next wage hit = weeklyWages() on nextWageDay(), sponsorLine()).
 *     Re-homed, nothing deleted: the old status card's CF/XI line →
 *     Money snapshot + header pill / Squad Alert + Team pinned bar;
 *     the stand-alone board warning card → the first hubAlerts()
 *     line; Coach's Corner card → the Today strip tip; the What's
 *     New banner → below the Money snapshot; sponsor-offers and
 *     camp cards → below Manager Actions (both also live in HQ);
 *     press card → after the Alert card (was after the match card);
 *     poach card → after the Alert card (was before it); Season
 *     Review, Last Match Report, Club News and Fan Buzz keep their
 *     order at the bottom.
 *  12 Bottom nav — each tab is now a drawn Icons symbol (HOME /
 *     SHIRT / TROPHY / globe / PERSON / BUILDING — four new kinds
 *     drawn in the Icons style) over its label, with a gold top
 *     indicator bar + gold bold label + pill on the active tab.
 *  13 Sub-screen headers — Ui.subHeader (chevron "‹" text glyph,
 *     h1 title, optional subtitle, one optional right action)
 *     applied to Transfers, Modes, Calendar, Search, Settings,
 *     WhatsNew and the Team player detail — replacing their ad-hoc
 *     back buttons. NOT applied: the team Picker and the Sacked
 *     screen (root states with no back by design) and the Trophy
 *     Ceremony (a Hub card, not a separate view).
 *  14 Category titles — Ui.sectionHeader now leads groups on Team
 *     (SQUAD), World (RANKINGS / WATCHLIST), HQ (CLUB / DEALS &
 *     STAFF / FACILITIES / MONEY) and Transfers (OFF-SEASON /
 *     THE MARKET / CONTRACTS & WAGES) and Modes (PLAY / PROGRESS),
 *     joining Hub, League and Profile from v13.
 *  15 Sticky chips — Team role filters and a new Transfers section
 *     filter (All / Window / Free Agents / Loans / Release, state
 *     on MainActivity.transfersFilter) park in stickySlot: fixed
 *     while the list scrolls, refreshed on every render. League
 *     has no selector chips to stick (its tables all show at
 *     once) — noted, not invented.
 *  16 Collapsibles — Ui.collapsible (gold header + ▸/▾ chevron,
 *     toggles in place, state lives only for the screen visit)
 *     applied to: Profile Match History results, Profile Records
 *     Book lines, Profile Season History detail, HQ Finances
 *     category detail, Team detail career batting/bowling lines.
 *  17 Sheets extended — Team player cards tap into the shared
 *     SearchScreen.playerSheet (now public + player-based, with
 *     stamina/morale gauges added; Full Details routes to the
 *     detail screen); League fixture, playoff and cup rows tap
 *     into CalendarScreen.fixtureSheet (now public) via a
 *     calendar-shaped sheetRow built in LeagueScreen.
 *  18 List rows — Ui.listRow (left visual, title, subtitle,
 *     right-aligned display value, hairline divider) applied to:
 *     Transfers free-agent + window listings (price/fee as the
 *     value), Search result groups (avatar/crest/badge + kind
 *     tag), Modes achievements + scenario entries, Calendar rows
 *     and League fixture rows.
 *  19 Subtitles — subHeader context lines from real state:
 *     Transfers (season + window close/open day or off-season
 *     phase), Modes (reset cadence), Calendar (window days),
 *     Settings, Search, WhatsNew, Team detail (role · club · tier).
 *  20 Pinned action bars — parked in actionSlot: live Match
 *     (Bowl Ball + Sim Over + Sim Match, or Stop Auto-Sim while a
 *     staged sim runs — same handlers as the controls card), Team
 *     list (XI n/11 · Legal/Blocked + Auto-pick, sharing the one
 *     autoPick() path with the head card), Transfers (Budget CF ·
 *     Squad n/22 · Wages/wk on every phase). The slot sits in the
 *     root layout above the nav, so overlap is impossible.
 *  What's New gained the v15 group (show-once keys off
 *  versionCode 16). build.sh: 16 / "15.0".
 *
 *  ================= PROFESSIONAL PACK P3 (v16) =================
 *  PRESENTATION ONLY - the BROADCAST MATCH SCREEN (suggestions
 *  21-30), refining what v13/P2 built rather than duplicating it.
 *  No gameplay or engine-number change and no career-save change:
 *  the only engine touches are two presentation recordings in the
 *  match object (commEv event tags beside each commentary line, and
 *  the wpSeries win-% points - the engine never reads either back),
 *  defaulted by migrateMatch for resumed pre-v16 matches. A career
 *  save with no live match round-trips byte-identical (asserted).
 *  The pure half is MatchCentre.java (comparison, timeline model,
 *  graph series, turning point, top performers, derived maidens).
 *  21 Score bug - broadcast-grade: format-aware overs (x/20 or x/50
 *     ov, Super Over labelled), the pair at the crease, the current
 *     bowler's figures and the last-12-balls strip, still sticky in
 *     MainActivity.bugSlot outside the ScrollView.
 *  22 Timeline - one row per over for the current innings live and
 *     both innings at full time (and innings 1 at the break): real
 *     ball chips where lastBalls reaches (it stores only the last
 *     12), otherwise an honest aggregate chip (the over's runs) plus
 *     a larger red W chip per fall with the batter's initials; the
 *     row end carries the over's runs/wkts. Rows sum to the innings
 *     totals by construction (asserted in tests).
 *  23 Commentary - chronological under OVER headers; key balls are
 *     event rows (chip + text) driven by the engine's commEv tags
 *     (W/4/6/M), quiet balls compact muted lines. Roman Urdu lines
 *     ride the same data. The comm cap (60) is unchanged.
 *  24 Tactics - MatchScreen.segmented() equal-width controls for
 *     tactics, running style, powerplay plans, field presets (two
 *     rows of three) and per-batter plans; ppStrip intent cells
 *     (gold Attacking / slate Balanced / green Safe) under each PP
 *     plan; planStrip mini grid for the rotation (initials per over,
 *     phase colours, bowled overs dimmed); the FieldMapView gains a
 *     preset-name title in addFieldPicker and position initials on
 *     every dot (WK/B + LABELS table). Shield stays a chip picker
 *     (it is a player list, not a mode switch).
 *  25 Win graph - WinGraphView (gold area line, dashed 50 line,
 *     final point labelled) under the momentum bar live, plus graph
 *     cards at the break and full time. Series: recordWp appends
 *     winPredictor after each completed over and at innings end
 *     (wpBalls guards doubles; Super Overs are skipped and never
 *     wipe a series - setupInnings resets only for real innings;
 *     inn1Wp / inn2Wp are stashed with the other innings copies).
 *  26 Comparison - MatchCentre.comparison: Top-order batting,
 *     Bowling attack, All-round strength, Form (last 5, from
 *     oppRecentForm), Squad depth - top-5/top-11/bench averages of
 *     the two real squads on a 0-100 scale; rendered as split bars
 *     with the better side's number in gold, on the Hub analysis
 *     card (addAnalysis) and in the match screen's toss view.
 *  27 Scorecard - fixed header rows, right-aligned display numerals,
 *     zebra rows, the not-out pair in gold with an asterisk, status
 *     under the name; bowling O-M-R-W-ECON with maidens DERIVED
 *     (overBowlers x overRuns - a scoreless completed over; shown
 *     as a dash after a Super Over, whose over record is the super
 *     over's own and cannot speak for the main innings).
 *  28 Full-time infographic - leads the done screen: result, POTM
 *     with AvatarView + tier frame (rating read off the match
 *     cards), turning point (the biggest recorded win-% swing of
 *     8+ points; fallbacks, plainly labelled: a hundred, a five-for,
 *     a 3-wicket over, else "no single swing"), top-2 scorers +
 *     best bowler from MatchCentre.topPerformers, and the graph.
 *     The old FULL TIME card keeps share / press / back (its result
 *     + POTM lines moved up into the infographic).
 *  29 Control bar - the pinned bar IS the control bar now: Bowl
 *     Ball (gold) + Sim Over + the speed segmented control + More
 *     (sheet: Sim Innings / Sim Match / Highlights). While a staged
 *     sim runs it carries Stop Auto-Sim + the speed control, so
 *     Stop is always reachable. The in-scroll controls card is
 *     GONE; the tactics card is what remains in scroll.
 *  30 Quiet motion - a phase change (same match, phase differs from
 *     the last build) fades the root once at 340ms; the newest
 *     ball's chip pops once per ball (keyed on the ball, so tactic
 *     taps never replay it). Both gate on MainActivity.animOk().
 *  What's New gained the v16 group (show-once keys off versionCode
 *  17). build.sh: 17 / "16.0".
 *  ============================================================
 *  PROFESSIONAL PACK P4 (v17) - Squad, Money & League Presentation
 *  (suggestions 31-40). PRESENTATION ONLY: no gameplay logic, no
 *  auction logic, no save fields - every new number is derived at
 *  render time by the NEW pure class Present (desktop-testable:
 *  role key stats, sorting, form dots, table movement, finance
 *  tiles, calendar weeks, auction-budget reconstruction, POT bar
 *  inputs). MainActivity gained three runtime view-state fields
 *  (teamViewMode / teamSort / teamDetailTab) - never persisted.
 *  31 Compact player cards - the Team card drops the attribute bars,
 *     season snapshot and form chart; it now shows avatar + name +
 *     role chip + tier frame (all pre-existing) and EXACTLY THREE key
 *     figures from Present.keyStats by role (Bat: BAT / season runs /
 *     SR; Bowl: BOWL / wkts / econ; AR: BAT/BOWL / runs / wkts; WK:
 *     BAT / runs / high score - catches and stumpings are NOT tracked
 *     anywhere in the save, so the brief's WK figure honestly falls
 *     back to HS). Card tap -> the P2 sheet (unchanged); the XI toggle
 *     stays on the card as a compact chip (same guards, now the shared
 *     TeamScreen.toggleXi); Rest/Watch moved into the sheet (new row)
 *     and the detail Manage card - no action lost. Shared statics
 *     (toggleXi / comparePick / restToggle / watchToggle) keep card,
 *     rows, sheet and detail on one code path.
 *  32 Detail tabs - the player detail swaps content under in-memory
 *     tab chips (Overview / Stats / Form / Contract): Overview =
 *     Set-role control + ratings card + tags + Manage (Rest/Watch);
 *     Stats = season + career tables; Form = FormBarsView + last-5
 *     list + milestones; Contract = the standing deal (years left,
 *     wage, season wage bill, renewal guidance) with the existing
 *     rename + contract cards moved under it. Nothing renamed/lost.
 *  33 Squad rows + sorting - a Cards|Rows toggle beside the role
 *     chips (Cards stays default). Rows are Ui.listRow lines (avatar,
 *     name + captain mark, role/status subtitle, RingView stamina +
 *     number + word, rating, XI or Compare chip, tap -> sheet) with a
 *     sort chip row (Rating / Bat / Bowl / Stamina / Morale / Age,
 *     in-memory, default Rating desc, name breaks ties) that only
 *     appears in Rows mode. Present.sortPlayers does the ordering.
 *  34 Meter visuals - NEW MeterChip (label + GaugeView + "value and
 *     word") on cards for Stamina (Fresh/Tiring/Tired/Exhausted) and
 *     Morale (Game.moraleLabel); rows use NEW RingView + number + the
 *     stamina word; the sheet now prints "value and word" beside both
 *     gauges. Rule kept everywhere in Team + sheet: a meter is never
 *     colour-only (the v12.1 lesson).
 *  35 Market cards - window listings and free agents are now market
 *     cards (TransfersScreen.marketBlock): avatar, name, role, age,
 *     bat/bowl, rating, NEW PotBarView (40-100 track; solid gold =
 *     rating now, pale gold extending to potential - exact POT for own
 *     or scouted players, the displayed range for the unscouted, via
 *     Present.potBar over Game.potDisplay/potRangeLowFor), scout
 *     verdict, and fee or wage as a right-aligned display figure.
 *     Actions unchanged (Sign secondary, Release quiet as in P3).
 *  36 Auction panel - the auction is a bidding panel: the lot wears
 *     the market card header; a bid-status block (leader crest for AI
 *     leaders, current bid in display type, who leads, and a ROOM
 *     SIGNAL from existing state only - Present.roomStillIn checks
 *     whether any rival's aiMax and budget still cover the next bid,
 *     values never shown); your budget as a MeterChip gauge against
 *     the auction's starting budget, reconstructed from existing
 *     fields (cf now + your settled spend parsed from the log -
 *     Present.auctionBase). QUICK-BID chips +10/+25/+50 call the
 *     EXISTING g.auctionBid() repeatedly until the bid has risen by
 *     the chip amount, the lot settles or a call changes nothing -
 *     zero auction-logic change. HISTORY DECISION: the auction log
 *     records SETTLED lots only (who won whom for how much), never
 *     individual bids, and recording them would touch auction state -
 *     outside this pack's presentation-only scope. The panel therefore
 *     shows the live bid + leader + room signal and the log section is
 *     honestly headed "Auction history - settled lots" (last 5).
 *  37 Finances dashboard - three tiles (INCOME / SPENDING / NET)
 *     from Present.financeSummary over financeTotals (the tile net
 *     equals the stored total by construction - income sums the four
 *     positive buckets plus any positive 'other', spending the rest);
 *     the BarChartView stays; a wage-bill line (season wages as a
 *     share of season income via wageSharePct, in the same weekly
 *     framing); biggest single income + expense as two list rows
 *     (scanned from the existing ledger, current season only); the P2
 *     collapsible category detail stays below. The old "Season net:"
 *     line folded into the NET tile.
 *  38 League tables - every group-table row gains last-5 form dots
 *     (green W / red L / muted T, oldest first, from
 *     Present.formDots over the fixtures - winner field first, summary
 *     tail as fallback, the same derivation oppRecentForm uses) and a
 *     movement marker (Present.movementText) vs the PREVIOUS completed
 *     match day: Present.previousOrder replays group fixtures with
 *     day < latest played day (2 pts win / 1 tie, approximate NRR from
 *     stored scores, all-outs = 120 balls) and movement() diffs it
 *     against the live order. SCOPE: group tables only - playoff/cup
 *     tables have no previous-round meaning; NRR in the replay is
 *     approximate where ball counts were never stored (dots and points
 *     are exact). Runtime-only: nothing is saved.
 *  39 Honours boards - Profile: Trophy Cabinet honours are list
 *     rows with the drawn Icons.TROPHY beside each (the stored lines'
 *     emoji prefix is stripped in presentation only); season champions
 *     in the Hall of Fame are crest rows ("Season N champions - beat X
 *     in the Final", YOURS marker); our title/cup HoF entries carry the
 *     trophy badge; Records Book entries are record rows - holder
 *     avatar (player records) or crest (team records), label over
 *     holder, the value in display type. Gold-ruled section headers
 *     already framed all three (v13/P2); legends and season-history
 *     blocks unchanged.
 *  40 Calendar timeline - fixtures group under WEEK headers
 *     (Present.weekOfDay: Day 8 = Week 2 - unit-checked) with section
 *     headers; a gold TODAY marker line rides the current day's group
 *     (plus the day-card title keeps its TODAY tag); every row gains a
 *     competition chip coloured by Present.compKind (League slate +
 *     gold text, Cup green, Playoff deep gold, Window pitch-green,
 *     other grey) and the stored window tag's emoji is stripped in
 *     presentation. Off-season: a phase card leads the calendar
 *     (Phase 1 Retain & Renew / Phase 2 The Auction) from g.offseason.
 *  What's New gained the v17 group (show-once keys off versionCode
 *  18). Tests: TestP4 34/34 (key-stats per role incl. the WK fallback,
 *  all six sort orders, form dots on a scripted six-result set incl.
 *  the summary-tail fallback, two-round movement incl. an NRR-split
 *  tie, finance tiles == financeTotals on a real simmed season,
 *  Day 8 = Week 2, auction spend/base, room signal both ways, POT bar
 *  exact vs ranged, save round-trip, ledger invariant); regressions
 *  TestDesign 43, TestJ 46, TestP2 28, TestP3 35 all green against
 *  the rebuilt classes. build.sh: 18 / "17.0".
 *  ================================================================
 *
 *  PROFESSIONAL PACK P5 (v18) - Onboarding, Help & Trust for Other
 *  Users (suggestions 41-50). The final Professional Pack batch.
 *  Career-save shape UNTOUCHED (round-trip byte-identical); the only
 *  new state is app-level, in the ccm_settings prefs.
 *  41 Onboarding - a 3-step welcome (Welcome / How a season works /
 *     Your money) shown BEFORE the team picker only on a true first
 *     launch: no career + the new Settings flag onboarding_seen
 *     unset. The flow predicate is the pure
 *     Settings.shouldShowOnboarding(hasCareer, seen); finish/skip
 *     sets the flag (MainActivity.finishOnboarding) and lands on the
 *     picker. Help's "Replay the welcome" re-enters view-only over a
 *     live career (onboardingMode over the tabs) and touches no
 *     career state. Steps carry the crest lockup + drawn icons, in
 *     the P1 splash's voice.
 *  42 Quick Start - a primary card at the TOP of the picker: one tap
 *     forces pickerDifficulty=Manager / hardcore off and calls the
 *     same startCareer("Lahore Qalandars") a manual pick calls, so
 *     the career is identical in every default. Full picker below.
 *  43 Help - NEW HelpScreen (Profile + Settings entries;
 *     MainActivity.openHelp remembers the sender for the back
 *     chevron): seven guides in P2 collapsibles (Getting Started,
 *     Picking Your XI, Club Cash & Wages, Transfers & the Auction,
 *     Playoffs & the Cup, Board Confidence & the Sack, Backup & Sync
 *     Codes), every number the game's real value at Manager
 *     difficulty (300 CF a win, wages Days 7/14/21, cap 22, window
 *     Days 13-15 / 25 CF release, scout 40 CF, 1500/500 playoffs,
 *     1000/300 cup from Season 2, sack under 10 at a season end).
 *  44 Glossary + info chips - NEW pure Glossary (12 terms: CF, NRR,
 *     POT, DLS, Set %, CRR, RRR, XI, Powerplay, Super Over, Gate,
 *     Wage bill), one map feeding Ui.infoChip/infoBadge sheets AND
 *     Help's Glossary section. Placements: NRR badge in the league
 *     table header, POT chip on the player detail line and the
 *     market cards, Set % row restored to the player detail with
 *     its badge, CRR/RRR chips in the match score-header card, DLS
 *     chip there whenever the par score shows or rain has cut in.
 *  45 Wording pass - "Legacy sponsor (old flat rate)..." became
 *     "Standard sponsor deal - in place until your first sponsor
 *     pick at the next season break." (Game.sponsorLine); Settings'
 *     "(idea 91)" file note and the "100-update mega-batch (v3.0 -
 *     v12.0)" What's-New card line rewritten plainly; Profile's
 *     stale "What's New in v15" button is now "What's New"; Modes'
 *     difficulty and quick-season paragraphs and HQ's camp line
 *     shortened; Data's Commercial Centre effect de-jargoned.
 *  46 Settings regrouped - section headers DISPLAY / SOUND /
 *     COMMENTARY / GAMEPLAY / DATA / HELP & ABOUT. GAMEPLAY is new:
 *     difficulty display + the same off-season change chips Profile
 *     uses (g.setDifficulty) + a hardcore state line. DATA gains a
 *     Career Slots link card. Labels only - every existing control
 *     keeps its handler and behaviour.
 *  47 Backup simplicity - the Backup & Sync card leads with the
 *     plain promise ("Your career lives only on this phone..."),
 *     "Get Sync Code" became the gold primary "Create my career
 *     code", and the import button is "Continue from a career code".
 *     Same SyncCode mechanism, same validation, same auto-backup.
 *  48 What's New as changelog - newest first, the current version
 *     expanded as a card, every older version folded into a
 *     collapsible under its version header; the stale "(this
 *     update)" tags on v17/v15 were removed.
 *  49 About & trust - the About block is a trust card: crest +
 *     name + tagline, live version, three pills (100% offline / No
 *     account / Zero permissions), "Your data never leaves this
 *     phone.", credits "Built for Farrakh - Lahore Qalandars
 *     theme", and the GitHub repo as a tappable ACTION_VIEW row
 *     (plain text fallback on screen if no browser answers).
 *  50 Consistency pass - audited all screens: subHeader/section
 *     headers everywhere a sub-screen exists (picker + sacked are
 *     standalone full-screen states by design), card factory only,
 *     gold primaries per card re-counted, no emoji added to any new
 *     chrome (P1's audit still holds), stale fallbacks in
 *     MainActivity (appVersionCode/Name defaults) caught up to the
 *     real build. Stragglers fixed are listed in the batch report.
 *  What's New gained the v18 group (show-once keys off versionCode
 *  19). Tests: TestP5 (onboarding predicate over a map-backed Kv,
 *  Quick Start defaults == manual Lahore pick, all 12 glossary
 *  terms non-empty, help numbers vs Game constants, round-trip,
 *  two-season regression + ledger invariant) + TestDesign 43,
 *  TestJ 46, TestP2, TestP3, TestP4 regressions. build.sh: 19 /
 *  "18.0".
 *  ================================================================
 *
 *  AUDIO PACK (v19) - Sound & Music (the 25 approved audio
 *  suggestions). The Batch J ToneGenerator beeps are REPLACED by a
 *  real synthesized sound engine. Career-save shape UNTOUCHED
 *  (round-trip byte-identical); all new state is audio prefs in
 *  ccm_settings. NO audio files ship - every sound is PCM
 *  synthesized at runtime, so the APK grows by code only.
 *  SoundSynth (PURE, desktop-tested) generates mono 16-bit PCM at
 *  22050 Hz: batHit in 3 weights (lowpassed noise crack + sine
 *  thump), stumps (wooden tick clatter + knock), pads (low thud +
 *  a soft crowd lift - the "appeal" is a murmur swell, NOT a fake
 *  voice), crowdSwell (band-shaped noise; happy rising / groan
 *  falling), applause patter, and partial-based stings (wicket,
 *  win arpeggio, 5.6s title, achievement sparkle, level-up).
 *  Loops are seam-folded for click-free looping: crowd bed (+ a
 *  louder derby variant), rain patter, an Am-F-C-G menu pad, a
 *  low match-bed pulse and a last-overs tension throb.
 *  SoundEngine (Android side) owns static AudioTracks that release
 *  themselves on their end marker (max 7 one-shots), singleton
 *  loop tracks, STREAM_MUSIC everywhere, the ringer-mode rule
 *  (silent/vibrate = no forced sound) and a lazily-built TTS.
 *  1-8 Match sounds - MainActivity.playBallSound reads the ball
 *  off lastBalls + the dismissal "how" parsed from the newest
 *  commentary line (no new match fields): weights by outcome,
 *  STUMPS on bowled, PADS on lbw, wicket sting when the USER
 *  bowls the wicket, GROAN on a user wicket, happy swells scaled
 *  4 < 6, applause + swell when a crease batter crosses 50/100
 *  (checked against runs-minus-outcome), tension loop inside the
 *  last 3 overs of a live chase (need <= 60) and Super Overs.
 *  9-12 Atmosphere - per-render audioSync(): crowd bed under
 *  live matches only (ball/staged paths - the screens that call
 *  playBallSound), home 0.55 / away 0.35 / derby 0.7 bed levels,
 *  rain patter as a 3.5s burst when rainNote first appears (the
 *  engine applies rain instantly; there is no lingering delay
 *  state to sit in). Loops stop onPause, release onDestroy.
 *  13-18 UI sounds - button clicks via a shared ACTION_DOWN touch
 *  hook installed by MainActivity into Ui's gold/dark/danger/chip
 *  factories (never consumes the click; engine throttles 120ms);
 *  confirm chime by render-diff on new ledger entries whose
 *  reason names a signing / loan-in / window transfer (those only
 *  ever follow a user tap); blocked thud in showXiBlocked and on
 *  any "Not enough CF..." toast (Game's universal refusal line);
 *  auction bid tick + gavel from the Transfers handlers via
 *  MainActivity.auctionSound(result); cash chime at full time on
 *  a win (the prize posts there); achievement shine, level-up
 *  and title stings by render-diff on counts (the same pattern
 *  as the hardcore sack counting) - Game itself stays untouched.
 *  19-20 Music - menu pad on non-match screens, match bed in a
 *  live match, both through the Music channel; ON by default
 *  under the master Sound toggle at low default volume (50).
 *  21-22 Voice - TextToSpeech score lines, OFF by default, a
 *  Settings toggle; triggers: innings break, chase balls 90 and
 *  108 ("X need N off M balls"), full-time summary; spoken 650ms
 *  after the ball so it never talks over a sting. English only -
 *  the phone's TTS voice speaks it; Roman Urdu has no voice and
 *  Settings says so. TTS builds lazily on first use; any failure
 *  is silent. No permission is needed for TTS or AudioTrack.
 *  23-25 Mixer - Settings SOUND is a mixer: master on/off, the
 *  legacy Low/Med/High master step, five channel steppers
 *  (Match 90 / Crowd 80 / UI 60 / Music 50 / Voice 100 defaults)
 *  with per-channel Test buttons, Quiet Mode (Settings.audioGate
 *  + SoundSynth.isBigEvent: wickets, boundaries, results, titles
 *  only), and the ringer line in the copy. The idea-94 live-path
 *  gate (Settings.soundPlays) still guards every match sound, so
 *  Instant sims stay silent on every channel.
 *  What's New gained the v19 group (show-once keys off
 *  versionCode 20). Tests: TestAudio (buffer durations/RMS/no-clip,
 *  loop seams, event mapping, dismissal kinds, gate truth table,
 *  mixer prefs round-trip) + TestDesign 43, TestJ 46, TestP2-P5
 *  regressions, two-season sim + ledger invariant, save
 *  round-trip byte-identical. build.sh: 20 / "19.0".
 *  ================================================================ */
public class Game {
    public int season = 1;
    public int day = 1;
    public int cf = 1000;
    public JSONArray players = new JSONArray();   // name, role, bat, bowl, stam, set, inXI, overseas, rested
    public JSONArray facilities = new JSONArray(); // 5 levels
    public JSONArray fixtures = new JSONArray();   // day, home, away, played, summary (+ top performers)
    public JSONObject tables = new JSONObject();   // team -> p,w,l,pts,rf,bf,ra,ba (balls)
    public JSONObject career = new JSONObject();   // played,won,lost,streak,best,titles
    public JSONArray history = new JSONArray();    // user result strings
    public JSONArray news = new JSONArray();       // strings, newest first (watchlist alerts land here)
    public JSONArray watchlist = new JSONArray();  // player names (strings), v2
    public JSONArray ledger = new JSONArray();     // {season, day, amt, reason}, newest first, v2
    public JSONObject match = null;                // in-progress match (MatchEngine state)
    public int talkDay = -1;
    public int speed = 1;                          // Batch A (idea 10): 1 = 1x, 2 = 2x, 0 = Instant
    public JSONArray potmHistory = new JSONArray(); // Batch A (idea 8): POTM strings, newest first
    public String captain = "Shaheen Shah Afridi"; // Batch C (idea 26): designated captain (player name)
    // ---- Batch D (ideas 31–40): transfers & contracts state ----
    public JSONArray faPool = new JSONArray();     // free-agent player objects (idea 37)
    public JSONObject scouted = new JSONObject();  // name -> {pot, grade, verdict} (idea 39)
    public JSONObject auction = null;              // live auction state, phase 2 (idea 31)
    public JSONArray departed = new JSONArray();   // released / out-of-contract men awaiting the auction
    public int offseason = 0;                      // 0 in-season, 1 retain/renew, 2 auction
    public int windowSeason = -1;                  // season the mid-season window opened in (idea 33)
    public int windowSigns = 0;                    // signings used in the current window (max 2)
    public JSONArray windowList = new JSONArray(); // mid-season window listings (player obj + team/price)
    public JSONArray loanList = new JSONArray();   // loan-IN candidates (player objects, idea 36)
    public JSONObject poachOffer = null;           // {name, team, fee, expDay, expSeason} (idea 40)
    public int wageShortStreak = 0;                // consecutive short-paid wage weeks (idea 35)
    // ---- Batch E (ideas 41–50): playoffs, tournament book, records, history ----
    public int playoffPhase = 0;                   // 0 group stage, 1 playoffs live, 2 ceremony pending, 3 acknowledged
    public JSONArray playoffFixtures = new JSONArray(); // {stage, home, away, played, summary, winner, day, standouts…}
    public String seasonChampion = "";             // set at the Final (idea 42); "" = not decided / legacy season
    public String seasonRunnerUp = "";
    public JSONObject ceremony = null;             // {season, champion, runnerUp, finalSummary, potm, potmDesc}
    public JSONObject lastAwards = new JSONObject();    // idea 47: this season's award winners
    public JSONObject tournBook = new JSONObject();     // idea 43: name -> tournament season figures, ALL teams
    public JSONObject records = new JSONObject();       // idea 48: all-time records book
    public JSONArray seasonHistory = new JSONArray();   // idea 50: completed-season entries, newest first
    public JSONArray hof = new JSONArray();             // idea 49: title squads + Lahore Legends
    public JSONArray pendingLegends = new JSONArray();  // idea 49: departed greats awaiting the auction verdict
    public JSONObject h2h = new JSONObject();           // idea 46: team -> {p, w, l, last} vs Lahore, all-time
    // ---- Batch F (ideas 51–60): teams & world state ----
    public String userTeam = Data.USER_TEAM;       // idea 51: the managed club (default Lahore Qalandars)
    public boolean customTeam = false;             // idea 52: userTeam is a created club
    public String customCode = "";                 // idea 52: 2–3 letter short code
    public int customColor = 0;                    // idea 52: badge tint argb (0 = gold default)
    public JSONObject aiInj = new JSONObject();    // idea 53: team -> {playerName -> days out}
    public JSONObject aiXiCache = new JSONObject();// idea 53: team -> {stamp, names[]}
    public JSONArray worldNations = new JSONArray(); // idea 54: T20I nations {name, pts, prev}, current order
    public JSONArray worldBat = new JSONArray();     // idea 54: T20I batting {name, tag, pts, prev}
    public JSONArray worldBowl = new JSONArray();    // idea 54: T20I bowling {name, tag, pts, prev}
    public JSONArray callups = new JSONArray();      // idea 55: squad names away on international duty
    public int cupPhase = 0;                         // idea 56: 0 not started, 1 live, 2 done
    public JSONArray cupFixtures = new JSONArray();  // idea 56: {stage, cup:true, day, home, away, played, summary, winner}
    public String cupChampion = "";
    public String cupRunnerUp = "";
    // ---- Batch G (ideas 61–70): staff, money, board, fans, XP ----
    public JSONObject staff = new JSONObject();        // idea 61: role -> {name, rating, wage}
    public JSONArray staffCandidates = new JSONArray(); // idea 61: {role, name, rating, wage}, 3 per role
    public int ticketTier = 1;                          // idea 63: 0 Cheap, 1 Standard, 2 Premium, 3 Expensive, 4 Premium Plus
    public JSONObject sponsor = null;                   // idea 64: {brand, lump, weekly, objType, objText, bonus}
    public JSONArray sponsorOffers = new JSONArray();   // idea 64: this off-season's 3 deals
    public boolean sponsorLegacy = true;                // idea 64: old flat sponsor until the next rollover
    public int sponsorProgress = 0;                     // idea 64: 200+ totals counted toward the objective
    public boolean sponsorDone = false;                 // idea 64: objective already paid
    public boolean campPending = false;                 // idea 66: a camp choice is waiting (off-season)
    public int campChoice = -1;                         // idea 66: 0 Bat, 1 Bowl, 2 Fitness, 3 Fielding, 4 skipped
    public int campSeason = -1;                         // idea 66: season the camp belongs to
    public int campMatchesUsed = 0;                     // idea 66: user matches played under the camp
    public int boardConfidence = 70;                    // idea 67: 0..100
    public int boardObjectiveType = 1;                  // idea 67: 0 avoid bottom, 1 playoffs, 2 title
    public String boardObjectiveText = "Reach the playoffs";
    public int boardObjectiveSeason = 1;                // season the objective applies to
    public int boardObjectiveResolved = -1;             // last season whose objective was judged
    public boolean sacked = false;                      // idea 68: career over — summary screen only
    public int managerXp = 0;                           // idea 69
    public int managerLevel = 1;                        // idea 69: cached level (perks read this)
    public boolean legendBonusPaid = false;             // idea 69: the L10 +500 CF is paid once
    public int freeScoutSeason = -1;                    // idea 69: season the L3 free scout was used
    public int fanMood = 65;                            // idea 70: 0..100
    public int fanLossStreak = 0;                       // idea 70: consecutive losses (mood drag)
    // ---- Batch H (ideas 71–80): news & immersion state ----
    public JSONArray fanPosts = new JSONArray();        // idea 73: {name, handle, text, mood}, newest first, cap 30
    public JSONObject pressConf = null;                 // idea 71: pending conference {q, won, opp, comp, star, season, day}
    public int pressBoost = 0;                          // idea 71: Fiery charges waiting for the next match
    public int lastHeadlineTpl = -1;                    // idea 72: last headline template id (never twice in a row)
    public JSONObject lastReport = null;                // idea 77: last finished user match's report data
    public String coachTipText = "";                    // idea 74: today's cached tip
    public String coachTipKey = "";                     // idea 74: today's tip id
    public int coachTipSeason = -1, coachTipDay = -1;   // idea 74: when the cache was made
    public String lastTipKey = "";                      // idea 74: yesterday's tip id (rotation)
    public JSONObject seasonBestBat = null;             // idea 76: {name, runs, balls, text}
    public JSONObject seasonBestBowl = null;            // idea 76: {name, wkts, conc, text}
    public JSONObject seasonBigWin = null;              // idea 76: {val, text}
    public JSONObject seasonFanMoment = null;           // idea 76: {score, text}
    // ---- Batch I (ideas 81–90): modes & challenges state ----
    public int difficulty = 1;                          // idea 81: 0 Casual, 1 Manager, 2 Legend
    public boolean hardcore = false;                    // idea 90: stricter sack line, no undo, halved mode rewards
    public boolean hardcoreCounted = false;             // idea 90: this career's sack is in the persistent record
    public String lastChallengeDate = "";               // idea 82: real date (yyyy-MM-dd) of the last attempt
    public String challengePaidDate = "";               // idea 82: real date whose challenge win was paid
    public String challengeResult = "";                 // idea 82: "W"/"L" of the last finished challenge
    public int challengeStreak = 0;                     // idea 82: current challenge win streak
    public int challengeWins = 0;                       // idea 82: total challenge wins
    public JSONObject scenarios = new JSONObject();     // idea 83: id -> {done, margin, summary, wins}
    public int questWeekKey = -1;                       // idea 84: season*10+week of the live quest set
    public JSONArray quests = new JSONArray();          // idea 84: {type, text, target, progress, done}
    public JSONObject achievements = new JSONObject();  // idea 85: key -> {season, day}
    public JSONObject prediction = null;                // idea 86: pending picks for the next user tie
    public int predSettled = 0, predWins = 0, predBoth = 0; // idea 86: prediction record
    public boolean undoArmed = false;                   // idea 87: autoslot restore still available
    public int seasonHomeWins = 0;                      // idea 85: Fortress counter (per season)
    public int transferSpendSeason = 0;                 // idea 85: Big Spender counter (per season)
    public String captainSeasonStart = "";              // idea 85: Loyal — captain when the season began
    public boolean captainChangedSeason = false;        // idea 85: Loyal — a user-initiated change breaks it
    public Random rng = new Random();

    public static final int TRAVEL_COST = 50;
    public static final int PRESEASON_CHARGE = 200;
    public static final int RESTED_REGEN = 12;
    public static final int BREAK_REGEN = 6;
    // Batch D constants
    public static final int SQUAD_CAP = 22;
    public static final int SCOUT_COST = 40;
    public static final int RELEASE_FEE_WINDOW = 25;
    public static final int LOAN_IN_FEE = 30;
    public static final int WINDOW_OPEN_DAY = 13;
    public static final int WINDOW_CLOSE_DAY = 15;
    public static final int WINDOW_MAX_SIGNINGS = 2;
    public static final int DERBY_WIN_BONUS = 150; // Batch F (idea 58): +50% of the 300 CF win prize
    // Batch G constants
    public static final String[] STAFF_ROLES = {"Head Coach", "Batting Coach", "Bowling Coach", "Physio", "Scout"};
    public static final String[][] STAFF_NAMES = {
            {"Imran Khattak", "Shahid Mehmood", "Carlos Mendes", "Adeel Rana", "Graham Ellis"},
            {"Yasir Hameed", "Rohan Patel", "Faisal Iqbal", "Miguel Santos", "Tom Becker"},
            {"Wasim Javed", "Nathan Cole", "Haroon Rasheed", "Pieter Vos", "Sanjay Rao"},
            {"Dr. Nadia Khan", "Dr. Peter Shaw", "Dr. Ali Raza", "Sara Lindqvist", "Dr. Imran Sheikh"},
            {"Bilal Chaudhry", "George Mathews", "Arjun Mehta", "Kashif Nawaz", "Diego Fuentes"}};
    public static final String[] TICKET_TIERS = {"Cheap", "Standard", "Premium", "Expensive", "Premium Plus"};
    public static final double[] TICKET_MULT = {0.8, 1.0, 1.2, 1.4, 1.6};
    public static final int[] TICKET_ATT = {4, 0, -5, -10, -15};
    public static final String[] SPONSOR_BRANDS = {"Chakwal Chai Co.", "Sargodha Citrus Fresh", "Punjab Pulao House",
            "Desi Dukaan", "Noor Travels", "Kissan Tractor Parts", "Lahore Lassi Lab", "Multan Mango Co."};
    public static final String[] CAMP_NAMES = {"Batting Camp", "Bowling Camp", "Fitness Camp", "Fielding Camp"};
    public static final int CAMP_COST = 100;
    public static final int[] XP_THRESHOLDS = {0, 150, 325, 525, 750, 1000, 1275, 1575, 1900, 2250}; // index = level-1
    public static final String[] PERK_TEXT = {
            "L2 — Training Complex upgrades cost 10% less",
            "L3 — One free scouting report every season",
            "L4 — Gate income +5%",
            "L5 — Team Talk gives +2 extra morale",
            "L6 — Auction rivals bid less aggressively (their max bids −8%)",
            "L7 — Academy prospects arrive +1 quality",
            "L8 — The weekly wage bill is 5% cheaper",
            "L9 — +10 board confidence at the start of every season",
            "L10 — LEGEND status: badge + 500 CF (one-off)"};

    // ---------------- lifecycle ----------------

    public static Game fresh() {
        return freshForTeam(Data.USER_TEAM);
    }

    /** Batch F (idea 51): a new career managing ANY of the 8 league clubs.
     *  The squad is that club's full 18 (Data.squadFor) with its legal
     *  default XI and named captain; the club simply occupies its existing
     *  group slot, so fixtures/tables need no special-casing at all. */
    public static Game freshForTeam(String team) {
        return freshInternal(team, false, "", 0);
    }

    /** Batch F (idea 52): a custom club. The robust route: the custom club
     *  takes LAHORE'S slot (group, fixtures, rival) and rebrands Lahore's
     *  squad — the players keep their names, only the club identity is new. */
    public static Game freshCustom(String name, String code, int color) {
        return freshInternal(name, true, code, color);
    }

    private static Game freshInternal(String team, boolean custom, String code, int color) {
        Game g = new Game();
        try {
            g.userTeam = team;
            g.customTeam = custom;
            g.customCode = code == null ? "" : code;
            g.customColor = color;
            Object[][] squad = Data.squadFor(custom ? Data.USER_TEAM : team);
            for (Object[] p : squad) {
                JSONObject o = new JSONObject();
                o.put("name", p[0]);
                o.put("role", p[1]);
                o.put("bat", p[2]);
                o.put("bowl", p[3]);
                o.put("stam", 88 + g.rng.nextInt(12));
                o.put("set", 55 + g.rng.nextInt(30));
                o.put("overseas", (Boolean) p[4]);
                o.put("rested", false);
                o.put("inXI", Data.inTeamXi(team, (String) p[0]));
                ensurePlayerMeta(o); // Batch C: age/pot/morale/tags/stats defaults
                g.players.put(o);
            }
            for (int i = 0; i < 5; i++) g.facilities.put(1);
            g.career.put("played", 0).put("won", 0).put("lost", 0)
                    .put("streak", 0).put("best", 0).put("titles", 0).put("cups", 0);
            g.captain = Data.captainFor(team); // Batch F: each club's named skipper
            g.captainSeasonStart = g.captain; // Batch I (idea 85): the Loyal watch starts here
            // a custom club plays at strength 82, so it starts at exactly 1000 CF
            g.cf = custom ? 1000 : startingCfFor(team);
            g.genFaPool();   // Batch D (idea 37)
            g.genLoanList(); // Batch D (idea 36)
            g.seedWorldState(); // Batch F (idea 54)
            g.genStaffCandidates(); // Batch G (idea 61)
            g.setBoardObjective();  // Batch G (idea 67): the Season 1 brief
            g.resetSeasonTablesAndFixtures();
            g.ensureQuests(); // Batch I (idea 84): Season 1 Week 1 quests from day one
            g.pushLedger(g.cf, "Opening balance");
            g.addNews("Welcome to " + team + "! Season 1 begins. Pick your XI and play your first match.");
            g.addNews("Board: win matches to earn Club Cash (CF) and upgrade HQ facilities.");
        } catch (Exception ignored) {}
        return g;
    }

    // ---- Batch F club identity helpers (ideas 51/52) ----

    /** Starting Club Cash for a fresh career: stronger clubs start a touch
     *  richer in squad value but the board balances it — CF =
     *  1000 + (strength - 82) x 50, so Lahore 1200, Hyderabad 700, a custom
     *  club (strength 82) exactly 1000. Shown on the team-picker cards. */
    public static int startingCfFor(String team) {
        return 1000 + (Data.teamStrength(team) - 82) * 50;
    }

    /** The 8 league clubs as they exist in THIS career: a custom club
     *  substitutes for Lahore Qalandars in its group. */
    public String[] groupA() { return substituteTeam(Data.GROUP_A); }
    public String[] groupB() { return substituteTeam(Data.GROUP_B); }

    private String[] substituteTeam(String[] grp) {
        if (!customTeam) return grp;
        String[] out = grp.clone();
        for (int i = 0; i < out.length; i++) if (Data.USER_TEAM.equals(out[i])) out[i] = userTeam;
        return out;
    }

    public String[] allTeams() {
        String[] a = groupA(), b = groupB();
        String[] out = new String[a.length + b.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }

    public boolean isUserTeam(String team) { return userTeam.equals(team); }

    /** Effective strength: a custom club plays at 82 (a solid mid-table side). */
    public int strengthFor(String team) {
        if (customTeam && userTeam.equals(team)) return 82;
        return Data.teamStrength(team);
    }

    /** Short code: the custom club's chosen code, else the static table. */
    public String shortFor(String team) {
        if (customTeam && userTeam.equals(team)) {
            if (!customCode.isEmpty()) return customCode;
            return team.substring(0, Math.min(3, team.length())).toUpperCase();
        }
        return Data.shortName(team);
    }

    /** Badge tint: the custom club's colour, else the app's gold. Returned
     *  as a raw argb int so this class stays Android-free for the tests. */
    public int teamColor() {
        return customTeam && customColor != 0 ? customColor : 0xFFF59E0B;
    }

    // ---- Batch I (idea 81): the ONE difficulty helper set. Every affected
    // system reads these — prizes, wages, board falls, XP, auction heat
    // and AI strength (live cards in MatchEngine, sims via simStrength). ----
    public static final String[] DIFF_NAMES = {"Casual", "Manager", "Legend"};

    /** AI effective-strength shift: Casual softens opponents, Legend sharpens them. */
    public int aiDelta() { return difficulty == 0 ? -4 : difficulty == 2 ? 4 : 0; }

    /** Prize multiplier: Casual pays +25%, Legend trims 15%. */
    public double prizeMult() { return difficulty == 0 ? 1.25 : difficulty == 2 ? 0.85 : 1.0; }

    /** A CF prize after the difficulty multiplier. */
    public int prize(int base) { return (int) Math.round(base * prizeMult()); }

    /** A board-confidence delta after difficulty: only FALLS are bent —
     *  Casual halves them (rounded toward zero), Legend cuts them x4/3,
     *  so a Legend match loss (-3) lands as -4. Gains pass through. */
    public int boardDeltaFor(int d) {
        if (d >= 0 || difficulty == 1) return d;
        if (difficulty == 0) return -((-d + 1) / 2);
        return d * 4 / 3;
    }

    /** Team strength as the quick-sims should see it: the user's own club
     *  is never bent; every AI club shifts by aiDelta(). */
    public int simStrength(String team) {
        return strengthFor(team) + (userTeam.equals(team) ? 0 : aiDelta());
    }

    /** Batch I (idea 90): challenge/scenario rewards are halved in hardcore. */
    public int modeReward(int base) { return hardcore ? base / 2 : base; }

    /** Difficulty changes ONLY between seasons (the off-season phase) —
     *  mid-season requests are refused with a note. New careers pick on
     *  the team picker instead (MainActivity.pickerDifficulty). */
    public String setDifficulty(int d) {
        if (d < 0 || d > 2) return "Unknown difficulty.";
        if (d == difficulty) return "Already playing on " + DIFF_NAMES[d] + ".";
        if (offseason == 0) return "Difficulty can only be changed between seasons — finish Season "
                + season + " first, then change it in Profile during the off-season.";
        difficulty = d;
        addNews("⚙ Difficulty set to " + DIFF_NAMES[d] + " for Season " + season + ".");
        return "Difficulty set to " + DIFF_NAMES[d] + " for Season " + season + ".";
    }

    public void resetSeasonTablesAndFixtures() {
        try {
            tables = new JSONObject();
            for (String t : groupA()) tables.put(t, emptyRow());
            for (String t : groupB()) tables.put(t, emptyRow());
            fixtures = new JSONArray();
            String[][] groups = {groupA(), groupB()};
            int[][] pairs = {{0, 1}, {2, 3}, {0, 2}, {1, 3}, {0, 3}, {1, 2}};
            int d = 1;
            // 6 rounds; in each round every group plays both pairings -> 4 fixtures per round.
            // Home/away alternates by round, so Lahore has real away fixtures (incl. an early one)
            // from round 0: day 1 home vs Karachi, day 2 AWAY at Islamabad.
            for (int round = 0; round < 6; round++) {
                for (int gi = 0; gi < 2; gi++) {
                    for (int pi = 0; pi < 2; pi++) {
                        int[] pr = pairs[(round + pi * 3) % 6];
                        String home = groups[gi][pr[0]];
                        String away = groups[gi][pr[1]];
                        if (round >= 3) { String tmp = home; home = away; away = tmp; }
                        JSONObject f = new JSONObject();
                        f.put("day", d++);
                        f.put("home", home);
                        f.put("away", away);
                        f.put("played", false);
                        f.put("summary", "");
                        ensureFixtureMeta(f, season);
                        fixtures.put(f);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private JSONObject emptyRow() throws Exception {
        return new JSONObject().put("p", 0).put("w", 0).put("l", 0).put("pts", 0)
                .put("rf", 0).put("bf", 0).put("ra", 0).put("ba", 0);
    }

    // ---------------- Batch A: fixture conditions (ideas 2, 3, 4) ----------------

    /** Deterministic per-fixture conditions: pitch type, evening (dew) flag and
     *  rain risk %. Derived only from season/day/teams, so a v2 save that lacks
     *  them generates exactly the same values on every load. Fills only fields
     *  that are missing — never overwrites an existing fixture's conditions. */
    public static void ensureFixtureMeta(JSONObject f, int season) {
        try {
            // Batch F (idea 59): the ground comes from the HOME team alone,
            // so it fills deterministically even on v7 fixtures that already
            // carry pitch/evening/rain (which the early return below guards).
            if (!f.has("ground")) {
                f.put("ground", Data.groundName(f.optString("home")));
                f.put("groundChar", Data.groundChar(f.optString("home")));
            }
            if (f.has("pitch") && f.has("evening") && f.has("rain")) return;
            int h = (season * 31 + f.optInt("day") * 17
                    + f.optString("home").hashCode() + f.optString("away").hashCode()) & 0x7fffffff;
            if (!f.has("pitch")) f.put("pitch", h % 4);                 // Data.PITCH_TYPES index
            if (!f.has("evening")) f.put("evening", (h / 4) % 2 == 0); // ~half the fixtures are day/night
            if (!f.has("rain")) f.put("rain", 10 + (h / 8) % 40);      // 10–49% rain risk
        } catch (Exception ignored) {}
    }

    /** Batch A (idea 8): remember a Player of the Match for the Profile/history trail. */
    public void addPotm(String entry) {
        try {
            JSONArray n = new JSONArray();
            n.put(entry);
            for (int i = 0; i < Math.min(potmHistory.length(), 19); i++) n.put(potmHistory.getString(i));
            potmHistory = n;
        } catch (Exception ignored) {}
    }

    // ---------------- Club Cash ledger (v2) ----------------

    /** Records an entry WITHOUT changing the balance (used for the opening balance). */
    public void pushLedger(int amt, String reason) {
        try {
            JSONArray n = new JSONArray();
            JSONObject e = new JSONObject();
            e.put("season", season).put("day", day).put("amt", amt).put("reason", reason);
            n.put(e);
            for (int i = 0; i < Math.min(ledger.length(), 79); i++) n.put(ledger.getJSONObject(i));
            ledger = n;
        } catch (Exception ignored) {}
    }

    /** The ONLY way CF moves: changes the balance and writes the ledger entry together. */
    public void ledgerCf(int amt, String reason) {
        cf += amt;
        pushLedger(amt, reason);
    }

    /** Mandatory expense (travel / pre-season): charges up to the amount, never below zero,
     *  and ledgers the amount actually charged. Returns the amount charged (>= 0). */
    public int ledgerExpense(int amount, String reason) {
        int actual = Math.min(amount, Math.max(0, cf));
        if (actual > 0) ledgerCf(-actual, reason);
        return actual;
    }

    // ================= Batch G helpers (ideas 61–70) =================

    // ---- staff (idea 61) ----

    public JSONObject staffMember(String role) {
        return staff == null ? null : staff.optJSONObject(role);
    }

    public int staffRating(String role) {
        JSONObject s = staffMember(role);
        return s == null ? 0 : s.optInt("rating", 0);
    }

    public int staffWage(String role) {
        JSONObject s = staffMember(role);
        return s == null ? 0 : s.optInt("wage", 0);
    }

    public int staffWages() {
        int sum = 0;
        for (String r : STAFF_ROLES) sum += staffWage(r);
        return sum;
    }

    /** (Re)builds the 3-candidates-per-role market. Hired names are never
     *  offered, and no name appears twice in one market. */
    public void genStaffCandidates() {
        try {
            staffCandidates = new JSONArray();
            java.util.Set<String> used = new java.util.HashSet<>();
            for (String r : STAFF_ROLES) {
                JSONObject h = staffMember(r);
                if (h != null) used.add(h.optString("name"));
            }
            for (int ri = 0; ri < STAFF_ROLES.length; ri++) {
                List<String> names = new ArrayList<>();
                for (String n : STAFF_NAMES[ri]) if (!used.contains(n)) names.add(n);
                java.util.Collections.shuffle(names, rng);
                for (int k = 0; k < 3 && k < names.size(); k++) {
                    int rating = 60 + rng.nextInt(36); // 60..95
                    if (k == 0) rating = Math.max(rating, 78 + rng.nextInt(18)); // one strong option per role
                    int wage = Math.max(3, 3 + (rating - 58) / 3 + (ri == 0 ? 3 : ri == 3 ? 2 : ri == 4 ? 1 : 0) + rng.nextInt(3));
                    JSONObject c = new JSONObject();
                    c.put("role", STAFF_ROLES[ri]).put("name", names.get(k)).put("rating", rating).put("wage", wage);
                    staffCandidates.put(c);
                    used.add(names.get(k));
                }
            }
        } catch (Exception ignored) {}
    }

    public JSONObject staffCandidate(int idx) {
        return (idx < 0 || idx >= staffCandidates.length()) ? null : staffCandidates.optJSONObject(idx);
    }

    /** Hires candidate idx: signing fee = 2x his weekly wage, via the ledger. */
    public String hireStaff(int idx) {
        JSONObject c = staffCandidate(idx);
        if (c == null) return "That candidate is gone.";
        String role = c.optString("role");
        if (staffMember(role) != null) return role + " is filled — fire the current holder first.";
        int fee = 2 * c.optInt("wage");
        if (cf < fee) return "Not enough CF — the signing fee is " + fee + " CF.";
        try {
            JSONObject s = new JSONObject();
            s.put("name", c.optString("name")).put("rating", c.optInt("rating")).put("wage", c.optInt("wage"));
            staff.put(role, s);
            ledgerCf(-fee, "Staff signing fee — " + s.optString("name") + " (" + role + ")");
            addNews("STAFF: " + s.optString("name") + " joins as " + role + " (rating " + s.optInt("rating")
                    + ", " + s.optInt("wage") + " CF/week).");
            return s.optString("name") + " hired as " + role + ".";
        } catch (Exception e) {
            return "Hiring failed.";
        }
    }

    /** Firing is free; the role simply falls vacant. */
    public String fireStaff(String role) {
        JSONObject s = staffMember(role);
        if (s == null) return "Nobody holds that role.";
        staff.remove(role);
        addNews("STAFF: " + s.optString("name") + " leaves the " + role + " post.");
        return s.optString("name") + " released.";
    }

    /** Deterministic per-player coach coverage: a coach rated R gives the
     *  +1 to roughly R% of the squad (hashed by name), so a better coach
     *  visibly covers more players. Used by MatchEngine for both the
     *  Batting and Bowling Coach. */
    public int coachBonusFor(String role, String playerName) {
        int r = staffRating(role);
        if (r <= 0 || playerName == null || playerByName(playerName) == null) return 0;
        int h = Math.abs((playerName + "|" + role).hashCode() % 100);
        return h < r ? 1 : 0;
    }

    /** Batting/Bowling Coach strength as a 0..1 double (tests + UI). */
    public double coachStrength(String role) {
        return staffRating(role) / 100.0;
    }

    // Physio (idea 61): chance/length/healing all scale with his rating.
    public double physioInjuryMult() {
        int r = staffRating("Physio");
        return r <= 0 ? 1.0 : 1.0 - r / 250.0;
    }

    public int physioDays(int rawDays) {
        int r = staffRating("Physio");
        if (r <= 0) return rawDays;
        return Math.max(2, (int) Math.round(rawDays * (1.0 - r * 0.003)));
    }

    public int physioHealStep() {
        return staffRating("Physio") >= 85 ? 2 : 1;
    }

    public int physioRecoveryBonus() {
        int r = staffRating("Physio");
        return r >= 70 ? 3 : r > 0 ? 2 : 0;
    }

    // Scout (idea 61): fee discount + narrower POT ranges.
    public int scoutCost() {
        if (managerLevel >= 3 && freeScoutSeason != season) return 0; // L3 perk first
        int r = staffRating("Scout");
        if (r <= 0) return SCOUT_COST;
        return Math.max(28, (int) Math.round(SCOUT_COST * (1.0 - r * 0.003)));
    }

    public int potRangeWidth() {
        int r = staffRating("Scout");
        if (r >= 90) return 4;
        if (r >= 75) return 6;
        if (r > 0) return 8;
        return 10;
    }

    public int potRangeLowFor(String name, int pot) {
        int w = potRangeWidth();
        if (w >= 10) return potRangeLow(name, pot);
        int low = pot - w / 2 + Math.abs(name.hashCode() % 3);
        return Math.max(40, Math.min(low, pot));
    }

    /** A small quality lift for free agents who surface while a good
     *  Scout is employed (idea 61: better pool quality). */
    public void applyScoutBoost(JSONObject p) {
        try {
            int r = staffRating("Scout");
            if (r < 75 || p == null) return;
            int boost = r >= 90 ? 3 : 2;
            p.put("bat", Math.min(95, p.optInt("bat") + boost));
            p.put("bowl", Math.min(95, p.optInt("bowl") + boost));
            p.put("pot", Math.min(99, p.optInt("pot", rating(p)) + boost));
            refreshWage(p);
        } catch (Exception ignored) {}
    }

    // ---- tickets (idea 63) ----

    public String ticketTierName() { return TICKET_TIERS[ticketTier]; }

    public double ticketMultiplier() { return TICKET_MULT[ticketTier]; }

    public int ticketAttendanceShift() { return TICKET_ATT[ticketTier]; }

    /** Changes the tier; Fan Mood reacts to the move (idea 70): each tier
     *  stepped ABOVE Standard costs 2 mood, stepping back down refunds
     *  it, and landing on Cheap pleases the fans (+2). */
    public void setTicketTier(int tier) {
        tier = clamp(tier, 0, 4);
        if (tier == ticketTier) return;
        int oldAbove = Math.max(0, ticketTier - 1), newAbove = Math.max(0, tier - 1);
        adjustFanMood(-2 * (newAbove - oldAbove));
        if (tier == 0) adjustFanMood(2);
        ticketTier = tier;
        addNews("Tickets set to " + TICKET_TIERS[tier] + " (gate x" + TICKET_MULT[tier] + ").");
    }

    public String ticketLine(JSONObject f) {
        return "Tickets: " + ticketTierName() + " — expect ~" + expectedAttendance(f) + "% crowd";
    }

    // ---- fan mood (idea 70) ----

    public void adjustFanMood(int delta) {
        fanMood = clamp(fanMood + delta, 0, 100);
    }

    public String fanMoodLabel() {
        if (fanMood < 20) return "Furious";
        if (fanMood < 40) return "Unhappy";
        if (fanMood < 60) return "Content";
        if (fanMood < 85) return "Happy";
        return "Ecstatic";
    }

    public int fanAttendanceShift() {
        if (fanMood >= 80) return 8;
        if (fanMood < 35) return -10;
        return 0;
    }

    /** A star through the door lifts the fanbase (idea 70). */
    public void noteStarSigning(JSONObject p) {
        if (p != null && rating(p) >= 85) {
            adjustFanMood(4);
            addNews("The fans are buzzing — star signing " + p.optString("name") + " (rating " + rating(p) + ") lifts the mood!");
            fanEventPost("signing", p.optString("name")); // Batch H (idea 73)
        }
    }

    // ---- board confidence + objective (ideas 67/68) ----

    public void adjustBoardConfidence(int delta) {
        int before = boardConfidence;
        // Batch I (idea 81): difficulty bends every FALL centrally — Casual
        // halves losses, Legend cuts them a third deeper; gains untouched.
        delta = boardDeltaFor(delta);
        boardConfidence = clamp(boardConfidence + delta, 0, 100);
        int warnAt = hardcore ? 40 : 25; // Batch I (idea 90): hardcore warns earlier
        if (before >= warnAt && boardConfidence < warnAt) {
            addNews("⚠ BOARD WARNING: confidence has fallen to " + boardConfidence
                    + " — the board is losing patience. Results must improve, fast.");
            fanEventPost("sackwarn", ""); // Batch H (idea 73): the fans hear about it too
        }
    }

    public boolean boardWarning() { return boardConfidence < (hardcore ? 40 : 25); }

    /** Professional Pack P2 (suggestion 11): the Hub's Squad Alert
     *  conditions, as display lines — pure state checks, no UI. The
     *  card exists on the Hub ONLY when this returns a non-empty list.
     *  Sources: the board warning (idea 67), an illegal team sheet
     *  (xiProblems, in-season only — an off-season squad is mid-rebuild
     *  by design), an injured man still named in the XI, a starter
     *  running on empty (stamina < 40, the Coach's Corner threshold),
     *  a live poach offer (idea 40) and a pending press conference
     *  (idea 71). */
    public List<String> hubAlerts() {
        List<String> out = new ArrayList<>();
        if (boardWarning()) {
            out.add("THE BOARD IS LOSING PATIENCE — confidence is " + boardConfidence
                    + "/100. End the season under " + sackThreshold() + " and you are SACKED. Win matches — starting now.");
        }
        if (offseason == 0) {
            List<String> problems = xiProblems();
            if (!problems.isEmpty()) {
                out.add("Team sheet blocked: " + problems.get(0)
                        + (problems.size() > 1 ? " (+" + (problems.size() - 1) + " more — fix it in the Team tab)" : ""));
            }
        }
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            if (!p.optBoolean("inXI")) continue;
            if (p.optInt("injured", 0) > 0) {
                out.add(p.optString("name") + " is INJURED (" + p.optInt("injured")
                        + " day(s) out) but still named in your XI.");
            } else if (p.optInt("stam") < 40) {
                out.add(p.optString("name") + " is running on empty — stamina "
                        + p.optInt("stam") + ". Rest or rotate him before the next match.");
            }
        }
        if (poachOffer != null) {
            out.add(poachOffer.optString("team") + " have bid " + poachOffer.optInt("fee")
                    + " CF for " + poachOffer.optString("name") + " — decide below or in Transfers before Day "
                    + poachOffer.optInt("expDay") + ".");
        }
        if (pressConf != null) {
            out.add("The press are waiting — a press conference is pending. Answer it below; it expires when the day advances.");
        }
        return out;
    }

    /** Batch I (idea 90): the season-end sack line — 10 normally, a much
     *  stricter 20 in a hardcore career. */
    public int sackThreshold() { return hardcore ? 20 : 10; }

    /** Average rating of the strongest 11 — the board judges the squad,
     *  not the badge, when it sets the season's objective. */
    public int squadStrengthTop11() {
        List<Integer> rs = new ArrayList<>();
        for (int i = 0; i < players.length(); i++) rs.add(rating(player(i)));
        java.util.Collections.sort(rs, java.util.Collections.reverseOrder());
        if (rs.isEmpty()) return 0;
        int sum = 0, n = Math.min(11, rs.size());
        for (int i = 0; i < n; i++) sum += rs.get(i);
        return sum / n;
    }

    public void setBoardObjective() {
        int s = squadStrengthTop11();
        if (s >= 80) { boardObjectiveType = 2; boardObjectiveText = "Win the league title"; }
        else if (s >= 72) { boardObjectiveType = 1; boardObjectiveText = "Reach the playoffs"; }
        else { boardObjectiveType = 0; boardObjectiveText = "Avoid bottom place in the group"; }
        boardObjectiveSeason = season;
    }

    /** The user's final group position (1..4) from the CURRENT tables. */
    public int userGroupPosition() {
        String[] grp = groupA();
        for (String t : groupB()) if (userTeam.equals(t)) grp = groupB();
        List<String> sorted = sortedGroup(grp);
        int i = sorted.indexOf(userTeam);
        return i < 0 ? 4 : i + 1;
    }

    public boolean boardObjectiveMet() {
        if (boardObjectiveType == 2) return userTeam.equals(seasonChampion) || userTeam.equals(pointsLeader());
        if (boardObjectiveType == 1) return userGroupPosition() <= 2;
        return userGroupPosition() < 4; // avoid bottom
    }

    /** Judges the ending season: bottom place and the board objective
     *  itself. (Qualification +8 / missing out −8 already landed when
     *  the bracket was set in beginPlayoffs — never counted twice.)
     *  Runs at rollover BEFORE the tables are reset; guarded so it can
     *  only fire once per season. */
    public void evaluateBoardSeasonEnd() {
        if (boardObjectiveResolved == season) return;
        boardObjectiveResolved = season;
        if (userGroupPosition() >= 4) adjustBoardConfidence(-10);
        if (boardObjectiveSeason == season) {
            if (boardObjectiveMet()) {
                adjustBoardConfidence(10);
                ledgerCf(200, "Board objective bonus — " + boardObjectiveText);
                addNews("BOARD: objective met (" + boardObjectiveText + ") — +200 CF bonus and confidence is up.");
            } else {
                adjustBoardConfidence(-10);
                addNews("BOARD: objective missed (" + boardObjectiveText + ") — confidence takes a hit.");
            }
        }
    }

    // ---- manager XP & levels (idea 69) ----

    public static int levelForXp(int xp) {
        int lvl = 1;
        for (int i = 0; i < XP_THRESHOLDS.length; i++) if (xp >= XP_THRESHOLDS[i]) lvl = i + 1;
        return lvl;
    }

    public int xpForNextLevel() {
        return managerLevel >= 10 ? XP_THRESHOLDS[9] : XP_THRESHOLDS[managerLevel];
    }

    public void addManagerXp(int xp) {
        if (xp <= 0) return;
        if (difficulty == 2) xp = Math.max(1, (int) Math.round(xp * 1.25)); // Batch I (idea 81): Legend pays +25% XP
        managerXp += xp;
        int nl = levelForXp(managerXp);
        if (nl > managerLevel) {
            managerLevel = nl;
            addNews("MANAGER LEVEL UP: you are now a Level " + nl + " manager! Perk unlocked: "
                    + (nl >= 2 && nl <= 10 ? PERK_TEXT[nl - 2] : ""));
            if (nl >= 10 && !legendBonusPaid) {
                legendBonusPaid = true;
                ledgerCf(500, "Legend manager bonus — Level 10 reached");
            }
        }
        // Batch I (idea 85): the Legend Manager badge rides the same crossing
        if (managerLevel >= 10) unlockAchievement("LEGENDMGR");
    }

    // ---- sponsorship (idea 64) ----

    /** Builds the 3 off-season deals: one of each objective type, brands
     *  shuffled, money scaled a little by the season number. */
    public void genSponsorOffers() {
        try {
            sponsorOffers = new JSONArray();
            List<String> brands = new ArrayList<>();
            for (String b : SPONSOR_BRANDS) brands.add(b);
            java.util.Collections.shuffle(brands, rng);
            int[][] money = {{170, 14}, {230, 18}, {290, 22}}; // {lump, weekly} per objective tier below
            int[] types = {0, 1, 2};
            int[] bonuses = {300, 600, 150};
            String[] texts = {"Reach the playoffs", "Win the league title", "Score 200+ in 3 matches"};
            for (int i = 0; i < 3; i++) {
                JSONObject d = new JSONObject();
                d.put("brand", brands.get(i));
                d.put("lump", money[i][0] + (season - 1) * 10);
                d.put("weekly", money[i][1]);
                d.put("objType", types[i]);
                d.put("objText", texts[i]);
                d.put("bonus", bonuses[i]);
                sponsorOffers.put(d);
            }
        } catch (Exception ignored) {}
    }

    /** Picks offer 0..2, or 3 = the safe "No sponsor" board grant. */
    public String chooseSponsor(int idx) {
        try {
            if (idx == 3) {
                sponsor = new JSONObject().put("brand", "Board Grant (No sponsor)")
                        .put("lump", 50).put("weekly", 5).put("objType", -1).put("objText", "").put("bonus", 0);
            } else {
                if (idx < 0 || idx >= sponsorOffers.length()) return "That deal is gone.";
                sponsor = new JSONObject(sponsorOffers.getJSONObject(idx).toString());
            }
            sponsorOffers = new JSONArray();
            sponsorProgress = 0;
            sponsorDone = false;
            sponsorLegacy = false;
            int lump = sponsor.optInt("lump");
            if (lump > 0) ledgerCf(lump, "Sponsor signing — " + sponsor.optString("brand"));
            addNews("SPONSOR: " + sponsor.optString("brand") + " sign on (" + lump + " CF up front, "
                    + sponsor.optInt("weekly") + " CF/week"
                    + (sponsor.optInt("objType") >= 0
                        ? "; objective: " + sponsor.optString("objText") + " for +" + sponsor.optInt("bonus") + " CF" : "") + ").");
            return sponsor.optString("brand") + " it is!";
        } catch (Exception e) {
            return "Deal failed.";
        }
    }

    /** The objective pays out exactly once: bonus via the ledger, board
     *  +5, manager +15 XP, and the news carries it. */
    public void completeSponsorObjective() {
        if (sponsor == null || sponsorDone || sponsor.optInt("objType", -1) < 0) return;
        sponsorDone = true;
        ledgerCf(sponsor.optInt("bonus"), "Sponsor objective bonus — " + sponsor.optString("brand")
                + ": " + sponsor.optString("objText"));
        adjustBoardConfidence(5);
        addManagerXp(15);
        addNews("SPONSOR OBJECTIVE HIT: " + sponsor.optString("objText") + " — "
                + sponsor.optString("brand") + " pay the +" + sponsor.optInt("bonus") + " CF bonus!");
    }

    public void noteSponsorTeamScore(int runs) {
        if (sponsor == null || sponsorDone || sponsor.optInt("objType", -1) != 2) return;
        if (runs >= 200) {
            sponsorProgress++;
            if (sponsorProgress >= 3) completeSponsorObjective();
        }
    }

    public String sponsorLine() {
        if (sponsorLegacy) return "Standard sponsor deal — in place until your first sponsor pick at the next season break.";
        if (sponsor == null) return sponsorOffers.length() > 0 ? "Sponsor deals are on the table — pick one in HQ!" : "No sponsor this season.";
        String s = sponsor.optString("brand") + " — " + sponsor.optInt("weekly") + " CF/week";
        if (sponsor.optInt("objType", -1) >= 0) {
            s += sponsorDone ? " · objective DONE ✓" : " · objective: " + sponsor.optString("objText")
                    + (sponsor.optInt("objType") == 2 ? " (" + sponsorProgress + "/3)" : "")
                    + " → +" + sponsor.optInt("bonus") + " CF";
        }
        return s;
    }

    // ---- training camp (idea 66) ----

    public String chooseCamp(int focus) {
        if (!campPending) return "No camp is on offer right now.";
        if (focus < 0 || focus > 3) { skipCamp(); return "Camp skipped."; }
        if (cf < CAMP_COST) return "Not enough CF — the camp costs " + CAMP_COST + " CF (or Skip it free).";
        campChoice = focus;
        campPending = false;
        campMatchesUsed = 0;
        ledgerCf(-CAMP_COST, "Pre-season training camp — " + CAMP_NAMES[focus]);
        if (focus == 2) {
            try {
                for (int i = 0; i < players.length(); i++) player(i).put("stam", 100);
            } catch (Exception ignored) {}
        }
        addNews("TRAINING CAMP: the squad drilled " + CAMP_NAMES[focus] + " all week — the boost is live for the early season.");
        return CAMP_NAMES[focus] + " booked!";
    }

    public void skipCamp() {
        campChoice = 4;
        campPending = false;
    }

    /** Batting/Bowling camps: live for the first 8 user matches. */
    public boolean campDisciplineActive(int focus) {
        return campChoice == focus && campSeason == season && campMatchesUsed < 8;
    }

    public int campBatBonus() { return campDisciplineActive(0) ? 1 : 0; }

    public int campBowlBonus() { return campDisciplineActive(1) ? 1 : 0; }

    /** Fitness/Fielding camps: live through the first half (Day 12). */
    public boolean campHalfActive(int focus) {
        return campChoice == focus && campSeason == season && day <= 12;
    }

    public String campLine() {
        if (campPending) return "Pre-season camp: pick a focus in HQ (100 CF) or skip it free.";
        if (campChoice == 0 && campDisciplineActive(0)) return "🏕 Batting Camp boost active (" + (8 - campMatchesUsed) + " matches left)";
        if (campChoice == 1 && campDisciplineActive(1)) return "🏕 Bowling Camp boost active (" + (8 - campMatchesUsed) + " matches left)";
        if (campChoice == 2 && campHalfActive(2)) return "🏕 Fitness Camp: injury risk halved until Day 12";
        if (campChoice == 3 && campHalfActive(3)) return "🏕 Fielding Camp: sharper run-outs until Day 12";
        return "";
    }

    // ---- merchandise (idea 65) ----

    /** 10..60 CF: the crowd that came, the stars they came to see, and
     *  whether they went home happy. */
    public int merchandiseFor(JSONObject fixture, int attendance, boolean won) {
        int top = 0, second = 0, third = 0, stars = 0;
        for (int i = 0; i < players.length(); i++) {
            int r = rating(player(i));
            if (r >= 90) stars++;
            if (r > top) { third = second; second = top; top = r; }
            else if (r > second) { third = second; second = r; }
            else if (r > third) third = r;
        }
        double avg = (top + second + third) / 3.0;
        double amt = 8 + attendance * 0.25 + Math.max(0, avg - 75) * 0.5 + stars * 3 + (won ? 8 : 0)
                + (fixture != null && isDerby(fixture) ? 4 : 0);
        if (fanMood >= 85) amt *= 1.25;
        return clamp((int) Math.round(amt), 10, 60);
    }

    // ---- facilities (idea 62): numeric benefits + tier names ----

    public String facilityTier(int lvl) {
        if (lvl >= 10) return "World Class";
        if (lvl >= 7) return "Excellent";
        if (lvl >= 4) return "Good";
        return "Basic";
    }

    /** Numeric benefit of facility idx at a given level (current/next). */
    public String facilityBenefit(int idx, int lvl) {
        switch (idx) {
            case 0: return "Base crowd " + (38 + 7 * lvl) + "% · gate base " + (150 + 90 * lvl) + " CF at a full house";
            case 1: return "Recovery +" + recoveryGainFor(lvl) + " stamina for " + recoveryCostFor(lvl)
                    + " CF · new injuries shortened by " + (lvl - 1) + " day(s)";
            case 2: return "Every upgrade gives the whole squad +1 bat and +1 bowl (applied on upgrade)";
            case 3: return lvl >= 2 ? "A prospect joins each rollover at +" + academyQualityBonusFor(lvl) + " quality"
                    : "Reaches Level 2 to unlock a youth prospect every rollover";
            case 4: return (sponsorLegacy ? "Sponsor income " + (25 * lvl) + " CF every 3 days (legacy rate)"
                    : "Commercial income " + (10 * lvl) + " CF every 3 days");
            default: return "";
        }
    }

    public int recoveryGainFor(int medLvl) { return 10 + 5 * medLvl; }

    public int recoveryCostFor(int medLvl) { return Math.max(5, 30 - 5 * (medLvl - 1)); }

    public int academyQualityBonusFor(int acadLvl) {
        return Math.max(0, acadLvl - 2) + (managerLevel >= 7 ? 1 : 0);
    }

    public int facilityUpgradeCost(int idx) {
        int lvl = facilityLevel(idx);
        int cost = Data.FACILITY_BASE_COST[idx] * lvl;
        if (idx == 2 && managerLevel >= 2) cost = (int) Math.round(cost * 0.9); // L2 perk
        return cost;
    }

    // ---- finances (Batch G): this season's ledger, categorised ----

    public static String financeCategory(String reason) {
        String r = reason == null ? "" : reason.toLowerCase();
        if (r.contains("merchandise")) return "merch";
        if (r.startsWith("gate receipts")) return "gate";
        if (r.contains("sponsor") || r.contains("commercial centre")) return "sponsor";
        if (r.contains("wages")) return "wages";
        if (r.contains("upgrade to level")) return "upgrades";
        if (r.contains("signing") || r.contains("auction") || r.startsWith("transfer")
                || r.contains("contract renewal") || r.contains("release settlement") || r.contains("loan-in")) return "transfers";
        if (r.contains("prize") || r.contains("bonus") || r.contains("appearance fee")
                || r.contains("champions") || r.contains("runners-up") || r.contains("winners")) return "prizes";
        return "other";
    }

    /** Totals for the CURRENT season only; the categories always sum to
     *  "total", and the wage split comes from the fields stored on the
     *  wage entries themselves. */
    public JSONObject financeTotals() {
        JSONObject t = new JSONObject();
        try {
            String[] keys = {"prizes", "gate", "merch", "sponsor", "wages", "transfers", "upgrades", "other"};
            for (String k : keys) t.put(k, 0);
            t.put("total", 0).put("playerWages", 0).put("staffWages", 0).put("wageDiscount", 0);
            for (int i = 0; i < ledger.length(); i++) {
                JSONObject e = ledger.optJSONObject(i);
                if (e == null || e.optInt("season") != season) continue;
                int amt = e.optInt("amt");
                String cat = financeCategory(e.optString("reason"));
                t.put(cat, t.optInt(cat) + amt);
                t.put("total", t.optInt("total") + amt);
                if ("wages".equals(cat)) {
                    t.put("playerWages", t.optInt("playerWages") + e.optInt("pWages", 0));
                    t.put("staffWages", t.optInt("staffWages") + e.optInt("sWages", 0));
                    t.put("wageDiscount", t.optInt("wageDiscount") + e.optInt("wDisc", 0));
                }
            }
        } catch (Exception ignored) {}
        return t;
    }

    /** Idea 61 (optional flourish, implemented): at rollover a staffer
     *  rated 88+ has a 12% chance of being poached by a richer club —
     *  the role falls vacant and the news desk hears of it. */
    public void maybePoachStaff() {
        try {
            for (String role : STAFF_ROLES) {
                JSONObject s = staffMember(role);
                if (s != null && s.optInt("rating") >= 88 && rng.nextDouble() < 0.12) {
                    staff.remove(role);
                    addNews("STAFF POACHED: " + s.optString("name") + " (" + role + ", rating "
                            + s.optInt("rating") + ") has been lured away by a richer club. The post is vacant — hire in HQ.");
                }
            }
        } catch (Exception ignored) {}
    }

    public int ledgerSum() {
        int s = 0;
        for (int i = 0; i < ledger.length(); i++) {
            try { s += ledger.getJSONObject(i).optInt("amt"); } catch (Exception ignored) {}
        }
        return s;
    }

    // ================= BATCH H (ideas 71–80): NEWS & IMMERSION ==========
    // Everything in this section feeds off ONE match "context" built in
    // onUserMatchFinished for every finished user match (live or simmed):
    // {won, opp, comp, compLabel, stage, derby, finalTie, r1, w1, r2, w2,
    //  winner, chased, marginRuns, marginWkts, marginClass, topBat,
    //  topBatRuns, topBatTeam, bestBowl, bestBowlWkts, bestBowlTeam,
    //  centuryName, centuryTeam, centuryRuns, fiveForName, fiveForTeam,
    //  fiveForWkts, userAllOutLow, summary}.

    /** True when the live match object belongs to this fixture — the guard
     *  that keeps a day-skip sim from borrowing an unrelated live match's
     *  cards for its context. */
    private boolean liveCtxOk(JSONObject f) {
        if (match == null || f == null) return false;
        boolean cup = f.optBoolean("cup"), stage = f.has("stage");
        if (cup) return match.optBoolean("cup") && match.optInt("fixtureDay") == f.optInt("day");
        if (stage) return match.optBoolean("playoff") && f.optString("stage").equals(match.optString("stageName"));
        return !match.optBoolean("playoff") && !match.optBoolean("cup")
                && match.optInt("fixtureDay") == f.optInt("day");
    }

    /** Best {name, runs, balls} across two batting cards (may be null). */
    private JSONObject scanTopBat(JSONArray a, JSONArray b) {
        JSONObject best = null;
        for (JSONArray card : new JSONArray[]{a, b}) {
            if (card == null) continue;
            for (int i = 0; i < card.length(); i++) {
                JSONObject e = card.optJSONObject(i);
                if (e == null) continue;
                if (best == null || e.optInt("runs") > best.optInt("runs")) best = e;
            }
        }
        return best;
    }

    /** Best {name, wkts, conc} across two bowling cards (may be null). */
    private JSONObject scanBestBowl(JSONArray a, JSONArray b) {
        JSONObject best = null;
        for (JSONArray card : new JSONArray[]{a, b}) {
            if (card == null) continue;
            for (int i = 0; i < card.length(); i++) {
                JSONObject e = card.optJSONObject(i);
                if (e == null) continue;
                if (best == null || e.optInt("wkts") > best.optInt("wkts")
                        || (e.optInt("wkts") == best.optInt("wkts") && e.optInt("runs") < best.optInt("runs"))) best = e;
            }
        }
        return best;
    }

    /** Build the Batch H context for a just-finished user match. */
    public JSONObject matchContext(boolean userWon, String summary, JSONObject f) {
        JSONObject c = new JSONObject();
        try {
            String opp = f != null ? opponentOf(f) : "";
            boolean cup = f != null && f.optBoolean("cup");
            boolean stage = f != null && f.has("stage");
            String stageName = f != null ? f.optString("stage") : "";
            c.put("won", userWon).put("opp", opp).put("summary", summary);
            c.put("cup", cup).put("playoff", stage && !cup);
            c.put("stage", stageName);
            c.put("comp", cup ? "cup" : stage ? "playoff" : "league");
            c.put("compLabel", cup ? "One-Day Cup" : stage ? stageName + " (Playoffs)" : "T20 League");
            c.put("derby", f != null && isDerby(f));
            c.put("finalTie", "Final".equals(stageName));
            c.put("ground", f != null ? f.optString("ground", Data.groundName(f.optString("home")))
                    : Data.groundName(userTeam));
            c.put("home", f != null ? f.optString("home") : "").put("away", f != null ? f.optString("away") : "");
            int r1 = -1, w1 = -1, r2 = -1, w2 = -1;
            String winner = userWon ? userTeam : opp;
            boolean chased = false;
            String topBat = "", topBatTeam = "", bestBowl = "", bestBowlTeam = "";
            int topBatRuns = 0, bestBowlWkts = 0;
            String cenName = "", cenTeam = ""; int cenRuns = 0;
            String ffName = "", ffTeam = ""; int ffWkts = 0;
            if (liveCtxOk(f)) {
                JSONObject m = match;
                r1 = m.optInt("inn1Runs", -1);
                r2 = m.has("inn2Runs") ? m.optInt("inn2Runs") : m.optInt("runs", -1);
                w1 = m.optInt("inn1Wkts", -1);
                w2 = m.has("inn2Wkts") ? m.optInt("inn2Wkts") : m.optInt("wkts", -1);
                String inn1Team = m.optString("inn1BatTeam"), inn2Team = m.optString("inn2BatTeam");
                winner = m.optString("winnerTeam", winner);
                chased = winner.equals(inn2Team);
                JSONObject tb = scanTopBat(m.optJSONArray("inn1BatCard"), m.optJSONArray("batCard"));
                // which innings did the top bat bat in? re-scan per card
                JSONObject tb1 = scanTopBat(m.optJSONArray("inn1BatCard"), null);
                if (tb != null) {
                    topBat = tb.optString("name"); topBatRuns = tb.optInt("runs");
                    topBatTeam = (tb1 != null && tb == tb1) ? inn1Team : inn2Team;
                }
                JSONObject bb = scanBestBowl(m.optJSONArray("inn1BowlCard"), m.optJSONArray("bowlCard"));
                JSONObject bb1 = scanBestBowl(m.optJSONArray("inn1BowlCard"), null);
                if (bb != null) {
                    bestBowl = bb.optString("name"); bestBowlWkts = bb.optInt("wkts");
                    // inn1 bowlers belong to the team that batted SECOND
                    bestBowlTeam = (bb1 != null && bb == bb1) ? inn2Team : inn1Team;
                }
                // feats: centuries and 5-fors anywhere in the match
                for (JSONArray card : new JSONArray[]{m.optJSONArray("inn1BatCard"), m.optJSONArray("batCard")}) {
                    if (card == null) continue;
                    boolean first = card == m.optJSONArray("inn1BatCard");
                    for (int i = 0; i < card.length(); i++) {
                        JSONObject e = card.optJSONObject(i);
                        if (e != null && e.optInt("runs") >= 100 && e.optInt("runs") > cenRuns) {
                            cenName = e.optString("name"); cenRuns = e.optInt("runs");
                            cenTeam = first ? inn1Team : inn2Team;
                        }
                    }
                }
                for (JSONArray card : new JSONArray[]{m.optJSONArray("inn1BowlCard"), m.optJSONArray("bowlCard")}) {
                    if (card == null) continue;
                    boolean first = card == m.optJSONArray("inn1BowlCard");
                    for (int i = 0; i < card.length(); i++) {
                        JSONObject e = card.optJSONObject(i);
                        if (e != null && e.optInt("wkts") >= 5 && e.optInt("wkts") > ffWkts) {
                            ffName = e.optString("name"); ffWkts = e.optInt("wkts");
                            ffTeam = first ? inn2Team : inn1Team; // bowlers of inn1 = inn2's team
                        }
                    }
                }
                if (cenName.isEmpty() && topBatRuns >= 100) { cenName = topBat; cenRuns = topBatRuns; cenTeam = topBatTeam; }
                if (ffName.isEmpty() && bestBowlWkts >= 5) { ffName = bestBowl; ffWkts = bestBowlWkts; ffTeam = bestBowlTeam; }
            } else if (f != null) {
                r1 = f.optInt("r1", -1); w1 = f.optInt("w1", -1);
                r2 = f.optInt("r2", -1); w2 = f.optInt("w2", -1);
                winner = f.optString("winner", winner);
                chased = winner.equals(f.optString("away")); // sims: home bats first
                topBat = f.optString("topBat"); topBatRuns = f.optInt("topBatRuns");
                topBatTeam = f.optString("topBatTeam");
                bestBowl = f.optString("bestBowl"); bestBowlWkts = f.optInt("bestBowlWkts");
                bestBowlTeam = f.optString("bestBowlTeam");
                if (topBatRuns >= 100) { cenName = topBat; cenRuns = topBatRuns; cenTeam = topBatTeam; }
                if (bestBowlWkts >= 5) { ffName = bestBowl; ffWkts = bestBowlWkts; ffTeam = bestBowlTeam; }
            }
            c.put("r1", r1).put("w1", w1).put("r2", r2).put("w2", w2);
            c.put("winner", winner).put("chased", chased);
            c.put("topBat", topBat).put("topBatRuns", topBatRuns).put("topBatTeam", topBatTeam);
            c.put("bestBowl", bestBowl).put("bestBowlWkts", bestBowlWkts).put("bestBowlTeam", bestBowlTeam);
            c.put("centuryName", cenName).put("centuryTeam", cenTeam).put("centuryRuns", cenRuns);
            c.put("fiveForName", ffName).put("fiveForTeam", ffTeam).put("fiveForWkts", ffWkts);
            int marginRuns = (r1 >= 0 && r2 >= 0) ? Math.abs(r1 - r2) : -1;
            int marginWkts = chased && w2 >= 0 ? 10 - w2 : -1;
            c.put("marginRuns", marginRuns).put("marginWkts", marginWkts);
            int loserRuns = userWon ? (userTeam.equals(c.optString("home")) ? r2 : r1)
                    : (userTeam.equals(c.optString("home")) ? r1 : r2);
            int loserWkts = userWon ? (userTeam.equals(c.optString("home")) ? w2 : w1)
                    : (userTeam.equals(c.optString("home")) ? w1 : w2);
            int winRuns = Math.max(r1, r2);
            boolean collapse = loserWkts == 10 && winRuns > 0 && loserRuns * 100 <= winRuns * 62;
            c.put("userAllOutLow", !userWon && loserWkts == 10 && loserRuns > 0 && loserRuns <= (cup ? 190 : 118));
            boolean thriller = (marginRuns >= 0 && marginRuns <= (cup ? 20 : 12))
                    || (chased && marginWkts >= 0 && marginWkts <= 2);
            boolean big = marginRuns >= (cup ? 80 : 45) || (chased && marginWkts >= 7);
            c.put("marginClass", thriller ? "thriller" : big ? "big" : collapse && !userWon ? "collapse" : "normal");
            c.put("collapse", collapse);
        } catch (Exception ignored) {}
        return c;
    }

    /** The single Batch H post-match flow, called at the end of
     *  onUserMatchFinished for EVERY user match: headline (72), fan buzz
     *  (73), press conference offer (71), rival reaction (80), the
     *  season-review trackers (76) and the shareable report (77). */
    public void batchHOnMatchFinished(boolean userWon, String summary, JSONObject f) {
        try {
            JSONObject c = matchContext(userWon, summary, f);
            // ---- idea 72: headline + summary line (summary posted first so
            // the headline sits on top of the feed)
            addNews("📰 " + genHeadline(c) + "\n" + summary);
            // ---- idea 73: fan buzz
            genFanPosts(c);
            // ---- idea 80: the rival gaffer reacts
            rivalPostQuote(c);
            // ---- idea 71: press conference for the big occasions
            if (pressConfQualifies(c)) {
                JSONObject pc = new JSONObject();
                pc.put("q", pressQuestion(c)).put("won", userWon)
                        .put("opp", c.optString("opp")).put("comp", c.optString("compLabel"))
                        .put("star", starOf(c)).put("season", season).put("day", day);
                pressConf = pc;
            }
            // ---- idea 76: season-review trackers (user-squad feats only)
            trackSeasonReview(c);
            // ---- idea 77: the report card data
            JSONObject r = new JSONObject();
            r.put("season", season).put("day", day).put("compLabel", c.optString("compLabel"))
                    .put("home", c.optString("home")).put("away", c.optString("away"))
                    .put("ground", c.optString("ground")).put("summary", summary)
                    .put("won", userWon).put("userTeam", userTeam).put("opp", c.optString("opp"))
                    .put("r1", c.optInt("r1", -1)).put("w1", c.optInt("w1", -1))
                    .put("r2", c.optInt("r2", -1)).put("w2", c.optInt("w2", -1))
                    // simmed ties already know their POTM; live ones are
                    // patched in afterwards by noteLivePotm()
                    .put("potm", f != null ? f.optString("potm", "") : "")
                    .put("potmDesc", f != null ? f.optString("potmDesc", "") : "")
                    .put("topBatLine", c.optString("topBat").isEmpty() ? "" :
                            c.optString("topBat") + " — " + c.optInt("topBatRuns") + " runs")
                    .put("bestBowlLine", c.optString("bestBowl").isEmpty() ? "" :
                            c.optString("bestBowl") + " — " + c.optInt("bestBowlWkts") + " wickets")
                    .put("fixtureDay", f != null ? f.optInt("day") : day)
                    .put("stage", c.optString("stage")).put("cup", c.optBoolean("cup"));
            lastReport = r;
        } catch (Exception ignored) {}
    }

    /** MatchEngine calls this once the live POTM is computed (it runs
     *  AFTER onUserMatchFinished) so the report can name him. */
    public void noteLivePotm(JSONObject m) {
        try {
            if (lastReport == null || m == null) return;
            if (lastReport.optInt("season") != season) return;
            boolean cup = m.optBoolean("cup"), playoff = m.optBoolean("playoff");
            if (cup != lastReport.optBoolean("cup")) return;
            if (playoff != (!lastReport.optString("stage").isEmpty() && !cup)) return;
            if (!cup && !playoff && lastReport.optInt("fixtureDay") != m.optInt("fixtureDay")) return;
            if (playoff && !lastReport.optString("stage").equals(m.optString("stageName"))) return;
            if (cup && lastReport.optInt("fixtureDay") != m.optInt("fixtureDay")) return;
            lastReport.put("potm", m.optString("potm", ""));
            lastReport.put("potmDesc", m.optString("potmDesc", ""));
        } catch (Exception ignored) {}
    }

    /** The match's headline act: a user century, else a user 5-for, else
     *  the overall top bat / best bowler. */
    private String starOf(JSONObject c) {
        if (!c.optString("centuryName").isEmpty()) return c.optString("centuryName");
        if (!c.optString("fiveForName").isEmpty()) return c.optString("fiveForName");
        if (c.optInt("topBatRuns") >= 50 || c.optInt("bestBowlWkts") < 4) return c.optString("topBat");
        return c.optString("bestBowl");
    }

    private static String surname(String name) {
        if (name == null) return "";
        String[] parts = name.trim().split("\\s+");
        return parts.length > 0 ? parts[parts.length - 1] : name;
    }

    // ---- idea 72: newspaper headlines --------------------------------
    // Template ids (lastHeadlineTpl): the first APPLICABLE template whose
    // id differs from the last one used wins — the same template can
    // therefore never lead the paper twice in a row.
    public static final int HL_BIG_WIN = 0, HL_THRILLER = 1, HL_CHASE = 2,
            HL_TON = 3, HL_TON_LOSS = 4, HL_FIVEFOR = 5, HL_DERBY_WIN = 6,
            HL_DERBY_LOSS = 7, HL_CHAMPIONS = 8, HL_KNOCKOUT = 9,
            HL_COLLAPSE = 10, HL_BIG_LOSS = 11, HL_HOME = 12, HL_AWAY = 13,
            HL_CLOSE_LOSS = 14, HL_WIN_A = 15, HL_WIN_B = 16,
            HL_LOSS_A = 17, HL_LOSS_B = 18;

    private boolean hlApplies(int id, JSONObject c) {
        boolean won = c.optBoolean("won");
        String mc = c.optString("marginClass");
        boolean cenUser = userTeam.equals(c.optString("centuryTeam"));
        boolean cenAny = !c.optString("centuryName").isEmpty();
        boolean ffUser = userTeam.equals(c.optString("fiveForTeam"));
        switch (id) {
            case HL_BIG_WIN: return won && "big".equals(mc);
            case HL_THRILLER: return won && "thriller".equals(mc);
            case HL_CHASE: return won && c.optBoolean("chased") && !"big".equals(mc);
            case HL_TON: return cenUser;
            case HL_TON_LOSS: return !won && cenAny && !cenUser;
            case HL_FIVEFOR: return ffUser;
            case HL_DERBY_WIN: return won && c.optBoolean("derby");
            case HL_DERBY_LOSS: return !won && c.optBoolean("derby");
            case HL_CHAMPIONS: return won && c.optBoolean("finalTie");
            case HL_KNOCKOUT: return won && (c.optBoolean("playoff") || c.optBoolean("cup")) && !c.optBoolean("finalTie");
            case HL_COLLAPSE: return (!won && c.optBoolean("userAllOutLow")) || (!won && "collapse".equals(mc));
            case HL_BIG_LOSS: return !won && "big".equals(mc);
            case HL_HOME: return won && userTeam.equals(c.optString("home"));
            case HL_AWAY: return won && !userTeam.equals(c.optString("home"));
            case HL_CLOSE_LOSS: return !won && "thriller".equals(mc);
            case HL_WIN_A: case HL_WIN_B: return won;
            case HL_LOSS_A: case HL_LOSS_B: return !won;
            default: return false;
        }
    }

    private String hlText(int id, JSONObject c) {
        String UT = userTeam.toUpperCase(Locale.US), OT = c.optString("opp").toUpperCase(Locale.US);
        String star = surname(starOf(c)).toUpperCase(Locale.US);
        String cen = surname(c.optString("centuryName")).toUpperCase(Locale.US);
        String comp = c.optBoolean("cup") ? "CUP" : c.optBoolean("playoff") ? "PLAYOFF" : "DERBY";
        switch (id) {
            case HL_BIG_WIN: return UT + " CRUSH " + OT + " IN ONE-SIDED ROUT";
            case HL_THRILLER: return "LAST-GASP THRILLER: " + UT + " HOLD THEIR NERVE";
            case HL_CHASE: return UT + " CHASE IT DOWN IN STYLE AGAINST " + OT;
            case HL_TON: return cen + "'S TON SINKS " + OT;
            case HL_TON_LOSS: return cen + "'S HUNDRED DOOMS " + UT;
            case HL_FIVEFOR: return surname(c.optString("fiveForName")).toUpperCase(Locale.US) + "'S FIVE-FOR WRECKS " + OT;
            case HL_DERBY_WIN: return "DERBY DELIGHT: " + UT + " TAKE THE BRAGGING RIGHTS";
            case HL_DERBY_LOSS: return "DERBY PAIN AS " + OT + " RULE THE RIVALRY";
            case HL_CHAMPIONS: return "CHAMPIONS! " + UT + " LIFT THE TROPHY";
            case HL_KNOCKOUT: return UT + " SURVIVE THE KNOCKOUT HEAT";
            case HL_COLLAPSE: return UT + " COLLAPSE HANDS " + OT + " AN EASY WIN";
            case HL_BIG_LOSS: return OT + " TOO STRONG AS " + UT + " SLIDE AGAIN";
            case HL_HOME: return "HOME FORTRESS HOLDS FOR " + UT;
            case HL_AWAY: return UT + " SILENCE THE AWAY CROWD";
            case HL_CLOSE_LOSS: return "SO CLOSE: " + UT + " FALL JUST SHORT";
            case HL_WIN_A: return star + " THE STAR AS " + UT + " MARCH ON";
            case HL_WIN_B: return UT + " GET THE JOB DONE AGAINST " + OT;
            case HL_LOSS_A: return UT + " BEATEN DESPITE THE FIGHT";
            case HL_LOSS_B: return "WORK TO DO: " + UT + " SECOND BEST ON THE DAY";
            default: return UT + " IN THE NEWS AGAIN";
        }
    }

    /** Pick + render the headline for a match context (updates the
     *  no-repeat tracker). Public for the desktop tests. */
    public String genHeadline(JSONObject c) {
        int[] order = {HL_CHAMPIONS, HL_TON, HL_FIVEFOR, HL_DERBY_WIN, HL_DERBY_LOSS,
                HL_TON_LOSS, HL_COLLAPSE, HL_THRILLER, HL_BIG_WIN, HL_KNOCKOUT,
                HL_CHASE, HL_BIG_LOSS, HL_CLOSE_LOSS, HL_HOME, HL_AWAY,
                HL_WIN_A, HL_WIN_B, HL_LOSS_A, HL_LOSS_B};
        for (int id : order) {
            if (id != lastHeadlineTpl && hlApplies(id, c)) {
                lastHeadlineTpl = id;
                return hlText(id, c);
            }
        }
        // every applicable template was the last one (single-candidate case):
        // fall back to the generic pair so the text still changes
        int fb = c.optBoolean("won") ? (lastHeadlineTpl == HL_WIN_A ? HL_WIN_B : HL_WIN_A)
                : (lastHeadlineTpl == HL_LOSS_A ? HL_LOSS_B : HL_LOSS_A);
        lastHeadlineTpl = fb;
        return hlText(fb, c);
    }

    // ---- idea 73: Fan Buzz --------------------------------------------
    private static final String[][] FAN_PERSONAS = {
            {"Chacha Nasir", "@LahoreLoyal"}, {"Baji Rukhsana", "@QalandarTillIDie"},
            {"Usman the Analyst", "@NRRWatcher"}, {"Little Bilal", "@GaddafiRoars"},
            {"Aunty Shamim", "@ChaiAndCricket"}, {"Fahad Frustrated", "@TukTukOut"},
            {"Sehrish", "@SixMachineFan"}, {"Haji Sahib", "@SinceNineteenNinety"},
    };
    private static final String[][] FAN_POSTS = { // [bucket][variants] — 0 ecstatic, 1 happy, 2 mixed, 3 angry
            {"CHAMPIONS ENERGY! What a win over {opp}! This team, this city — UNREAL! 🏆",
             "{star} you BEAUTY! Best day of my life, no exaggeration. {ut} forever! 💛",
             "I have watched {ut} for years and THIS is the night I will tell my grandchildren about!"},
            {"Solid win against {opp}. Professional job, boys. Onwards! 👏",
             "Three points... wait, wrong sport. GREAT win anyway! {ut} marching on 💪",
             "{star} was class today. This squad is quietly building something special."},
            {"A loss, but at least we fought till the end. Heads up, {ut}. 😔",
             "So close today. The intent was there — the finishing wasn't. Next one, insha'Allah.",
             "Mixed feelings. Some good signs, some same old mistakes. We go again."},
            {"Absolutely embarrassing against {opp}. Changes needed, and needed NOW. 😡",
             "I pay for my data pack to watch THIS? Sort it out, {ut} management!",
             "That collapse was criminal. Someone has to answer for the batting order."},
    };
    private static final String[] FAN_AMBIENT = {
            "Quiet day at the club. Anyone else refreshing the fixtures page every hour? Just me? 😅",
            "Heard a rumour in the bazaar about a new signing... probably nothing, but imagine! 👀",
            "Throwback to that famous chase last season. Still gives me goosebumps. 💛",
            "My chai tastes better when {ut} are top of the group. Science.",
            "Ticket prices, travel plans, new jersey — the season eats my whole salary and I love it.",
    };

    /** Prepend one fan post (newest first), keeping the store capped. */
    public void addFanBuzz(int bucket, String text) {
        try {
            String[] p = FAN_PERSONAS[rng.nextInt(FAN_PERSONAS.length)];
            JSONArray keep = new JSONArray();
            keep.put(new JSONObject().put("name", p[0]).put("handle", p[1])
                    .put("text", text).put("mood", bucket).put("season", season).put("day", day));
            for (int i = 0; i < fanPosts.length() && keep.length() < 30; i++) keep.put(fanPosts.get(i));
            fanPosts = keep;
        } catch (Exception ignored) {}
    }

    private String fanFill(String tpl, JSONObject c) {
        return tpl.replace("{opp}", c.optString("opp")).replace("{ut}", shortFor(userTeam))
                .replace("{star}", starOf(c));
    }

    /** Idea 73: 2–4 posts after a user match, sentiment from result + mood. */
    public void genFanPosts(JSONObject c) {
        boolean won = c.optBoolean("won");
        int bucket;
        if (won && (c.optBoolean("derby") || c.optBoolean("finalTie"))) bucket = 0;
        else if (won) bucket = fanMood >= 85 ? 0 : 1;
        else if ("thriller".equals(c.optString("marginClass"))) bucket = 2;
        else if (c.optBoolean("collapse") || "big".equals(c.optString("marginClass"))) bucket = 3;
        else bucket = fanMood < 35 ? 3 : 2;
        int n = 2 + rng.nextInt(3);
        int start = rng.nextInt(FAN_POSTS[bucket].length);
        for (int i = 0; i < n; i++) {
            addFanBuzz(bucket, fanFill(FAN_POSTS[bucket][(start + i) % FAN_POSTS[bucket].length], c));
        }
    }

    /** Idea 73: flavour posts for club events (signings, sack warnings). */
    public void fanEventPost(String kind, String name) {
        if ("signing".equals(kind)) {
            addFanBuzz(1, "NEW SIGNING ALERT! Welcome to " + shortFor(userTeam) + ", " + name
                    + "! The fans are already singing your name 🔥");
        } else if ("sackwarn".equals(kind)) {
            addFanBuzz(3, "Board losing patience with the gaffer?? The fans deserve answers. Worrying times at "
                    + shortFor(userTeam) + "... 😟");
        } else if ("title".equals(kind)) {
            addFanBuzz(0, "WE ARE THE CHAMPIONS! 🏆🏆 The city doesn't sleep tonight! " + shortFor(userTeam) + " forever!");
        }
    }

    /** Idea 73: an ambient post on some quiet days (advanceDay hook). */
    public void maybeAmbientFanPost() {
        if (rng.nextInt(100) >= 30) return;
        addFanBuzz(fanMood >= 60 ? 1 : 2,
                FAN_AMBIENT[rng.nextInt(FAN_AMBIENT.length)].replace("{ut}", shortFor(userTeam)));
    }

    // ---- idea 71: press conferences ------------------------------------
    /** A conference is offered after derbies, playoff/cup ties, finals,
     *  and any match containing a century or a 5-for. */
    public boolean pressConfQualifies(JSONObject c) {
        return c.optBoolean("derby") || c.optBoolean("playoff") || c.optBoolean("cup")
                || c.optBoolean("finalTie")
                || !c.optString("centuryName").isEmpty() || !c.optString("fiveForName").isEmpty();
    }

    private String pressQuestion(JSONObject c) {
        boolean won = c.optBoolean("won");
        if (c.optBoolean("finalTie") && won) return "CHAMPIONS! Gaffer, describe this feeling — what does this trophy mean to this club?";
        if (c.optBoolean("finalTie")) return "Beaten in the Final. What do you say to the fans who travelled for this?";
        if (!c.optString("centuryName").isEmpty() && userTeam.equals(c.optString("centuryTeam")))
            return c.optString("centuryName") + "'s hundred lit the place up. Just how special is this lad?";
        if (!c.optString("fiveForName").isEmpty() && userTeam.equals(c.optString("fiveForTeam")))
            return c.optString("fiveForName") + " ran through them today. Is this the best attack in the league?";
        if (c.optBoolean("derby") && won) return "A derby win — the fans are still singing outside. How sweet does this one taste?";
        if (c.optBoolean("derby")) return "A derby defeat hurts twice as much. Your message to the supporters?";
        if (won && "thriller".equals(c.optString("marginClass"))) return "A last-over thriller! How is the heart rate in that dressing room right now?";
        if (won) return "A statement win. How far can this side honestly go this season?";
        if ("big".equals(c.optString("marginClass")) || "collapse".equals(c.optString("marginClass")))
            return "A heavy defeat — the fans are asking hard questions. Are they right to worry?";
        return "So close at the end there. What was the one moment that got away?";
    }

    private static final String[][] PRESS_LINES = { // [choice][won?1:0]
            {"\"No fear in this dressing room. We respect everyone — but we fear absolutely no one.\"",
             "\"We lost, but write us off at your peril. This group will come back swinging.\""},
            {"\"The boys executed the plan. Credit to the whole squad — we move on to the next one.\"",
             "\"We take the lessons and we move on. No drama, no excuses — just work.\""},
            {"\"Let them talk. We will do our talking on the pitch — and the next lot who come here will feel it.\"",
             "\"Remember this feeling. Next match, somebody is paying for it — mark my words.\""},
    };

    /** Answer the pending conference. choice: 0 Confident, 1 Balanced,
     *  2 Fiery, -1 Skip. Effects land exactly once (the conference is
     *  cleared first); returns a short outcome line for the UI. */
    public String answerPress(int choice) {
        if (pressConf == null) return "";
        boolean won = pressConf.optBoolean("won");
        String star = pressConf.optString("star");
        pressConf = null;
        if (choice < 0) return "You skip the press conference.";
        choice = Math.min(2, choice);
        String quote = PRESS_LINES[choice][won ? 0 : 1];
        addNews("🎙 Manager: " + quote);
        if (choice == 0) { // Confident
            if (won) { adjustFanMood(2); adjustBoardConfidence(1); return "The fans love the confidence. Fans +2 · Board +1"; }
            adjustFanMood(-1); adjustBoardConfidence(-1);
            return "Talking big after a defeat backfires. Fans −1 · Board −1";
        }
        if (choice == 1) { // Balanced
            for (int i = 0; i < players.length(); i++) adjustMorale(player(i).optString("name"), 1);
            return "A calm, professional answer. Squad morale +1" + (star.isEmpty() ? "" : "");
        }
        // Fiery: mind games — the next match's powerplay gets aggressive
        pressBoost = 1;
        adjustFanMood(2); adjustBoardConfidence(-1);
        return "Mind games! Fans +2 · Board −1 · the next match starts FIERY 🔥";
    }

    /** Idea 71: a pending conference expires quietly when the day moves on. */
    public void expirePressConf() { pressConf = null; }

    // ---- idea 74: Coach's Corner ---------------------------------------
    /** One concrete tip for today, computed from real state in priority
     *  order and cached for the day. Yesterday's tip key is skipped, so
     *  the corner never says the same thing two days running while
     *  another true condition exists. */
    public String coachTip() {
        if (coachTipSeason == season && coachTipDay == day && !coachTipText.isEmpty()) return coachTipText;
        List<String[]> cands = new ArrayList<>(); // {key, text}
        try {
            if (boardWarning()) cands.add(new String[]{"board",
                    "Board confidence is down to " + boardConfidence + " — a win today matters more than tactics. Protect the job first."});
            if (poachOffer != null) cands.add(new String[]{"poach",
                    poachOffer.optString("club") + " are sniffing around " + poachOffer.optString("name")
                            + " — decide on their offer in Transfers before it festers."});
            JSONObject next = todaysUserFixture();
            if (next == null && playoffPhase == 0 && cupPhase == 0) next = nextUserFixture();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (p.optBoolean("inXI") && p.optInt("injured") > 0) {
                    cands.add(new String[]{"injured", p.optString("name") + " is injured (" + p.optInt("injured")
                            + " day(s) left) — he cannot play. Use Recovery in Team or reshuffle the XI."});
                    break;
                }
            }
            JSONObject tired = null;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (p.optBoolean("inXI") && (tired == null || p.optInt("stam") < tired.optInt("stam"))) tired = p;
            }
            if (tired != null && tired.optInt("stam") < 40) cands.add(new String[]{"stamina",
                    tired.optString("name") + "'s stamina is " + tired.optInt("stam") + " — consider resting him; tired legs lose matches late on."});
            if (next != null) {
                if (next.optInt("pitch") == 3) { // Turning
                    int spinners = 0;
                    for (int i = 0; i < players.length(); i++) {
                        JSONObject p = player(i);
                        if (p.optBoolean("inXI") && Data.isSpinner(p.optString("name"))) spinners++;
                    }
                    if (spinners < 2) cands.add(new String[]{"pitchspin",
                            "The next pitch is Turning but your XI has only " + spinners
                                    + " spinner(s) — get another slow bowler in before the toss."});
                }
                String dm = MatchEngine.dangerManName(this, opponentOf(next));
                if (!dm.isEmpty()) cands.add(new String[]{"dangerman",
                        dm + " is " + shortFor(opponentOf(next)) + "'s danger man — set a per-batter plan for him in Match Tactics."});
            }
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (p.optInt("contract", 2) <= 1 && !p.optBoolean("loanIn")) {
                    cands.add(new String[]{"contract",
                            p.optString("name") + "'s contract is in its final year — renew him in the off-season or lose him for free."});
                    break;
                }
            }
            int lowMorale = 0;
            for (int i = 0; i < players.length(); i++) if (player(i).optInt("morale", 70) < 40) lowMorale++;
            if (lowMorale >= 3) cands.add(new String[]{"morale",
                    "You have " + lowMorale + " players with morale under 40 — a Team Talk or a couple of wins will lift the room."});
            if (transferWindowOpen()) cands.add(new String[]{"window",
                    "The transfer window is OPEN (Days " + WINDOW_OPEN_DAY + "–" + WINDOW_CLOSE_DAY
                            + ") — up to 2 signings from the window list in Transfers."});
            if (cf < 200) cands.add(new String[]{"cash",
                    "Club cash is down to " + cf + " CF — careful: wages still come out on Days 7, 14 and 21."});
        } catch (Exception ignored) {}
        String chosen = null, chosenKey = "sharp";
        for (String[] cd : cands) if (!cd[0].equals(lastTipKey)) { chosenKey = cd[0]; chosen = cd[1]; break; }
        if (chosen == null && !cands.isEmpty()) { chosenKey = cands.get(0)[0]; chosen = cands.get(0)[1]; }
        if (chosen == null) chosen = "The squad looks sharp, gaffer — no fires to put out today. Trust the process.";
        lastTipKey = chosenKey;
        coachTipKey = chosenKey; coachTipText = chosen;
        coachTipSeason = season; coachTipDay = day;
        return chosen;
    }

    // ---- idea 75: pre-match analysis ------------------------------------
    /** A club's last-5 results ("W L W W L", oldest first) from played
     *  league/playoff/cup fixtures — winner field where stored, else the
     *  summary's tail (" — X won ..."). "" when nothing has been played. */
    public String oppRecentForm(String team) {
        List<Character> res = new ArrayList<>();
        JSONArray[] pools = {fixtures, playoffFixtures, cupFixtures};
        for (JSONArray pool : pools) {
            if (pool == null) continue;
            for (int i = 0; i < pool.length(); i++) {
                JSONObject f = pool.optJSONObject(i);
                if (f == null || !f.optBoolean("played")) continue;
                if (!team.equals(f.optString("home")) && !team.equals(f.optString("away"))) continue;
                String winner = f.optString("winner");
                if (winner.isEmpty()) {
                    String s = f.optString("summary");
                    int cut = s.lastIndexOf(" — ");
                    if (cut >= 0) {
                        String tail = s.substring(cut + 3);
                        if (tail.startsWith("Match tied")) winner = "TIE";
                        else {
                            int w = tail.indexOf(" won");
                            if (w > 0) winner = tail.substring(0, w);
                        }
                    }
                }
                if (winner.isEmpty()) continue;
                res.add(winner.equals("TIE") ? 'T' : winner.equals(team) ? 'W' : 'L');
            }
        }
        if (res.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(0, res.size() - 5); i < res.size(); i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(res.get(i));
        }
        return sb.toString();
    }

    /** Our best bat vs their best bowler, real ratings from the squads. */
    public String keyBattleLine(String opp) {
        try {
            JSONObject bestBat = null;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (bestBat == null || p.optInt("bat") > bestBat.optInt("bat")) bestBat = p;
            }
            Object[][] rows = Data.squadFor(opp);
            Object[] bestBowl = null;
            for (Object[] r : rows) if (bestBowl == null || (Integer) r[3] > (Integer) bestBowl[3]) bestBowl = r;
            if (bestBat == null || bestBowl == null) return "";
            return "Key battle: " + bestBat.optString("name") + " (Bat " + bestBat.optInt("bat") + ") vs "
                    + bestBowl[0] + " (Bowl " + bestBowl[3] + ")";
        } catch (Exception e) { return ""; }
    }

    /** The bookmaker's line: team strengths +/- home edge, clamped. */
    public int preMatchWinPct(JSONObject f) {
        if (f == null) return 50;
        int us = strengthFor(userTeam), them = strengthFor(opponentOf(f));
        int pct = 50 + (us - them) * 2 + (userTeam.equals(f.optString("home")) ? 4 : -2);
        return clamp(pct, 28, 72);
    }

    public String favouriteLine(JSONObject f) {
        int pct = preMatchWinPct(f);
        String opp = opponentOf(f);
        if (pct >= 58) return userTeam + " strong favourites (" + pct + "%)";
        if (pct > 52) return userTeam + " slight favourites (" + pct + "%)";
        if (pct >= 48) return "Dead even — a coin flip (" + pct + "%)";
        if (pct > 42) return opp + " slight favourites (" + (100 - pct) + "%)";
        return opp + " strong favourites (" + (100 - pct) + "%)";
    }

    // ---- idea 76: season-review trackers --------------------------------
    /** Fed by every match context: the season's biggest user win, best
     *  user innings, best user bowling and the fan moment. */
    public void trackSeasonReview(JSONObject c) {
        try {
            if (c.optBoolean("won")) {
                int val = c.optInt("marginRuns", -1) >= 0 ? c.optInt("marginRuns") : c.optInt("marginWkts", 0) * 15;
                String marginText = c.optInt("marginRuns", -1) >= 0 && !c.optBoolean("chased")
                        ? "by " + c.optInt("marginRuns") + " runs" : "by " + c.optInt("marginWkts") + " wickets";
                if (seasonBigWin == null || val > seasonBigWin.optInt("val")) {
                    seasonBigWin = new JSONObject().put("val", val)
                            .put("text", "Beat " + c.optString("opp") + " " + marginText + " (" + c.optString("compLabel") + ")");
                }
            }
            if (userTeam.equals(c.optString("topBatTeam")) && playerByName(c.optString("topBat")) != null) {
                if (seasonBestBat == null || c.optInt("topBatRuns") > seasonBestBat.optInt("runs")) {
                    seasonBestBat = new JSONObject().put("name", c.optString("topBat"))
                            .put("runs", c.optInt("topBatRuns"))
                            .put("text", c.optString("topBat") + " — " + c.optInt("topBatRuns") + " vs " + c.optString("opp"));
                }
            }
            if (userTeam.equals(c.optString("bestBowlTeam")) && playerByName(c.optString("bestBowl")) != null) {
                JSONObject cur = seasonBestBowl;
                if (cur == null || c.optInt("bestBowlWkts") > cur.optInt("wkts")) {
                    seasonBestBowl = new JSONObject().put("name", c.optString("bestBowl"))
                            .put("wkts", c.optInt("bestBowlWkts"))
                            .put("text", c.optString("bestBowl") + " — " + c.optInt("bestBowlWkts") + " wickets vs " + c.optString("opp"));
                }
            }
            int total = Math.max(0, c.optInt("r1", 0)) + Math.max(0, c.optInt("r2", 0));
            int score = total + (c.optBoolean("derby") ? 400 : 0) + (c.optBoolean("won") ? 100 : 0)
                    + (c.optBoolean("finalTie") ? 300 : 0);
            if (seasonFanMoment == null || score > seasonFanMoment.optInt("score")) {
                seasonFanMoment = new JSONObject().put("score", score)
                        .put("text", (c.optBoolean("derby") ? "The derby: " : "") + c.optString("summary"));
            }
        } catch (Exception ignored) {}
    }

    /** The season's review lines for a history entry (idea 76) — empty
     *  for pre-v10 entries, which render without the section. */
    public List<String> seasonReviewLines(JSONObject e) {
        List<String> out = new ArrayList<>();
        if (e == null || !e.has("reviewBestPlayer")) return out;
        try {
            out.add("⭐ Best player: " + e.optString("reviewBestPlayer"));
            if (!e.optString("reviewBigWin").isEmpty()) out.add("💪 Biggest win: " + e.optString("reviewBigWin"));
            if (!e.optString("reviewBestBat").isEmpty()) out.add("🏏 Best innings: " + e.optString("reviewBestBat"));
            if (!e.optString("reviewBestBowl").isEmpty()) out.add("🎯 Best bowling: " + e.optString("reviewBestBowl"));
            if (!e.optString("reviewFanMoment").isEmpty()) out.add("🎉 Fan moment: " + e.optString("reviewFanMoment"));
            out.add("💰 Finances: net " + (e.optInt("reviewFinNet") >= 0 ? "+" : "") + e.optInt("reviewFinNet") + " CF"
                    + (e.optString("reviewFinIn").isEmpty() ? "" : " · biggest in: " + e.optString("reviewFinIn"))
                    + (e.optString("reviewFinOut").isEmpty() ? "" : " · biggest out: " + e.optString("reviewFinOut")));
            int pos = e.optInt("lahorePos");
            String suf = pos == 1 ? "st" : pos == 2 ? "nd" : pos == 3 ? "rd" : "th";
            out.add("🏁 Finished " + pos + suf + " in the group · Champions: " + e.optString("champion"));
        } catch (Exception ignored) {}
        return out;
    }

    // ---- idea 77: report text (the image card lives in ReportCard) -----
    public String reportText(JSONObject r) {
        if (r == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("🏏 MATCH REPORT — Season ").append(r.optInt("season")).append(" · ").append(r.optString("compLabel")).append("\n");
        sb.append(r.optString("home")).append(" vs ").append(r.optString("away")).append("\n");
        sb.append("📍 ").append(r.optString("ground")).append("\n");
        sb.append(r.optString("summary")).append("\n");
        if (!r.optString("potm").isEmpty())
            sb.append("⭐ Player of the Match: ").append(r.optString("potm"))
                    .append(r.optString("potmDesc").isEmpty() ? "" : " (" + r.optString("potmDesc") + ")").append("\n");
        if (!r.optString("topBatLine").isEmpty()) sb.append("🔥 Top score: ").append(r.optString("topBatLine")).append("\n");
        if (!r.optString("bestBowlLine").isEmpty()) sb.append("🎯 Best bowling: ").append(r.optString("bestBowlLine")).append("\n");
        sb.append(r.optBoolean("won") ? "✅ " + userTeam + " won" : "❌ " + userTeam + " lost");
        sb.append("\n— Cricket Club Manager");
        return sb.toString();
    }

    // ---- idea 78: trophy cabinet ----------------------------------------
    /** Every honour, rendered from seasonHistory + hof + career counters
     *  (no duplicated storage). First line is the summary. */
    public List<String> trophyCabinetLines() {
        List<String> out = new ArrayList<>();
        int titles = career.optInt("titles"), cups = career.optInt("cups");
        out.add("Titles: " + titles + " · Cups: " + cups);
        try {
            java.util.Set<Integer> hofTitleSeasons = new java.util.HashSet<>();
            java.util.Set<Integer> hofCupSeasons = new java.util.HashSet<>();
            for (int i = 0; i < hof.length(); i++) {
                JSONObject h = hof.optJSONObject(i);
                if (h == null) continue;
                if ("title".equals(h.optString("kind"))) { hofTitleSeasons.add(h.optInt("season")); out.add("🏆 " + h.optString("line")); }
                else if ("cup".equals(h.optString("kind"))) { hofCupSeasons.add(h.optInt("season")); out.add("🏆 " + h.optString("line")); }
            }
            for (int i = 0; i < seasonHistory.length(); i++) {
                JSONObject e = seasonHistory.optJSONObject(i);
                if (e == null) continue;
                if (userTeam.equals(e.optString("champion")) && !hofTitleSeasons.contains(e.optInt("season"))) {
                    String ru = e.optString("runnerUp");
                    out.add("🏆 Season " + e.optInt("season") + " — League champions"
                            + (ru.isEmpty() ? "" : " (beat " + ru + " in the Final)"));
                }
            }
            if (cups > hofCupSeasons.size())
                out.add("🏆 One-Day Cup winners ×" + cups + " (early cup wins predate the detailed records)");
        } catch (Exception ignored) {}
        return out;
    }

    // ---- idea 79: season calendar ----------------------------------------
    /** All fixtures merged into day-ordered rows for CalendarScreen:
     *  [{day, rows:[{tag, text, user, played}]}]. */
    public JSONArray calendarDays() {
        JSONArray out = new JSONArray();
        try {
            java.util.TreeMap<Integer, JSONArray> byDay = new java.util.TreeMap<>();
            addCalFixtures(byDay, fixtures, "T20 League");
            addCalFixtures(byDay, playoffFixtures, "Playoff");
            addCalFixtures(byDay, cupFixtures, "50-Over Cup");
            int maxDay = byDay.isEmpty() ? day : Math.max(day, byDay.lastKey());
            for (java.util.Map.Entry<Integer, JSONArray> en : byDay.entrySet()) {
                JSONArray rows = en.getValue();
                int d = en.getKey();
                if (d >= WINDOW_OPEN_DAY && d <= WINDOW_CLOSE_DAY) {
                    JSONArray withMark = new JSONArray();
                    withMark.put(new JSONObject().put("tag", "🛒 Window").put("user", false).put("played", false)
                            .put("text", "Transfer window open — signings in the Transfers tab"));
                    for (int i = 0; i < rows.length(); i++) withMark.put(rows.get(i));
                    rows = withMark;
                }
                out.put(new JSONObject().put("day", d).put("rows", rows));
            }
            if (out.length() == 0) out.put(new JSONObject().put("day", Math.max(1, maxDay)).put("rows", new JSONArray()));
        } catch (Exception ignored) {}
        return out;
    }

    private void addCalFixtures(java.util.TreeMap<Integer, JSONArray> byDay, JSONArray pool, String compTag) {
        if (pool == null) return;
        try {
            for (int i = 0; i < pool.length(); i++) {
                JSONObject f = pool.optJSONObject(i);
                if (f == null) continue;
                int d = f.optInt("day");
                JSONArray rows = byDay.get(d);
                if (rows == null) { rows = new JSONArray(); byDay.put(d, rows); }
                String tag = compTag;
                if (f.has("stage")) tag = compTag + " · " + f.optString("stage");
                String text = f.optBoolean("played") ? f.optString("summary")
                        : f.optString("home") + " vs " + f.optString("away")
                        + (f.optString("ground").isEmpty() ? "" : " · " + f.optString("ground"));
                rows.put(new JSONObject().put("tag", tag).put("text", text)
                        .put("user", involvesUser(f)).put("played", f.optBoolean("played"))
                        // Design Batch (item 9b): team names ride along so
                        // the calendar can draw crests + a fixture sheet
                        .put("home", f.optString("home")).put("away", f.optString("away")));
            }
        } catch (Exception ignored) {}
    }

    // ---- idea 80: rival manager quotes ------------------------------------
    private static final String[][] RIVAL_PRE = { // [tone]: 0 confident, 1 dismissive, 2 respectful
            {"\"We know exactly how to beat them — we did the homework weeks ago. Bring your earplugs, their fans will need them.\"",
             "\"{ut} are a good side, but good isn't enough against us. We come to win, not to participate.\""},
            {"\"With respect, {ut} are struggling for a reason. We'll just play our game and let the table do the talking.\"",
             "\"I don't spend much time thinking about {ut}, to be honest. Bigger tests await us.\""},
            {"\"{ut} are dangerous on their day — anyone who underestimates them is a fool. It'll be a proper contest.\"",
             "\"Games against {ut} are always special. May the better team win — and we intend to be exactly that.\""},
    };
    private static final String[] RIVAL_POST_GRACIOUS = {
            "\"Fair play to {ut} — they were better today. We take it on the chin and we go again.\"",
            "\"Congratulations to {ut}. No excuses from us: beaten by the better side on the day.\"",
    };
    private static final String[] RIVAL_POST_GLOAT = {
            "\"I did warn everyone, didn't I? {ut} felt the full force of this team today.\"",
            "\"That's what happens when you meet a proper side. We enjoyed that one — a lot.\"",
    };

    private int rivalTone(String opp) {
        try {
            JSONObject mine = tables.optJSONObject(userTeam), theirs = tables.optJSONObject(opp);
            int myPts = mine != null ? mine.optInt("pts") : 0, theirPts = theirs != null ? theirs.optInt("pts") : 0;
            if (boardConfidence < 25) return 1;
            if (theirPts > myPts + 2) return 0;
            if (myPts > theirPts + 4) return 1;
        } catch (Exception ignored) {}
        return 2;
    }

    /** Pre-match talk from the rival gaffer before a derby or a playoff
     *  tie vs the rival — each fixture is quoted at most once. Called
     *  from advanceDay, beginPlayoffs and onPlayoffMatchFinished. */
    public void maybeRivalPreQuote() {
        try {
            JSONObject cand = null;
            JSONObject t = todaysUserFixture();
            if (t != null && isDerby(t) && !t.optBoolean("played")) cand = t;
            if (cand == null) {
                JSONObject p = pendingUserPlayoff();
                if (p != null && Data.rivalOf(userTeam).equals(opponentOf(p))) cand = p;
            }
            if (cand == null || cand.optBoolean("rivalPre")) return;
            cand.put("rivalPre", true);
            String opp = opponentOf(cand);
            int tone = rivalTone(opp);
            String q = RIVAL_PRE[tone][rng.nextInt(RIVAL_PRE[tone].length)].replace("{ut}", shortFor(userTeam));
            addNews("🎙 " + Data.managerFor(opp) + " (" + shortFor(opp) + ") before the big one: " + q);
        } catch (Exception ignored) {}
    }

    /** The rival gaffer's reaction after a derby / rival playoff tie. */
    public void rivalPostQuote(JSONObject c) {
        try {
            boolean big = c.optBoolean("derby")
                    || (c.optBoolean("playoff") && Data.rivalOf(userTeam).equals(c.optString("opp")));
            if (!big) return;
            String opp = c.optString("opp");
            String q = (c.optBoolean("won")
                    ? RIVAL_POST_GRACIOUS[rng.nextInt(RIVAL_POST_GRACIOUS.length)]
                    : RIVAL_POST_GLOAT[rng.nextInt(RIVAL_POST_GLOAT.length)])
                    .replace("{ut}", shortFor(userTeam));
            addNews("🎙 " + Data.managerFor(opp) + " (" + shortFor(opp) + ") reacts: " + q);
        } catch (Exception ignored) {}
    }

    // ---------------- persistence + v1 -> v2 migration ----------------

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("season", season).put("day", day).put("cf", cf);
            o.put("players", players).put("facilities", facilities);
            o.put("fixtures", fixtures).put("tables", tables);
            o.put("career", career).put("history", history).put("news", news);
            o.put("watchlist", watchlist).put("ledger", ledger);
            o.put("talkDay", talkDay);
            o.put("speed", speed).put("potmHistory", potmHistory); // Batch A
            o.put("captain", captain); // Batch C (idea 26)
            // Batch D (ideas 31–40)
            o.put("faPool", faPool).put("scouted", scouted).put("departed", departed);
            o.put("offseason", offseason).put("windowSeason", windowSeason);
            o.put("windowSigns", windowSigns).put("windowList", windowList);
            o.put("loanList", loanList).put("wageShortStreak", wageShortStreak);
            if (auction != null) o.put("auction", auction);
            if (poachOffer != null) o.put("poachOffer", poachOffer);
            // Batch E (ideas 41–50)
            o.put("playoffPhase", playoffPhase).put("playoffFixtures", playoffFixtures);
            o.put("seasonChampion", seasonChampion).put("seasonRunnerUp", seasonRunnerUp);
            o.put("lastAwards", lastAwards).put("tournBook", tournBook);
            o.put("records", records).put("seasonHistory", seasonHistory);
            o.put("hof", hof).put("pendingLegends", pendingLegends).put("h2h", h2h);
            // Batch F (ideas 51–60)
            o.put("userTeam", userTeam).put("customTeam", customTeam);
            o.put("customCode", customCode).put("customColor", customColor);
            o.put("aiInj", aiInj).put("aiXiCache", aiXiCache);
            o.put("worldNations", worldNations).put("worldBat", worldBat).put("worldBowl", worldBowl);
            o.put("callups", callups);
            o.put("cupPhase", cupPhase).put("cupFixtures", cupFixtures);
            o.put("cupChampion", cupChampion).put("cupRunnerUp", cupRunnerUp);
            // Batch G (ideas 61–70)
            o.put("staff", staff).put("staffCandidates", staffCandidates);
            o.put("ticketTier", ticketTier);
            if (sponsor != null) o.put("sponsor", sponsor);
            o.put("sponsorOffers", sponsorOffers).put("sponsorLegacy", sponsorLegacy);
            o.put("sponsorProgress", sponsorProgress).put("sponsorDone", sponsorDone);
            o.put("campPending", campPending).put("campChoice", campChoice);
            o.put("campSeason", campSeason).put("campMatchesUsed", campMatchesUsed);
            o.put("boardConfidence", boardConfidence).put("boardObjectiveType", boardObjectiveType);
            o.put("boardObjectiveText", boardObjectiveText).put("boardObjectiveSeason", boardObjectiveSeason);
            o.put("boardObjectiveResolved", boardObjectiveResolved).put("sacked", sacked);
            o.put("managerXp", managerXp).put("managerLevel", managerLevel);
            o.put("legendBonusPaid", legendBonusPaid).put("freeScoutSeason", freeScoutSeason);
            o.put("fanMood", fanMood).put("fanLossStreak", fanLossStreak);
            // Batch H: news & immersion stores
            o.put("fanPosts", fanPosts).put("pressConf", pressConf).put("pressBoost", pressBoost);
            o.put("lastHeadlineTpl", lastHeadlineTpl).put("lastReport", lastReport);
            o.put("coachTipText", coachTipText).put("coachTipKey", coachTipKey);
            o.put("coachTipSeason", coachTipSeason).put("coachTipDay", coachTipDay);
            o.put("lastTipKey", lastTipKey);
            o.put("seasonBestBat", seasonBestBat).put("seasonBestBowl", seasonBestBowl);
            o.put("seasonBigWin", seasonBigWin).put("seasonFanMoment", seasonFanMoment);
            // Batch I (ideas 81–90)
            o.put("difficulty", difficulty).put("hardcore", hardcore).put("hardcoreCounted", hardcoreCounted);
            o.put("lastChallengeDate", lastChallengeDate).put("challengePaidDate", challengePaidDate);
            o.put("challengeResult", challengeResult).put("challengeStreak", challengeStreak);
            o.put("challengeWins", challengeWins).put("scenarios", scenarios);
            o.put("questWeekKey", questWeekKey).put("quests", quests);
            o.put("achievements", achievements);
            if (prediction != null) o.put("prediction", prediction);
            o.put("predSettled", predSettled).put("predWins", predWins).put("predBoth", predBoth);
            o.put("undoArmed", undoArmed);
            o.put("seasonHomeWins", seasonHomeWins).put("transferSpendSeason", transferSpendSeason);
            o.put("captainSeasonStart", captainSeasonStart).put("captainChangedSeason", captainChangedSeason);
            if (ceremony != null) o.put("ceremony", ceremony);
            if (match != null) o.put("match", match);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static Game fromJson(String s) {
        Game g = new Game();
        try {
            JSONObject o = new JSONObject(s);
            g.season = o.optInt("season", 1);
            g.day = o.optInt("day", 1);
            g.cf = o.optInt("cf", 1000);
            g.players = o.getJSONArray("players");
            g.facilities = o.getJSONArray("facilities");
            g.fixtures = o.getJSONArray("fixtures");
            g.tables = o.getJSONObject("tables");
            g.career = o.getJSONObject("career");
            g.history = o.optJSONArray("history");
            if (g.history == null) g.history = new JSONArray();
            g.news = o.optJSONArray("news");
            if (g.news == null) g.news = new JSONArray();
            g.talkDay = o.optInt("talkDay", -1);
            g.match = o.optJSONObject("match");
            // ---- v2 migration: auto-fill every new field with a safe default.
            // A v1 career loads intact: nothing is wiped, nothing crashes. ----
            for (int i = 0; i < g.players.length(); i++) {
                JSONObject p = g.players.getJSONObject(i);
                if (!p.has("overseas")) p.put("overseas", Data.overseasFor(p.optString("name")));
                if (!p.has("rested")) p.put("rested", false);
                ensurePlayerMeta(p); // Batch C migration: meta/stats defaults, nothing wiped
            }
            g.captain = o.optString("captain", "Shaheen Shah Afridi");
            g.watchlist = o.optJSONArray("watchlist");
            if (g.watchlist == null) g.watchlist = new JSONArray();
            g.ledger = o.optJSONArray("ledger");
            if (g.ledger == null) {
                g.ledger = new JSONArray();
                g.pushLedger(g.cf, "Opening balance (carried from v1 save)");
            }
            if (g.match != null) {
                if (!g.match.has("field")) g.match.put("field", 1);       // Balanced
                if (!g.match.has("shield")) g.match.put("shield", "");
            }
            // ---- Batch D migration (v5 -> v6): player contract/wage/loan
            // fields were already filled by ensurePlayerMeta above. All
            // transfer state defaults to a plain in-season game: offseason 0
            // and NO auction pending, so an old save is never trapped — its
            // rollover proceeds normally and the off-season phase appears
            // from the NEXT rollover onward. Keys exist only in v6 saves. ----
            g.faPool = o.optJSONArray("faPool");
            if (g.faPool == null) { g.faPool = new JSONArray(); g.genFaPool(); }
            g.scouted = o.optJSONObject("scouted");
            if (g.scouted == null) g.scouted = new JSONObject();
            g.departed = o.optJSONArray("departed");
            if (g.departed == null) g.departed = new JSONArray();
            g.offseason = o.optInt("offseason", 0);
            g.auction = o.optJSONObject("auction");
            g.windowSeason = o.optInt("windowSeason", -1);
            g.windowSigns = o.optInt("windowSigns", 0);
            g.windowList = o.optJSONArray("windowList");
            if (g.windowList == null) g.windowList = new JSONArray();
            g.loanList = o.optJSONArray("loanList");
            if (g.loanList == null) { g.loanList = new JSONArray(); g.genLoanList(); }
            g.poachOffer = o.optJSONObject("poachOffer");
            g.wageShortStreak = o.optInt("wageShortStreak", 0);
            // ---- Batch A migration: speed defaults to 1x, POTM history empty,
            // fixture conditions generated deterministically (see BATCHLOG). ----
            // ---- Batch E migration (v6 -> v7): every League & Season field
            // defaults to a plain group-stage game. A v6 save mid-season meets
            // the playoffs when its group stage finishes; a v6 save already
            // sitting in its off-season keeps that phase untouched (its
            // champion was settled under the old rules) and its history /
            // records simply start accumulating from the next rollover. ----
            g.playoffPhase = o.optInt("playoffPhase", 0);
            g.playoffFixtures = o.optJSONArray("playoffFixtures");
            if (g.playoffFixtures == null) g.playoffFixtures = new JSONArray();
            g.seasonChampion = o.optString("seasonChampion", "");
            g.seasonRunnerUp = o.optString("seasonRunnerUp", "");
            g.ceremony = o.optJSONObject("ceremony");
            g.lastAwards = o.optJSONObject("lastAwards");
            if (g.lastAwards == null) g.lastAwards = new JSONObject();
            g.tournBook = o.optJSONObject("tournBook");
            if (g.tournBook == null) g.tournBook = new JSONObject();
            g.records = o.optJSONObject("records");
            if (g.records == null) g.records = new JSONObject();
            g.seasonHistory = o.optJSONArray("seasonHistory");
            if (g.seasonHistory == null) g.seasonHistory = new JSONArray();
            g.hof = o.optJSONArray("hof");
            if (g.hof == null) g.hof = new JSONArray();
            g.pendingLegends = o.optJSONArray("pendingLegends");
            if (g.pendingLegends == null) g.pendingLegends = new JSONArray();
            g.h2h = o.optJSONObject("h2h");
            if (g.h2h == null) g.h2h = new JSONObject();
            // ---- Batch F migration (v7 -> v8): an existing career keeps
            // managing Lahore untouched; every Teams & World field takes a
            // safe default. World state seeds from the static tables with
            // prev = current rank, so no phantom movement appears. The cup
            // simply begins at this career's next group-stage finish when
            // its season number is >= 2. ----
            g.userTeam = o.optString("userTeam", Data.USER_TEAM);
            g.customTeam = o.optBoolean("customTeam", false);
            g.customCode = o.optString("customCode", "");
            g.customColor = o.optInt("customColor", 0);
            g.aiInj = o.optJSONObject("aiInj");
            if (g.aiInj == null) g.aiInj = new JSONObject();
            g.aiXiCache = o.optJSONObject("aiXiCache");
            if (g.aiXiCache == null) g.aiXiCache = new JSONObject();
            g.worldNations = o.optJSONArray("worldNations");
            if (g.worldNations == null) g.worldNations = new JSONArray();
            g.worldBat = o.optJSONArray("worldBat");
            if (g.worldBat == null) g.worldBat = new JSONArray();
            g.worldBowl = o.optJSONArray("worldBowl");
            if (g.worldBowl == null) g.worldBowl = new JSONArray();
            g.seedWorldState();
            g.callups = o.optJSONArray("callups");
            if (g.callups == null) g.callups = new JSONArray();
            g.cupPhase = o.optInt("cupPhase", 0);
            g.cupFixtures = o.optJSONArray("cupFixtures");
            if (g.cupFixtures == null) g.cupFixtures = new JSONArray();
            g.cupChampion = o.optString("cupChampion", "");
            g.cupRunnerUp = o.optString("cupRunnerUp", "");
            // ---- Batch G migration: a v8 save gains the defaults below —
            // vacant staff, Standard tickets, the LEGACY sponsor (the old
            // flat rate keeps paying until this career's next rollover
            // offers real deals), board 70, fans 65, and XP seeded from
            // the career wins already on the books (10 XP each). ----
            g.staff = o.optJSONObject("staff");
            if (g.staff == null) g.staff = new JSONObject();
            g.staffCandidates = o.optJSONArray("staffCandidates");
            if (g.staffCandidates == null || g.staffCandidates.length() == 0) {
                g.staffCandidates = new JSONArray();
                g.genStaffCandidates();
            }
            g.ticketTier = clamp(o.optInt("ticketTier", 1), 0, 4);
            g.sponsor = o.optJSONObject("sponsor");
            g.sponsorOffers = o.optJSONArray("sponsorOffers");
            if (g.sponsorOffers == null) g.sponsorOffers = new JSONArray();
            g.sponsorLegacy = o.optBoolean("sponsorLegacy", true);
            g.sponsorProgress = o.optInt("sponsorProgress", 0);
            g.sponsorDone = o.optBoolean("sponsorDone", false);
            g.campPending = o.optBoolean("campPending", false);
            g.campChoice = o.optInt("campChoice", -1);
            g.campSeason = o.optInt("campSeason", -1);
            g.campMatchesUsed = o.optInt("campMatchesUsed", 0);
            g.boardConfidence = clamp(o.optInt("boardConfidence", 70), 0, 100);
            g.boardObjectiveType = o.optInt("boardObjectiveType", -1);
            g.boardObjectiveSeason = o.optInt("boardObjectiveSeason", g.season);
            g.boardObjectiveText = o.optString("boardObjectiveText", "");
            if (g.boardObjectiveType < 0 || g.boardObjectiveText.isEmpty()) g.setBoardObjective();
            g.boardObjectiveResolved = o.optInt("boardObjectiveResolved", -1);
            g.sacked = o.optBoolean("sacked", false);
            if (o.has("managerXp")) {
                g.managerXp = o.optInt("managerXp", 0);
            } else {
                g.managerXp = 10 * Math.max(0, g.career.optInt("won", 0));
            }
            g.managerLevel = levelForXp(g.managerXp);
            if (g.managerLevel >= 10) g.legendBonusPaid = true; // seeded XP never retro-pays the L10 bonus
            if (o.has("legendBonusPaid")) g.legendBonusPaid = o.optBoolean("legendBonusPaid", g.legendBonusPaid);
            g.freeScoutSeason = o.optInt("freeScoutSeason", -1);
            g.fanMood = clamp(o.optInt("fanMood", 65), 0, 100);
            g.fanLossStreak = o.optInt("fanLossStreak", 0);
            // ---- Batch H migration (v9 -> v10): every news & immersion
            // store defaults EMPTY — no pending conference, no boost, no
            // report, no fan posts, fresh season-review trackers. Press
            // conferences therefore only ever trigger for matches the
            // user finishes after this update; nothing is wiped. ----
            g.fanPosts = o.optJSONArray("fanPosts");
            if (g.fanPosts == null) g.fanPosts = new JSONArray();
            g.pressConf = o.optJSONObject("pressConf");
            g.pressBoost = o.optInt("pressBoost", 0);
            g.lastHeadlineTpl = o.optInt("lastHeadlineTpl", -1);
            g.lastReport = o.optJSONObject("lastReport");
            g.coachTipText = o.optString("coachTipText", "");
            g.coachTipKey = o.optString("coachTipKey", "");
            g.coachTipSeason = o.optInt("coachTipSeason", -1);
            g.coachTipDay = o.optInt("coachTipDay", -1);
            g.lastTipKey = o.optString("lastTipKey", "");
            g.seasonBestBat = o.optJSONObject("seasonBestBat");
            g.seasonBestBowl = o.optJSONObject("seasonBestBowl");
            g.seasonBigWin = o.optJSONObject("seasonBigWin");
            g.seasonFanMoment = o.optJSONObject("seasonFanMoment");
            // ---- Batch I migration (v10 -> v11): difficulty defaults to
            // Manager, hardcore off, challenge/scenario/prediction state
            // empty, slots live outside the save (Slots.java). Achievements
            // start locked EXCEPT four honest retro-grants the career
            // counters already prove — granted silently, with no XP. ----
            g.difficulty = clamp(o.optInt("difficulty", 1), 0, 2);
            g.hardcore = o.optBoolean("hardcore", false);
            g.hardcoreCounted = o.optBoolean("hardcoreCounted", false);
            g.lastChallengeDate = o.optString("lastChallengeDate", "");
            g.challengePaidDate = o.optString("challengePaidDate", "");
            g.challengeResult = o.optString("challengeResult", "");
            g.challengeStreak = o.optInt("challengeStreak", 0);
            g.challengeWins = o.optInt("challengeWins", 0);
            g.scenarios = o.optJSONObject("scenarios");
            if (g.scenarios == null) g.scenarios = new JSONObject();
            g.questWeekKey = o.optInt("questWeekKey", -1);
            g.quests = o.optJSONArray("quests");
            if (g.quests == null) g.quests = new JSONArray();
            g.achievements = o.optJSONObject("achievements");
            if (g.achievements == null) {
                g.achievements = new JSONObject();
                if (g.career.optInt("won") > 0) g.grantRetroAchievement("FIRSTWIN");
                if (g.career.optInt("titles") > 0) g.grantRetroAchievement("FIRSTTITLE");
                if (g.career.optInt("cups") > 0) g.grantRetroAchievement("CUPWINNER");
                if (g.managerLevel >= 10) g.grantRetroAchievement("LEGENDMGR");
            }
            g.prediction = o.optJSONObject("prediction");
            g.predSettled = o.optInt("predSettled", 0);
            g.predWins = o.optInt("predWins", 0);
            g.predBoth = o.optInt("predBoth", 0);
            g.undoArmed = o.optBoolean("undoArmed", false);
            g.seasonHomeWins = o.optInt("seasonHomeWins", 0);
            g.transferSpendSeason = o.optInt("transferSpendSeason", 0);
            g.captainSeasonStart = o.optString("captainSeasonStart", g.captain);
            g.captainChangedSeason = o.optBoolean("captainChangedSeason", false);
            g.ensureQuests(); // quests for the current week (Days 1–21) generate on first load
            g.speed = o.optInt("speed", 1);
            g.potmHistory = o.optJSONArray("potmHistory");
            if (g.potmHistory == null) g.potmHistory = new JSONArray();
            for (int i = 0; i < g.fixtures.length(); i++) {
                ensureFixtureMeta(g.fixtures.getJSONObject(i), g.season);
            }
            if (g.match != null) MatchEngine.migrateMatch(g);
        } catch (Exception e) {
            return fresh();
        }
        return g;
    }

    // ---------------- helpers ----------------

    public void addNews(String s) {
        try {
            JSONArray n = new JSONArray();
            n.put(s);
            for (int i = 0; i < Math.min(news.length(), 14); i++) n.put(news.getString(i));
            news = n;
        } catch (Exception ignored) {}
    }

    public JSONObject player(int i) {
        try { return players.getJSONObject(i); } catch (Exception e) { return new JSONObject(); }
    }

    public int xiCount() {
        int n = 0;
        for (int i = 0; i < players.length(); i++) if (player(i).optBoolean("inXI")) n++;
        return n;
    }

    public List<JSONObject> xi() {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < players.length(); i++) if (player(i).optBoolean("inXI")) out.add(player(i));
        return out;
    }

    public int facilityLevel(int idx) {
        return facilities.optInt(idx, 1);
    }

    public double nrr(String team) {
        try {
            JSONObject r = tables.getJSONObject(team);
            double rf = r.optInt("rf"), bf = r.optInt("bf"), ra = r.optInt("ra"), ba = r.optInt("ba");
            if (bf == 0 || ba == 0) return 0;
            return rf / (bf / 6.0) - ra / (ba / 6.0);
        } catch (Exception e) { return 0; }
    }

    /** The user's unplayed fixture scheduled for today, or null. */
    public JSONObject todaysUserFixture() {
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (!f.optBoolean("played") && f.optInt("day") == day && involvesUser(f)) return f;
            } catch (Exception ignored) {}
        }
        return null;
    }

    /** Next unplayed user fixture (any day), or null. */
    public JSONObject nextUserFixture() {
        JSONObject best = null;
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (!f.optBoolean("played") && involvesUser(f)) {
                    if (best == null || f.optInt("day") < best.optInt("day")) best = f;
                }
            } catch (Exception ignored) {}
        }
        return best;
    }

    public boolean involvesUser(JSONObject f) {
        return userTeam.equals(f.optString("home")) || userTeam.equals(f.optString("away"));
    }

    public String opponentOf(JSONObject f) {
        return userTeam.equals(f.optString("home")) ? f.optString("away") : f.optString("home");
    }

    // ---------------- team-sheet validator (v2) ----------------

    /** Bowling option = a selected player with bowling rating 60+. */
    public static final int BOWL_OPTION_MIN = 60;
    public static final int MIN_BOWL_OPTIONS = 5;
    public static final int MAX_OVERSEAS = 4;

    /** Every problem with the current XI, in plain words. Empty list = legal team sheet. */
    public List<String> xiProblems() {
        List<String> out = new ArrayList<>();
        try {
            int count = 0, overseas = 0, bowlOpts = 0;
            boolean hasWK = false;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (!p.optBoolean("inXI")) continue;
                count++;
                if (p.optBoolean("overseas")) overseas++;
                if ("WK".equals(p.optString("role"))) hasWK = true;
                if (p.optInt("bowl") >= BOWL_OPTION_MIN) bowlOpts++;
                if (p.optBoolean("rested")) out.add(p.optString("name") + " is RESTED — un-rest him or remove him from the XI.");
                if (p.optBoolean("loanOut")) out.add(p.optString("name") + " is ON LOAN for the season — he cannot play until he returns.");
                if (p.optInt("injured", 0) > 0) out.add(p.optString("name") + " is INJURED (" + p.optInt("injured") + " days out) — he cannot play until fit.");
            }
            if (count != 11) out.add(0, "XI has " + count + "/11 players — select exactly 11.");
            if (!hasWK) out.add("No wicketkeeper (WK) in the XI — pick a WK.");
            if (bowlOpts < MIN_BOWL_OPTIONS) out.add("Only " + bowlOpts + " bowling options (bowl " + BOWL_OPTION_MIN + "+) — need at least " + MIN_BOWL_OPTIONS + ".");
            if (overseas > MAX_OVERSEAS) out.add(overseas + " overseas players in the XI — the limit is " + MAX_OVERSEAS + ".");
        } catch (Exception ignored) {}
        return out;
    }

    public boolean xiLegal() {
        return xiProblems().isEmpty();
    }

    public int xiOverseasCount() {
        int n = 0;
        for (JSONObject p : xi()) if (p.optBoolean("overseas")) n++;
        return n;
    }

    // ---------------- rested system (v2) ----------------

    /** Rest / un-rest a player. Resting removes him from the XI immediately
     *  (the batting order is just the XI list, so it compacts on its own). */
    public void setRested(JSONObject p, boolean rested) {
        try {
            p.put("rested", rested);
            if (rested) p.put("inXI", false);
        } catch (Exception ignored) {}
    }

    // ---------------- watchlist (v2) ----------------

    public boolean isWatched(String name) {
        for (int i = 0; i < watchlist.length(); i++) if (name.equals(watchlist.optString(i))) return true;
        return false;
    }

    public void toggleWatch(String name) {
        try {
            JSONArray n = new JSONArray();
            boolean removed = false;
            for (int i = 0; i < watchlist.length(); i++) {
                String w = watchlist.getString(i);
                if (w.equals(name)) { removed = true; continue; }
                n.put(w);
            }
            if (!removed) n.put(name);
            watchlist = n;
        } catch (Exception ignored) {}
    }

    /** Inbox alert if a watchlisted player produced a headline feat. */
    public void watchlistAlert(String name, String feat, String matchSummary) {
        if (name == null || name.isEmpty() || !isWatched(name)) return;
        addNews("★ WATCHLIST: " + name + " — " + feat + " (" + matchSummary + ")");
    }

    /** Scan a finished innings' cards for watchlist centuries / 5-wicket hauls. */
    public void watchlistCheckCards(JSONArray batCard, JSONArray bowlCard, String matchSummary) {
        try {
            if (batCard != null) for (int i = 0; i < batCard.length(); i++) {
                JSONObject b = batCard.getJSONObject(i);
                if (b.optInt("runs") >= 100)
                    watchlistAlert(b.optString("name"), "scored " + b.optInt("runs") + " (century!)", matchSummary);
            }
            if (bowlCard != null) for (int i = 0; i < bowlCard.length(); i++) {
                JSONObject b = bowlCard.getJSONObject(i);
                if (b.optInt("wkts") >= 5)
                    watchlistAlert(b.optString("name"), "took " + b.optInt("wkts") + " wickets (5-for!)", matchSummary);
            }
        } catch (Exception ignored) {}
    }

    // ---------------- Batch C: player meta, morale, captain, Best XI ----------------

    /** Season/career stats object (ideas 21/29). Batting: m matches, inn innings,
     *  runs, balls, hs, f50, f100, outs (dismissals — the average divisor).
     *  Bowling: bwBalls, wkts, conc (runs conceded), bestW/bestR best figures,
     *  f3 (3-fors), f5 (5-fors). */
    public static JSONObject emptyStats() {
        JSONObject s = new JSONObject();
        try {
            s.put("m", 0).put("inn", 0).put("runs", 0).put("balls", 0).put("hs", 0)
             .put("f50", 0).put("f100", 0).put("outs", 0)
             .put("bwBalls", 0).put("wkts", 0).put("conc", 0)
             .put("bestW", 0).put("bestR", 0).put("f3", 0).put("f5", 0);
        } catch (Exception ignored) {}
        return s;
    }

    /** Fills ONLY the missing Batch C fields on a player object (fresh careers,
     *  v4-save migration, academy prospects). Never touches existing values. */
    public static void ensurePlayerMeta(JSONObject p) {
        try {
            String name = p.optString("name");
            if (!p.has("age")) p.put("age", Data.ageFor(name));
            if (!p.has("pot")) p.put("pot", Data.potFor(name, rating(p)));
            if (!p.has("morale")) p.put("morale", 70);
            if (!p.has("injured")) p.put("injured", 0);
            if (!p.has("injType")) p.put("injType", "");
            if (!p.has("bench")) p.put("bench", 0);
            if (!p.has("ss")) p.put("ss", emptyStats());
            if (!p.has("cs")) p.put("cs", emptyStats());
            if (!p.has("formB")) p.put("formB", new JSONArray());
            if (!p.has("formW")) p.put("formW", new JSONArray());
            if (!p.has("miles")) p.put("miles", new JSONArray());
            // Batch D (ideas 34–36): contract, weekly wage, loan flags
            if (!p.has("contract")) p.put("contract", Data.contractFor(name));
            if (!p.has("wage")) p.put("wage", wageFor(rating(p)));
            if (!p.has("loanOut")) p.put("loanOut", false);
            if (!p.has("loanIn")) p.put("loanIn", false);
            if (!p.has("tags")) {
                JSONArray t = new JSONArray();
                for (String s : Data.tagsFor(name, p.optInt("bat"), p.optInt("bowl"))) t.put(s);
                p.put("tags", t);
            }
        } catch (Exception ignored) {}
    }

    public JSONObject playerByName(String name) {
        if (name == null) return null;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            if (name.equals(p.optString("name"))) return p;
        }
        return null;
    }

    public static int clampMorale(int v) {
        return Math.max(0, Math.min(100, v));
    }

    /** Morale shift with clamping (idea 25). No-op for unknown names. */
    public void adjustMorale(String name, int delta) {
        JSONObject p = playerByName(name);
        if (p == null || delta == 0) return;
        try { p.put("morale", clampMorale(p.optInt("morale", 70) + delta)); } catch (Exception ignored) {}
    }

    /** Effective-rating modifier from morale (idea 25): morale 70 = 0,
     *  100 = +3, 40 or below = −3. Unit-testable; MatchEngine adds this to a
     *  squad player's bat/bowl rating before computing the ball weights. */
    public int moraleMod(String name) {
        JSONObject p = playerByName(name);
        if (p == null) return 0;
        int mod = (p.optInt("morale", 70) - 70) / 10;
        // Batch G (idea 61): an elite Head Coach (85+) stretches the
        // positive morale cap from +3 to +4 — his men get more from form.
        int cap = staffRating("Head Coach") >= 85 ? 4 : 3;
        return Math.max(-3, Math.min(cap, mod));
    }

    /** Specialist tags stored on a squad player (idea 30); empty for others. */
    public List<String> tagsOf(String name) {
        List<String> out = new ArrayList<>();
        JSONObject p = playerByName(name);
        if (p == null) return out;
        JSONArray t = p.optJSONArray("tags");
        if (t != null) for (int i = 0; i < t.length(); i++) out.add(t.optString(i));
        return out;
    }

    public boolean hasTag(String name, String tag) {
        return tagsOf(name).contains(tag);
    }

    /** True when any current XI player carries the tag (Safe Hands check). */
    public boolean xiHasTag(String tag) {
        for (JSONObject p : xi()) if (tagsOf(p.optString("name")).contains(tag)) return true;
        return false;
    }

    public static String moraleLabel(int morale) {
        if (morale >= 80) return "High";
        if (morale >= 60) return "Good";
        if (morale >= 40) return "Okay";
        return "Low";
    }

    // ---- captain (idea 26) ----

    public boolean captainInXi() {
        JSONObject c = playerByName(captain);
        return c != null && c.optBoolean("inXI");
    }

    /** Designates a new captain: the old skipper takes a small morale hit,
     *  the new one gets a lift. Returns false if the name is not in the squad. */
    public boolean setCaptain(String name) {
        JSONObject np = playerByName(name);
        if (np == null || name.equals(captain)) return false;
        adjustMorale(captain, -5);
        captain = name;
        if (!captainSeasonStart.isEmpty()) captainChangedSeason = true; // Batch I (idea 85): Loyal broken
        adjustMorale(name, +8);
        addNews(name + " is the new " + userTeam + " captain.");
        return true;
    }

    // ---- auto-pick Best XI (idea 27) ----

    /** Selection score: rating leads, stamina/morale/form support, pitch bonus. */
    public double bestXiScore(JSONObject p, int pitch) {
        double s = rating(p) * 1.0 + p.optInt("stam") * 0.15 + p.optInt("morale", 70) * 0.10;
        int trend = StatsBook.formTrend(p); // +1 hot, -1 cold
        s += trend * 4;
        if (pitch == 3 && Data.isSpinner(p.optString("name"))) s += 6;  // Turning: spinners gold
        if (pitch == 1 && p.optInt("bowl") >= 80 && !Data.isSpinner(p.optString("name"))) s += 5; // Green: pace
        return s;
    }

    /** Fills a validator-legal XI maximising bestXiScore: keeper first, then
     *  enough bowling options, then the best of the rest — overseas cap and
     *  rested/injured availability always respected. Returns a summary line. */
    public String pickBestXI(int pitch) {
        try {
            List<JSONObject> cand = new ArrayList<>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (p.optBoolean("rested") || p.optInt("injured", 0) > 0 || p.optBoolean("loanOut")) continue;
                cand.add(p);
            }
            final int pf = pitch;
            java.util.Collections.sort(cand, new java.util.Comparator<JSONObject>() {
                @Override public int compare(JSONObject a, JSONObject b) {
                    return Double.compare(bestXiScore(b, pf), bestXiScore(a, pf));
                }
            });
            List<JSONObject> sel = new ArrayList<>();
            int osUsed = 0;
            // 1) best keeper
            for (JSONObject p : cand) {
                if (!"WK".equals(p.optString("role"))) continue;
                if (p.optBoolean("overseas") && osUsed >= MAX_OVERSEAS) continue;
                sel.add(p); if (p.optBoolean("overseas")) osUsed++;
                break;
            }
            // 2) bowling options until we have 5+
            for (JSONObject p : cand) {
                if (countBowlOptions(sel) >= MIN_BOWL_OPTIONS || sel.size() >= 11) break;
                if (sel.contains(p) || p.optInt("bowl") < BOWL_OPTION_MIN) continue;
                if (p.optBoolean("overseas") && osUsed >= MAX_OVERSEAS) continue;
                sel.add(p); if (p.optBoolean("overseas")) osUsed++;
            }
            // 3) fill by score
            for (JSONObject p : cand) {
                if (sel.size() >= 11) break;
                if (sel.contains(p)) continue;
                if (p.optBoolean("overseas") && osUsed >= MAX_OVERSEAS) continue;
                sel.add(p); if (p.optBoolean("overseas")) osUsed++;
            }
            // 4) last resort (very thin squad): best-effort fill to 11 names —
            //    if that breaks a rule, xiProblems() below reports it honestly
            for (JSONObject p : cand) {
                if (sel.size() >= 11) break;
                if (!sel.contains(p)) sel.add(p);
            }
            for (int i = 0; i < players.length(); i++) player(i).put("inXI", sel.contains(player(i)));
            List<String> probs = xiProblems();
            String pitchNote = pitch == 3 ? " (extra spinner for the Turning pitch)"
                    : pitch == 1 ? " (extra pace for the Green pitch)" : "";
            return probs.isEmpty()
                    ? "Best XI picked" + pitchNote + " — team sheet is legal."
                    : "Best XI picked" + pitchNote + " — still " + probs.size() + " problem(s): " + probs.get(0);
        } catch (Exception e) {
            return "Best XI unavailable.";
        }
    }

    private static int countBowlOptions(List<JSONObject> sel) {
        int n = 0;
        for (JSONObject p : sel) if (p.optInt("bowl") >= BOWL_OPTION_MIN) n++;
        return n;
    }

    // ---------------- Batch D: transfers & contracts (ideas 31–40) ----------------

    /** Builds a complete squad-ready player object from raw attributes,
     *  with every Batch A–D field defaulted (auction lots, free agents,
     *  window listings, loan-ins all start life here). */
    public static JSONObject makePlayer(String name, String role, int bat, int bowl, boolean overseas) {
        JSONObject p = new JSONObject();
        try {
            p.put("name", name).put("role", role).put("bat", bat).put("bowl", bowl);
            p.put("stam", 88 + (Math.abs(name.hashCode()) % 12));
            p.put("set", 55 + (Math.abs(name.hashCode() / 7) % 30));
            p.put("overseas", overseas).put("rested", false).put("inXI", false);
            p.put("age", Data.ageFor(name));
            ensurePlayerMeta(p);
        } catch (Exception ignored) {}
        return p;
    }

    private static JSONObject makeFromRow(Object[] r) {
        return makePlayer((String) r[0], (String) r[1], (Integer) r[2], (Integer) r[3], (Boolean) r[4]);
    }

    // ---- wages (idea 35) ----

    /** Weekly wage from overall rating: ~4–10 CF per man, ≈102 CF/week for
     *  the whole starting squad — meaningful against ~1,600+ CF of typical
     *  season income, never instantly bankrupting. */
    public static int wageFor(int rating) {
        return Math.max(2, rating * rating / 900);
    }

    public void refreshWage(JSONObject p) {
        try { p.put("wage", wageFor(rating(p))); } catch (Exception ignored) {}
    }

    /** Player wages only (gross). Loaned-IN men cost nothing; loaned-OUT
     *  men's wages are paid by their host club. */
    public int playerWagesGross() {
        int sum = 0;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            if (p.optBoolean("loanIn") || p.optBoolean("loanOut")) continue;
            sum += p.optInt("wage", wageFor(rating(p)));
        }
        return sum;
    }

    /** Batch G (idea 69): the L8 perk shaves 5% off the whole bill. */
    public int wageDiscountAmount() {
        if (managerLevel < 8) return 0;
        return (int) Math.round((playerWagesGross() + staffWages()) * 0.05);
    }

    /** The full weekly bill (idea 35 + Batch G idea 61): players + staff,
     *  minus the L8 manager discount. ONE combined ledger line charges
     *  this; the split rides on the entry for the Finances view.
     *  Batch I (idea 81): difficulty scales the whole bill — Casual
     *  x0.8, Legend x1.15 (the stored split stays the gross split). */
    public int weeklyWages() {
        int base = playerWagesGross() + staffWages() - wageDiscountAmount();
        if (difficulty == 0) return (int) Math.round(base * 0.8);
        if (difficulty == 2) return (int) Math.round(base * 1.15);
        return base;
    }

    /** Next in-game day (within the season) on which wages fall due. */
    public int nextWageDay() {
        int d = ((day - 1) / 7 + 1) * 7;
        return Math.min(d, 21);
    }

    // ---- squad membership helpers ----

    /** Removes a player from the squad entirely. Reassigns the captaincy if
     *  he held it. Returns true when the name was found. */
    public boolean removePlayer(String name) {
        try {
            JSONArray kept = new JSONArray();
            boolean found = false;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (name.equals(p.optString("name"))) {
                    found = true;
                    // Batch E (idea 49): a departing great is parked for the
                    // Hall of Fame — inducted once the auction proves he is
                    // really gone (flushPendingLegends), not if he's rebought.
                    maybeParkLegend(p);
                    continue;
                }
                kept.put(p);
            }
            if (found) {
                players = kept;
                ensureCaptain();
            }
            return found;
        } catch (Exception e) {
            return false;
        }
    }

    /** Batch E (idea 49): Lahore Legends thresholds — 50+ career matches,
     *  1,000+ career runs or 50+ career wickets in Lahore colours. */
    private void maybeParkLegend(JSONObject p) {
        try {
            JSONObject cs = p.optJSONObject("cs");
            if (cs == null) return;
            if (cs.optInt("m") < 50 && cs.optInt("runs") < 1000 && cs.optInt("wkts") < 50) return;
            String name = p.optString("name");
            for (int i = 0; i < hof.length(); i++) {
                JSONObject e = hof.getJSONObject(i);
                if ("legend".equals(e.optString("kind")) && name.equals(e.optString("name"))) return;
            }
            for (int i = 0; i < pendingLegends.length(); i++) {
                if (name.equals(pendingLegends.getJSONObject(i).optString("name"))) return;
            }
            JSONObject e = new JSONObject();
            e.put("name", name);
            e.put("line", cs.optInt("m") + " matches · " + cs.optInt("runs") + " runs · "
                    + cs.optInt("wkts") + " wickets for " + userTeam);
            pendingLegends.put(e);
        } catch (Exception ignored) {}
    }

    /** Batch E (idea 49): called when the auction closes — a parked legend
     *  who is still gone is inducted (with a news item); one who was
     *  rebought simply comes off the list and plays on. */
    public void flushPendingLegends() {
        try {
            for (int i = 0; i < pendingLegends.length(); i++) {
                JSONObject e = pendingLegends.getJSONObject(i);
                String name = e.optString("name");
                if (playerByName(name) != null) continue; // rebought — not gone after all
                JSONObject h = new JSONObject();
                h.put("kind", "legend").put("name", name)
                        .put("line", e.optString("line")).put("season", season);
                hof.put(h);
                addNews("🏛 HALL OF FAME: " + name + " is inducted as a " + userTeam + " Legend — "
                        + e.optString("line") + ". The home crowd will sing his name for years.");
            }
            pendingLegends = new JSONArray();
        } catch (Exception ignored) {}
    }

    /** If the captain has left the squad, the armband passes to the
     *  highest-rated man still here. */
    public void ensureCaptain() {
        if (playerByName(captain) != null || players.length() == 0) return;
        JSONObject best = null;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            if (best == null || rating(p) > rating(best)) best = p;
        }
        if (best != null) {
            captain = best.optString("name");
            addNews(captain + " takes over as " + userTeam + " captain.");
        }
    }

    public boolean squadFull() {
        return players.length() >= SQUAD_CAP;
    }

    // ---- release (idea 32) ----

    /** Releases a player. Off-season phase 1: free, he joins the departed
     *  list and will appear in the auction pool. Mid-season window: a 25 CF
     *  settlement and he is simply gone. Returns a result line, or null and
     *  sets nothing when the release is not currently allowed. */
    public String releasePlayer(String name) {
        JSONObject p = playerByName(name);
        if (p == null) return "Player not found.";
        if (players.length() <= 11) return "The squad must keep at least 11 players.";
        if (p.optBoolean("loanIn")) return "He is only here on loan — he goes back at rollover.";
        if (p.optBoolean("loanOut")) return name + " is out on loan — he cannot be released until he returns.";
        try {
            if (offseason == 1) {
                JSONObject copy = new JSONObject(p.toString());
                removePlayer(name);
                departed.put(copy);
                addNews("Released: " + name + " leaves " + userTeam + " and enters the auction pool.");
                return name + " released (free) — he is in the auction pool.";
            }
            if (transferWindowOpen()) {
                int fee = ledgerExpense(RELEASE_FEE_WINDOW, "Release settlement — " + name);
                removePlayer(name);
                addNews("Released: " + name + " leaves " + userTeam + " (settlement −" + fee + " CF).");
                return name + " released — settlement " + fee + " CF.";
            }
        } catch (Exception ignored) {}
        return "Releases open in the off-season (free) or the transfer window (" + RELEASE_FEE_WINDOW + " CF).";
    }

    // ---- contracts & renewals (idea 34) ----

    /** Renewal fee for one extra season: scaled by rating. */
    public int renewFeePerYear(JSONObject p) {
        return Math.max(15, rating(p) - 50);
    }

    /** Renews an OUT-OF-CONTRACT player for 1–3 more seasons during the
     *  off-season phase. Returns a result line. */
    public String renewPlayer(String name, int years) {
        JSONObject p = playerByName(name);
        if (p == null) return "Player not found.";
        if (offseason != 1) return "Renewals happen in the off-season.";
        if (p.optInt("contract", 1) > 0) return name + " is still under contract.";
        years = Math.max(1, Math.min(3, years));
        int fee = renewFeePerYear(p) * years;
        if (cf < fee) return "Not enough CF — renewal costs " + fee + " CF.";
        try {
            ledgerCf(-fee, "Contract renewal — " + name + " (" + years + " season" + (years > 1 ? "s" : "") + ")");
            p.put("contract", years);
            refreshWage(p);
            adjustMorale(name, +5);
            addNews(name + " signs a new " + years + "-season deal (−" + fee + " CF).");
            return name + " renewed for " + years + " season(s) — " + fee + " CF.";
        } catch (Exception e) {
            return "Renewal failed.";
        }
    }

    /** Ends off-season phase 1: every still-out-of-contract man leaves into
     *  the departed list, then the auction opens (phase 2). */
    public String confirmOffseason() {
        try {
            List<String> leaving = new ArrayList<>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (p.optInt("contract", 1) <= 0 && !p.optBoolean("loanIn")) leaving.add(p.optString("name"));
            }
            for (String name : leaving) {
                JSONObject p = playerByName(name);
                if (p == null) continue;
                departed.put(new JSONObject(p.toString()));
                removePlayer(name);
                addNews(name + "'s contract expired — he leaves " + userTeam + " and enters the auction pool.");
            }
            ensureCaptain();
            beginAuction();
            return "Squad confirmed. The Season " + season + " auction is open — "
                    + auctionPool().length() + " lots.";
        } catch (Exception e) {
            offseason = 0;
            return "Off-season wrapped up.";
        }
    }

    // ---- auction (idea 31) ----

    private static final String[] AI_BIDDERS = {"Karachi Kings", "Islamabad United", "Multan Sultans"};

    public int basePrice(JSONObject p) {
        return Math.max(40, (rating(p) - 55) * 6);
    }

    public JSONArray auctionPool() {
        return auction == null ? new JSONArray() : auction.optJSONArray("pool");
    }

    public JSONObject auctionLot() {
        JSONArray pool = auctionPool();
        if (auction == null || pool == null) return null;
        int idx = auction.optInt("idx");
        return idx < pool.length() ? pool.optJSONObject(idx) : null;
    }

    /** Builds the ~10-lot pool (departed men + 3 star lots + generated
     *  names) and opens lot 1. AI budgets/valuations live in the auction
     *  JSON, so a mid-auction save resumes exactly. */
    public void beginAuction() {
        try {
            JSONArray pool = new JSONArray();
            java.util.Set<String> used = new java.util.HashSet<>();
            for (int i = 0; i < departed.length(); i++) {
                JSONObject d = departed.optJSONObject(i);
                if (d == null) continue;
                d.put("base", basePrice(d));
                pool.put(d);
                used.add(d.optString("name"));
            }
            departed = new JSONArray();
            // 3 star lots, order shuffled by the game rng
            List<Object[]> stars = new ArrayList<>();
            for (Object[] r : Data.AUCTION_STARS) stars.add(r);
            java.util.Collections.shuffle(stars, rng);
            for (int i = 0; i < Math.min(3, stars.size()); i++) {
                Object[] r = stars.get(i);
                if (used.contains((String) r[0]) || playerByName((String) r[0]) != null) continue;
                JSONObject p = makeFromRow(r);
                p.put("base", basePrice(p));
                pool.put(p);
                used.add((String) r[0]);
            }
            // generated names fill the pool toward 10 lots
            List<Object[]> gens = new ArrayList<>();
            for (Object[] r : Data.GEN_POOL) gens.add(r);
            java.util.Collections.shuffle(gens, rng);
            for (Object[] r : gens) {
                if (pool.length() >= 10) break;
                if (used.contains((String) r[0]) || playerByName((String) r[0]) != null) continue;
                JSONObject p = makeFromRow(r);
                p.put("base", basePrice(p));
                pool.put(p);
                used.add((String) r[0]);
            }
            auction = new JSONObject();
            auction.put("pool", pool);
            auction.put("idx", 0);
            JSONObject budgets = new JSONObject();
            budgets.put(AI_BIDDERS[0], 900).put(AI_BIDDERS[1], 850).put(AI_BIDDERS[2], 800);
            auction.put("budgets", budgets);
            auction.put("log", new JSONArray());
            offseason = 2;
            auctionOpenLot();
            addNews("The Season " + season + " auction is open: " + pool.length()
                    + " lots. Bid from HQ → Transfers — or skip it.");
        } catch (Exception ignored) {}
    }

    /** Sets up the current lot: opening bid just under base, one AI
     *  valuation per rival (rolled once per lot, budget-capped). */
    private void auctionOpenLot() {
        try {
            JSONObject lot = auctionLot();
            if (lot == null) { finishAuction(); return; }
            int base = lot.optInt("base");
            auction.put("inc", Math.max(10, base / 8));
            auction.put("curBid", base - auction.optInt("inc"));
            auction.put("leader", "");
            JSONObject budgets = auction.optJSONObject("budgets");
            JSONObject mx = new JSONObject();
            for (String t : AI_BIDDERS) {
                int budget = budgets == null ? 0 : budgets.optInt(t, 0);
                int m = (int) (base * (0.85 + rng.nextDouble() * 0.95));
                if (rating(lot) >= 85) m = (int) (m * 1.15);
                if (managerLevel >= 6) m = (int) (m * 0.92); // Batch G L6 perk: a calmer room
                if (difficulty == 2) m = (int) (m * 1.15); // Batch I (idea 81): a Legend room bids harder
                mx.put(t, Math.min(m, budget));
            }
            auction.put("aiMax", mx);
        } catch (Exception ignored) {}
    }

    private void auctionLog(String s) {
        try {
            JSONArray log = auction.optJSONArray("log");
            if (log == null) { log = new JSONArray(); auction.put("log", log); }
            log.put(s);
        } catch (Exception ignored) {}
    }

    /** First rival (random order) willing and able to raise above the
     *  current bid, or null when the room has gone quiet. */
    private String pickAiRaiser() {
        try {
            int inc = auction.optInt("inc");
            int next = auction.optInt("curBid") + inc;
            JSONObject mx = auction.optJSONObject("aiMax");
            JSONObject budgets = auction.optJSONObject("budgets");
            int start = rng.nextInt(AI_BIDDERS.length);
            for (int k = 0; k < AI_BIDDERS.length; k++) {
                String t = AI_BIDDERS[(start + k) % AI_BIDDERS.length];
                if (t.equals(auction.optString("leader"))) continue;
                if (mx != null && mx.optInt(t, 0) >= next && budgets != null && budgets.optInt(t, 0) >= next) return t;
            }
        } catch (Exception ignored) {}
        return null;
    }

    /** The user raises by one increment; the room gets one response. If no
     *  rival counters, the hammer falls for the user immediately. */
    public String auctionBid() {
        JSONObject lot = auctionLot();
        if (lot == null) return "The auction is over.";
        try {
            int next = auction.optInt("curBid") + auction.optInt("inc");
            if (!"USER".equals(auction.optString("leader")) && squadFull())
                return "Squad is full (" + SQUAD_CAP + ") — a signing is blocked until someone is released.";
            if (cf < next) return "Not enough CF — that bid needs " + next + " CF.";
            auction.put("curBid", next);
            auction.put("leader", "USER");
            String raiser = pickAiRaiser();
            if (raiser != null) {
                int nb = next + auction.optInt("inc");
                auction.put("curBid", nb);
                auction.put("leader", raiser);
                return raiser + " counter at " + nb + " CF — bid again or pass.";
            }
            settleAuctionUserWin(lot, next);
            return "SOLD! " + lot.optString("name") + " joins " + userTeam + " for " + next + " CF.";
        } catch (Exception e) {
            return "Bid failed.";
        }
    }

    /** Pass on the current lot: a leading rival takes him, an unbid lot
     *  goes unsold (and into the free-agent pool if there is room). */
    public String auctionPass() {
        JSONObject lot = auctionLot();
        if (lot == null) return "The auction is over.";
        try {
            String leader = auction.optString("leader");
            String name = lot.optString("name");
            int price = auction.optInt("curBid");
            if ("USER".equals(leader)) {
                return "You are the highest bidder — the lot is yours when the room goes quiet. Bid once more to close it.";
            }
            if (!leader.isEmpty()) {
                JSONObject budgets = auction.optJSONObject("budgets");
                if (budgets != null) budgets.put(leader, budgets.optInt(leader, 0) - price);
                auctionLog(leader + " signed " + name + " for " + price + " CF.");
                addNews("Auction: " + leader + " sign " + name + " for " + price + " CF.");
            } else {
                auctionLog(name + " went unsold.");
                if (faPool.length() < 6 && playerByName(name) == null) faPool.put(new JSONObject(lot.toString()));
            }
            advanceAuctionLot();
            return "Passed on " + name + ".";
        } catch (Exception e) {
            return "Pass failed.";
        }
    }

    private void settleAuctionUserWin(JSONObject lot, int price) {
        try {
            JSONObject p = new JSONObject(lot.toString());
            p.remove("base");
            p.put("contract", 2);
            p.put("inXI", false);
            p.put("loanOut", false);
            p.put("loanIn", false);
            p.put("rested", false);
            refreshWage(p);
            players.put(p);
            ledgerCf(-price, "Auction signing — " + p.optString("name"));
            noteTransferSpend(price); // Batch I (idea 85)
            noteStarSigning(p); // Batch G (idea 70)
            auctionLog("You signed " + p.optString("name") + " for " + price + " CF.");
            addNews("AUCTION: " + userTeam + " sign " + p.optString("name") + " for " + price + " CF!");
            advanceAuctionLot();
        } catch (Exception ignored) {}
    }

    private void advanceAuctionLot() {
        try {
            auction.put("idx", auction.optInt("idx") + 1);
            if (auctionLot() == null) finishAuction();
            else auctionOpenLot();
        } catch (Exception ignored) {}
    }

    private void finishAuction() {
        auction = null;
        offseason = 0;
        flushPendingLegends(); // Batch E (idea 49): the departed are really gone now
        resolveCallups(); // Batch F (idea 55): the internationals are back for Season start
        // Batch G (idea 64): no sponsor picked by now? The safe board
        // grant is auto-taken so the season never starts sponsor-less.
        if (sponsor == null && sponsorOffers.length() > 0) chooseSponsor(3);
        addNews("The auction is done — Season " + season + " fixtures are live. Good luck, manager!");
    }

    /** Skipping is always available: unbid lots simply vanish (released
     *  men already left the squad when they were released). */
    public String skipAuction() {
        if (auction == null) {
            offseason = 0;
            flushPendingLegends();
            resolveCallups();
            if (sponsor == null && sponsorOffers.length() > 0) chooseSponsor(3); // Batch G (idea 64)
            return "No auction running.";
        }
        int left = Math.max(0, auctionPool().length() - auction.optInt("idx"));
        auction = null;
        offseason = 0;
        flushPendingLegends(); // Batch E (idea 49)
        resolveCallups(); // Batch F (idea 55)
        if (sponsor == null && sponsorOffers.length() > 0) chooseSponsor(3); // Batch G (idea 64)
        addNews("Auction skipped (" + left + " lots unbid) — Season " + season + " begins with the squad as it stands.");
        return "Auction skipped — season on!";
    }

    // ---- mid-season transfer window (idea 33) ----

    public boolean transferWindowOpen() {
        return offseason == 0 && windowSeason == season && day >= WINDOW_OPEN_DAY && day <= WINDOW_CLOSE_DAY;
    }

    private void openWindow() {
        windowSeason = season;
        windowSigns = 0;
        genWindowList();
        addNews("TRANSFER WINDOW OPEN (Days " + WINDOW_OPEN_DAY + "–" + WINDOW_CLOSE_DAY
                + "): up to " + WINDOW_MAX_SIGNINGS + " signings from rival clubs — see Transfers in HQ.");
    }

    /** Four listings drawn from rival XIs at fixed asking prices. */
    public void genWindowList() {
        try {
            windowList = new JSONArray();
            List<JSONObject> cand = new ArrayList<>();
            // Batch F: listings are drawn from every OTHER club's full
            // 18-man squad — roles and overseas flags are real data now.
            for (String t : allTeams()) {
                if (userTeam.equals(t)) continue;
                for (Object[] r : Data.squadFor(t)) {
                    String name = (String) r[0];
                    if (playerByName(name) != null) continue;
                    JSONObject p = makePlayer(name, (String) r[1], (Integer) r[2], (Integer) r[3], (Boolean) r[4]);
                    p.put("team", t);
                    cand.add(p);
                }
            }
            java.util.Collections.shuffle(cand, rng);
            for (int i = 0; i < Math.min(4, cand.size()); i++) {
                JSONObject p = cand.get(i);
                p.put("price", Math.max(60, (rating(p) - 50) * 5));
                windowList.put(p);
            }
        } catch (Exception ignored) {}
    }

    /** Buys a window listing at its asking price. */
    public String buyWindowPlayer(int idx) {
        if (!transferWindowOpen()) return "The transfer window is not open.";
        if (windowSigns >= WINDOW_MAX_SIGNINGS) return "Window limit reached — " + WINDOW_MAX_SIGNINGS + " signings max.";
        if (idx < 0 || idx >= windowList.length()) return "That listing is gone.";
        JSONObject lot = windowList.optJSONObject(idx);
        if (lot == null) return "That listing is gone.";
        int price = lot.optInt("price");
        if (squadFull()) return "Squad is full (" + SQUAD_CAP + ") — release someone first.";
        if (cf < price) return "Not enough CF — he costs " + price + " CF.";
        try {
            JSONObject p = new JSONObject(lot.toString());
            String from = p.optString("team");
            p.remove("team");
            p.remove("price");
            p.put("contract", 2);
            p.put("inXI", false);
            refreshWage(p);
            players.put(p);
            ledgerCf(-price, "Transfer — " + p.optString("name") + " from " + from);
            noteTransferSpend(price); // Batch I (idea 85)
            noteStarSigning(p); // Batch G (idea 70)
            JSONArray kept = new JSONArray();
            for (int i = 0; i < windowList.length(); i++) if (i != idx) kept.put(windowList.get(i));
            windowList = kept;
            windowSigns++;
            addNews("SIGNED: " + p.optString("name") + " joins " + userTeam + " from " + from + " for " + price + " CF!");
            return p.optString("name") + " signed for " + price + " CF.";
        } catch (Exception e) {
            return "Signing failed.";
        }
    }

    // ---- free agents (idea 37) ----

    public void genFaPool() {
        try {
            faPool = new JSONArray();
            for (Object[] r : Data.GEN_POOL) {
                if (faPool.length() >= 6) break;
                if (playerByName((String) r[0]) != null) continue;
                faPool.put(makeFromRow(r));
            }
        } catch (Exception ignored) {}
    }

    /** Tops the pool back toward 6 with the first unused generated name.
     *  Batch G: while a good Scout is employed, newcomers arrive with his
     *  quality lift applied (applyScoutBoost). */
    public void topUpFaPool() {
        try {
            if (faPool.length() >= 6) return;
            for (Object[] r : Data.GEN_POOL) {
                String name = (String) r[0];
                if (playerByName(name) != null || faHas(name)) continue;
                JSONObject np = makeFromRow(r);
                applyScoutBoost(np);
                faPool.put(np);
                if (faPool.length() >= 6) return;
            }
        } catch (Exception ignored) {}
    }

    private boolean faHas(String name) {
        for (int i = 0; i < faPool.length(); i++)
            if (name.equals(faPool.optJSONObject(i) == null ? "" : faPool.optJSONObject(i).optString("name"))) return true;
        return false;
    }

    /** Every 4th day one unsigned name drifts away and a fresh one appears. */
    private void rotateFaPool() {
        try {
            if (faPool.length() == 0) { genFaPool(); return; }
            int drop = rng.nextInt(faPool.length());
            JSONArray kept = new JSONArray();
            for (int i = 0; i < faPool.length(); i++) if (i != drop) kept.put(faPool.get(i));
            faPool = kept;
            topUpFaPool();
        } catch (Exception ignored) {}
    }

    public int faFee(JSONObject p) {
        return Math.max(30, (rating(p) - 55) * 3);
    }

    /** Signs a free agent at any time of year for the listed fee. */
    public String signFreeAgent(int idx) {
        if (idx < 0 || idx >= faPool.length()) return "That free agent is gone.";
        JSONObject lot = faPool.optJSONObject(idx);
        if (lot == null) return "That free agent is gone.";
        int fee = faFee(lot);
        if (squadFull()) return "Squad is full (" + SQUAD_CAP + ") — release someone first.";
        if (cf < fee) return "Not enough CF — his signing fee is " + fee + " CF.";
        try {
            JSONObject p = new JSONObject(lot.toString());
            p.put("contract", 2);
            p.put("inXI", false);
            refreshWage(p);
            players.put(p);
            ledgerCf(-fee, "Free-agent signing — " + p.optString("name"));
            noteTransferSpend(fee); // Batch I (idea 85)
            noteStarSigning(p); // Batch G (idea 70)
            JSONArray kept = new JSONArray();
            for (int i = 0; i < faPool.length(); i++) if (i != idx) kept.put(faPool.get(i));
            faPool = kept;
            topUpFaPool();
            addNews("Free agent signed: " + p.optString("name") + " joins " + userTeam + " (" + fee + " CF fee).");
            return p.optString("name") + " signed for " + fee + " CF.";
        } catch (Exception e) {
            return "Signing failed.";
        }
    }

    // ---- loans (idea 36) ----

    public void genLoanList() {
        try {
            loanList = new JSONArray();
            for (Object[] r : Data.LOAN_POOL) {
                if (playerByName((String) r[0]) != null) continue;
                loanList.put(makeFromRow(r));
            }
        } catch (Exception ignored) {}
    }

    public boolean hasActiveLoanIn() {
        for (int i = 0; i < players.length(); i++) if (player(i).optBoolean("loanIn")) return true;
        return false;
    }

    public int availableCount() {
        int n = 0;
        for (int i = 0; i < players.length(); i++) if (!player(i).optBoolean("loanOut")) n++;
        return n;
    }

    /** Loans a youngster (≤23) out for the rest of the season. He leaves
     *  the XI, cannot be picked, and comes back sharper at rollover. */
    public String loanOutPlayer(String name) {
        JSONObject p = playerByName(name);
        if (p == null) return "Player not found.";
        if (p.optBoolean("loanIn")) return "He is here on loan himself.";
        if (p.optBoolean("loanOut")) return name + " is already out on loan.";
        if (p.optInt("age", 99) > 23) return "Only players aged 23 or under can go out on loan.";
        if (availableCount() <= 12) return "Too few men left — the squad needs cover.";
        try {
            p.put("loanOut", true);
            p.put("inXI", false);
            addNews("Loaned out: " + name + " spends the rest of Season " + season
                    + " gaining experience elsewhere. He returns at rollover.");
            return name + " loaned out for the season.";
        } catch (Exception e) {
            return "Loan failed.";
        }
    }

    /** Brings one youngster in on loan (fee, no wage) during a window or
     *  the off-season. He returns to his parent club at rollover. */
    public String loanInPlayer(int idx) {
        if (!transferWindowOpen() && offseason == 0) return "Loan-ins open in the transfer window or off-season.";
        if (hasActiveLoanIn()) return "One loan-in at a time — your current loanee is still here.";
        if (idx < 0 || idx >= loanList.length()) return "That loanee is gone.";
        JSONObject lot = loanList.optJSONObject(idx);
        if (lot == null) return "That loanee is gone.";
        if (squadFull()) return "Squad is full (" + SQUAD_CAP + ").";
        if (cf < LOAN_IN_FEE) return "Not enough CF — the loan fee is " + LOAN_IN_FEE + " CF.";
        try {
            JSONObject p = new JSONObject(lot.toString());
            p.put("loanIn", true);
            p.put("contract", 1);
            p.put("wage", 0);
            p.put("inXI", false);
            players.put(p);
            ledgerCf(-LOAN_IN_FEE, "Loan-in fee — " + p.optString("name"));
            JSONArray kept = new JSONArray();
            for (int i = 0; i < loanList.length(); i++) if (i != idx) kept.put(loanList.get(i));
            loanList = kept;
            addNews("Loaned in: " + p.optString("name") + " joins " + userTeam + " until the end of Season " + season + ".");
            return p.optString("name") + " loaned in for " + LOAN_IN_FEE + " CF.";
        } catch (Exception e) {
            return "Loan failed.";
        }
    }

    // ---- scouting (idea 39) ----

    /** Deterministic display range for an unscouted player's POT: same
     *  numbers on every render, roughly ±5 around the truth. */
    public static int potRangeLow(String name, int pot) {
        int h = Math.abs(name.hashCode()) % 3;
        return Math.max(40, pot - 6 + h);
    }

    public String potDisplay(JSONObject p) {
        String name = p.optString("name");
        int pot = p.optInt("pot", 0);
        if (playerByName(name) != null || scouted.has(name)) return "POT " + pot;
        // Batch G (idea 61): a good Scout narrows the range around the truth
        int low = potRangeLowFor(name, pot);
        return "POT " + low + "–" + (low + potRangeWidth() - 1);
    }

    public JSONObject scoutReport(String name) {
        return scouted.optJSONObject(name);
    }

    /** Pays for a scout report and files it permanently: exact POT, a
     *  grade and a one-line verdict. Batch G: the fee runs through
     *  scoutCost() — a staffed Scout discounts it, and a Level 3+
     *  manager's first report each season is free. Returns a line. */
    public String scoutPlayer(String name, int truePot) {
        if (scouted.has(name)) return name + " is already scouted.";
        int cost = scoutCost();
        if (cf < cost) return "Not enough CF — a scout report costs " + cost + " CF.";
        try {
            if (cost > 0) {
                ledgerCf(-cost, "Scouting report — " + name);
            } else if (managerLevel >= 3 && freeScoutSeason != season) {
                freeScoutSeason = season; // the free report is spent (no CF moves, no ledger line)
            }
            String grade, verdict;
            if (truePot >= 90) { grade = "A"; verdict = "Future star — sign him before someone else does."; }
            else if (truePot >= 84) { grade = "B"; verdict = "First-team quality — worth the money."; }
            else if (truePot >= 76) { grade = "C"; verdict = "Solid squad player — fair price only."; }
            else { grade = "D"; verdict = "Limited ceiling — only as cheap cover."; }
            JSONObject r = new JSONObject();
            r.put("pot", truePot).put("grade", grade).put("verdict", verdict);
            scouted.put(name, r);
            return "Scouted " + name + ": POT " + truePot + " · Grade " + grade + " — " + verdict;
        } catch (Exception e) {
            return "Scouting failed.";
        }
    }

    // ---- poaching (idea 40) ----

    /** A man is poachable when he is unhappy AND running his deal down. */
    public boolean poachEligible(JSONObject p) {
        return p != null && !p.optBoolean("loanIn") && !p.optBoolean("loanOut")
                && p.optInt("morale", 70) < 35 && p.optInt("contract", 2) == 1;
    }

    public int poachFee(JSONObject p) {
        return Math.max(60, (rating(p) - 45) * 4);
    }

    /** Files a rival's offer for a poachable man. Used by the window-day
     *  roll and directly testable. */
    public void createPoachOffer(JSONObject p) {
        try {
            String team = AI_BIDDERS[rng.nextInt(AI_BIDDERS.length)];
            poachOffer = new JSONObject();
            poachOffer.put("name", p.optString("name"));
            poachOffer.put("team", team);
            poachOffer.put("fee", poachFee(p));
            poachOffer.put("expDay", day + 3);
            poachOffer.put("expSeason", season);
            addNews("TRANSFER OFFER: " + team + " bid " + poachOffer.optInt("fee") + " CF for "
                    + p.optString("name") + " — decide within 3 days (Hub / Transfers).");
        } catch (Exception ignored) {}
    }

    private void maybePoachOffer() {
        if (poachOffer != null || !transferWindowOpen()) return;
        try {
            List<JSONObject> elig = new ArrayList<>();
            for (int i = 0; i < players.length(); i++) if (poachEligible(player(i))) elig.add(player(i));
            if (elig.isEmpty()) return;
            if (rng.nextDouble() < 0.55) createPoachOffer(elig.get(rng.nextInt(elig.size())));
        } catch (Exception ignored) {}
    }

    public String acceptPoach() {
        if (poachOffer == null) return "No offer on the table.";
        String name = poachOffer.optString("name");
        String team = poachOffer.optString("team");
        int fee = poachOffer.optInt("fee");
        if (playerByName(name) == null) { poachOffer = null; return "That player has already gone."; }
        if (players.length() <= 11) return "The squad must keep at least 11 players.";
        removePlayer(name);
        ledgerCf(fee, "Transfer sale — " + name + " to " + team);
        poachOffer = null;
        addNews("SOLD: " + name + " joins " + team + " for " + fee + " CF.");
        return name + " sold to " + team + " — +" + fee + " CF.";
    }

    public String rejectPoach() {
        if (poachOffer == null) return "No offer on the table.";
        String name = poachOffer.optString("name");
        poachOffer = null;
        adjustMorale(name, -5);
        addNews("Offer rejected: " + name + " stays — he is not thrilled about it (morale −5).");
        return "Offer for " + name + " rejected.";
    }

    // ---- rumours (idea 38) ----

    /** A daily news-desk roll. The true-leaning kind names a real
     *  final-year or low-morale man — the same men rivals can poach. */
    private void rollRumour() {
        try {
            double prob = (transferWindowOpen() || offseason > 0) ? 0.45 : 0.16;
            if (rng.nextDouble() >= prob) return;
            String[] rivals = {"Karachi Kings", "Islamabad United", "Multan Sultans", "Peshawar Zalmi"};
            String rival = rivals[rng.nextInt(rivals.length)];
            List<JSONObject> targets = new ArrayList<>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (p.optBoolean("loanIn") || p.optBoolean("loanOut")) continue;
                if (poachEligible(p) || p.optInt("morale", 70) < 45 || p.optInt("contract", 2) == 1) targets.add(p);
            }
            int kind = rng.nextInt(3);
            if (!targets.isEmpty() && (kind == 0 || rng.nextBoolean())) {
                JSONObject p = targets.get(rng.nextInt(targets.size()));
                addNews("Rumour: " + rival + " are plotting a move for " + p.optString("name")
                        + " — out of favour and running his deal down, this one has legs…");
                return;
            }
            if (kind == 1) {
                JSONObject spinner = null;
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    if (Data.isSpinner(p.optString("name"))) { spinner = p; break; }
                }
                if (spinner != null) {
                    addNews("Rumour: " + rival + " are eyeing your spinner " + spinner.optString("name")
                            + " ahead of the next window…");
                    return;
                }
            }
            String link = faPool.length() > 0
                    ? faPool.optJSONObject(rng.nextInt(faPool.length())).optString("name")
                    : Data.GEN_POOL[rng.nextInt(Data.GEN_POOL.length)][0].toString();
            addNews("Rumour: " + userTeam + " are linked with a move for " + link + "…");
        } catch (Exception ignored) {}
    }

    // ---------------- calendar ----------------

    /** Advance one day. Returns a short event string for the Hub news/toast. */
    public String advanceDay() {
        // Batch H (idea 71): a press conference the manager walked away
        // from expires quietly the moment the calendar moves on.
        expirePressConf();
        // Batch D: the off-season phase must be finished in Transfers before
        // the new season's calendar can move — never a dead end, the phase
        // screens always offer Confirm / Skip.
        if (offseason > 0) {
            return offseason == 1
                    ? "Off-season: retain, release & renew first (HQ → Transfers)"
                    : "Off-season: finish the auction first (HQ → Transfers)";
        }
        // Batch G (idea 66): an unchosen camp never traps the season — the
        // first real day-advance with the choice still open auto-skips it.
        if (campPending) {
            skipCamp();
            addNews("No training camp was picked, so the squad went straight into the season.");
        }
        // Batch F (idea 56): the One-Day Cup runs in the gap between the
        // group stage and the playoffs — its state machine goes first.
        if (cupPhase == 1) return advanceCup();
        // Batch E: once the group stage is done, the calendar hands over to
        // the playoff state machine — days stop ticking until the off-season
        // opens (rolloverSeason still runs the Batch D off-season after it).
        if (playoffPhase == 1) return advancePlayoffs();
        if (playoffPhase == 2) {
            return "🏆 The Trophy Ceremony is waiting on the Hub — tap Continue there to open the off-season.";
        }
        if (playoffPhase == 3) return rolloverSeason();
        // skipping past an unplayed user fixture: the board sims it without you
        JSONObject skipped = todaysUserFixture();
        if (skipped != null && match == null) {
            simFixture(skipped);
            addNews("You skipped match day — the board simmed " + skipped.optString("summary") + ".");
        }
        day++;
        ensureQuests(); // Batch I (idea 84): a new week brings a new quest set
        // group stage over? Batch E: the playoffs come first now — the old
        // straight-to-rollover path only survives inside rolloverSeason as
        // the legacy fallback for a season with no playoff champion.
        if (day > 24) {
            // Batch F: cup week comes before the playoffs (Season 2+)
            if (cupEnabled() && cupPhase == 0) return beginCup();
            return beginPlayoffs();
        }
        // auto-sim other teams' fixtures up to (and including) today,
        // but never the user's fixture on its own day
        simOtherFixtures(day, true);
        // daily stamina regen: rested players recover properly (+12), everyone else +2
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try {
                int gain = p.optBoolean("rested") ? RESTED_REGEN : 2;
                p.put("stam", Math.min(100, p.optInt("stam") + gain));
                // Batch C (idea 24): injuries heal a day at a time —
                // Batch G: an elite Physio (85+) works them twice as fast
                int inj = p.optInt("injured", 0);
                if (inj > 0) {
                    inj = Math.max(0, inj - physioHealStep());
                    p.put("injured", inj);
                    if (inj == 0) {
                        p.put("injType", "");
                        addNews("Physio update: " + p.optString("name") + " has recovered from injury and is fit to play again.");
                    }
                }
            } catch (Exception ignored) {}
        }
        tickAiInjuries(); // Batch F (idea 53): AI knocks heal a day at a time
        // Commercial Centre income every 3 days (ledgered, v2). Batch G
        // (idea 64): the old flat sponsor is SPLIT — while sponsorLegacy
        // holds this pays the OLD 25 x level as sponsor income; once real
        // sponsor deals are live it drops to a plain 10 x level of
        // commercial income and the deal (below) is the main sponsor.
        if (day % 3 == 0) {
            if (sponsorLegacy) {
                int income = 25 * facilityLevel(4);
                ledgerCf(income, "Commercial Centre sponsor income");
                addNews("Commercial Centre sponsors paid +" + income + " CF.");
            } else {
                ledgerCf(10 * facilityLevel(4), "Commercial Centre income");
            }
        }
        // ---- Batch D daily business ----
        // Wages (idea 35): due on Days 7/14/21, AFTER sponsor income lands.
        // Batch G: the sponsor deal's weekly payment lands first, then ONE
        // combined wages line (players + staff; the split rides the entry).
        if (day % 7 == 0) {
            if (!sponsorLegacy && sponsor != null && sponsor.optInt("weekly") > 0) {
                ledgerCf(sponsor.optInt("weekly"), "Sponsor weekly — " + sponsor.optString("brand"));
            }
            int due = weeklyWages();
            int paid = Math.min(due, Math.max(0, cf));
            if (paid > 0) {
                ledgerCf(-paid, "Squad wages — week ending Day " + day);
                try {
                    JSONObject e = ledger.optJSONObject(0); // newest first: the entry just written
                    if (e != null) {
                        e.put("pWages", playerWagesGross());
                        e.put("sWages", staffWages());
                        e.put("wDisc", wageDiscountAmount());
                    }
                } catch (Exception ignored) {}
            }
            if (paid < due) {
                wageShortStreak++;
                adjustBoardConfidence(-6); // Batch G (idea 67)
                addNews("WAGES WARNING: the bill was " + due + " CF but only " + paid
                        + " CF could be paid. The squad noticed.");
                if (wageShortStreak >= 2) {
                    for (int i = 0; i < players.length(); i++)
                        adjustMorale(player(i).optString("name"), -3);
                    wageShortStreak = 0;
                    addNews("Short-paid wages twice in a row — squad morale drops across the board (−3).");
                }
            } else {
                wageShortStreak = 0;
            }
        }
        // Mid-season transfer window (idea 33): opens at the season midpoint
        if (day == WINDOW_OPEN_DAY && windowSeason != season) openWindow();
        if (day == WINDOW_CLOSE_DAY + 1 && windowSeason == season) {
            addNews("Transfer window closed. Business resumes at the season's end.");
        }
        // Poach offers (idea 40): can arrive on window days; lapse after 3
        if (poachOffer != null) {
            boolean past = season > poachOffer.optInt("expSeason")
                    || (season == poachOffer.optInt("expSeason") && day > poachOffer.optInt("expDay"));
            if (past) {
                addNews("The offer for " + poachOffer.optString("name") + " expired unanswered.");
                poachOffer = null;
            }
        }
        maybePoachOffer();
        // Free-agent churn (idea 37) + the rumour mill (idea 38)
        if (day % 4 == 0) rotateFaPool();
        rollRumour();
        JSONObject today = todaysUserFixture();
        if (today != null) {
            // Batch F (idea 58): the derby gets its hype exactly once
            if (isDerby(today) && !today.optBoolean("hype")) {
                try { today.put("hype", true); } catch (Exception ignored) {}
                addNews("🔥 DERBY DAY: " + userTeam + " vs " + opponentOf(today)
                        + " — the big rivalry! Expect a bumper crowd at "
                        + today.optString("ground", Data.groundName(today.optString("home")))
                        + " and a +50% win prize (300 + " + DERBY_WIN_BONUS + " CF).");
            }
            // Batch H (idea 80): the rival gaffer's pre-match talk
            maybeRivalPreQuote();
            addNews("MATCH DAY: " + userTeam + " vs " + opponentOf(today) + " — play it from the Hub!");
            return "Match day vs " + opponentOf(today);
        }
        // Batch H (idea 73): a quiet day sometimes hums with fan chatter
        if (match == null) maybeAmbientFanPost();
        return "Day " + day;
    }

    public void simOtherFixtures(int uptoDay, boolean includeToday) {
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (f.optBoolean("played")) continue;
                int fd = f.optInt("day");
                if (fd < uptoDay || (includeToday && fd == uptoDay)) {
                    if (!involvesUser(f)) simFixture(f);
                }
            } catch (Exception ignored) {}
        }
    }

    private List<String> namesFor(String team) {
        List<String> names = new ArrayList<>();
        if (userTeam.equals(team)) {
            List<JSONObject> xi = xi();
            if (xi.size() >= 2) {
                for (JSONObject p : xi) names.add(p.optString("name"));
            } else {
                for (int i = 0; i < Math.min(11, players.length()); i++) names.add(player(i).optString("name"));
            }
        } else {
            // Batch F (idea 53): standouts come from the AI club's ACTUAL
            // current XI — rotated and injury-aware, not a fixed list.
            names.addAll(aiXiNames(team));
            if (names.size() < 2) for (Object[] p : Data.xiFor(team)) names.add((String) p[0]);
        }
        return names;
    }

    /** Quick-sim a fixture between any two teams and record it.
     *  v2: also generates top-scorer / best-bowler figures so watchlist
     *  centuries and 5-fors can be spotted in auto-simmed fixtures too. */
    public void simFixture(JSONObject f) {
        try {
            String home = f.getString("home"), away = f.getString("away");
            int hs = simStrength(home), as = simStrength(away); // Batch I (idea 81)
            // innings 1 (home bats first)
            int r1 = clamp(115 + rng.nextInt(105) + (hs - 80), 95, 235);
            int w1 = r1 > 205 ? 4 + rng.nextInt(5) : 5 + rng.nextInt(6);
            if (w1 > 10) w1 = 10;
            int b1 = w1 == 10 ? 96 + rng.nextInt(24) : 120;
            // chase
            double chaseChance = 0.46 + (as - hs) * 0.008;
            boolean awayWins = rng.nextDouble() < chaseChance;
            int r2, w2, b2;
            if (awayWins) {
                r2 = r1 + 1 + rng.nextInt(12);
                w2 = 3 + rng.nextInt(6);
                b2 = 96 + rng.nextInt(23);
            } else {
                r2 = Math.max(70, r1 - 1 - rng.nextInt(38));
                w2 = 6 + rng.nextInt(5);
                if (w2 > 10) w2 = 10;
                b2 = w2 == 10 ? 90 + rng.nextInt(30) : 120;
            }
            applyResult(home, away, r1, b1, w1, r2, b2, w2);
            String summary = shortFor(home) + " " + r1 + "/" + w1 + " vs " +
                    shortFor(away) + " " + r2 + "/" + w2 + " — " +
                    (awayWins ? away : home) + " won";
            // lightweight standout performers for the fixture (v2)
            List<String> hn = namesFor(home), an = namesFor(away);
            String topBat, bestBowl, topBatTeam, bestBowlTeam;
            int topRuns, bestWkts;
            if (rng.nextBoolean()) {
                topBat = hn.get(rng.nextInt(Math.min(6, hn.size()))); topBatTeam = home;
                bestBowl = an.get(5 + rng.nextInt(Math.max(1, an.size() - 5))); bestBowlTeam = away;
            } else {
                topBat = an.get(rng.nextInt(Math.min(6, an.size()))); topBatTeam = away;
                bestBowl = hn.get(5 + rng.nextInt(Math.max(1, hn.size() - 5))); bestBowlTeam = home;
            }
            topRuns = 38 + rng.nextInt(92);                       // 38..129 — centuries possible
            bestWkts = rng.nextInt(100) < 12 ? 5 + rng.nextInt(2) // ~12%: a 5-for day
                    : 1 + rng.nextInt(4);
            f.put("topBat", topBat).put("topBatRuns", topRuns);
            f.put("bestBowl", bestBowl).put("bestBowlWkts", bestWkts);
            f.put("topBatTeam", topBatTeam).put("bestBowlTeam", bestBowlTeam);
            f.put("r1", r1).put("w1", w1).put("r2", r2).put("w2", w2); // Batch H: real margins for headlines/reports
            f.put("played", true);
            f.put("summary", summary);
            // Batch E (ideas 43/48): standouts also feed the tournament book
            // and — where figures exist — the all-time records book
            creditSimStandouts(f);
            // Batch F (idea 53): AI clubs pick up knocks too
            if (!involvesUser(f)) { rollAiInjury(home); rollAiInjury(away); }
            if (topRuns >= 100) watchlistAlert(topBat, "scored " + topRuns + " (century!)", summary);
            if (bestWkts >= 5) watchlistAlert(bestBowl, "took " + bestWkts + " wickets (5-for!)", summary);
            if (involvesUser(f)) {
                boolean userWon = (userTeam.equals(home) && !awayWins) ||
                        (userTeam.equals(away) && awayWins);
                // Batch C (idea 21): credit appearances + the generated standouts
                StatsBook.recordAppearances(this);
                StatsBook.recordSimStandouts(this, f);
                noteSponsorTeamScore(userTeam.equals(home) ? r1 : r2); // Batch G (idea 64)
                onUserMatchFinished(userWon, summary, f);
            }
        } catch (Exception ignored) {}
    }

    /** Record a completed match in the tables. Balls stored raw; all-out counts as 120 for NRR. */
    public void applyResult(String home, String away, int r1, int b1, int w1, int r2, int b2, int w2) {
        applyResultDecided(home, away, r1, b1, w1, r2, b2, w2, null);
    }

    /** Batch A: same as applyResult, but a Super Over can DECIDE a match whose
     *  scores finished level — decidedWinner (a team name, or null) then forces
     *  the points instead of the runs comparison. A still-tied Super Over passes
     *  "" and the points are shared, as before. */
    public void applyResultDecided(String home, String away, int r1, int b1, int w1,
                                   int r2, int b2, int w2, String decidedWinner) {
        try {
            JSONObject H = tables.getJSONObject(home), A = tables.getJSONObject(away);
            H.put("p", H.optInt("p") + 1);
            A.put("p", A.optInt("p") + 1);
            int eb1 = w1 == 10 ? 120 : b1;
            int eb2 = w2 == 10 ? 120 : b2;
            H.put("rf", H.optInt("rf") + r1).put("bf", H.optInt("bf") + eb1)
             .put("ra", H.optInt("ra") + r2).put("ba", H.optInt("ba") + eb2);
            A.put("rf", A.optInt("rf") + r2).put("bf", A.optInt("bf") + eb2)
             .put("ra", A.optInt("ra") + r1).put("ba", A.optInt("ba") + eb1);
            int cmp = decidedWinner == null ? Integer.compare(r1, r2)
                    : decidedWinner.equals(home) ? 1 : decidedWinner.equals(away) ? -1 : 0;
            if (cmp > 0) {
                H.put("w", H.optInt("w") + 1).put("pts", H.optInt("pts") + 2);
                A.put("l", A.optInt("l") + 1);
            } else if (cmp < 0) {
                A.put("w", A.optInt("w") + 1).put("pts", A.optInt("pts") + 2);
                H.put("l", A.optInt("l") + 1);
            } else {
                H.put("pts", H.optInt("pts") + 1);
                A.put("pts", A.optInt("pts") + 1);
            }
            // Batch E (idea 46): head-to-head vs Lahore rides along with
            // every decided user result (live or simmed), playoffs included
            // via recordH2h below. cmp is from the HOME side's perspective.
            if (userTeam.equals(home)) updateH2h(away, cmp);
            else if (userTeam.equals(away)) updateH2h(home, -cmp);
        } catch (Exception ignored) {}
    }

    /** Batch E (idea 46): one more chapter in the Lahore-vs-X story.
     *  userCmp: +1 Lahore won, 0 tied, −1 Lahore lost. "last" is a string of
     *  W/L/T characters, NEWEST first, capped at 5. */
    public void updateH2h(String opp, int userCmp) {
        try {
            JSONObject e = h2h.optJSONObject(opp);
            if (e == null) { e = new JSONObject().put("p", 0).put("w", 0).put("l", 0).put("last", ""); h2h.put(opp, e); }
            e.put("p", e.optInt("p") + 1);
            if (userCmp > 0) e.put("w", e.optInt("w") + 1);
            else if (userCmp < 0) e.put("l", e.optInt("l") + 1);
            String c = userCmp > 0 ? "W" : userCmp < 0 ? "L" : "T";
            String last = c + e.optString("last");
            if (last.length() > 5) last = last.substring(0, 5);
            e.put("last", last);
        } catch (Exception ignored) {}
    }

    /** Shared bookkeeping after ANY user match (played live or simmed). All CF is ledgered. */
    public void onUserMatchFinished(boolean userWon, String summary, JSONObject fixture) {
        try {
            career.put("played", career.optInt("played") + 1);
            boolean homeGame = fixture != null && userTeam.equals(fixture.optString("home"));
            // Batch F (idea 57): gate receipts are attendance-driven now —
            // att% of a capacity that grows with the Stadium level — and
            // REPLACE the old flat 40 x level stadium bonus entirely.
            int gate = 0, att = 0;
            if (homeGame) {
                att = expectedAttendance(fixture);
                gate = gateFor(fixture, att);
                try { fixture.put("att", att); } catch (Exception ignored) {}
            }
            // Batch F (idea 58): a derby win pays +50% on the win prize
            boolean derbyWin = userWon && isDerby(fixture);
            // ---- Batch G wiring (ideas 65/67/69/70): every finished user
            // match moves the board, the fans and the manager's XP, counts
            // toward the camp, and pays merchandise at home. ----
            campMatchesUsed++;
            boolean playoffTie = fixture != null && fixture.has("stage") && !fixture.optBoolean("cup");
            addManagerXp(2 + (userWon ? 10 : 0) + (userWon && playoffTie ? 25 : 0));
            adjustBoardConfidence(userWon ? 2 : -3);
            if (derbyWin) adjustBoardConfidence(4);
            if (userWon) {
                fanLossStreak = 0;
                adjustFanMood(derbyWin ? 6 : 3);
            } else {
                fanLossStreak++;
                adjustFanMood(-2);
                if (fanLossStreak >= 3) adjustFanMood(-4); // the streak drag (idea 70)
            }
            if (homeGame) {
                int merch = merchandiseFor(fixture, att, userWon);
                ledgerCf(merch, "Merchandise — vs " + opponentOf(fixture) + " · " + att + "% crowd");
            }
            if (userWon) {
                career.put("won", career.optInt("won") + 1);
                int streak = career.optInt("streak") + 1;
                career.put("streak", streak);
                if (streak > career.optInt("best")) career.put("best", streak);
                // Batch I (idea 81): prizes scale with difficulty; the derby
                // bonus stays 50% of the (scaled) win prize.
                int winPrize = prize(300);
                int derbyBonus = winPrize / 2;
                ledgerCf(winPrize, "Match prize — win vs " + (fixture != null ? opponentOf(fixture) : "opposition"));
                if (derbyWin) ledgerCf(derbyBonus, "Derby win bonus — vs " + opponentOf(fixture));
                if (gate > 0) ledgerCf(gate, "Gate receipts — " + fixture.optString("ground", homeGroundName()) + " · " + att + "% full");
                addNews("WIN! +" + winPrize + " CF prize" + (derbyWin ? " (+" + derbyBonus + " derby bonus)" : "")
                        + (gate > 0 ? " (+" + gate + " gate · " + att + "% crowd)" : "") + ". " + summary);
            } else {
                career.put("lost", career.optInt("lost") + 1);
                career.put("streak", 0);
                int fee = prize(120); // Batch I (idea 81)
                ledgerCf(fee, "Appearance fee — vs " + (fixture != null ? opponentOf(fixture) : "opposition"));
                if (gate > 0) ledgerCf(gate, "Gate receipts — " + fixture.optString("ground", homeGroundName()) + " · " + att + "% full");
                addNews("Defeat. +" + fee + " CF appearance fee"
                        + (gate > 0 ? " (+" + gate + " gate · " + att + "% crowd)" : "") + ". " + summary);
            }
            if (!homeGame && fixture != null) { // away travel, charged once per away fixture (v2)
                int charged = ledgerExpense(TRAVEL_COST, "Away travel — at " + opponentOf(fixture));
                if (charged > 0) addNews("Away travel cost −" + charged + " CF.");
            }
            // history (newest first, cap 20)
            JSONArray h = new JSONArray();
            h.put((userWon ? "W — " : "L — ") + summary);
            for (int i = 0; i < Math.min(history.length(), 19); i++) h.put(history.getString(i));
            history = h;
            // fatigue + morale for the XI (Batch F: a 50-over cup day drains 20)
            int drain = fixture != null && fixture.optBoolean("cup") ? 20 : 12;
            for (JSONObject p : xi()) {
                p.put("stam", Math.max(20, p.optInt("stam") - drain));
                int set = p.optInt("set") + (userWon ? 5 : -5);
                p.put("set", Math.max(25, Math.min(99, set)));
            }
            // Batch C (idea 25): morale from the result and from selection.
            // Playing lifts you, results lift/drop you, and sitting on the
            // bench match after match drags a player down.
            java.util.Set<String> xiNames = new java.util.HashSet<>();
            for (JSONObject p : xi()) xiNames.add(p.optString("name"));
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (xiNames.contains(p.optString("name"))) {
                    p.put("bench", 0);
                    adjustMorale(p.optString("name"), userWon ? 4 : -3);
                } else {
                    int b = p.optInt("bench", 0) + 1;
                    p.put("bench", b);
                    if (b >= 2) adjustMorale(p.optString("name"), -2);
                }
            }
            // Batch C (idea 24): at most one fresh injury per match
            rollInjury();
            // Batch I (ideas 84–86): quests progress, the prediction game
            // settles and the match-based achievements are judged — all off
            // this same hook, so live and simmed ties count identically.
            // (Friendlies never reach here: finishMatch short-circuits.)
            undoArmed = false; // idea 87: a played match spends the slot undo
            if (derbyWin) career.put("derbyWins", career.optInt("derbyWins") + 1);
            if (userWon && homeGame) seasonHomeWins++;
            batchIOnMatchFinished(userWon, summary, fixture);
            // Batch H (ideas 71–80): the whole news & immersion flow hangs
            // off this one hook — headline, fan buzz, press conference,
            // rival reaction, season-review trackers, match report.
            batchHOnMatchFinished(userWon, summary, fixture);
        } catch (Exception ignored) {}
    }

    /** Batch C (idea 24): post-match injury roll for the XI that just played.
     *  Base 4% per player, +4% when running on fumes (stamina < 45). At most
     *  ONE injury per match. Days out 3–14, reduced by Medical Centre level
     *  (min 2). The injured man leaves the XI and the news desk hears of it. */
    public void rollInjury() {
        try {
            for (JSONObject p : xi()) {
                if (p.optInt("injured", 0) > 0) continue;
                double chance = 0.04 + (p.optInt("stam") < 45 ? 0.04 : 0);
                // Batch G: the Physio bends the chance down, and a Fitness
                // Camp halves it through the first half of the season
                chance *= physioInjuryMult();
                if (campHalfActive(2)) chance *= 0.5;
                if (rng.nextDouble() >= chance) continue;
                String type = Data.INJURY_TYPES[rng.nextInt(Data.INJURY_TYPES.length)];
                int days = 3 + rng.nextInt(12); // 3..14
                days = Math.max(2, days - (facilityLevel(1) - 1));
                days = physioDays(days); // Batch G: the Physio shortens it further
                p.put("injured", days);
                p.put("injType", type);
                p.put("inXI", false);
                adjustMorale(p.optString("name"), -6);
                addNews("INJURY: " + p.optString("name") + " has a " + type + " and is out for about "
                        + days + " days. He leaves the XI — the physio queue has him now.");
                return; // one injury per match, max
            }
        } catch (Exception ignored) {}
    }

    /** Batch C (idea 23): end-of-season development. Under-27s drift UP
     *  toward their Potential (main skill +1/+2, never past 99); 33+ veterans
     *  decline 1–2 off their main skill (floor 40). Middle ages hold. */
    public void developPlayer(JSONObject p) {
        try {
            int age = p.optInt("age", 25);
            int pot = p.optInt("pot", rating(p));
            String role = p.optString("role");
            if (age <= 26) {
                int gap = pot - rating(p);
                if (gap <= 0) return;
                int step = Math.min(2, gap);
                if ("Bowl".equals(role)) {
                    p.put("bowl", Math.min(99, p.optInt("bowl") + step));
                } else if ("AR".equals(role)) {
                    int up = Math.max(1, step / 2);
                    p.put("bat", Math.min(99, p.optInt("bat") + up));
                    p.put("bowl", Math.min(99, p.optInt("bowl") + up));
                } else { // Bat / WK grow with the bat
                    p.put("bat", Math.min(99, p.optInt("bat") + step));
                }
            } else if (age >= 33) {
                int dec = 1 + rng.nextInt(2);
                if ("Bowl".equals(role)) {
                    p.put("bowl", Math.max(40, p.optInt("bowl") - dec));
                } else if ("AR".equals(role)) {
                    boolean batHigher = p.optInt("bat") >= p.optInt("bowl");
                    if (batHigher) p.put("bat", Math.max(40, p.optInt("bat") - dec));
                    else p.put("bowl", Math.max(40, p.optInt("bowl") - dec));
                } else {
                    p.put("bat", Math.max(40, p.optInt("bat") - dec));
                }
            }
        } catch (Exception ignored) {}
    }

    public String rolloverSeason() {
        // Batch E (idea 50): capture the finished season into the history
        // book FIRST — before tables reset and season stats are wiped below.
        captureSeasonHistory();
        String champion;
        try {
            // Batch E: the Final already decided this — title and prize
            // were paid at finalizePlayoffs(); never pay them twice. The
            // points-leader rule is only the fallback for seasons whose
            // playoffs never ran (e.g. a v6 off-season save meeting v7).
            champion = !seasonChampion.isEmpty() ? seasonChampion : pointsLeader();
            boolean viaPlayoffs = !seasonChampion.isEmpty();
            if (userTeam.equals(champion)) {
                if (!viaPlayoffs) { // legacy fallback only — playoffs paid at the Final
                    career.put("titles", career.optInt("titles") + 1);
                    ledgerCf(prize(1500), "Title prize — Season " + season + " champions"); // Batch I (idea 81)
                    unlockAchievement("FIRSTTITLE"); // Batch I (idea 85)
                    // Batch G: the playoff path pays these at the Final;
                    // the legacy path pays them here instead (never both)
                    adjustBoardConfidence(20);
                    adjustFanMood(15);
                    addManagerXp(100);
                    if (sponsor != null && sponsor.optInt("objType", -1) == 1) completeSponsorObjective();
                }
                addNews("CHAMPIONS! " + userTeam + " win Season " + season + "!"
                        + (viaPlayoffs ? " The Final is won — the trophy belongs to " + userTeam + "." : " +" + prize(1500) + " CF title prize."));
            } else {
                addNews("Season " + season + " champions: " + champion + ". " + userTeam + " go again next season.");
            }
            JSONArray h = new JSONArray();
            h.put("Season " + season + " champion: " + champion);
            for (int i = 0; i < Math.min(history.length(), 19); i++) h.put(history.getString(i));
            history = h;
            // Batch G (ideas 67/68): the board judges the season NOW —
            // while the tables still show it — and a confidence under 10
            // at a season end ends the career on the spot.
            // Batch I (idea 90): the hardcore sack line is stricter (20).
            evaluateBoardSeasonEnd();
            if (boardConfidence < sackThreshold()) {
                sacked = true;
                playoffPhase = 0;
                cupPhase = 0;
                match = null;
                addNews("SACKED: the board has run out of patience after Season " + season
                        + " — the manager's reign is over.");
                return "SACKED — the board has run out of patience.";
            }
            // Batch I (idea 85): the two season-end badges are judged here,
            // while the finished season's facts are still on the table —
            // Survivor (kept the job with a rattled board) and Loyal (the
            // same captain from the season's first day to its last).
            if (boardConfidence < 30) unlockAchievement("SURVIVOR");
            if (!captainSeasonStart.isEmpty() && !captainChangedSeason
                    && captain.equals(captainSeasonStart)) unlockAchievement("LOYAL");
            // Batch D (idea 36): loans settle BEFORE anything else touches
            // the squad — loanees-in go home, loanees-out come back sharper
            // (their boost replaces normal development in the loop below).
            {
                JSONArray kept = new JSONArray();
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    if (p.optBoolean("loanIn")) {
                        addNews(p.optString("name") + "'s loan ends — he returns to his parent club.");
                        continue;
                    }
                    if (p.optBoolean("loanOut")) {
                        p.put("loanOut", false);
                        p.put("loanReturned", true);
                        adjustMorale(p.optString("name"), +8);
                        addNews(p.optString("name") + " returns from his loan spell — a season of first-team cricket has sharpened him.");
                    }
                    kept.put(p);
                }
                players = kept;
                ensureCaptain();
            }
            // academy prospect (level 2+)
            if (facilityLevel(3) >= 2) {
                int worstIdx = -1, worstRat = 999;
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    if (!p.optBoolean("inXI")) {
                        int rat = rating(p);
                        if (rat < worstRat) { worstRat = rat; worstIdx = i; }
                    }
                }
                if (worstIdx >= 0) {
                    String name = Data.PROSPECTS[rng.nextInt(Data.PROSPECTS.length)];
                    JSONObject p = player(worstIdx);
                    p.put("name", name);
                    p.put("role", rng.nextBoolean() ? "AR" : "Bat");
                    // Batch G (idea 62): prospect quality scales with the
                    // Academy level (and the L7 manager perk rides along)
                    int aq = academyQualityBonusFor(facilityLevel(3));
                    p.put("bat", Math.min(95, 66 + rng.nextInt(11) + aq));
                    p.put("bowl", Math.min(95, 45 + rng.nextInt(30) + aq));
                    p.put("stam", 95);
                    p.put("set", 70);
                    p.put("overseas", false); // academy prospects are local
                    p.put("rested", false);
                    // Batch D: the prospect signs a first pro deal
                    p.put("loanOut", false);
                    p.put("loanIn", false);
                    p.put("contract", 3);
                    p.put("wage", wageFor(rating(p)));
                    // Batch C: the prospect is a NEW player — fresh stats/meta
                    p.put("ss", emptyStats());
                    p.put("cs", emptyStats());
                    p.put("formB", new JSONArray());
                    p.put("formW", new JSONArray());
                    p.put("miles", new JSONArray());
                    p.put("age", 17 + rng.nextInt(3));
                    p.put("pot", Data.potFor(name, rating(p)));
                    p.put("morale", 75);
                    p.put("injured", 0);
                    p.put("injType", "");
                    p.put("bench", 0);
                    JSONArray tg = new JSONArray();
                    for (String t : Data.tagsFor(name, p.optInt("bat"), p.optInt("bowl"))) tg.put(t);
                    p.put("tags", tg);
                    addNews("Youth Academy prospect " + name + " joins the squad for Season " + (season + 1) + "!");
                }
            }
            List<String> finalYear = new ArrayList<>();
            List<String> expired = new ArrayList<>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                p.put("stam", 88 + rng.nextInt(12));
                // Batch C rollover housekeeping: development (idea 23),
                // a birthday for everyone, a clean physio room, and season
                // stats reset while career stats/milestones carry over.
                // Batch D: a returned loanee develops from his loan instead.
                if (p.optBoolean("loanReturned")) {
                    p.remove("loanReturned");
                    int step = 1 + rng.nextInt(2);
                    String role = p.optString("role");
                    if ("Bowl".equals(role)) p.put("bowl", Math.min(99, p.optInt("bowl") + step));
                    else if ("AR".equals(role)) {
                        p.put("bat", Math.min(99, p.optInt("bat") + 1));
                        p.put("bowl", Math.min(99, p.optInt("bowl") + 1));
                    } else p.put("bat", Math.min(99, p.optInt("bat") + step));
                } else {
                    developPlayer(p);
                }
                p.put("age", p.optInt("age", 25) + 1);
                p.put("injured", 0);
                p.put("injType", "");
                p.put("bench", 0);
                p.put("ss", emptyStats());
                // Batch D (idea 34): contracts run down one season
                if (!p.optBoolean("loanIn")) {
                    int c = Math.max(0, p.optInt("contract", 2) - 1);
                    p.put("contract", c);
                    if (c == 1) finalYear.add(p.optString("name"));
                    if (c == 0) expired.add(p.optString("name"));
                }
                refreshWage(p);
            }
            // Batch D (idea 34): contract news — final-year warnings first,
            // then who is now out of contract (decided in Transfers phase 1)
            for (String n : finalYear) {
                addNews("Contract watch: " + n + " is in the FINAL YEAR of his deal — renew him next off-season or risk losing him for free.");
            }
            for (String n : expired) {
                addNews("Out of contract: " + n + " — renew him in Transfers now, or he leaves into the auction pool.");
            }
            // pre-season charge for the new season (ledgered, v2) — applied before the
            // season counter turns so the ledger keeps a clean "Season N" marker trail
            int charged = ledgerExpense(PRESEASON_CHARGE, "Pre-season charge — Season " + (season + 1));
            if (charged > 0) addNews("Pre-season charge −" + charged + " CF for Season " + (season + 1) + ".");
        } catch (Exception ignored) {}
        season++;
        day = 1;
        match = null;
        // Batch F (idea 54): the world game reacts to the season just
        // finished — read lastAwards / seasonChampion BEFORE the reset
        // block below wipes them.
        driftWorldRankings();
        // Batch E: the new season starts with a clean League & Season slate —
        // history/records/HoF/H2H above are career-permanent and stay.
        playoffPhase = 0;
        playoffFixtures = new JSONArray();
        seasonChampion = "";
        seasonRunnerUp = "";
        ceremony = null;
        lastAwards = new JSONObject();
        tournBook = new JSONObject();
        // Batch F (idea 56): the cup slate resets with the league slate
        cupPhase = 0;
        cupFixtures = new JSONArray();
        cupChampion = "";
        cupRunnerUp = "";
        // Batch H (idea 76): the review trackers start the new season empty
        // (the finished season's values were captured into history above);
        // a stale press conference never survives a season change either.
        seasonBestBat = null; seasonBestBowl = null;
        seasonBigWin = null; seasonFanMoment = null;
        pressConf = null;
        // Batch I (idea 85): the per-season achievement counters reset, the
        // Loyal watch restarts on whoever holds the armband now, the quest
        // set lapses with the season, and a stale prediction never carries.
        seasonHomeWins = 0;
        transferSpendSeason = 0;
        captainSeasonStart = captain;
        captainChangedSeason = false;
        questWeekKey = -1;
        quests = new JSONArray();
        prediction = null;
        // Batch D: the new season starts with the OFF-SEASON phase (idea 31/32/34).
        // Calendar is frozen (advanceDay refuses) until the manager confirms
        // the squad and finishes/skips the auction in HQ → Transfers.
        offseason = 1;
        departed = new JSONArray();
        auction = null;
        windowSeason = -1;
        windowSigns = 0;
        windowList = new JSONArray();
        poachOffer = null;
        wageShortStreak = 0;
        genLoanList();
        topUpFaPool();
        resetSeasonTablesAndFixtures();
        // ---- Batch G: the new season's HQ & money slate ----
        genStaffCandidates();          // idea 61: a fresh staff market
        maybePoachStaff();             // idea 61: elite staff can be lured away
        sponsorLegacy = false;         // idea 64: real deals replace the old flat sponsor now
        sponsor = null;
        sponsorProgress = 0;
        sponsorDone = false;
        genSponsorOffers();
        campPending = true;            // idea 66: a camp choice opens with the off-season
        campChoice = -1;
        campSeason = season;
        campMatchesUsed = 0;
        fanLossStreak = 0;
        setBoardObjective();           // idea 67: the new season's brief
        if (managerLevel >= 9) adjustBoardConfidence(10); // idea 69: the L9 perk
        addNews("BOARD OBJECTIVE for Season " + season + ": " + boardObjectiveText + ".");
        addNews("OFF-SEASON BUSINESS: three sponsor deals are on the table in HQ, and a pre-season training camp is yours to pick (or skip).");
        // Batch F (idea 55): 1–3 stars spend the off-season on international duty
        pickCallups();
        // Batch F (idea 56): the cup unlocks from Season 2
        if (season == 2) {
            addNews("🏆 NEW COMPETITION: the 50-over One-Day Cup launches this season! "
                    + "It runs as a straight knockout in the gap between the group stage and the playoffs.");
        }
        addNews("Season " + season + " is here — but first, the OFF-SEASON: retain/release and renew contracts in HQ → Transfers, then the auction.");
        return "Season " + season + " — off-season open";
    }

    // =====================================================================
    // Batch E (ideas 41–50): League & Season — playoffs, tournament book,
    // records, awards, qualification, head-to-head, history, Hall of Fame
    // =====================================================================

    /** The one true group ordering: points, then NRR. */
    public List<String> sortedGroup(String[] teams) {
        List<String> sorted = new ArrayList<>();
        Collections.addAll(sorted, teams);
        Collections.sort(sorted, (a, b) -> {
            JSONObject ra = tables.optJSONObject(a), rb = tables.optJSONObject(b);
            int pa = ra == null ? 0 : ra.optInt("pts"), pb = rb == null ? 0 : rb.optInt("pts");
            if (pb != pa) return pb - pa;
            return Double.compare(nrr(b), nrr(a));
        });
        return sorted;
    }

    /** Group-stage fixtures still to play for a team (qualification maths). */
    public int remainingFixtures(String team) {
        int n = 0;
        for (int i = 0; i < fixtures.length(); i++) {
            JSONObject f = fixtures.optJSONObject(i);
            if (f != null && !f.optBoolean("played")
                    && (team.equals(f.optString("home")) || team.equals(f.optString("away")))) n++;
        }
        return n;
    }

    /** The old pre-v7 crowning rule, kept as the legacy fallback. */
    public String pointsLeader() {
        String champion = null;
        int bestPts = -1;
        double bestNrr = -999;
        String[] all = allTeams();
        try {
            for (String t : all) {
                JSONObject r = tables.getJSONObject(t);
                int pts = r.optInt("pts");
                double n = nrr(t);
                if (pts > bestPts || (pts == bestPts && n > bestNrr)) {
                    bestPts = pts; bestNrr = n; champion = t;
                }
            }
        } catch (Exception ignored) {}
        return champion == null ? "" : champion;
    }

    // ---- playoffs (idea 41) ----

    private JSONObject addPlayoffFixture(String stage, String home, String away) throws Exception {
        JSONObject f = new JSONObject();
        f.put("stage", stage);
        f.put("day", 25 + playoffFixtures.length());
        f.put("home", home);
        f.put("away", away);
        f.put("played", false);
        f.put("summary", "");
        f.put("winner", "");
        ensureFixtureMeta(f, season);
        playoffFixtures.put(f);
        return f;
    }

    public JSONObject playoffFixture(String stage) {
        for (int i = 0; i < playoffFixtures.length(); i++) {
            JSONObject f = playoffFixtures.optJSONObject(i);
            if (f != null && stage.equals(f.optString("stage"))) return f;
        }
        return null;
    }

    /** The next playoff tie waiting for the manager (his team is in it). */
    public JSONObject pendingUserPlayoff() {
        for (int i = 0; i < playoffFixtures.length(); i++) {
            JSONObject f = playoffFixtures.optJSONObject(i);
            if (f != null && !f.optBoolean("played") && involvesUser(f)) return f;
        }
        return null;
    }

    public boolean userInPlayoffs() {
        for (int i = 0; i < playoffFixtures.length(); i++) {
            JSONObject f = playoffFixtures.optJSONObject(i);
            if (f != null && involvesUser(f)) return true;
        }
        return false;
    }

    private static String playoffLoser(JSONObject f) {
        String w = f.optString("winner");
        if (w.isEmpty()) return "";
        return w.equals(f.optString("home")) ? f.optString("away") : f.optString("home");
    }

    /** Group-seeding rank of a team (1 = won its group). Used when a playoff
     *  is level even after the Super Over: the higher seed advances. */
    private int seedRank(String team) {
        int i = sortedGroup(groupA()).indexOf(team);
        if (i >= 0) return i + 1;
        i = sortedGroup(groupB()).indexOf(team);
        return i >= 0 ? i + 1 : 99;
    }

    public String playoffSeedWinner(JSONObject f) {
        String home = f.optString("home"), away = f.optString("away");
        int rh = seedRank(home), ra = seedRank(away);
        if (rh != ra) return rh < ra ? home : away;
        JSONObject th = tables.optJSONObject(home), ta = tables.optJSONObject(away);
        int ph = th == null ? 0 : th.optInt("pts"), pa = ta == null ? 0 : ta.optInt("pts");
        if (ph != pa) return ph > pa ? home : away;
        return nrr(home) >= nrr(away) ? home : away;
    }

    /** Group stage finished: build the bracket and let it run. */
    public String beginPlayoffs() {
        try {
            playoffPhase = 1;
            playoffFixtures = new JSONArray();
            List<String> A = sortedGroup(groupA()), B = sortedGroup(groupB());
            addPlayoffFixture("Qualifier", A.get(0), B.get(0));
            addPlayoffFixture("Eliminator 1", A.get(1), B.get(1));
            // Batch G (ideas 64/67): reaching the bracket is a board and
            // sponsor event the moment it is sealed
            if (userInPlayoffs()) {
                adjustBoardConfidence(8);
                if (sponsor != null && sponsor.optInt("objType", -1) == 0) completeSponsorObjective();
            } else {
                adjustBoardConfidence(-8);
            }
            addNews("🏆 GROUP STAGE OVER — the Playoffs are set! Qualifier: " + A.get(0) + " vs " + B.get(0)
                    + " · Eliminator 1: " + A.get(1) + " vs " + B.get(1) + ".");
            progressPlayoffs();
            maybeRivalPreQuote(); // Batch H (idea 80)
            JSONObject pend = pendingUserPlayoff();
            if (pend != null) {
                addNews("PLAYOFF TIME: " + userTeam + " face " + opponentOf(pend) + " in the " + pend.optString("stage")
                        + " — play it from the Hub!");
                return "Playoffs! Your " + pend.optString("stage") + " vs " + opponentOf(pend) + " is waiting on the Hub.";
            }
            if (playoffPhase == 2) return "Playoffs done — " + seasonChampion + " are champions! Ceremony on the Hub.";
            return "Playoffs are under way — " + userTeam + " missed the top two, so the bracket plays out without them.";
        } catch (Exception e) {
            // never trap the manager: fall through to the off-season path
            playoffPhase = 3;
            return "Season over — off-season next.";
        }
    }

    /** The bracket driver: generates the next round when a round completes,
     *  quick-sims every tie that doesn't involve Lahore, and finalises the
     *  tournament when the Final is played. Idempotent and phase-guarded,
     *  so the recursion through simPlayoffFixture stays shallow and safe. */
    public void progressPlayoffs() {
        if (playoffPhase != 1) return;
        try {
            boolean moved = true;
            int guard = 0;
            while (moved && guard++ < 12 && playoffPhase == 1) {
                moved = false;
                JSONObject q = playoffFixture("Qualifier");
                JSONObject e1 = playoffFixture("Eliminator 1");
                if (q != null && e1 != null && q.optBoolean("played") && e1.optBoolean("played")
                        && playoffFixture("Eliminator 2") == null) {
                    addPlayoffFixture("Eliminator 2", playoffLoser(q), e1.optString("winner"));
                    moved = true;
                }
                JSONObject e2 = playoffFixture("Eliminator 2");
                if (q != null && e2 != null && e2.optBoolean("played") && playoffFixture("Final") == null) {
                    addPlayoffFixture("Final", q.optString("winner"), e2.optString("winner"));
                    moved = true;
                }
                for (int i = 0; i < playoffFixtures.length(); i++) {
                    JSONObject f = playoffFixtures.getJSONObject(i);
                    if (!f.optBoolean("played") && !involvesUser(f)) {
                        simPlayoffFixture(f);
                        moved = true;
                    }
                }
                JSONObject fin = playoffFixture("Final");
                if (fin != null && fin.optBoolean("played")) { finalizePlayoffs(); return; }
            }
        } catch (Exception ignored) {}
    }

    /** Advance Day during the playoffs: a pending Lahore tie is board-simmed
     *  (the same rule as a skipped league fixture); anything else just lets
     *  the bracket breathe. The manager can never be trapped here. */
    public String advancePlayoffs() {
        JSONObject pend = pendingUserPlayoff();
        if (pend != null) {
            simPlayoffFixture(pend);
            addNews("The day passed — the board simmed your " + pend.optString("stage")
                    + ": " + pend.optString("summary") + ".");
        } else {
            progressPlayoffs();
        }
        if (playoffPhase == 2) {
            return "Playoffs complete — " + seasonChampion + " are champions! Ceremony on the Hub.";
        }
        JSONObject next = pendingUserPlayoff();
        if (next != null) {
            return "Playoffs: your " + next.optString("stage") + " vs " + opponentOf(next) + " is waiting on the Hub.";
        }
        return "Playoffs are moving on…";
    }

    /** Quick-sim a playoff tie. Unlike simFixture this NEVER touches the
     *  group tables — but standouts, watchlist, records, the tournament
     *  book, career bookkeeping and head-to-head all still apply. A playoff
     *  always produces a winner: level scores go to a "Super Over" that the
     *  higher group seed is deemed to have edged. */
    public void simPlayoffFixture(JSONObject f) {
        try {
            if (f == null || f.optBoolean("played")) return;
            String home = f.getString("home"), away = f.getString("away");
            int hs = simStrength(home), as = simStrength(away); // Batch I (idea 81)
            int r1 = clamp(115 + rng.nextInt(105) + (hs - 80), 95, 235);
            int w1 = r1 > 205 ? 4 + rng.nextInt(5) : 5 + rng.nextInt(6);
            if (w1 > 10) w1 = 10;
            int b1 = w1 == 10 ? 96 + rng.nextInt(24) : 120;
            double chaseChance = 0.46 + (as - hs) * 0.008;
            boolean awayWins = rng.nextDouble() < chaseChance;
            int r2, w2, b2;
            if (awayWins) {
                r2 = r1 + 1 + rng.nextInt(12);
                w2 = 3 + rng.nextInt(6);
                b2 = 96 + rng.nextInt(23);
            } else {
                r2 = Math.max(70, r1 - 1 - rng.nextInt(38));
                w2 = 6 + rng.nextInt(5);
                if (w2 > 10) w2 = 10;
                b2 = w2 == 10 ? 90 + rng.nextInt(30) : 120;
            }
            String winner = awayWins ? away : home;
            String summary = f.optString("stage") + ": " + shortFor(home) + " " + r1 + "/" + w1
                    + " vs " + shortFor(away) + " " + r2 + "/" + w2 + " — " + winner + " won";
            // standouts (same generator as league sims)
            List<String> hn = namesFor(home), an = namesFor(away);
            String topBat, bestBowl, topBatTeam, bestBowlTeam;
            int topRuns, bestWkts;
            if (rng.nextBoolean()) {
                topBat = hn.get(rng.nextInt(Math.min(6, hn.size()))); topBatTeam = home;
                bestBowl = an.get(5 + rng.nextInt(Math.max(1, an.size() - 5))); bestBowlTeam = away;
            } else {
                topBat = an.get(rng.nextInt(Math.min(6, an.size()))); topBatTeam = away;
                bestBowl = hn.get(5 + rng.nextInt(Math.max(1, hn.size() - 5))); bestBowlTeam = home;
            }
            topRuns = 38 + rng.nextInt(92);
            bestWkts = rng.nextInt(100) < 12 ? 5 + rng.nextInt(2) : 1 + rng.nextInt(4);
            f.put("topBat", topBat).put("topBatRuns", topRuns);
            f.put("bestBowl", bestBowl).put("bestBowlWkts", bestWkts);
            f.put("topBatTeam", topBatTeam).put("bestBowlTeam", bestBowlTeam);
            // a simmed tie's Player of the Match: the day's standout
            if (topRuns >= 50 || bestWkts < 4) { f.put("potm", topBat); f.put("potmDesc", topRuns + " runs"); }
            else { f.put("potm", bestBowl); f.put("potmDesc", bestWkts + " wickets"); }
            f.put("r1", r1).put("w1", w1).put("r2", r2).put("w2", w2); // Batch H
            f.put("played", true);
            f.put("summary", summary);
            f.put("winner", winner);
            creditSimStandouts(f);
            if (topRuns >= 100) watchlistAlert(topBat, "scored " + topRuns + " (century!)", summary);
            if (bestWkts >= 5) watchlistAlert(bestBowl, "took " + bestWkts + " wickets (5-for!)", summary);
            // team totals can still trouble the records book (idea 48)
            considerTotal(home, r1, w1, away);
            considerTotal(away, r2, w2, home);
            if (r1 > r2) considerMarginRuns(home, r1 - r2, away);
            else if (r2 > r1) considerMarginWkts(away, 10 - w2, home);
            if (involvesUser(f)) {
                boolean userWon = winner.equals(userTeam);
                StatsBook.recordAppearances(this);
                StatsBook.recordSimStandouts(this, f);
                updateH2h(opponentOf(f), userWon ? 1 : -1);
                noteSponsorTeamScore(userTeam.equals(home) ? r1 : r2); // Batch G (idea 64)
                onUserMatchFinished(userWon, summary, f);
            }
            addNews("Playoffs — " + summary + ".");
            progressPlayoffs();
        } catch (Exception ignored) {}
    }

    /** Called by MatchEngine.finishMatch after a LIVE playoff tie: the
     *  Final's Player of the Match is copied onto the fixture for the
     *  ceremony, then the bracket moves on. */
    public void onPlayoffMatchFinished(JSONObject f, JSONObject m) {
        try {
            if (f != null && m != null) {
                f.put("potm", m.optString("potm", ""));
                f.put("potmDesc", m.optString("potmDesc", ""));
            }
        } catch (Exception ignored) {}
        progressPlayoffs();
        maybeRivalPreQuote(); // Batch H (idea 80): the next tie may be the rival
    }

    /** The Final is played: crown the champion, pay the prizes, hand out
     *  the season awards and set up the Trophy Ceremony (idea 42). */
    private void finalizePlayoffs() {
        if (playoffPhase != 1) return;
        try {
            JSONObject fin = playoffFixture("Final");
            if (fin == null) return;
            seasonChampion = fin.optString("winner");
            seasonRunnerUp = playoffLoser(fin);
            JSONObject c = new JSONObject();
            c.put("season", season).put("champion", seasonChampion).put("runnerUp", seasonRunnerUp);
            c.put("finalSummary", fin.optString("summary"));
            c.put("potm", fin.optString("potm", ""));
            c.put("potmDesc", fin.optString("potmDesc", ""));
            ceremony = c;
            if (userTeam.equals(seasonChampion)) {
                career.put("titles", career.optInt("titles") + 1);
                ledgerCf(prize(1500), "🏆 Champions! Season " + season + " Final winners"); // Batch I (idea 81)
                unlockAchievement("FIRSTTITLE"); // Batch I (idea 85)
                // Batch G (ideas 67/69/70): a title moves everyone
                adjustBoardConfidence(20);
                adjustFanMood(15);
                addManagerXp(100);
                if (sponsor != null && sponsor.optInt("objType", -1) == 1) completeSponsorObjective();
                // Hall of Fame (idea 49): this title squad's key men
                JSONObject h = new JSONObject();
                h.put("kind", "title").put("season", season).put("captain", captain)
                        .put("potm", fin.optString("potm", ""))
                        .put("line", "Season " + season + " champions — Final: " + fin.optString("summary"));
                hof.put(h);
                addNews("🏆🏆 CHAMPIONS! " + userTeam + " win the Season " + season
                        + " Final! +" + prize(1500) + " CF champions' prize — the trophy comes home!");
                fanEventPost("title", ""); // Batch H (idea 73)
            } else if (userTeam.equals(seasonRunnerUp)) {
                ledgerCf(prize(500), "Runners-up prize — Season " + season + " Final"); // Batch I (idea 81)
                addNews("So close — " + userTeam + " fall in the Season " + season + " Final. +" + prize(500) + " CF runners-up prize. "
                        + seasonChampion + " lift the trophy.");
            } else {
                addNews("🏆 " + seasonChampion + " win the Season " + season + " Final"
                        + (seasonRunnerUp.isEmpty() ? "" : " against " + seasonRunnerUp) + ".");
            }
            computeAwards();
            playoffPhase = 2;
        } catch (Exception ignored) {}
    }

    /** The ceremony's Continue button: off-season opens on the next Advance. */
    public void acknowledgeCeremony() {
        if (playoffPhase == 2) playoffPhase = 3;
    }

    // ---- tournament book & awards (ideas 43, 47) ----

    private JSONObject tournEntry(String name, String team) throws Exception {
        JSONObject e = tournBook.optJSONObject(name);
        if (e == null) {
            e = new JSONObject().put("team", team).put("runs", 0).put("balls", 0).put("outs", 0)
                    .put("f50", 0).put("f100", 0).put("bwBalls", 0).put("wkts", 0).put("conc", 0)
                    .put("f3", 0).put("f5", 0);
            tournBook.put(name, e);
        }
        return e;
    }

    public void tournCreditBat(String name, String team, int runs, int balls, boolean out) {
        if (name == null || name.isEmpty()) return;
        try {
            JSONObject e = tournEntry(name, team);
            e.put("runs", e.optInt("runs") + runs);
            e.put("balls", e.optInt("balls") + balls);
            if (out) e.put("outs", e.optInt("outs") + 1);
            if (runs >= 100) e.put("f100", e.optInt("f100") + 1);
            else if (runs >= 50) e.put("f50", e.optInt("f50") + 1);
        } catch (Exception ignored) {}
    }

    public void tournCreditBowl(String name, String team, int balls, int wkts, int conc) {
        if (name == null || name.isEmpty()) return;
        try {
            JSONObject e = tournEntry(name, team);
            e.put("bwBalls", e.optInt("bwBalls") + balls);
            e.put("wkts", e.optInt("wkts") + wkts);
            e.put("conc", e.optInt("conc") + conc);
            if (wkts >= 5) e.put("f5", e.optInt("f5") + 1);
            else if (wkts >= 3) e.put("f3", e.optInt("f3") + 1);
        } catch (Exception ignored) {}
    }

    /** A quick-sim's two generated standouts join the tournament book (and
     *  the records book). Balls/conceded use the SAME approximations as
     *  StatsBook.recordSimStandouts, so a Lahore man's tournament line
     *  matches his squad season stats exactly. */
    public void creditSimStandouts(JSONObject f) {
        String tb = f.optString("topBat", ""), bb = f.optString("bestBowl", "");
        int tr = f.optInt("topBatRuns", 0), bw = f.optInt("bestBowlWkts", 0);
        if (!tb.isEmpty() && tr > 0) {
            tournCreditBat(tb, f.optString("topBatTeam", ""), tr, Math.max(1, tr * 3 / 4), true);
            considerHighScore(tb, f.optString("topBatTeam", ""), tr, -1);
        }
        if (!bb.isEmpty() && bw > 0) {
            int conc = 18 + bw * 4;
            tournCreditBowl(bb, f.optString("bestBowlTeam", ""), 24, bw, conc);
            considerBestBowl(bb, f.optString("bestBowlTeam", ""), bw, conc);
        }
    }

    /** Live matches feed the tournament book from the FULL innings cards —
     *  the same events StatsBook credits to the squad's season stats. */
    public void recordTournMatch(JSONObject m) {
        if (m == null) return;
        String inn1Team = m.optString("inn1BatTeam");
        String inn2Team = userTeam.equals(inn1Team) ? m.optString("opp") : userTeam;
        creditCardTourn(m.optJSONArray("inn1BatCard"), inn1Team, true);
        creditCardTourn(m.optJSONArray("inn1BowlCard"), inn2Team, false);
        creditCardTourn(m.optJSONArray("batCard"), inn2Team, true);
        creditCardTourn(m.optJSONArray("bowlCard"), inn1Team, false);
    }

    private void creditCardTourn(JSONArray card, String team, boolean batting) {
        if (card == null) return;
        for (int i = 0; i < card.length(); i++) {
            JSONObject e = card.optJSONObject(i);
            if (e == null) continue;
            if (batting) {
                if (!e.optBoolean("in")) continue;
                tournCreditBat(e.optString("name"), team, e.optInt("runs"), e.optInt("balls"), e.optBoolean("out"));
            } else {
                if (e.optInt("balls") <= 0) continue;
                tournCreditBowl(e.optString("name"), team, e.optInt("balls"), e.optInt("wkts"), e.optInt("runs"));
            }
        }
    }

    /** MVP race formula (idea 43): runs + 25 per wicket, with bonuses for
     *  fifties, hundreds, 3-fors and 5-fors. */
    public static int mvpPoints(JSONObject e) {
        return e.optInt("runs") + 25 * e.optInt("wkts") + 5 * e.optInt("f50")
                + 10 * e.optInt("f100") + 4 * e.optInt("f3") + 10 * e.optInt("f5");
    }

    /** Sorted tournament rows {name, team, …figures} for a category:
     *  0 Most Runs · 1 Most Wickets · 2 Strike Rate (min 60 balls) ·
     *  3 Economy (min 36 balls bowled) · 4 MVP race. */
    public List<JSONObject> tournLeaders(int cat) {
        List<JSONObject> rows = new ArrayList<>();
        try {
            java.util.Iterator<String> it = tournBook.keys();
            while (it.hasNext()) {
                String name = it.next();
                JSONObject e = tournBook.getJSONObject(name);
                if (cat == 2 && e.optInt("balls") < 60) continue;
                if (cat == 3 && e.optInt("bwBalls") < 36) continue;
                JSONObject r = new JSONObject(e.toString());
                r.put("name", name);
                rows.add(r);
            }
        } catch (Exception ignored) {}
        Collections.sort(rows, (a, b) -> Double.compare(tournCatValue(b, cat), tournCatValue(a, cat)));
        return rows;
    }

    private static double tournCatValue(JSONObject e, int cat) {
        switch (cat) {
            case 0: return e.optInt("runs");
            case 1: return e.optInt("wkts");
            case 2: return e.optInt("balls") == 0 ? 0 : e.optInt("runs") * 100.0 / e.optInt("balls");
            case 3: return e.optInt("bwBalls") == 0 ? -999 : -(e.optInt("conc") * 6.0 / e.optInt("bwBalls"));
            default: return mvpPoints(e);
        }
    }

    /** Season awards (idea 47), judged on the tournament book at the Final.
     *  A Lahore winner pockets +15 CF per award through the ledger. */
    public void computeAwards() {
        try {
            lastAwards = new JSONObject();
            List<JSONObject> byRuns = tournLeaders(0);
            List<JSONObject> byWkts = tournLeaders(1);
            List<JSONObject> byMvp = tournLeaders(4);
            if (!byRuns.isEmpty()) lastAwards.put("goldenBat", awardRow(byRuns.get(0), "runs"));
            if (!byWkts.isEmpty()) {
                int maxW = byWkts.get(0).optInt("wkts");
                JSONObject best = byWkts.get(0);
                for (JSONObject r : byWkts) {
                    if (r.optInt("wkts") != maxW) break;
                    double eBest = best.optInt("bwBalls") == 0 ? 99 : best.optInt("conc") * 6.0 / best.optInt("bwBalls");
                    double eR = r.optInt("bwBalls") == 0 ? 99 : r.optInt("conc") * 6.0 / r.optInt("bwBalls");
                    if (eR < eBest) best = r;
                }
                lastAwards.put("bestBowler", awardRow(best, "wkts"));
            }
            if (!byMvp.isEmpty()) lastAwards.put("mvp", awardRow(byMvp.get(0), "pts"));
            // Emerging Player: best MVP points among players aged ≤ 23 whose
            // age is genuinely known (squad meta, or Data.hasAge)
            for (JSONObject r : byMvp) {
                int age = awardAge(r.optString("name"));
                if (age >= 0 && age <= 23) { lastAwards.put("emerging", awardRow(r, "pts")); break; }
            }
            String[][] defs = {{"goldenBat", "Golden Bat"}, {"bestBowler", "Best Bowler"},
                    {"mvp", "MVP of the Season"}, {"emerging", "Emerging Player"}};
            for (String[] d : defs) {
                JSONObject a = lastAwards.optJSONObject(d[0]);
                if (a == null) continue;
                addNews("🏅 Season " + season + " award — " + d[1] + ": " + a.optString("name")
                        + " (" + a.optString("team") + ") — " + a.optString("detail") + ".");
                if (playerByName(a.optString("name")) != null) {
                    ledgerCf(15, "Season award bonus — " + d[1] + ": " + a.optString("name"));
                    addManagerXp(5); // Batch G (idea 69): his players' awards are his XP too
                }
            }
        } catch (Exception ignored) {}
    }

    private JSONObject awardRow(JSONObject r, String key) throws Exception {
        JSONObject a = new JSONObject();
        a.put("name", r.optString("name")).put("team", r.optString("team"));
        a.put("runs", r.optInt("runs")).put("wkts", r.optInt("wkts")).put("pts", mvpPoints(r));
        if ("runs".equals(key)) a.put("detail", r.optInt("runs") + " runs");
        else if ("wkts".equals(key)) a.put("detail", r.optInt("wkts") + " wickets");
        else a.put("detail", mvpPoints(r) + " MVP pts");
        return a;
    }

    private int awardAge(String name) {
        JSONObject p = playerByName(name);
        if (p != null) return p.optInt("age", 99);
        return Data.hasAge(name) ? Data.ageFor(name) : -1;
    }

    // ---- records book (idea 48) ----

    private void considerTotal(String team, int runs, int wkts, String vs) {
        try {
            JSONObject cur = records.optJSONObject("highTotal");
            if (cur == null || runs > cur.optInt("runs")) {
                records.put("highTotal", new JSONObject().put("team", team).put("runs", runs)
                        .put("wkts", wkts).put("vs", vs).put("season", season));
            }
        } catch (Exception ignored) {}
    }

    private void considerMarginRuns(String team, int margin, String vs) {
        try {
            JSONObject cur = records.optJSONObject("bigWinRuns");
            if (cur == null || margin > cur.optInt("margin")) {
                records.put("bigWinRuns", new JSONObject().put("team", team).put("margin", margin)
                        .put("vs", vs).put("season", season));
            }
        } catch (Exception ignored) {}
    }

    private void considerMarginWkts(String team, int margin, String vs) {
        try {
            JSONObject cur = records.optJSONObject("bigWinWkts");
            if (cur == null || margin > cur.optInt("margin")) {
                records.put("bigWinWkts", new JSONObject().put("team", team).put("margin", margin)
                        .put("vs", vs).put("season", season));
            }
        } catch (Exception ignored) {}
    }

    private void considerHighScore(String player, String team, int runs, int balls) {
        try {
            JSONObject cur = records.optJSONObject("highScore");
            if (cur == null || runs > cur.optInt("runs")) {
                records.put("highScore", new JSONObject().put("player", player).put("team", team)
                        .put("runs", runs).put("balls", balls).put("season", season));
            }
        } catch (Exception ignored) {}
    }

    private void considerBestBowl(String player, String team, int wkts, int conc) {
        try {
            JSONObject cur = records.optJSONObject("bestBowl");
            if (cur == null || wkts > cur.optInt("wkts")
                    || (wkts == cur.optInt("wkts") && conc < cur.optInt("runs"))) {
                records.put("bestBowl", new JSONObject().put("player", player).put("team", team)
                        .put("wkts", wkts).put("runs", conc).put("season", season));
            }
        } catch (Exception ignored) {}
    }

    private void considerFastest50(String player, String team, int balls) {
        if (balls <= 0) return;
        try {
            JSONObject cur = records.optJSONObject("fastest50");
            if (cur == null || balls < cur.optInt("balls")) {
                records.put("fastest50", new JSONObject().put("player", player).put("team", team)
                        .put("balls", balls).put("season", season));
            }
        } catch (Exception ignored) {}
    }

    /** Feed the records book from a finished live match's full cards. */
    public void updateRecordsFromMatch(JSONObject m) {
        if (m == null) return;
        try {
            String inn1Team = m.optString("inn1BatTeam");
            String inn2Team = userTeam.equals(inn1Team) ? m.optString("opp") : userTeam;
            int r1 = m.optInt("inn1Runs"), w1 = m.optInt("inn1Wkts");
            int r2 = m.has("inn2Runs") ? m.optInt("inn2Runs") : m.optInt("runs");
            int w2 = m.has("inn2Runs") ? m.optInt("inn2Wkts") : m.optInt("wkts");
            considerTotal(inn1Team, r1, w1, inn2Team);
            considerTotal(inn2Team, r2, w2, inn1Team);
            if (r1 > r2) considerMarginRuns(inn1Team, r1 - r2, inn2Team);
            else if (r2 > r1) considerMarginWkts(inn2Team, 10 - w2, inn1Team);
            recordCardIndividuals(m.optJSONArray("inn1BatCard"), inn1Team, m.optJSONArray("inn1BowlCard"), inn2Team);
            recordCardIndividuals(m.optJSONArray("batCard"), inn2Team, m.optJSONArray("bowlCard"), inn1Team);
        } catch (Exception ignored) {}
    }

    private void recordCardIndividuals(JSONArray batCard, String batTeam, JSONArray bowlCard, String bowlTeam) {
        if (batCard != null) {
            for (int i = 0; i < batCard.length(); i++) {
                JSONObject e = batCard.optJSONObject(i);
                if (e == null || !e.optBoolean("in")) continue;
                considerHighScore(e.optString("name"), batTeam, e.optInt("runs"), e.optInt("balls"));
                if (e.has("balls50")) considerFastest50(e.optString("name"), batTeam, e.optInt("balls50"));
            }
        }
        if (bowlCard != null) {
            for (int i = 0; i < bowlCard.length(); i++) {
                JSONObject e = bowlCard.optJSONObject(i);
                if (e == null || e.optInt("balls") <= 0) continue;
                considerBestBowl(e.optString("name"), bowlTeam, e.optInt("wkts"), e.optInt("runs"));
            }
        }
    }

    private void considerSeasonRecord(String key, JSONObject leader) {
        try {
            int val = "mostRunsSeason".equals(key) ? leader.optInt("runs") : leader.optInt("wkts");
            if (val <= 0) return;
            JSONObject cur = records.optJSONObject(key);
            if (cur == null || val > cur.optInt("value")) {
                records.put(key, new JSONObject().put("player", leader.optString("name"))
                        .put("team", leader.optString("team")).put("value", val).put("season", season));
            }
        } catch (Exception ignored) {}
    }

    // ---- qualification scenarios (idea 45) ----

    /** Points-only bounds logic. "Guaranteed" claims are conservative:
     *  a rival counts as able to finish ahead of Lahore if his maximum
     *  possible points reach Lahore's reference points (level points can
     *  still be lost on NRR, so equality counts against Lahore). */
    public JSONObject qualificationInfo() {
        JSONObject q = new JSONObject();
        try {
            String[] grp = groupA();
            for (String t : groupB()) if (userTeam.equals(t)) grp = groupB();
            List<String> sorted = sortedGroup(grp);
            int pos = sorted.indexOf(userTeam) + 1;
            JSONObject row = tables.optJSONObject(userTeam);
            int pts = row == null ? 0 : row.optInt("pts");
            int played = row == null ? 0 : row.optInt("p");
            int rem = remainingFixtures(userTeam);
            int maxPts = pts + 2 * rem;
            q.put("pos", pos).put("pts", pts).put("played", played)
                    .put("remaining", rem).put("maxPts", maxPts).put("need", -1);
            if (playoffPhase > 0) {
                if (userInPlayoffs()) {
                    q.put("state", "qualified");
                    q.put("line", "Playoffs reached — " + userTeam + " finished in the group top two. Now it's knockout cricket.");
                } else {
                    q.put("state", "eliminated");
                    q.put("line", userTeam + " finished outside the top two — the playoffs go on without them.");
                }
                return q;
            }
            if (played < 3) {
                q.put("state", "early");
                q.put("line", "Top two in the group reach the playoffs — Qualifier, Eliminators and the Final await.");
                return q;
            }
            int canReachOrPass = 0, alreadyBeyond = 0;
            for (String t : grp) {
                if (userTeam.equals(t)) continue;
                JSONObject r = tables.optJSONObject(t);
                int rp = r == null ? 0 : r.optInt("pts");
                int rMax = rp + 2 * remainingFixtures(t);
                if (rMax >= pts) canReachOrPass++;
                if (rp > maxPts) alreadyBeyond++;
            }
            if (canReachOrPass <= 1) {
                q.put("state", "qualified");
                q.put("need", 0);
                q.put("line", "Already qualified ✓ — at most one rival can still catch " + userTeam + ". A top-two finish is guaranteed.");
            } else if (alreadyBeyond >= 2) {
                q.put("state", "eliminated");
                q.put("line", "Eliminated — two rivals are already beyond " + userTeam + "'s reach. Playing for pride and prize money now.");
            } else {
                int need = -1;
                for (int k = 0; k <= rem; k++) {
                    int target = pts + 2 * k;
                    int cnt = 0;
                    for (String t : grp) {
                        if (userTeam.equals(t)) continue;
                        JSONObject r = tables.optJSONObject(t);
                        int rMax = (r == null ? 0 : r.optInt("pts")) + 2 * remainingFixtures(t);
                        if (rMax >= target) cnt++;
                    }
                    if (cnt <= 1) { need = k; break; }
                }
                q.put("state", "alive");
                q.put("need", need);
                if (need >= 0) {
                    q.put("line", "Win " + need + " of the last " + rem + " to guarantee a top-two finish.");
                } else if (rem == 0) {
                    q.put("line", userTeam + "'s group games are done — they need favours from other results now.");
                } else {
                    q.put("line", "Must win out and hope results elsewhere go " + userTeam + "'s way — it's out of their hands.");
                }
            }
        } catch (Exception ignored) {}
        return q;
    }

    // ---- As It Stands (idea 44) ----

    /** Provisional group rows with the live match applied as if it ended
     *  this ball: rows {team, p, w, l, pts, nrr} sorted by pts then NRR. */
    public List<JSONObject> provisionalRows(JSONObject m) {
        List<JSONObject> out = new ArrayList<>();
        try {
            String[] grp = groupA();
            for (String t : groupB()) if (userTeam.equals(t)) grp = groupB();
            java.util.Map<String, JSONObject> rows = new java.util.HashMap<>();
            for (String t : grp) {
                JSONObject src = tables.optJSONObject(t);
                JSONObject c = new JSONObject();
                c.put("team", t);
                c.put("p", src == null ? 0 : src.optInt("p"));
                c.put("w", src == null ? 0 : src.optInt("w"));
                c.put("l", src == null ? 0 : src.optInt("l"));
                c.put("pts", src == null ? 0 : src.optInt("pts"));
                c.put("rf", src == null ? 0 : src.optInt("rf"));
                c.put("bf", src == null ? 0 : src.optInt("bf"));
                c.put("ra", src == null ? 0 : src.optInt("ra"));
                c.put("ba", src == null ? 0 : src.optInt("ba"));
                rows.put(t, c);
            }
            String teamA, teamB;
            int rA, bA, wA, rB, bB, wB;
            if (m.optInt("inn", 1) == 1 && !m.optBoolean("superMode") && !m.has("inn1BatTeam")) {
                teamA = m.optString("batTeam");
                rA = m.optInt("runs"); bA = m.optInt("balls"); wA = m.optInt("wkts");
                teamB = userTeam.equals(teamA) ? m.optString("opp") : userTeam;
                rB = 0; bB = 0; wB = 0;
            } else {
                teamA = m.optString("inn1BatTeam");
                rA = m.optInt("inn1Runs"); bA = m.optInt("inn1Balls"); wA = m.optInt("inn1Wkts");
                teamB = userTeam.equals(teamA) ? m.optString("opp") : userTeam;
                rB = m.has("inn2Runs") ? m.optInt("inn2Runs") : m.optInt("runs");
                bB = m.has("inn2Runs") ? m.optInt("inn2Balls") : m.optInt("balls");
                wB = m.has("inn2Runs") ? m.optInt("inn2Wkts") : m.optInt("wkts");
            }
            applyProvisional(rows.get(teamA), rows.get(teamB), rA, bA, wA, rB, bB, wB);
            for (String t : grp) {
                JSONObject c = rows.get(t);
                double n = (c.optInt("bf") == 0 || c.optInt("ba") == 0) ? 0
                        : c.optInt("rf") * 6.0 / c.optInt("bf") - c.optInt("ra") * 6.0 / c.optInt("ba");
                c.put("nrr", n);
                out.add(c);
            }
            Collections.sort(out, (a, b) -> {
                if (b.optInt("pts") != a.optInt("pts")) return b.optInt("pts") - a.optInt("pts");
                return Double.compare(b.optDouble("nrr"), a.optDouble("nrr"));
            });
        } catch (Exception ignored) {}
        return out;
    }

    private void applyProvisional(JSONObject A, JSONObject B, int r1, int b1, int w1,
                                   int r2, int b2, int w2) throws Exception {
        if (A == null || B == null) return;
        int eb1 = w1 == 10 ? 120 : b1, eb2 = w2 == 10 ? 120 : b2;
        A.put("p", A.optInt("p") + 1);
        B.put("p", B.optInt("p") + 1);
        A.put("rf", A.optInt("rf") + r1).put("bf", A.optInt("bf") + eb1)
                .put("ra", A.optInt("ra") + r2).put("ba", A.optInt("ba") + eb2);
        B.put("rf", B.optInt("rf") + r2).put("bf", B.optInt("bf") + eb2)
                .put("ra", B.optInt("ra") + r1).put("ba", B.optInt("ba") + eb1);
        if (r1 > r2) {
            A.put("w", A.optInt("w") + 1).put("pts", A.optInt("pts") + 2);
            B.put("l", B.optInt("l") + 1);
        } else if (r2 > r1) {
            B.put("w", B.optInt("w") + 1).put("pts", B.optInt("pts") + 2);
            A.put("l", A.optInt("l") + 1);
        } else {
            A.put("pts", A.optInt("pts") + 1);
            B.put("pts", B.optInt("pts") + 1);
        }
    }

    // ---- season history (idea 50) ----

    /** Snapshot the finished season BEFORE rollover wipes tables/stats.
     *  Runs once per season (guarded by the season number). */
    public void captureSeasonHistory() {
        try {
            if (seasonHistory.length() > 0
                    && seasonHistory.getJSONObject(0).optInt("season") == season) return;
            JSONObject e = new JSONObject();
            e.put("season", season);
            e.put("champion", !seasonChampion.isEmpty() ? seasonChampion : pointsLeader());
            e.put("runnerUp", seasonRunnerUp);
            String[] grp = groupA();
            String gname = "A";
            for (String t : groupB()) if (userTeam.equals(t)) { grp = groupB(); gname = "B"; }
            List<String> sorted = sortedGroup(grp);
            JSONObject row = tables.optJSONObject(userTeam);
            e.put("lahoreGroup", gname);
            e.put("lahorePos", sorted.indexOf(userTeam) + 1);
            e.put("lahoreP", row == null ? 0 : row.optInt("p"));
            e.put("lahoreW", row == null ? 0 : row.optInt("w"));
            e.put("lahoreL", row == null ? 0 : row.optInt("l"));
            JSONObject topBat = null, topBowl = null;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                JSONObject ss = p.optJSONObject("ss");
                if (ss == null) continue;
                if (topBat == null || ss.optInt("runs") > topBat.optJSONObject("ss").optInt("runs")) topBat = p;
                if (topBowl == null || ss.optInt("wkts") > topBowl.optJSONObject("ss").optInt("wkts")) topBowl = p;
            }
            if (topBat != null) {
                e.put("topScorer", topBat.optString("name") + " (" + topBat.optJSONObject("ss").optInt("runs") + " runs)");
            }
            if (topBowl != null) {
                e.put("topWkts", topBowl.optString("name") + " (" + topBowl.optJSONObject("ss").optInt("wkts") + " wkts)");
            }
            e.put("awards", lastAwards);
            // ---- Batch H (idea 76): the Season Review rides INSIDE this
            // same entry — best player by MVP points among the user squad,
            // the tracked season feats, the fan moment, and the finances.
            {
                JSONObject bestP = null; int bestPts = -1;
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    JSONObject tb = tournBook.optJSONObject(p.optString("name"));
                    if (tb == null || !userTeam.equals(tb.optString("team"))) continue;
                    int pts = mvpPoints(tb);
                    if (pts > bestPts) { bestPts = pts; bestP = p; }
                }
                e.put("reviewBestPlayer", bestP == null ? "—"
                        : bestP.optString("name") + " (" + bestPts + " MVP pts)");
                e.put("reviewBigWin", seasonBigWin == null ? "" : seasonBigWin.optString("text"));
                e.put("reviewBestBat", seasonBestBat == null ? "" : seasonBestBat.optString("text"));
                e.put("reviewBestBowl", seasonBestBowl == null ? "" : seasonBestBowl.optString("text"));
                e.put("reviewFanMoment", seasonFanMoment == null ? "" : seasonFanMoment.optString("text"));
                JSONObject fin = financeTotals();
                e.put("reviewFinNet", fin.optInt("total"));
                String bigIn = "", bigOut = "";
                int maxIn = 0, maxOut = 0;
                for (int i = 0; i < ledger.length(); i++) {
                    JSONObject le = ledger.optJSONObject(i);
                    if (le == null || le.optInt("season") != season) continue;
                    int amt = le.optInt("amt");
                    if (amt > maxIn) { maxIn = amt; bigIn = "+" + amt + " CF — " + le.optString("reason"); }
                    if (amt < maxOut) { maxOut = amt; bigOut = amt + " CF — " + le.optString("reason"); }
                }
                e.put("reviewFinIn", bigIn);
                e.put("reviewFinOut", bigOut);
            }
            JSONArray n = new JSONArray();
            n.put(e);
            for (int i = 0; i < Math.min(seasonHistory.length(), 29); i++) n.put(seasonHistory.getJSONObject(i));
            seasonHistory = n;
            // idea 48: most runs / wickets in a season, judged on the book
            List<JSONObject> byRuns = tournLeaders(0), byWkts = tournLeaders(1);
            if (!byRuns.isEmpty()) considerSeasonRecord("mostRunsSeason", byRuns.get(0));
            if (!byWkts.isEmpty()) considerSeasonRecord("mostWktsSeason", byWkts.get(0));
        } catch (Exception ignored) {}
    }

    // =====================================================================
    // Batch I (ideas 81–90): Modes & Challenges — achievements, quests,
    // predictions, the daily challenge, scenarios, quick season, result
    // codes and hardcore. Difficulty helpers live by teamColor() above.
    // =====================================================================

    // ---- achievements (idea 85) ----

    public static final String[][] ACH = {
        {"FIRSTWIN", "First Win", "Win your first match"},
        {"FIRSTTITLE", "First Title", "Win the league championship"},
        {"CUPWINNER", "Cup Winner", "Win the One-Day Cup"},
        {"DERBYKING", "Derby King", "Win 3 derbies in your career"},
        {"GIANTKILLER", "Giant Killer", "Beat a team rated 5+ stronger than yours"},
        {"WHITEWASH", "Winning Machine", "Win 5 matches in a row"},
        {"CENTURION", "Centurion Club", "One of your players reaches 3 career centuries"},
        {"FIVESTAR", "Five-Star", "One of your players takes a 5-wicket haul"},
        {"SUPERHERO", "Super Over Hero", "Win a Super Over"},
        {"FORTRESS", "Fortress", "Win 5 home matches in one season"},
        {"COMEBACK", "Comeback Kings", "Win a chase of 180 or more"},
        {"BIGSPENDER", "Big Spender", "Spend 1,000 CF on signings in one season"},
        {"LOYAL", "Loyal", "Keep the same captain for a whole season"},
        {"SURVIVOR", "Survivor", "Finish a season with board confidence under 30 — and keep your job"},
        {"LEGENDMGR", "Legend Manager", "Reach manager Level 10"},
    };

    public static String achName(String key) {
        for (String[] a : ACH) if (a[0].equals(key)) return a[1];
        return key;
    }

    public static String achDesc(String key) {
        for (String[] a : ACH) if (a[0].equals(key)) return a[2];
        return "";
    }

    public boolean achUnlocked(String key) { return achievements.has(key); }

    /** Unlocks a badge: recorded with the season/day, announced in the
     *  news, and worth +10 manager XP. Repeat calls are no-ops. */
    public void unlockAchievement(String key) {
        try {
            if (achievements.has(key)) return;
            JSONObject e = new JSONObject();
            e.put("season", season).put("day", day);
            achievements.put(key, e);
            addNews("🏅 Achievement unlocked: " + achName(key) + " — +10 manager XP!");
            addManagerXp(10);
        } catch (Exception ignored) {}
    }

    /** Migration only: a badge the career counters already proved before
     *  v11 existed — recorded with NO news and NO XP (see fromJson). */
    private void grantRetroAchievement(String key) {
        try {
            JSONObject e = new JSONObject();
            e.put("season", season).put("day", day).put("retro", true);
            achievements.put(key, e);
        } catch (Exception ignored) {}
    }

    /** The two player-stat badges, judged off career stats (cs). Called
     *  after StatsBook credits a live match (finishMatch) and from the
     *  post-match hook (which covers simmed standouts). */
    public void checkPlayerAchievements() {
        try {
            for (int i = 0; i < players.length(); i++) {
                JSONObject cs = player(i).optJSONObject("cs");
                if (cs == null) continue;
                if (cs.optInt("f100") >= 3) unlockAchievement("CENTURION");
                if (cs.optInt("f5") >= 1) unlockAchievement("FIVESTAR");
            }
        } catch (Exception ignored) {}
    }

    /** Every signing fee of the season feeds Big Spender (idea 85). */
    public void noteTransferSpend(int amount) {
        if (amount <= 0) return;
        transferSpendSeason += amount;
        if (transferSpendSeason >= 1000) unlockAchievement("BIGSPENDER");
    }

    /** The Batch I post-match flow, called from onUserMatchFinished for
     *  every season match (league/cup/playoff, live or simmed): quests
     *  progress, the prediction settles, and the match-based badges are
     *  judged off the Batch H match context + the career counters. */
    public void batchIOnMatchFinished(boolean userWon, String summary, JSONObject f) {
        try {
            JSONObject ctx = matchContext(userWon, summary, f);
            questProgress(ctx, f);
            settlePrediction(ctx, f);
            if (career.optInt("won") > 0) unlockAchievement("FIRSTWIN");
            if (career.optInt("derbyWins") >= 3) unlockAchievement("DERBYKING");
            if (career.optInt("streak") >= 5) unlockAchievement("WHITEWASH");
            if (seasonHomeWins >= 5) unlockAchievement("FORTRESS");
            if (userWon) {
                String opp = ctx.optString("opp");
                if (!opp.isEmpty() && strengthFor(opp) - strengthFor(userTeam) >= 5)
                    unlockAchievement("GIANTKILLER");
                // a chase won against a target of 180+ (innings-1 total r1)
                if (ctx.optBoolean("chased") && ctx.optInt("r1") >= 179)
                    unlockAchievement("COMEBACK");
            }
            checkPlayerAchievements();
        } catch (Exception ignored) {}
    }

    // ---- weekly quests (idea 84) ----

    /** Quest weeks are the three league weeks: Days 1–7, 8–14, 15–21.
     *  Days 22–24 and everything after (cup/playoffs) have no quests. */
    public static int questWeekOf(int d) { return d >= 1 && d <= 21 ? (d - 1) / 7 + 1 : -1; }

    /** Generates the current week's quest set when the week rolls over.
     *  Safe to call any time (load, Advance Day, Modes screen): it only
     *  acts when the live set belongs to another week. Expired sets are
     *  simply replaced — incomplete quests lapse with no penalty. */
    public void ensureQuests() {
        try {
            if (offseason > 0 || playoffPhase > 0 || cupPhase != 0) return;
            int wk = questWeekOf(day);
            if (wk < 0) return;
            int key = season * 10 + wk;
            if (questWeekKey == key && quests.length() > 0) return;
            questWeekKey = key;
            quests = genQuests(wk);
        } catch (Exception ignored) {}
    }

    /** Three quests, deterministic per season+week+club (seeded, so a
     *  reload can never re-roll them). The derby quest only joins the
     *  pool in a week that actually contains the derby fixture. */
    private JSONArray genQuests(int wk) {
        JSONArray out = new JSONArray();
        try {
            Random r = new Random(season * 100003L + wk * 977L + userTeam.hashCode());
            List<String[]> pool = new ArrayList<>();
            pool.add(new String[]{"WINS", "Win 2 matches this week", "2"});
            pool.add(new String[]{"TOTAL200", "Score 200+ in a match", "1"});
            pool.add(new String[]{"WKTS10", "Take 10 wickets this week", "10"});
            pool.add(new String[]{"AWAY", "Win an away match", "1"});
            pool.add(new String[]{"CENTURY", "A squad player scores a century", "1"});
            pool.add(new String[]{"LOW", "Keep an opponent under 120", "1"});
            pool.add(new String[]{"CHASE", "Win a match batting second", "1"});
            pool.add(new String[]{"FIVEFOR", "Take a 5-wicket haul in a match", "1"});
            pool.add(new String[]{"THRILLER", "Win a thriller (by ≤10 runs or ≤2 wkts)", "1"});
            int d0 = (wk - 1) * 7 + 1, d1 = d0 + 6;
            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject f = fixtures.getJSONObject(i);
                if (f.optInt("day") >= d0 && f.optInt("day") <= d1 && isDerby(f)) {
                    pool.add(new String[]{"DERBY", "Win the derby this week", "1"});
                    break;
                }
            }
            List<Integer> idx = new ArrayList<>();
            for (int i = 0; i < pool.size(); i++) idx.add(i);
            Collections.shuffle(idx, r);
            for (int k = 0; k < Math.min(3, idx.size()); k++) {
                String[] q = pool.get(idx.get(k));
                JSONObject o = new JSONObject();
                o.put("type", q[0]).put("text", q[1]).put("target", Integer.parseInt(q[2]))
                        .put("progress", 0).put("done", false);
                out.put(o);
            }
        } catch (Exception ignored) {}
        return out;
    }

    /** Judged per match from the FIXTURE's own day: only matches inside
     *  the live quest week move it — a quick-simmed future week or a
     *  late knockout can never leak progress into the wrong set. */
    private void questProgress(JSONObject ctx, JSONObject f) {
        try {
            if (quests.length() == 0 || f == null) return;
            int fw = questWeekOf(f.optInt("day", day));
            if (fw < 0 || questWeekKey != season * 10 + fw) return;
            boolean won = ctx.optBoolean("won");
            boolean home = userTeam.equals(ctx.optString("home"));
            boolean chased = ctx.optBoolean("chased");
            int r1 = ctx.optInt("r1", -1), r2 = ctx.optInt("r2", -1);
            int w1 = ctx.optInt("w1", -1), w2 = ctx.optInt("w2", -1);
            boolean userBattedFirst = won != chased;
            int userTotal = userBattedFirst ? r1 : r2;
            int oppTotal = userBattedFirst ? r2 : r1;
            int oppWkts = userBattedFirst ? w2 : w1;
            for (int i = 0; i < quests.length(); i++) {
                JSONObject q = quests.getJSONObject(i);
                if (q.optBoolean("done")) continue;
                int add = 0;
                switch (q.optString("type")) {
                    case "WINS": add = won ? 1 : 0; break;
                    case "TOTAL200": add = userTotal >= 200 ? 1 : 0; break;
                    case "WKTS10": add = Math.max(0, oppWkts); break;
                    case "AWAY": add = won && !home ? 1 : 0; break;
                    case "CENTURY": add = userTeam.equals(ctx.optString("centuryTeam"))
                            && ctx.optInt("centuryRuns") >= 100 ? 1 : 0; break;
                    case "DERBY": add = won && ctx.optBoolean("derby") ? 1 : 0; break;
                    case "LOW": add = oppTotal >= 0 && oppTotal < 120 ? 1 : 0; break;
                    case "CHASE": add = won && chased ? 1 : 0; break;
                    case "FIVEFOR": add = userTeam.equals(ctx.optString("fiveForTeam"))
                            && ctx.optInt("fiveForWkts") >= 5 ? 1 : 0; break;
                    case "THRILLER": add = won && "thriller".equals(ctx.optString("marginClass")) ? 1 : 0; break;
                    default: break;
                }
                if (add <= 0) continue;
                int p = Math.min(q.optInt("target"), q.optInt("progress") + add);
                q.put("progress", p);
                if (p >= q.optInt("target")) {
                    q.put("done", true);
                    ledgerCf(40, "Quest complete — " + q.optString("text"));
                    addNews("✅ Quest complete: " + q.optString("text") + " (+40 CF)");
                }
            }
        } catch (Exception ignored) {}
    }

    /** One compact line for the Hub: the live quests with progress. */
    public String questLine() {
        if (quests.length() == 0) return "";
        StringBuilder sb = new StringBuilder("🎯 Quests (Week " + Math.max(1, questWeekKey % 10) + "): ");
        for (int i = 0; i < quests.length(); i++) {
            JSONObject q = quests.optJSONObject(i);
            if (q == null) continue;
            if (i > 0) sb.append(" · ");
            sb.append(q.optBoolean("done") ? "✓ " : "")
                    .append(q.optString("text")).append(" — ")
                    .append(q.optInt("progress")).append("/").append(q.optInt("target"));
        }
        return sb.toString();
    }

    // ---- prediction game (idea 86) ----

    /** The identity of a user tie for prediction purposes. */
    public String predKeyFor(JSONObject f) {
        if (f == null) return "";
        if (f.optBoolean("cup")) return "C" + f.optInt("day");
        if (f.has("stage")) return "P" + f.optString("stage");
        return "L" + f.optInt("day");
    }

    /** The four top-scorer candidates: the two best bats of the user's XI
     *  and of the opponent's XI. */
    public List<String> predictionNames(String opp) {
        List<String> names = new ArrayList<>();
        try {
            List<JSONObject> cand = new ArrayList<>(xi());
            if (cand.size() < 2) for (int i = 0; i < Math.min(11, players.length()); i++) cand.add(player(i));
            Collections.sort(cand, (a, b) -> b.optInt("bat") - a.optInt("bat"));
            for (int i = 0; i < Math.min(2, cand.size()); i++) names.add(cand.get(i).optString("name"));
            List<Object[]> oxi = aiXiObjects(opp);
            Collections.sort(oxi, (a, b) -> ((Integer) b[1]) - ((Integer) a[1]));
            for (int i = 0; i < Math.min(2, oxi.size()); i++) names.add((String) oxi.get(i)[0]);
        } catch (Exception ignored) {}
        return names;
    }

    /** Builds (or returns) the pending prediction for a user tie, with
     *  the AI pundit's own picks rolled deterministically for flavour. */
    public JSONObject ensurePrediction(JSONObject f) {
        try {
            String key = predKeyFor(f);
            if (key.isEmpty()) return null;
            if (prediction != null && key.equals(prediction.optString("key"))) return prediction;
            String opp = opponentOf(f);
            List<String> names = predictionNames(opp);
            JSONObject p = new JSONObject();
            int h = Math.abs((season + "|" + key + "|" + opp).hashCode());
            p.put("key", key).put("opp", opp);
            p.put("winnerPick", "").put("scorerPick", "");
            p.put("punditWinner", h % 2 == 0 ? userTeam : opp);
            p.put("punditScorer", names.isEmpty() ? "" : names.get(h % names.size()));
            JSONArray na = new JSONArray();
            for (String n : names) na.put(n);
            p.put("names", na);
            prediction = p;
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    /** Settles the pending prediction at full time. Both picks right pays
     *  +60 CF, the winner alone +15 CF; a match the user never picked on
     *  leaves the record untouched. */
    private void settlePrediction(JSONObject ctx, JSONObject f) {
        try {
            if (prediction == null || f == null) return;
            if (!predKeyFor(f).equals(prediction.optString("key"))) return;
            JSONObject p = prediction;
            prediction = null; // the match is done — the picks are spent either way
            String wp = p.optString("winnerPick");
            if (wp.isEmpty()) return;
            String winner = ctx.optString("winner");
            boolean winnerRight = !winner.isEmpty() && wp.equals(winner);
            boolean scorerRight = false;
            String sp = p.optString("scorerPick");
            if (!sp.isEmpty()) {
                if (liveCtxOk(f)) scorerRight = predictionScorerRight(match, sp);
                else scorerRight = sp.equals(ctx.optString("topBat"));
            }
            predSettled++;
            if (winnerRight) predWins++;
            int pay = 0;
            if (winnerRight && scorerRight) { pay = 60; predBoth++; }
            else if (winnerRight) pay = 15;
            if (pay > 0) {
                ledgerCf(pay, "Prediction bonus — vs " + ctx.optString("opp"));
                addNews("🔮 Prediction: " + (pay == 60 ? "BOTH picks landed" : "winner called right")
                        + " — +" + pay + " CF bonus!");
            } else {
                addNews("🔮 Prediction missed this time — the pundit sends his regards.");
            }
        } catch (Exception ignored) {}
    }

    /** Live top-scorer verdict with ties: the pick is right when it
     *  matches ANY batter who finished on the match's highest score. */
    public boolean predictionScorerRight(JSONObject m, String pick) {
        if (m == null || pick == null || pick.isEmpty()) return false;
        try {
            JSONArray[] cards = {m.optJSONArray("inn1BatCard"), m.optJSONArray("batCard")};
            int best = -1;
            for (JSONArray c : cards) {
                if (c == null) continue;
                for (int i = 0; i < c.length(); i++) best = Math.max(best, c.optJSONObject(i).optInt("runs"));
            }
            if (best < 0) return false;
            for (JSONArray c : cards) {
                if (c == null) continue;
                for (int i = 0; i < c.length(); i++) {
                    JSONObject e = c.optJSONObject(i);
                    if (e.optInt("runs") == best && pick.equals(e.optString("name"))) return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    // ---- daily challenge (idea 82) ----

    /** The real calendar date, the seed the daily challenge hangs off. */
    public static String todayStr() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date());
    }

    /** Today's opponent is a pure function of the date string — closing
     *  and re-opening the Modes screen can never re-roll it. */
    public String challengeOpponentFor(String dateStr) {
        List<String> teams = new ArrayList<>();
        for (String t : allTeams()) if (!t.equals(userTeam)) teams.add(t);
        Collections.sort(teams);
        if (teams.isEmpty()) return userTeam;
        return teams.get(Math.abs(dateStr.hashCode()) % teams.size());
    }

    /** The exhibition fixture: outside the season, the opponent boosted
     *  +2 strength (the match's aiBoost, read by MatchEngine). */
    public JSONObject challengeFixture(String dateStr) {
        JSONObject f = new JSONObject();
        try {
            String opp = challengeOpponentFor(dateStr);
            boolean home = Math.abs((dateStr + "#").hashCode()) % 2 == 0;
            f.put("day", day);
            f.put("home", home ? userTeam : opp);
            f.put("away", home ? opp : userTeam);
            f.put("played", false);
            ensureFixtureMeta(f, season);
            f.put("friendly", 1);
            f.put("aiBoost", 2);
            f.put("challengeDate", dateStr);
        } catch (Exception ignored) {}
        return f;
    }

    /** The attempt is consumed at LAUNCH — the date is stamped before the
     *  match starts, so backing out and re-entering changes nothing. */
    public void startChallengeAttempt(String dateStr) {
        lastChallengeDate = dateStr;
        challengeResult = "";
    }

    // ---- scenarios (idea 83) ----

    public static final String[] SCENARIO_TITLES = {
            "The Chase", "Defend the Last Over", "The Collapse", "Super Over Decider"};
    public static final String[] SCENARIO_DESCS = {
            "Chasing 180 vs Karachi: you need 60 off 30 balls with 4 wickets in hand and two set batters in.",
            "The opponents need 12 off the final over with 3 wickets in hand. Your ball, your field, your nerve.",
            "45 for 5 chasing 150, with 14 overs left. One partnership rebuilds it — panic loses it.",
            "Scores level after 40 overs against your biggest rivals. Straight into a Super Over: 6 balls, 2 wickets."};

    /** The friendly fixture a scenario launches from; MatchEngine
     *  .injectScenario() then scripts the state through the engine. */
    public JSONObject scenarioFixture(int id) {
        JSONObject f = new JSONObject();
        try {
            String opp;
            if (id == 3) opp = Data.rivalOf(userTeam);
            else opp = userTeam.equals("Karachi Kings") ? "Lahore Qalandars" : "Karachi Kings";
            boolean home = id != 1;
            f.put("day", day);
            f.put("home", home ? userTeam : opp);
            f.put("away", home ? opp : userTeam);
            f.put("played", false);
            ensureFixtureMeta(f, season);
            f.put("friendly", 2);
            f.put("scenarioId", id);
        } catch (Exception ignored) {}
        return f;
    }

    public JSONObject scenarioState(int id) {
        return scenarios.optJSONObject(String.valueOf(id));
    }

    /** Batch I (ideas 82/83): a friendly has finished. finishMatch has
     *  already skipped EVERY season hook (tables, stats, records, morale,
     *  stamina, POTM money); the only traces allowed are the mode
     *  bookkeeping and the mode reward, both handled here. */
    public void finishFriendly(JSONObject m, String winner, String summary) {
        try {
            int type = m.optInt("friendly");
            boolean userWon = userTeam.equals(winner);
            if (type == 1) {
                String d = m.optString("challengeDate");
                challengeResult = userWon ? "W" : "L";
                if (userWon) {
                    challengeStreak++;
                    challengeWins++;
                    if (!d.isEmpty() && !d.equals(challengePaidDate)) {
                        challengePaidDate = d;
                        int amt = modeReward(75);
                        ledgerCf(amt, "Daily challenge reward");
                        m.put("friendlyNote", "🎯 Daily challenge WON — +" + amt + " CF reward banked. A new challenge arrives tomorrow.");
                        addNews("🎯 Daily challenge beaten! " + summary + " (+" + amt + " CF)");
                    } else {
                        m.put("friendlyNote", "🎯 Daily challenge won — today's reward was already banked.");
                    }
                } else {
                    challengeStreak = 0;
                    m.put("friendlyNote", "🎯 Daily challenge lost — no reward today. A new challenge arrives tomorrow.");
                    addNews("🎯 Daily challenge lost. " + summary);
                }
            } else if (type == 2) {
                int sid = m.optInt("scenarioId", -1);
                if (sid < 0 || sid >= SCENARIO_TITLES.length) return;
                JSONObject e = scenarios.optJSONObject(String.valueOf(sid));
                if (e == null) { e = new JSONObject(); scenarios.put(String.valueOf(sid), e); }
                e.put("played", e.optInt("played") + 1);
                if (userWon) {
                    int margin = friendlyMargin(m, winner);
                    if (!e.optBoolean("done")) {
                        e.put("done", true);
                        e.put("margin", margin);
                        e.put("summary", summary);
                        int amt = modeReward(50);
                        ledgerCf(amt, "Scenario reward — " + SCENARIO_TITLES[sid]);
                        m.put("friendlyNote", "🎬 Scenario cleared: " + SCENARIO_TITLES[sid] + " — +" + amt + " CF first-clear reward!");
                        addNews("🎬 Scenario cleared: " + SCENARIO_TITLES[sid] + "! " + summary + " (+" + amt + " CF)");
                    } else {
                        if (margin > e.optInt("margin")) { e.put("margin", margin); e.put("summary", summary); }
                        m.put("friendlyNote", "🎬 Scenario cleared again — replays are for pride; no repeat reward.");
                    }
                } else {
                    m.put("friendlyNote", "🎬 Scenario failed: " + SCENARIO_TITLES[sid] + " — replays are free, try again any time.");
                }
            }
        } catch (Exception ignored) {}
    }

    /** A comparable "how good was the win" number for scenario bests:
     *  the runs margin batting first; wickets/balls resource chasing. */
    private int friendlyMargin(JSONObject m, String winner) {
        int r1 = m.optInt("inn1Runs");
        int r2 = m.has("inn2Runs") ? m.optInt("inn2Runs") : m.optInt("runs");
        int w2 = m.has("inn2Runs") ? m.optInt("inn2Wkts") : m.optInt("wkts");
        int b2 = m.has("inn2Runs") ? m.optInt("inn2Balls") : m.optInt("balls");
        if (winner.equals(m.optString("inn1BatTeam"))) return Math.max(0, r1 - r2);
        return Math.max(0, (10 - w2) * 12 + Math.max(0, m.optInt("ballsLimit", 120) - b2) / 6);
    }

    // ---- quick season (idea 88) ----

    /** Sims every remaining GROUP-stage fixture through the normal
     *  simFixture path (standouts, injuries, morale, stats, quests and
     *  predictions all credit as usual), then hands over to the cup
     *  (Season 2+) or the playoffs exactly like advanceDay does.
     *  Knockouts, the ceremony and the off-season are NEVER auto-played,
     *  and the off-season itself cannot be quick-simmed. The caller
     *  gates the team sheet (xiProblems) like any match day. */
    public String quickSeason() {
        if (offseason > 0) return "The off-season can't be quick-simmed — finish Transfers first.";
        if (match != null) return "Finish the match in progress first.";
        if (playoffPhase > 0 || cupPhase != 0) return "The group stage is already over — knockouts are never auto-played.";
        if (!xiProblems().isEmpty()) return "BLOCKED";
        try {
            int p0 = career.optInt("played"), w0 = career.optInt("won");
            List<JSONObject> todo = new ArrayList<>();
            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject f = fixtures.getJSONObject(i);
                if (!f.optBoolean("played")) todo.add(f);
            }
            Collections.sort(todo, (a, b) -> a.optInt("day") - b.optInt("day"));
            for (JSONObject f : todo) simFixture(f);
            day = 25;
            int w = career.optInt("won") - w0, p = career.optInt("played") - p0;
            String tail;
            if (cupEnabled() && cupPhase == 0) { beginCup(); tail = "The One-Day Cup is up next — play it from the Hub."; }
            else { beginPlayoffs(); tail = "The playoffs are set — play them from the Hub."; }
            addNews("⏩ Quick Season: the group stage was simmed (your record: W" + w + " L" + (p - w) + ").");
            return "Group stage simmed — your record: W" + w + " L" + (p - w) + ". " + tail;
        } catch (Exception e) {
            return "Quick Season failed.";
        }
    }

    // ---- result codes (idea 89) ----

    private static String ordSuffix(int n) {
        if (n == 1) return "st";
        if (n == 2) return "nd";
        if (n == 3) return "rd";
        return "th";
    }

    /** A one-line code for the last completed season, from its history
     *  entry: "S3 · LAH · 2nd in Group A · CHAMPIONS · P12 W8 L4 ·
     *  Golden Bat: Saim Ayub · CF 2,148". Pure display/copy. */
    public String seasonResultCode() {
        try {
            if (seasonHistory.length() == 0)
                return "No completed season yet — finish Season " + season + " for your first result code.";
            JSONObject e = seasonHistory.getJSONObject(0);
            String finish;
            if (userTeam.equals(e.optString("champion"))) finish = "CHAMPIONS";
            else if (userTeam.equals(e.optString("runnerUp"))) finish = "Runners-up";
            else finish = "Won by " + e.optString("champion");
            String bat = "";
            JSONObject aw = e.optJSONObject("awards");
            if (aw != null && aw.optJSONObject("goldenBat") != null)
                bat = aw.getJSONObject("goldenBat").optString("name");
            if (bat.isEmpty()) bat = e.optString("topScorer");
            return "S" + e.optInt("season") + " · " + shortFor(userTeam)
                    + " · " + e.optInt("lahorePos") + ordSuffix(e.optInt("lahorePos"))
                    + " in Group " + e.optString("lahoreGroup")
                    + " · " + finish
                    + " · P" + e.optInt("lahoreP") + " W" + e.optInt("lahoreW") + " L" + e.optInt("lahoreL")
                    + (bat.isEmpty() ? "" : " · Golden Bat: " + bat)
                    + " · CF " + String.format(Locale.US, "%,d", cf);
        } catch (Exception ex) {
            return "";
        }
    }

    /** The whole-career variant of the result code. */
    public String careerResultCode() {
        int seasons = seasonHistory.length();
        return "Career · " + shortFor(userTeam)
                + " · " + (seasons == 0 ? "Season " + season + " in progress"
                        : seasons + (seasons == 1 ? " season" : " seasons"))
                + " · Titles " + career.optInt("titles") + " · Cups " + career.optInt("cups")
                + " · P" + career.optInt("played") + " W" + career.optInt("won") + " L" + career.optInt("lost")
                + " · Manager L" + managerLevel
                + " · CF " + String.format(Locale.US, "%,d", cf);
    }

    // ---- hardcore (idea 90) ----

    /** Hardcore may be switched on for the current career ONLY at a
     *  season start: during the off-season, or on Day 1–2 before any
     *  match of the season has been played. */
    public boolean canEnableHardcore() {
        if (hardcore || match != null) return false;
        if (offseason > 0) return true; // between seasons IS a season start
        if (day > 2) return false;
        try {
            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject f = fixtures.getJSONObject(i);
                if (f.optBoolean("played") && involvesUser(f)) return false;
            }
            for (int i = 0; i < playoffFixtures.length(); i++)
                if (playoffFixtures.getJSONObject(i).optBoolean("played")) return false;
            for (int i = 0; i < cupFixtures.length(); i++)
                if (cupFixtures.getJSONObject(i).optBoolean("played")) return false;
        } catch (Exception ignored) {}
        return true;
    }

    public String enableHardcore() {
        if (hardcore) return "Hardcore is already on for this career.";
        if (!canEnableHardcore())
            return "Hardcore can only be switched on at a season start — Day 1–2 before any match, during the off-season, or when starting a new career.";
        hardcore = true;
        addNews("☠ HARDCORE MODE ON: the sack line is " + sackThreshold() + " board confidence, warnings start at 40, "
                + "daily-challenge and scenario rewards are halved, and slot load-undo is disabled.");
        return "☠ Hardcore mode ON for this career.";
    }

    // ---------------- Hub actions ----------------

    /** Cost of one medical recovery session: cheaper as the Medical Centre improves. */
    public int recoveryCost() {
        return recoveryCostFor(facilityLevel(1));
    }

    /** Stamina recovered per session: better as the Medical Centre
     *  improves — and a staffed Physio adds his bonus on top (Batch G). */
    public int recoveryGain() {
        return recoveryGainFor(facilityLevel(1)) + physioRecoveryBonus();
    }

    /** Runs a recovery session. Returns the stamina gain, or -1 if CF can't cover the cost. */
    public int recovery() {
        int cost = recoveryCost();
        if (cf < cost) return -1;
        ledgerCf(-cost, "Medical recovery session (Medical Lvl " + facilityLevel(1) + ")");
        int gain = recoveryGain();
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try { p.put("stam", Math.min(100, p.optInt("stam") + gain)); } catch (Exception ignored) {}
        }
        return gain;
    }

    public boolean teamTalk() {
        if (talkDay == day) return false;
        talkDay = day;
        // Batch G: a Head Coach makes the talk land harder (+6 morale,
        // not +4), and a Level 5+ manager adds +2 more (idea 69 perk)
        int moraleGain = (staffRating("Head Coach") > 0 ? 6 : 4) + (managerLevel >= 5 ? 2 : 0);
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try {
                int set = Math.min(99, p.optInt("set") + 8);
                p.put("set", set);
                // Batch C (idea 25): a good talk lifts morale too
                p.put("morale", clampMorale(p.optInt("morale", 70) + moraleGain));
            } catch (Exception ignored) {}
        }
        addNews("Team Talk done — squad Set % and morale boosted for today.");
        return true;
    }

    public boolean upgradeFacility(int idx) {
        int lvl = facilityLevel(idx);
        if (lvl >= Data.FACILITY_MAX) return false;
        int cost = facilityUpgradeCost(idx); // Batch G: base x level, L2 perk discount on Training
        if (cf < cost) return false; // purchase blocked — balance never silently negative
        ledgerCf(-cost, Data.FACILITY_NAMES[idx] + " upgrade to Level " + (lvl + 1));
        try {
            facilities.put(idx, lvl + 1);
            if (idx == 2) { // Training Complex: immediate small squad rating boost
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    p.put("bat", Math.min(99, p.optInt("bat") + 1));
                    p.put("bowl", Math.min(99, p.optInt("bowl") + 1));
                }
            }
            addNews(Data.FACILITY_NAMES[idx] + " upgraded to Level " + (lvl + 1) + "!");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static int rating(JSONObject p) {
        String role = p.optString("role");
        int bat = p.optInt("bat"), bowl = p.optInt("bowl");
        switch (role) {
            case "Bat": return (int) (bat * 0.85 + bowl * 0.15);
            case "Bowl": return (int) (bowl * 0.85 + bat * 0.15);
            case "WK": return (int) (bat * 0.9 + bowl * 0.1) + 2;
            default: return (bat + bowl) / 2 + 3; // AR
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // =====================================================================
    // Batch F (ideas 51–60): Teams & World — AI squad depth, dynamic world
    // rankings, international call-ups, the One-Day Cup, crowds, derbies,
    // grounds and player renames.
    // =====================================================================

    // ---- opponent squad depth (idea 53) ----

    /** Overall rating of a raw squad row {name, role, bat, bowl, overseas},
     *  using the same weights as rating(). */
    private static int aiOverall(Object[] r) {
        int bat = (Integer) r[2], bowl = (Integer) r[3];
        switch ((String) r[1]) {
            case "Bat": return (int) (bat * 0.85 + bowl * 0.15);
            case "Bowl": return (int) (bowl * 0.85 + bat * 0.15);
            case "WK": return (int) (bat * 0.9 + bowl * 0.1) + 2;
            default: return (bat + bowl) / 2 + 3; // AR
        }
    }

    /** Deterministic "form" 0–99 for an AI player this week — the rotation
     *  rests men whose number comes up low. (AI stamina is folded into this
     *  same roll: light tracking by design.) */
    private int aiForm(String name) {
        return Math.abs((name.hashCode() + season * 77 + day * 13) & 0x7fffffff) % 100;
    }

    /** An AI XI is re-picked whenever the world has moved on since the pick. */
    private String aiStamp(String team) {
        JSONObject row = tables.optJSONObject(team);
        int played = row == null ? 0 : row.optInt("p");
        int po = 0, cu = 0;
        for (int i = 0; i < playoffFixtures.length(); i++) {
            JSONObject f = playoffFixtures.optJSONObject(i);
            if (f != null && f.optBoolean("played")) po++;
        }
        for (int i = 0; i < cupFixtures.length(); i++) {
            JSONObject f = cupFixtures.optJSONObject(i);
            if (f != null && f.optBoolean("played")) cu++;
        }
        return season + ":" + day + ":" + played + ":" + po + ":" + cu;
    }

    public List<String> aiXiNames(String team) {
        List<String> out = new ArrayList<>();
        for (Object[] r : aiXiObjects(team)) out.add((String) r[0]);
        return out;
    }

    /** The AI club's current XI as engine rows {name, bat, bowl}, in batting
     *  order. Cached against aiStamp so a live match, the danger-man line
     *  and the quick sims around it all see the SAME eleven. */
    public List<Object[]> aiXiObjects(String team) {
        try {
            String stamp = aiStamp(team);
            JSONObject c = aiXiCache.optJSONObject(team);
            if (c != null && stamp.equals(c.optString("stamp"))) {
                JSONArray names = c.optJSONArray("names");
                if (names != null && names.length() == 11) {
                    List<Object[]> out = new ArrayList<>();
                    for (int i = 0; i < names.length(); i++) {
                        Object[] row = squadRow(team, names.getString(i));
                        if (row != null) out.add(new Object[]{row[0], row[2], row[3]});
                    }
                    if (out.size() == 11) return out;
                }
            }
            List<Object[]> xi = pickAiXi(team);
            JSONArray names = new JSONArray();
            for (Object[] r : xi) names.put((String) r[0]);
            JSONObject nc = new JSONObject();
            nc.put("stamp", stamp).put("names", names);
            aiXiCache.put(team, nc);
            List<Object[]> out = new ArrayList<>();
            for (Object[] r : xi) out.add(new Object[]{r[0], r[2], r[3]});
            return out;
        } catch (Exception e) {
            List<Object[]> out = new ArrayList<>();
            for (Object[] p : Data.xiFor(team)) out.add(p);
            return out;
        }
    }

    private Object[] squadRow(String team, String name) {
        for (Object[] r : Data.squadFor(team)) if (name.equals(r[0])) return r;
        return null;
    }

    /** Picks a validator-style legal XI from the club's full 18: keeper
     *  first, then bowling options, then the best of the rest — injured men
     *  sit out, the overseas cap holds — then applies 0–2 rotation swaps
     *  (an out-of-form man makes way for an in-form bench man in the same
     *  broad group, legality re-checked). Batting order = batting desc. */
    private List<Object[]> pickAiXi(String team) {
        Object[][] squad = Data.squadFor(team);
        JSONObject inj = aiInj.optJSONObject(team);
        List<Object[]> fit = new ArrayList<>();
        for (Object[] r : squad) {
            if (inj != null && inj.optInt((String) r[0], 0) > 0) continue;
            fit.add(r);
        }
        Collections.sort(fit, (a, b) -> aiOverall(b) - aiOverall(a));
        List<Object[]> xi = new ArrayList<>();
        int os = 0;
        for (Object[] r : fit) { // keeper first
            if (!"WK".equals(r[1])) continue;
            if ((Boolean) r[4] && os >= MAX_OVERSEAS) continue;
            xi.add(r); if ((Boolean) r[4]) os++;
            break;
        }
        for (Object[] r : fit) { // bowling options to 5+
            if (countAiBowlOptions(xi) >= MIN_BOWL_OPTIONS || xi.size() >= 11) break;
            if (xi.contains(r) || (Integer) r[3] < BOWL_OPTION_MIN) continue;
            if ((Boolean) r[4] && os >= MAX_OVERSEAS) continue;
            xi.add(r); if ((Boolean) r[4]) os++;
        }
        for (Object[] r : fit) { // fill by overall
            if (xi.size() >= 11) break;
            if (xi.contains(r)) continue;
            if ((Boolean) r[4] && os >= MAX_OVERSEAS) continue;
            xi.add(r); if ((Boolean) r[4]) os++;
        }
        for (Object[] r : fit) { // desperate fill: bodies over legality
            if (xi.size() >= 11) break;
            if (!xi.contains(r)) xi.add(r);
        }
        if (xi.size() < 11) {
            for (Object[] r : squad) {
                if (xi.size() >= 11) break;
                if (!xi.contains(r)) xi.add(r);
            }
        }
        // rotation swaps (deterministic per stamp)
        int swaps = Math.abs((team + "|" + aiStamp(team)).hashCode()) % 3;
        for (int s = 0; s < swaps; s++) {
            Object[] worst = null;
            int worstForm = 999;
            for (Object[] r : xi) {
                if ("WK".equals(r[1]) && aiWkCount(xi) <= 1) continue; // never rest the only keeper
                int f = aiForm((String) r[0]);
                if (f < worstForm) { worstForm = f; worst = r; }
            }
            if (worst == null || worstForm >= 45) break;
            Object[] bestBench = null;
            int bestForm = -1;
            for (Object[] r : fit) {
                if (xi.contains(r)) continue;
                boolean sameGroup = ((Integer) r[3] >= BOWL_OPTION_MIN) == ((Integer) worst[3] >= BOWL_OPTION_MIN);
                if (!sameGroup) continue;
                int f = aiForm((String) r[0]);
                if (f > bestForm) { bestForm = f; bestBench = r; }
            }
            if (bestBench == null || bestForm <= 55) break;
            int osAfter = aiOsCount(xi) - ((Boolean) worst[4] ? 1 : 0) + ((Boolean) bestBench[4] ? 1 : 0);
            if (osAfter > MAX_OVERSEAS) break;
            xi.remove(worst);
            xi.add(bestBench);
        }
        Collections.sort(xi, (a, b) -> (Integer) b[2] - (Integer) a[2]); // batting order
        return xi;
    }

    private static int countAiBowlOptions(List<Object[]> xi) {
        int n = 0;
        for (Object[] r : xi) if ((Integer) r[3] >= BOWL_OPTION_MIN) n++;
        return n;
    }

    private static int aiOsCount(List<Object[]> xi) {
        int n = 0;
        for (Object[] r : xi) if ((Boolean) r[4]) n++;
        return n;
    }

    private static int aiWkCount(List<Object[]> xi) {
        int n = 0;
        for (Object[] r : xi) if ("WK".equals(r[1])) n++;
        return n;
    }

    /** AI injury roll after a match (idea 53): 10% chance one man from the
     *  XI that just played misses 2–5 days. Tracked lightly per club. */
    public void rollAiInjury(String team) {
        if (team == null || userTeam.equals(team)) return;
        try {
            if (rng.nextDouble() >= 0.10) return;
            List<Object[]> xi = aiXiObjects(team);
            if (xi.isEmpty()) return;
            String victim = (String) xi.get(rng.nextInt(xi.size()))[0];
            JSONObject inj = aiInj.optJSONObject(team);
            if (inj == null) { inj = new JSONObject(); aiInj.put(team, inj); }
            if (inj.optInt(victim, 0) > 0) return;
            inj.put(victim, 2 + rng.nextInt(4));
            aiXiCache.remove(team); // the next pick must route around him
        } catch (Exception ignored) {}
    }

    /** AI knocks heal one day per Advance Day, like the user's physio queue. */
    public void tickAiInjuries() {
        try {
            java.util.Iterator<String> teams = aiInj.keys();
            while (teams.hasNext()) {
                String team = teams.next();
                JSONObject inj = aiInj.getJSONObject(team);
                boolean changed = false;
                java.util.Iterator<String> names = inj.keys();
                List<String> healed = new ArrayList<>();
                while (names.hasNext()) {
                    String n = names.next();
                    int d = inj.optInt(n, 0) - 1;
                    if (d <= 0) healed.add(n);
                    else inj.put(n, d);
                    changed = true;
                }
                for (String n : healed) inj.remove(n);
                if (changed) aiXiCache.remove(team);
            }
        } catch (Exception ignored) {}
    }

    // ---- dynamic World rankings (idea 54) ----

    /** Seeds the dynamic T20I tables from Data's static snapshot (used by
     *  fresh careers and the v7->v8 migration). prev = current rank, so the
     *  first drift is the first movement anyone ever sees. */
    public void seedWorldState() {
        try {
            if (worldNations.length() == 0) {
                String[][] ns = Data.worldNations(0);
                for (int i = 0; i < ns.length; i++) {
                    JSONObject e = new JSONObject();
                    e.put("name", ns[i][0]).put("pts", Integer.parseInt(ns[i][1])).put("prev", i + 1);
                    worldNations.put(e);
                }
            }
            if (worldBat.length() == 0) seedWorldList(worldBat, Data.worldPlayers(0, 0));
            if (worldBowl.length() == 0) seedWorldList(worldBowl, Data.worldPlayers(0, 1));
        } catch (Exception ignored) {}
    }

    private void seedWorldList(JSONArray arr, String[][] rows) throws Exception {
        for (int i = 0; i < rows.length; i++) {
            JSONObject e = new JSONObject();
            e.put("name", rows[i][0]).put("tag", rows[i][1])
                    .put("pts", Integer.parseInt(rows[i][2])).put("prev", i + 1);
            arr.put(e);
        }
    }

    /** The nation a league player represents, for ranking boosts: the
     *  static world tables first (Babar, Buttler…), then league squads —
     *  a non-overseas league man is Pakistani, an unlisted overseas man
     *  earns his (untracked) nation nothing. */
    private String nationOfLeaguePlayer(String name) {
        String n = Data.nationOfPlayer(name);
        if (!n.isEmpty()) return n;
        JSONObject p = playerByName(name);
        if (p != null) return p.optBoolean("overseas") ? "" : "Pakistan";
        for (String t : allTeams()) {
            Object[] r = squadRow(t, name);
            if (r != null) return (Boolean) r[4] ? "" : "Pakistan";
        }
        return "";
    }

    private void addNationBoost(JSONObject boost, String nation, int pts) {
        if (nation == null || nation.isEmpty()) return;
        try { boost.put(nation, boost.optInt(nation, 0) + pts); } catch (Exception ignored) {}
    }

    /** Season-end drift, run at rollover BEFORE lastAwards/seasonChampion
     *  reset: nations of the Golden Bat and Best Bowler winners gain +6,
     *  the champion captain's nation +4, everyone takes a small random
     *  walk (-3..+4 nations, ±14 rating points for players). prev records
     *  the rank each row held as the drift began — the World tab's ▲▼. */
    public void driftWorldRankings() {
        try {
            seedWorldState();
            JSONObject boost = new JSONObject();
            JSONObject gb = lastAwards.optJSONObject("goldenBat");
            JSONObject bb = lastAwards.optJSONObject("bestBowler");
            if (gb != null) addNationBoost(boost, nationOfLeaguePlayer(gb.optString("name")), 6);
            if (bb != null) addNationBoost(boost, nationOfLeaguePlayer(bb.optString("name")), 6);
            if (!seasonChampion.isEmpty()) {
                String cap = userTeam.equals(seasonChampion) ? captain : Data.captainFor(seasonChampion);
                addNationBoost(boost, nationOfLeaguePlayer(cap), 4);
            }
            applyWorldDrift(worldNations, boost, -3, 4);
            applyWorldDrift(worldBat, null, -14, 14);
            applyWorldDrift(worldBowl, null, -14, 14);
            JSONObject top = worldNations.optJSONObject(0);
            if (top != null) {
                String climber = "";
                int bestGain = 0;
                for (int i = 0; i < worldNations.length(); i++) {
                    JSONObject e = worldNations.getJSONObject(i);
                    int gain = e.optInt("prev") - (i + 1);
                    if (gain > bestGain) { bestGain = gain; climber = e.optString("name"); }
                }
                addNews("🌍 World rankings updated for Season " + season + ": " + top.optString("name")
                        + " top the T20I table (" + top.optInt("pts") + " pts)"
                        + (bestGain > 0 ? " · " + climber + " climb " + bestGain + " place" + (bestGain > 1 ? "s" : "") : "")
                        + ". See the World tab.");
            }
        } catch (Exception ignored) {}
    }

    private void applyWorldDrift(JSONArray arr, JSONObject boost, int lo, int hi) throws Exception {
        for (int i = 0; i < arr.length(); i++) {
            JSONObject e = arr.getJSONObject(i);
            e.put("prev", i + 1); // the rank held as this drift begins
            int extra = boost == null ? 0 : boost.optInt(e.optString("name"), 0);
            e.put("pts", Math.max(40, e.optInt("pts") + lo + rng.nextInt(hi - lo + 1) + extra));
        }
        // 5-row tables: a plain selection sort by points, descending
        for (int i = 0; i < arr.length(); i++) {
            for (int j = i + 1; j < arr.length(); j++) {
                if (arr.getJSONObject(j).optInt("pts") > arr.getJSONObject(i).optInt("pts")) {
                    JSONObject tmp = arr.getJSONObject(i);
                    arr.put(i, arr.getJSONObject(j));
                    arr.put(j, tmp);
                }
            }
        }
    }

    /** Movement label for a ranked row: ▲n / ▼n / — vs last season. */
    public static String rankMove(int prev, int rank) {
        int d = prev - rank;
        if (d > 0) return "▲" + d;
        if (d < 0) return "▼" + (-d);
        return "—";
    }

    // ---- international call-ups (idea 55) ----

    /** At rollover: 1–3 of the five highest-rated eligible men (rating
     *  72+) are called up for a fictional off-season international series.
     *  They stay in the squad (badge in the Team tab) and their return is
     *  resolved when the off-season closes. */
    public void pickCallups() {
        try {
            callups = new JSONArray();
            List<JSONObject> cand = new ArrayList<>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (p.optBoolean("loanIn") || p.optBoolean("loanOut")) continue;
                if (rating(p) >= 72) cand.add(p);
            }
            Collections.sort(cand, (a, b) -> rating(b) - rating(a));
            int pool = Math.min(5, cand.size());
            if (pool == 0) return;
            List<JSONObject> top = new ArrayList<>(cand.subList(0, pool));
            Collections.shuffle(top, rng);
            int n = Math.min(pool, 1 + rng.nextInt(3));
            StringBuilder names = new StringBuilder();
            for (int i = 0; i < n; i++) {
                String nm = top.get(i).optString("name");
                callups.put(nm);
                if (i > 0) names.append(", ");
                names.append(nm);
            }
            addNews("🌍 INTERNATIONAL CALL-UPS: " + names
                    + " will tour with their national side this off-season — they return before Season "
                    + season + " starts, in form or fatigued…");
        } catch (Exception ignored) {}
    }

    public boolean isCalledUp(String name) {
        for (int i = 0; i < callups.length(); i++) if (name.equals(callups.optString(i))) return true;
        return false;
    }

    /** The returning internationals report back as the off-season closes
     *  (auction finished or skipped): 55% In Form (+10 morale, +6 Set),
     *  33% Fatigued (stamina 50–60), 12% Fatigued with a short knock.
     *  A man released mid-off-season simply never reports. Idempotent —
     *  the list is cleared as it resolves. */
    public void resolveCallups() {
        if (callups.length() == 0) return;
        try {
            for (int i = 0; i < callups.length(); i++) {
                String name = callups.optString(i);
                JSONObject p = playerByName(name);
                if (p == null) continue;
                double r = rng.nextDouble();
                if (r < 0.55) {
                    p.put("morale", clampMorale(p.optInt("morale", 70) + 10));
                    p.put("set", Math.min(99, p.optInt("set") + 6));
                    addNews("🌍 " + name + " returns from international duty IN FORM — morale and sharpness up for Season " + season + ".");
                } else if (r < 0.88) {
                    p.put("stam", 50 + rng.nextInt(11));
                    addNews("🌍 " + name + " returns from international duty FATIGUED — his tank starts Season " + season + " low.");
                } else {
                    p.put("stam", 55);
                    int days = 2 + rng.nextInt(3);
                    p.put("injured", days);
                    p.put("injType", "Knock (international duty)");
                    p.put("inXI", false);
                    addNews("🌍 Bad luck — " + name + " picked up a knock on international duty and misses the first "
                            + days + " days of Season " + season + ".");
                }
            }
        } catch (Exception ignored) {}
        callups = new JSONArray();
    }

    // ---- the One-Day Cup (idea 56) ----

    /** The cup exists from Season 2 onward. */
    public boolean cupEnabled() { return season >= 2; }

    private JSONObject addCupFixture(String stage, String home, String away) throws Exception {
        JSONObject f = new JSONObject();
        f.put("stage", stage);
        f.put("cup", true);
        f.put("day", 25 + cupFixtures.length());
        f.put("home", home);
        f.put("away", away);
        f.put("played", false);
        f.put("summary", "");
        f.put("winner", "");
        ensureFixtureMeta(f, season);
        cupFixtures.put(f);
        return f;
    }

    private List<JSONObject> cupStageList(String stage) {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < cupFixtures.length(); i++) {
            JSONObject f = cupFixtures.optJSONObject(i);
            if (f != null && stage.equals(f.optString("stage"))) out.add(f);
        }
        return out;
    }

    private static boolean allPlayed(List<JSONObject> fs) {
        for (JSONObject f : fs) if (!f.optBoolean("played")) return false;
        return !fs.isEmpty();
    }

    /** The next cup tie waiting for the manager (his club is in it). */
    public JSONObject pendingUserCup() {
        for (int i = 0; i < cupFixtures.length(); i++) {
            JSONObject f = cupFixtures.optJSONObject(i);
            if (f != null && !f.optBoolean("played") && involvesUser(f)) return f;
        }
        return null;
    }

    /** Group stage done, Season 2+: build the cross-group knockout bracket
     *  (A1 v B4, B2 v A3, B1 v A4, A2 v B3) and let it run. The cup sits in
     *  the calendar gap BEFORE the playoffs — no league day is touched. */
    public String beginCup() {
        try {
            cupPhase = 1;
            cupFixtures = new JSONArray();
            cupChampion = "";
            cupRunnerUp = "";
            List<String> A = sortedGroup(groupA()), B = sortedGroup(groupB());
            addCupFixture("Quarter-final", A.get(0), B.get(3));
            addCupFixture("Quarter-final", B.get(1), A.get(2));
            addCupFixture("Quarter-final", B.get(0), A.get(3));
            addCupFixture("Quarter-final", A.get(1), B.get(2));
            addNews("🏆 THE ONE-DAY CUP — Quarter-finals (50 overs a side): "
                    + A.get(0) + " v " + B.get(3) + " · " + B.get(1) + " v " + A.get(2) + " · "
                    + B.get(0) + " v " + A.get(3) + " · " + A.get(1) + " v " + B.get(2) + ".");
            progressCup();
            JSONObject pend = pendingUserCup();
            if (pend != null) {
                addNews("CUP TIE: " + userTeam + " face " + opponentOf(pend) + " in the One-Day Cup "
                        + pend.optString("stage") + " — play it from the Hub!");
                return "One-Day Cup! Your " + pend.optString("stage") + " vs " + opponentOf(pend)
                        + " is waiting on the Hub.";
            }
            if (cupPhase == 2) return "The One-Day Cup is done — " + cupChampion + " lift it!";
            return "The One-Day Cup is under way.";
        } catch (Exception e) {
            cupPhase = 2; // never trap the manager: wash the cup out, playoffs next
            return "The cup was washed out this year — the playoffs are next.";
        }
    }

    /** The cup bracket driver — mirrors progressPlayoffs: generates the
     *  next round as rounds complete, quick-sims ties that don't involve
     *  the user's club, and finalises when the Final is played. */
    public void progressCup() {
        if (cupPhase != 1) return;
        try {
            boolean moved = true;
            int guard = 0;
            while (moved && guard++ < 12 && cupPhase == 1) {
                moved = false;
                List<JSONObject> qf = cupStageList("Quarter-final");
                if (qf.size() == 4 && allPlayed(qf) && cupStageList("Semi-final").isEmpty()) {
                    addCupFixture("Semi-final", qf.get(0).optString("winner"), qf.get(1).optString("winner"));
                    addCupFixture("Semi-final", qf.get(2).optString("winner"), qf.get(3).optString("winner"));
                    moved = true;
                }
                List<JSONObject> sf = cupStageList("Semi-final");
                if (sf.size() == 2 && allPlayed(sf) && cupStageList("Final").isEmpty()) {
                    addCupFixture("Final", sf.get(0).optString("winner"), sf.get(1).optString("winner"));
                    moved = true;
                }
                for (int i = 0; i < cupFixtures.length(); i++) {
                    JSONObject f = cupFixtures.getJSONObject(i);
                    if (!f.optBoolean("played") && !involvesUser(f)) {
                        simCupFixture(f);
                        moved = true;
                    }
                }
                List<JSONObject> fin = cupStageList("Final");
                if (fin.size() == 1 && fin.get(0).optBoolean("played")) { finalizeCup(); return; }
            }
        } catch (Exception ignored) {}
    }

    /** Advance Day during cup week: a pending user tie is board-simmed,
     *  exactly like a skipped league/playoff fixture. Never a trap. */
    public String advanceCup() {
        JSONObject pend = pendingUserCup();
        if (pend != null) {
            simCupFixture(pend);
            addNews("The day passed — the board simmed your cup " + pend.optString("stage")
                    + ": " + pend.optString("summary") + ".");
        } else {
            progressCup();
        }
        if (cupPhase == 2) return "One-Day Cup complete — " + cupChampion + " are the champions! Playoffs next.";
        JSONObject next = pendingUserCup();
        if (next != null) {
            return "One-Day Cup: your " + next.optString("stage") + " vs " + opponentOf(next)
                    + " is waiting on the Hub.";
        }
        return "The One-Day Cup is moving on…";
    }

    /** Quick-sim a cup tie at 50-over scale. Like simPlayoffFixture it
     *  never touches the group tables; a cup tie always produces a winner
     *  (level scores go to the higher group seed). Standouts feed the
     *  watchlist and (for the user's club) the squad's season stats via
     *  the usual approximations — but NOT the T20 tournament book or the
     *  records book, which stay league-only. */
    public void simCupFixture(JSONObject f) {
        try {
            if (f == null || f.optBoolean("played")) return;
            String home = f.getString("home"), away = f.getString("away");
            int hs = simStrength(home), as = simStrength(away); // Batch I (idea 81)
            int r1 = clamp(215 + rng.nextInt(125) + (hs - 80) * 2, 175, 375);
            int w1 = r1 > 320 ? 4 + rng.nextInt(5) : 5 + rng.nextInt(6);
            if (w1 > 10) w1 = 10;
            int b1 = w1 == 10 ? 210 + rng.nextInt(85) : 300;
            double chaseChance = 0.46 + (as - hs) * 0.008;
            boolean awayWins = rng.nextDouble() < chaseChance;
            int r2, w2, b2;
            if (awayWins) {
                r2 = r1 + 1 + rng.nextInt(18);
                w2 = 3 + rng.nextInt(6);
                b2 = 230 + rng.nextInt(65);
            } else {
                r2 = Math.max(140, r1 - 1 - rng.nextInt(55));
                w2 = 6 + rng.nextInt(5);
                if (w2 > 10) w2 = 10;
                b2 = w2 == 10 ? 200 + rng.nextInt(90) : 300;
            }
            String winner = awayWins ? away : home;
            if (r1 == r2) winner = playoffSeedWinner(f); // a cup tie cannot be drawn
            String summary = f.optString("stage") + " (Cup): " + shortFor(home) + " " + r1 + "/" + w1
                    + " vs " + shortFor(away) + " " + r2 + "/" + w2 + " — " + winner + " won";
            List<String> hn = namesFor(home), an = namesFor(away);
            String topBat, bestBowl, topBatTeam, bestBowlTeam;
            int topRuns, bestWkts;
            if (rng.nextBoolean()) {
                topBat = hn.get(rng.nextInt(Math.min(6, hn.size()))); topBatTeam = home;
                bestBowl = an.get(5 + rng.nextInt(Math.max(1, an.size() - 5))); bestBowlTeam = away;
            } else {
                topBat = an.get(rng.nextInt(Math.min(6, an.size()))); topBatTeam = away;
                bestBowl = hn.get(5 + rng.nextInt(Math.max(1, hn.size() - 5))); bestBowlTeam = home;
            }
            topRuns = 45 + rng.nextInt(105); // 45..149 — one-day hundreds happen
            bestWkts = rng.nextInt(100) < 15 ? 5 + rng.nextInt(2) : 2 + rng.nextInt(4);
            f.put("topBat", topBat).put("topBatRuns", topRuns);
            f.put("bestBowl", bestBowl).put("bestBowlWkts", bestWkts);
            f.put("topBatTeam", topBatTeam).put("bestBowlTeam", bestBowlTeam);
            if (topRuns >= 50 || bestWkts < 4) { f.put("potm", topBat); f.put("potmDesc", topRuns + " runs"); }
            else { f.put("potm", bestBowl); f.put("potmDesc", bestWkts + " wickets"); }
            f.put("r1", r1).put("w1", w1).put("r2", r2).put("w2", w2); // Batch H
            f.put("played", true);
            f.put("summary", summary);
            f.put("winner", winner);
            if (topRuns >= 100) watchlistAlert(topBat, "scored " + topRuns + " (century!)", summary);
            if (bestWkts >= 5) watchlistAlert(bestBowl, "took " + bestWkts + " wickets (5-for!)", summary);
            if (involvesUser(f)) {
                boolean userWon = winner.equals(userTeam);
                StatsBook.recordAppearances(this);
                StatsBook.recordSimStandouts(this, f);
                updateH2h(opponentOf(f), userWon ? 1 : -1);
                onUserMatchFinished(userWon, summary, f);
            } else {
                rollAiInjury(home);
                rollAiInjury(away);
            }
            addNews("One-Day Cup — " + summary + ".");
            progressCup();
        } catch (Exception ignored) {}
    }

    /** Called by MatchEngine.finishMatch after a LIVE cup tie: the POTM is
     *  parked on the fixture (the Final's goes to the Hall of Fame entry),
     *  then the bracket moves on. */
    public void onCupMatchFinished(JSONObject f, JSONObject m) {
        try {
            if (f != null && m != null) {
                f.put("potm", m.optString("potm", ""));
                f.put("potmDesc", m.optString("potmDesc", ""));
            }
        } catch (Exception ignored) {}
        progressCup();
    }

    /** The Final is played: crown the cup champions, pay the prizes once,
     *  count the cup separately in the career record, file the HoF entry. */
    private void finalizeCup() {
        if (cupPhase != 1) return;
        try {
            List<JSONObject> fin = cupStageList("Final");
            if (fin.isEmpty()) return;
            JSONObject f = fin.get(0);
            cupChampion = f.optString("winner");
            cupRunnerUp = cupChampion.equals(f.optString("home")) ? f.optString("away") : f.optString("home");
            if (userTeam.equals(cupChampion)) {
                career.put("cups", career.optInt("cups") + 1);
                ledgerCf(prize(1000), "🏆 One-Day Cup winners — Season " + season); // Batch I (idea 81)
                unlockAchievement("CUPWINNER"); // Batch I (idea 85)
                // Batch G (ideas 67/69): a cup is board confidence + a trophy's XP
                adjustBoardConfidence(12);
                addManagerXp(100);
                JSONObject h = new JSONObject();
                h.put("kind", "cup").put("season", season).put("captain", captain)
                        .put("potm", f.optString("potm", ""))
                        .put("line", "Season " + season + " One-Day Cup winners — Final: " + f.optString("summary"));
                hof.put(h);
                addNews("🏆 ONE-DAY CUP CHAMPIONS! " + userTeam + " lift the 50-over cup — +" + prize(1000) + " CF prize!");
            } else if (userTeam.equals(cupRunnerUp)) {
                ledgerCf(prize(300), "One-Day Cup runners-up — Season " + season); // Batch I (idea 81)
                addNews("Cup final heartbreak — " + userTeam + " fall at the last hurdle. +" + prize(300) + " CF runners-up prize. "
                        + cupChampion + " take the cup.");
            } else {
                addNews("🏆 " + cupChampion + " win the One-Day Cup, beating " + cupRunnerUp + " in the Final.");
            }
            cupPhase = 2;
        } catch (Exception ignored) {}
    }

    // ---- crowds, derbies, grounds (ideas 57–59) ----

    /** Idea 58: a fixture is a DERBY when the opponent is the user's
     *  club's biggest rival (Data.rivalOf; a custom club inherits
     *  Lahore's rival, Karachi, through the slot it took). */
    public boolean isDerby(JSONObject f) {
        if (f == null || !involvesUser(f)) return false;
        return Data.rivalOf(userTeam).equals(opponentOf(f));
    }

    /** Idea 57: expected attendance % for a user fixture — Stadium level
     *  is the base, recent league form nudges it, a big opponent and a
     *  derby pack the ground, a cup tie adds a little. Clamped 15–97. */
    public int expectedAttendance(JSONObject f) {
        if (f == null) return 0;
        int att = 38 + 7 * facilityLevel(0);
        JSONObject row = tables.optJSONObject(userTeam);
        if (row != null && row.optInt("p") > 0) {
            double wp = row.optInt("w") * 1.0 / row.optInt("p");
            att += (int) Math.max(-8, Math.min(12, (wp - 0.5) * 30));
        }
        int os = strengthFor(opponentOf(f));
        if (os >= 84) att += 8;
        else if (os >= 82) att += 4;
        if (isDerby(f)) att += 18;
        if (f.optBoolean("cup")) att += 3;
        // Batch G: ticket pricing (idea 63) and Fan Mood (idea 70) move
        // the crowd before the clamp — dearer seats, emptier stands.
        att += ticketAttendanceShift();
        att += fanAttendanceShift();
        return Math.max(15, Math.min(97, att));
    }

    /** Gate receipts for a home match: attendance % of a capacity purse
     *  that grows with the Stadium level (150 + 90/level CF at a full
     *  house). This REPLACED the old flat 40 x level bonus in
     *  onUserMatchFinished — one consistent formula, always ledgered.
     *  Batch G: the ticket tier multiplier (idea 63) and the manager's
     *  L4 perk (+5%, idea 69) ride on top. */
    public int gateFor(JSONObject f, int att) {
        double gate = att / 100.0 * (150 + 90 * facilityLevel(0)) * ticketMultiplier();
        if (managerLevel >= 4) gate *= 1.05;
        return (int) Math.round(gate);
    }

    public String homeGroundName() {
        return Data.groundName(userTeam);
    }

    /** The user's home ground as it reads on cards: the Stadium facility
     *  level is the ground's upgrade state (idea 59). */
    public String homeGroundLine() {
        return homeGroundName() + " — Stadium Level " + facilityLevel(0)
                + " · " + Data.GROUND_CHARS[Data.groundChar(userTeam)] + " deck"
                + " · capacity grows with every upgrade";
    }

    // ---- rename a player (idea 60) ----

    /** Renames ANY squad player and migrates every name-keyed record:
     *  captain, watchlist, tournament-book key, scouting key, records
     *  book player fields, Hall of Fame name/captain/potm, parked
     *  legends, POTM-history prefixes, season-history scorer strings,
     *  lastAwards, call-ups, a live poach offer, and a live match's
     *  cards / fall-of-wickets / partnerships / match-ups / shield /
     *  per-batter plan. Season & career stats live ON the player object
     *  itself, so they follow the rename automatically. Returns a
     *  result line for the UI. */
    public String renamePlayer(String oldName, String newName) {
        newName = newName == null ? "" : newName.trim();
        if (newName.length() < 3 || newName.length() > 30) return "Names must be 3–30 characters.";
        JSONObject p = playerByName(oldName);
        if (p == null) return "Player not found.";
        if (oldName.equals(newName)) return "That is already his name.";
        if (playerByName(newName) != null) return "Another squad player already has that name.";
        try {
            p.put("name", newName);
            if (oldName.equals(captain)) captain = newName;
            for (int i = 0; i < watchlist.length(); i++) {
                if (oldName.equals(watchlist.optString(i))) watchlist.put(i, newName);
            }
            // tournament book: move the key (merge defensively if a
            // same-named entry somehow already exists)
            if (tournBook.has(oldName)) {
                JSONObject e = tournBook.getJSONObject(oldName);
                tournBook.remove(oldName);
                JSONObject ex = tournBook.optJSONObject(newName);
                if (ex == null) {
                    tournBook.put(newName, e);
                } else {
                    String[] nums = {"runs", "balls", "outs", "f50", "f100", "bwBalls", "wkts", "conc", "f3", "f5"};
                    for (String k : nums) ex.put(k, ex.optInt(k) + e.optInt(k));
                }
            }
            if (scouted.has(oldName)) {
                JSONObject r = scouted.getJSONObject(oldName);
                scouted.remove(oldName);
                scouted.put(newName, r);
            }
            java.util.Iterator<String> rk = records.keys();
            while (rk.hasNext()) {
                JSONObject r = records.optJSONObject(rk.next());
                if (r != null && oldName.equals(r.optString("player"))) r.put("player", newName);
            }
            for (int i = 0; i < hof.length(); i++) {
                JSONObject h = hof.optJSONObject(i);
                if (h == null) continue;
                if (oldName.equals(h.optString("name"))) h.put("name", newName);
                if (oldName.equals(h.optString("captain"))) h.put("captain", newName);
                if (oldName.equals(h.optString("potm"))) h.put("potm", newName);
            }
            for (int i = 0; i < pendingLegends.length(); i++) {
                JSONObject e = pendingLegends.optJSONObject(i);
                if (e != null && oldName.equals(e.optString("name"))) e.put("name", newName);
            }
            for (int i = 0; i < potmHistory.length(); i++) {
                String s = potmHistory.optString(i);
                if (s.startsWith(oldName + " —")) potmHistory.put(i, newName + s.substring(oldName.length()));
            }
            for (int i = 0; i < seasonHistory.length(); i++) {
                JSONObject e = seasonHistory.optJSONObject(i);
                if (e == null) continue;
                for (String k : new String[]{"topScorer", "topWkts"}) {
                    String s = e.optString(k, "");
                    if (s.startsWith(oldName + " (")) e.put(k, newName + s.substring(oldName.length()));
                }
            }
            java.util.Iterator<String> ak = lastAwards.keys();
            while (ak.hasNext()) {
                JSONObject a = lastAwards.optJSONObject(ak.next());
                if (a != null && oldName.equals(a.optString("name"))) a.put("name", newName);
            }
            for (int i = 0; i < callups.length(); i++) {
                if (oldName.equals(callups.optString(i))) callups.put(i, newName);
            }
            if (poachOffer != null && oldName.equals(poachOffer.optString("name"))) {
                poachOffer.put("name", newName);
            }
            if (match != null) renameInMatch(match, oldName, newName);
            return newName + " — renamed everywhere (squad, stats, records, watchlist).";
        } catch (Exception e) {
            return "Rename failed.";
        }
    }

    /** Name migration inside a live match object (idea 60): the innings
     *  cards, fall-of-wickets, partnership pair strings, match-up rows
     *  and the tactical name fields. Commentary text is history and is
     *  deliberately left as it was written. */
    private void renameInMatch(JSONObject m, String oldName, String newName) {
        try {
            String[] cardKeys = {"batCard", "bowlCard", "inn1BatCard", "inn1BowlCard", "inn2BatCard", "inn2BowlCard"};
            for (String k : cardKeys) {
                JSONArray card = m.optJSONArray(k);
                if (card == null) continue;
                for (int i = 0; i < card.length(); i++) {
                    JSONObject e = card.optJSONObject(i);
                    if (e != null && oldName.equals(e.optString("name"))) e.put("name", newName);
                }
            }
            String[] fowKeys = {"fow", "inn1Fow", "inn2Fow"};
            for (String k : fowKeys) {
                JSONArray arr = m.optJSONArray(k);
                if (arr == null) continue;
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject e = arr.optJSONObject(i);
                    if (e != null && oldName.equals(e.optString("name"))) e.put("name", newName);
                }
            }
            String[] partKeys = {"parts", "inn1Parts", "inn2Parts"};
            for (String k : partKeys) {
                JSONArray arr = m.optJSONArray(k);
                if (arr == null) continue;
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject e = arr.optJSONObject(i);
                    if (e != null) e.put("pair", e.optString("pair").replace(oldName, newName));
                }
            }
            String[] muKeys = {"matchups", "inn1Matchups"};
            for (String k : muKeys) {
                JSONArray arr = m.optJSONArray(k);
                if (arr == null) continue;
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject e = arr.optJSONObject(i);
                    if (e == null) continue;
                    if (oldName.equals(e.optString("bat"))) e.put("bat", newName);
                    if (oldName.equals(e.optString("bowl"))) e.put("bowl", newName);
                }
            }
            if (oldName.equals(m.optString("shield"))) m.put("shield", newName);
            if (oldName.equals(m.optString("batPlanFor"))) m.put("batPlanFor", newName);
            if (oldName.equals(m.optString("potm"))) m.put("potm", newName);
            if (oldName.equals(m.optString("prevBowler"))) m.put("prevBowler", newName);
        } catch (Exception ignored) {}
    }
}
