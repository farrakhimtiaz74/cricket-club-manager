package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Whole game state + season engine. Serialised as one JSON string in SharedPreferences. */
public class Game {
    public int season = 1;
    public int day = 1;
    public int cf = 1000;
    public JSONArray players = new JSONArray();   // name, role, bat, bowl, stam, set, inXI
    public JSONArray facilities = new JSONArray(); // 5 levels
    public JSONArray fixtures = new JSONArray();   // day, home, away, played, summary
    public JSONObject tables = new JSONObject();   // team -> p,w,l,pts,rf,bf,ra,ba (balls)
    public JSONObject career = new JSONObject();   // played,won,lost,streak,best,titles
    public JSONArray history = new JSONArray();    // user result strings
    public JSONArray news = new JSONArray();       // strings, newest first
    public JSONObject match = null;                // in-progress match (MatchEngine state)
    public int talkDay = -1;
    public Random rng = new Random();

    // ---------------- lifecycle ----------------

    public static Game fresh() {
        Game g = new Game();
        try {
            for (Object[] p : Data.SQUAD) {
                JSONObject o = new JSONObject();
                o.put("name", p[0]);
                o.put("role", p[1]);
                o.put("bat", p[2]);
                o.put("bowl", p[3]);
                o.put("stam", 88 + g.rng.nextInt(12));
                o.put("set", 55 + g.rng.nextInt(30));
                o.put("inXI", false);
                g.players.put(o);
            }
            // default XI: first 11 in squad order (has WK + 6 bowling options)
            for (int i = 0; i < 11; i++) g.players.getJSONObject(i).put("inXI", true);
            for (int i = 0; i < 5; i++) g.facilities.put(1);
            g.career.put("played", 0).put("won", 0).put("lost", 0)
                    .put("streak", 0).put("best", 0).put("titles", 0);
            g.resetSeasonTablesAndFixtures();
            g.addNews("Welcome to Lahore Qalandars! Season 1 begins. Pick your XI and play your first match.");
            g.addNews("Board: win matches to earn Club Cash (CF) and upgrade HQ facilities.");
        } catch (Exception ignored) {}
        return g;
    }

    public void resetSeasonTablesAndFixtures() {
        try {
            tables = new JSONObject();
            for (String t : Data.GROUP_A) tables.put(t, emptyRow());
            for (String t : Data.GROUP_B) tables.put(t, emptyRow());
            fixtures = new JSONArray();
            String[][] groups = {Data.GROUP_A, Data.GROUP_B};
            int[][] pairs = {{0, 1}, {2, 3}, {0, 2}, {1, 3}, {0, 3}, {1, 2}};
            int d = 1;
            // 6 rounds; in each round every group plays both pairings -> 4 fixtures per round
            for (int round = 0; round < 6; round++) {
                for (int gi = 0; gi < 2; gi++) {
                    for (int pi = 0; pi < 2; pi++) {
                        int[] pr = pairs[(round + pi * 3) % 6];
                        String home = groups[gi][pr[0]];
                        String away = groups[gi][pr[1]];
                        if (round >= 3) { String tmp = home; home = away; away = tmp; }
                        JSONObject f = new JSONObject();
                        f.put("day", d++);
                        f.put("home", home);
                        f.put("away", away);
                        f.put("played", false);
                        f.put("summary", "");
                        fixtures.put(f);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private JSONObject emptyRow() throws Exception {
        return new JSONObject().put("p", 0).put("w", 0).put("l", 0).put("pts", 0)
                .put("rf", 0).put("bf", 0).put("ra", 0).put("ba", 0);
    }

    // ---------------- persistence ----------------

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("season", season).put("day", day).put("cf", cf);
            o.put("players", players).put("facilities", facilities);
            o.put("fixtures", fixtures).put("tables", tables);
            o.put("career", career).put("history", history).put("news", news);
            o.put("talkDay", talkDay);
            if (match != null) o.put("match", match);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static Game fromJson(String s) {
        Game g = new Game();
        try {
            JSONObject o = new JSONObject(s);
            g.season = o.optInt("season", 1);
            g.day = o.optInt("day", 1);
            g.cf = o.optInt("cf", 1000);
            g.players = o.getJSONArray("players");
            g.facilities = o.getJSONArray("facilities");
            g.fixtures = o.getJSONArray("fixtures");
            g.tables = o.getJSONObject("tables");
            g.career = o.getJSONObject("career");
            g.history = o.optJSONArray("history");
            if (g.history == null) g.history = new JSONArray();
            g.news = o.optJSONArray("news");
            if (g.news == null) g.news = new JSONArray();
            g.talkDay = o.optInt("talkDay", -1);
            g.match = o.optJSONObject("match");
        } catch (Exception e) {
            return fresh();
        }
        return g;
    }

    // ---------------- helpers ----------------

    public void addNews(String s) {
        try {
            JSONArray n = new JSONArray();
            n.put(s);
            for (int i = 0; i < Math.min(news.length(), 11); i++) n.put(news.getString(i));
            news = n;
        } catch (Exception ignored) {}
    }

    public JSONObject player(int i) {
        try { return players.getJSONObject(i); } catch (Exception e) { return new JSONObject(); }
    }

    public int xiCount() {
        int n = 0;
        for (int i = 0; i < players.length(); i++) if (player(i).optBoolean("inXI")) n++;
        return n;
    }

    public List<JSONObject> xi() {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < players.length(); i++) if (player(i).optBoolean("inXI")) out.add(player(i));
        return out;
    }

    public int facilityLevel(int idx) {
        return facilities.optInt(idx, 1);
    }

    public double nrr(String team) {
        try {
            JSONObject r = tables.getJSONObject(team);
            double rf = r.optInt("rf"), bf = r.optInt("bf"), ra = r.optInt("ra"), ba = r.optInt("ba");
            if (bf == 0 || ba == 0) return 0;
            return rf / (bf / 6.0) - ra / (ba / 6.0);
        } catch (Exception e) { return 0; }
    }

    /** The user's unplayed fixture scheduled for today, or null. */
    public JSONObject todaysUserFixture() {
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (!f.optBoolean("played") && f.optInt("day") == day && involvesUser(f)) return f;
            } catch (Exception ignored) {}
        }
        return null;
    }

    /** Next unplayed user fixture (any day), or null. */
    public JSONObject nextUserFixture() {
        JSONObject best = null;
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (!f.optBoolean("played") && involvesUser(f)) {
                    if (best == null || f.optInt("day") < best.optInt("day")) best = f;
                }
            } catch (Exception ignored) {}
        }
        return best;
    }

    public static boolean involvesUser(JSONObject f) {
        return Data.USER_TEAM.equals(f.optString("home")) || Data.USER_TEAM.equals(f.optString("away"));
    }

    public String opponentOf(JSONObject f) {
        return Data.USER_TEAM.equals(f.optString("home")) ? f.optString("away") : f.optString("home");
    }

    // ---------------- calendar ----------------

    /** Advance one day. Returns a short event string for the Hub news/toast. */
    public String advanceDay() {
        // skipping past an unplayed user fixture: the board sims it without you
        JSONObject skipped = todaysUserFixture();
        if (skipped != null && match == null) {
            simFixture(skipped);
            addNews("You skipped match day — the board simmed " + skipped.optString("summary") + ".");
        }
        day++;
        // season over?
        if (day > 24) {
            return rolloverSeason();
        }
        // auto-sim other teams' fixtures up to (and including) today,
        // but never the user's fixture on its own day
        simOtherFixtures(day, true);
        // gentle daily stamina regen
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try { p.put("stam", Math.min(100, p.optInt("stam") + 2)); } catch (Exception ignored) {}
        }
        // Commercial Centre income every 3 days
        if (day % 3 == 0) {
            int income = 25 * facilityLevel(4);
            cf += income;
            addNews("Commercial Centre sponsors paid +" + income + " CF.");
        }
        JSONObject today = todaysUserFixture();
        if (today != null) {
            addNews("MATCH DAY: Lahore Qalandars vs " + opponentOf(today) + " — play it from the Hub!");
            return "Match day vs " + opponentOf(today);
        }
        return "Day " + day;
    }

    public void simOtherFixtures(int uptoDay, boolean includeToday) {
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (f.optBoolean("played")) continue;
                int fd = f.optInt("day");
                if (fd < uptoDay || (includeToday && fd == uptoDay)) {
                    if (!involvesUser(f)) simFixture(f);
                }
            } catch (Exception ignored) {}
        }
    }

    /** Quick-sim a fixture between any two teams and record it. */
    public void simFixture(JSONObject f) {
        try {
            String home = f.getString("home"), away = f.getString("away");
            int hs = Data.teamStrength(home), as = Data.teamStrength(away);
            // innings 1 (home bats first)
            int r1 = clamp(115 + rng.nextInt(105) + (hs - 80), 95, 235);
            int w1 = r1 > 205 ? 4 + rng.nextInt(5) : 5 + rng.nextInt(6);
            if (w1 > 10) w1 = 10;
            int b1 = w1 == 10 ? 96 + rng.nextInt(24) : 120;
            // chase
            double chaseChance = 0.46 + (as - hs) * 0.008;
            boolean awayWins = rng.nextDouble() < chaseChance;
            int r2, w2, b2;
            if (awayWins) {
                r2 = r1 + 1 + rng.nextInt(12);
                w2 = 3 + rng.nextInt(6);
                b2 = 96 + rng.nextInt(23);
            } else {
                r2 = Math.max(70, r1 - 1 - rng.nextInt(38));
                w2 = 6 + rng.nextInt(5);
                if (w2 > 10) w2 = 10;
                b2 = w2 == 10 ? 90 + rng.nextInt(30) : 120;
            }
            applyResult(home, away, r1, b1, w1, r2, b2, w2);
            String summary = Data.shortName(home) + " " + r1 + "/" + w1 + " vs " +
                    Data.shortName(away) + " " + r2 + "/" + w2 + " — " +
                    (awayWins ? away : home) + " won";
            f.put("played", true);
            f.put("summary", summary);
            if (involvesUser(f)) {
                boolean userWon = (Data.USER_TEAM.equals(home) && !awayWins) ||
                        (Data.USER_TEAM.equals(away) && awayWins);
                onUserMatchFinished(userWon, summary, f);
            }
        } catch (Exception ignored) {}
    }

    /** Record a completed match in the tables. Balls stored raw; all-out counts as 120 for NRR. */
    public void applyResult(String home, String away, int r1, int b1, int w1, int r2, int b2, int w2) {
        try {
            JSONObject H = tables.getJSONObject(home), A = tables.getJSONObject(away);
            H.put("p", H.optInt("p") + 1);
            A.put("p", A.optInt("p") + 1);
            int eb1 = w1 == 10 ? 120 : b1;
            int eb2 = w2 == 10 ? 120 : b2;
            H.put("rf", H.optInt("rf") + r1).put("bf", H.optInt("bf") + eb1)
             .put("ra", H.optInt("ra") + r2).put("ba", H.optInt("ba") + eb2);
            A.put("rf", A.optInt("rf") + r2).put("bf", A.optInt("bf") + eb2)
             .put("ra", A.optInt("ra") + r1).put("ba", A.optInt("ba") + eb1);
            if (r1 > r2) {
                H.put("w", H.optInt("w") + 1).put("pts", H.optInt("pts") + 2);
                A.put("l", A.optInt("l") + 1);
            } else if (r2 > r1) {
                A.put("w", A.optInt("w") + 1).put("pts", A.optInt("pts") + 2);
                H.put("l", H.optInt("l") + 1);
            } else {
                H.put("pts", H.optInt("pts") + 1);
                A.put("pts", A.optInt("pts") + 1);
            }
        } catch (Exception ignored) {}
    }

    /** Shared bookkeeping after ANY user match (played live or simmed). */
    public void onUserMatchFinished(boolean userWon, String summary, JSONObject fixture) {
        try {
            career.put("played", career.optInt("played") + 1);
            boolean homeGame = fixture != null && Data.USER_TEAM.equals(fixture.optString("home"));
            int stadiumBonus = homeGame ? 40 * facilityLevel(0) : 0;
            if (userWon) {
                career.put("won", career.optInt("won") + 1);
                int streak = career.optInt("streak") + 1;
                career.put("streak", streak);
                if (streak > career.optInt("best")) career.put("best", streak);
                cf += 300 + stadiumBonus;
                addNews("WIN! +" + (300 + stadiumBonus) + " CF prize. " + summary);
            } else {
                career.put("lost", career.optInt("lost") + 1);
                career.put("streak", 0);
                cf += 120 + stadiumBonus;
                addNews("Defeat. +" + (120 + stadiumBonus) + " CF appearance fee. " + summary);
            }
            // history (newest first, cap 20)
            JSONArray h = new JSONArray();
            h.put((userWon ? "W — " : "L — ") + summary);
            for (int i = 0; i < Math.min(history.length(), 19); i++) h.put(history.getString(i));
            history = h;
            // fatigue + morale for the XI
            for (JSONObject p : xi()) {
                p.put("stam", Math.max(20, p.optInt("stam") - 12));
                int set = p.optInt("set") + (userWon ? 5 : -5);
                p.put("set", Math.max(25, Math.min(99, set)));
            }
        } catch (Exception ignored) {}
    }

    public String rolloverSeason() {
        String champion = null;
        int bestPts = -1;
        double bestNrr = -999;
        String[] all = {"Lahore Qalandars", "Karachi Kings", "Multan Sultans", "Islamabad United",
                "Peshawar Zalmi", "Quetta Gladiators", "Sialkot Stallions", "Hyderabad Hawks"};
        try {
            for (String t : all) {
                JSONObject r = tables.getJSONObject(t);
                int pts = r.optInt("pts");
                double n = nrr(t);
                if (pts > bestPts || (pts == bestPts && n > bestNrr)) {
                    bestPts = pts; bestNrr = n; champion = t;
                }
            }
            if (Data.USER_TEAM.equals(champion)) {
                career.put("titles", career.optInt("titles") + 1);
                cf += 1500;
                addNews("CHAMPIONS! Lahore Qalandars win Season " + season + "! +1500 CF title prize.");
            } else {
                addNews("Season " + season + " champions: " + champion + ". Lahore go again next season.");
            }
            JSONArray h = new JSONArray();
            h.put("Season " + season + " champion: " + champion);
            for (int i = 0; i < Math.min(history.length(), 19); i++) h.put(history.getString(i));
            history = h;
            // academy prospect (level 2+)
            if (facilityLevel(3) >= 2) {
                int worstIdx = -1, worstRat = 999;
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    if (!p.optBoolean("inXI")) {
                        int rat = rating(p);
                        if (rat < worstRat) { worstRat = rat; worstIdx = i; }
                    }
                }
                if (worstIdx >= 0) {
                    String name = Data.PROSPECTS[rng.nextInt(Data.PROSPECTS.length)];
                    JSONObject p = player(worstIdx);
                    p.put("name", name);
                    p.put("role", rng.nextBoolean() ? "AR" : "Bat");
                    p.put("bat", 66 + rng.nextInt(11));
                    p.put("bowl", 45 + rng.nextInt(30));
                    p.put("stam", 95);
                    p.put("set", 70);
                    addNews("Youth Academy prospect " + name + " joins the squad for Season " + (season + 1) + "!");
                }
            }
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                p.put("stam", 88 + rng.nextInt(12));
            }
        } catch (Exception ignored) {}
        season++;
        day = 1;
        match = null;
        resetSeasonTablesAndFixtures();
        addNews("Season " + season + " is here. Fixtures are out — good luck, manager!");
        return "Season " + season + " begins";
    }

    // ---------------- Hub actions ----------------

    public int recovery() {
        int gain = 10 + 5 * facilityLevel(1); // Medical Centre scales recovery
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try { p.put("stam", Math.min(100, p.optInt("stam") + gain)); } catch (Exception ignored) {}
        }
        return gain;
    }

    public boolean teamTalk() {
        if (talkDay == day) return false;
        talkDay = day;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try {
                int set = Math.min(99, p.optInt("set") + 8);
                p.put("set", set);
            } catch (Exception ignored) {}
        }
        addNews("Team Talk done — squad Set % boosted for today.");
        return true;
    }

    public boolean upgradeFacility(int idx) {
        int lvl = facilityLevel(idx);
        if (lvl >= Data.FACILITY_MAX) return false;
        int cost = Data.FACILITY_BASE_COST[idx] * lvl;
        if (cf < cost) return false;
        cf -= cost;
        try {
            facilities.put(idx, lvl + 1);
            if (idx == 2) { // Training Complex: immediate small squad rating boost
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    p.put("bat", Math.min(99, p.optInt("bat") + 1));
                    p.put("bowl", Math.min(99, p.optInt("bowl") + 1));
                }
            }
            addNews(Data.FACILITY_NAMES[idx] + " upgraded to Level " + (lvl + 1) + "!");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static int rating(JSONObject p) {
        String role = p.optString("role");
        int bat = p.optInt("bat"), bowl = p.optInt("bowl");
        switch (role) {
            case "Bat": return (int) (bat * 0.85 + bowl * 0.15);
            case "Bowl": return (int) (bowl * 0.85 + bat * 0.15);
            case "WK": return (int) (bat * 0.9 + bowl * 0.1) + 2;
            default: return (bat + bowl) / 2 + 3; // AR
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
