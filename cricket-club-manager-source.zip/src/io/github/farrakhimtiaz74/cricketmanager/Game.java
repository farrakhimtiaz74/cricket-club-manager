package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Whole game state + season engine. Serialised as one JSON string in SharedPreferences.
 *  v2 additions: overseas flags, rested players, team-sheet validator, watchlist,
 *  and a Club Cash ledger — EVERY CF movement goes through ledgerCf() so the
 *  ledger entries always sum to the balance change. */
public class Game {
    public int season = 1;
    public int day = 1;
    public int cf = 1000;
    public JSONArray players = new JSONArray();   // name, role, bat, bowl, stam, set, inXI, overseas, rested
    public JSONArray facilities = new JSONArray(); // 5 levels
    public JSONArray fixtures = new JSONArray();   // day, home, away, played, summary (+ top performers)
    public JSONObject tables = new JSONObject();   // team -> p,w,l,pts,rf,bf,ra,ba (balls)
    public JSONObject career = new JSONObject();   // played,won,lost,streak,best,titles
    public JSONArray history = new JSONArray();    // user result strings
    public JSONArray news = new JSONArray();       // strings, newest first (watchlist alerts land here)
    public JSONArray watchlist = new JSONArray();  // player names (strings), v2
    public JSONArray ledger = new JSONArray();     // {season, day, amt, reason}, newest first, v2
    public JSONObject match = null;                // in-progress match (MatchEngine state)
    public int talkDay = -1;
    public Random rng = new Random();

    public static final int TRAVEL_COST = 50;
    public static final int PRESEASON_CHARGE = 200;
    public static final int RESTED_REGEN = 12;
    public static final int BREAK_REGEN = 6;

    // ---------------- lifecycle ----------------

    public static Game fresh() {
        Game g = new Game();
        try {
            for (Object[] p : Data.SQUAD) {
                JSONObject o = new JSONObject();
                o.put("name", p[0]);
                o.put("role", p[1]);
                o.put("bat", p[2]);
                o.put("bowl", p[3]);
                o.put("stam", 88 + g.rng.nextInt(12));
                o.put("set", 55 + g.rng.nextInt(30));
                o.put("overseas", (Boolean) p[4]);
                o.put("rested", false);
                o.put("inXI", Data.inDefaultXI((String) p[0]));
                g.players.put(o);
            }
            for (int i = 0; i < 5; i++) g.facilities.put(1);
            g.career.put("played", 0).put("won", 0).put("lost", 0)
                    .put("streak", 0).put("best", 0).put("titles", 0);
            g.resetSeasonTablesAndFixtures();
            g.pushLedger(g.cf, "Opening balance");
            g.addNews("Welcome to Lahore Qalandars! Season 1 begins. Pick your XI and play your first match.");
            g.addNews("Board: win matches to earn Club Cash (CF) and upgrade HQ facilities.");
        } catch (Exception ignored) {}
        return g;
    }

    public void resetSeasonTablesAndFixtures() {
        try {
            tables = new JSONObject();
            for (String t : Data.GROUP_A) tables.put(t, emptyRow());
            for (String t : Data.GROUP_B) tables.put(t, emptyRow());
            fixtures = new JSONArray();
            String[][] groups = {Data.GROUP_A, Data.GROUP_B};
            int[][] pairs = {{0, 1}, {2, 3}, {0, 2}, {1, 3}, {0, 3}, {1, 2}};
            int d = 1;
            // 6 rounds; in each round every group plays both pairings -> 4 fixtures per round.
            // Home/away alternates by round, so Lahore has real away fixtures (incl. an early one)
            // from round 0: day 1 home vs Karachi, day 2 AWAY at Islamabad.
            for (int round = 0; round < 6; round++) {
                for (int gi = 0; gi < 2; gi++) {
                    for (int pi = 0; pi < 2; pi++) {
                        int[] pr = pairs[(round + pi * 3) % 6];
                        String home = groups[gi][pr[0]];
                        String away = groups[gi][pr[1]];
                        if (round >= 3) { String tmp = home; home = away; away = tmp; }
                        JSONObject f = new JSONObject();
                        f.put("day", d++);
                        f.put("home", home);
                        f.put("away", away);
                        f.put("played", false);
                        f.put("summary", "");
                        fixtures.put(f);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private JSONObject emptyRow() throws Exception {
        return new JSONObject().put("p", 0).put("w", 0).put("l", 0).put("pts", 0)
                .put("rf", 0).put("bf", 0).put("ra", 0).put("ba", 0);
    }

    // ---------------- Club Cash ledger (v2) ----------------

    /** Records an entry WITHOUT changing the balance (used for the opening balance). */
    public void pushLedger(int amt, String reason) {
        try {
            JSONArray n = new JSONArray();
            JSONObject e = new JSONObject();
            e.put("season", season).put("day", day).put("amt", amt).put("reason", reason);
            n.put(e);
            for (int i = 0; i < Math.min(ledger.length(), 79); i++) n.put(ledger.getJSONObject(i));
            ledger = n;
        } catch (Exception ignored) {}
    }

    /** The ONLY way CF moves: changes the balance and writes the ledger entry together. */
    public void ledgerCf(int amt, String reason) {
        cf += amt;
        pushLedger(amt, reason);
    }

    /** Mandatory expense (travel / pre-season): charges up to the amount, never below zero,
     *  and ledgers the amount actually charged. Returns the amount charged (>= 0). */
    public int ledgerExpense(int amount, String reason) {
        int actual = Math.min(amount, Math.max(0, cf));
        if (actual > 0) ledgerCf(-actual, reason);
        return actual;
    }

    public int ledgerSum() {
        int s = 0;
        for (int i = 0; i < ledger.length(); i++) {
            try { s += ledger.getJSONObject(i).optInt("amt"); } catch (Exception ignored) {}
        }
        return s;
    }

    // ---------------- persistence + v1 -> v2 migration ----------------

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("season", season).put("day", day).put("cf", cf);
            o.put("players", players).put("facilities", facilities);
            o.put("fixtures", fixtures).put("tables", tables);
            o.put("career", career).put("history", history).put("news", news);
            o.put("watchlist", watchlist).put("ledger", ledger);
            o.put("talkDay", talkDay);
            if (match != null) o.put("match", match);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static Game fromJson(String s) {
        Game g = new Game();
        try {
            JSONObject o = new JSONObject(s);
            g.season = o.optInt("season", 1);
            g.day = o.optInt("day", 1);
            g.cf = o.optInt("cf", 1000);
            g.players = o.getJSONArray("players");
            g.facilities = o.getJSONArray("facilities");
            g.fixtures = o.getJSONArray("fixtures");
            g.tables = o.getJSONObject("tables");
            g.career = o.getJSONObject("career");
            g.history = o.optJSONArray("history");
            if (g.history == null) g.history = new JSONArray();
            g.news = o.optJSONArray("news");
            if (g.news == null) g.news = new JSONArray();
            g.talkDay = o.optInt("talkDay", -1);
            g.match = o.optJSONObject("match");
            // ---- v2 migration: auto-fill every new field with a safe default.
            // A v1 career loads intact: nothing is wiped, nothing crashes. ----
            for (int i = 0; i < g.players.length(); i++) {
                JSONObject p = g.players.getJSONObject(i);
                if (!p.has("overseas")) p.put("overseas", Data.overseasFor(p.optString("name")));
                if (!p.has("rested")) p.put("rested", false);
            }
            g.watchlist = o.optJSONArray("watchlist");
            if (g.watchlist == null) g.watchlist = new JSONArray();
            g.ledger = o.optJSONArray("ledger");
            if (g.ledger == null) {
                g.ledger = new JSONArray();
                g.pushLedger(g.cf, "Opening balance (carried from v1 save)");
            }
            if (g.match != null) {
                if (!g.match.has("field")) g.match.put("field", 1);       // Balanced
                if (!g.match.has("shield")) g.match.put("shield", "");
            }
        } catch (Exception e) {
            return fresh();
        }
        return g;
    }

    // ---------------- helpers ----------------

    public void addNews(String s) {
        try {
            JSONArray n = new JSONArray();
            n.put(s);
            for (int i = 0; i < Math.min(news.length(), 14); i++) n.put(news.getString(i));
            news = n;
        } catch (Exception ignored) {}
    }

    public JSONObject player(int i) {
        try { return players.getJSONObject(i); } catch (Exception e) { return new JSONObject(); }
    }

    public int xiCount() {
        int n = 0;
        for (int i = 0; i < players.length(); i++) if (player(i).optBoolean("inXI")) n++;
        return n;
    }

    public List<JSONObject> xi() {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < players.length(); i++) if (player(i).optBoolean("inXI")) out.add(player(i));
        return out;
    }

    public int facilityLevel(int idx) {
        return facilities.optInt(idx, 1);
    }

    public double nrr(String team) {
        try {
            JSONObject r = tables.getJSONObject(team);
            double rf = r.optInt("rf"), bf = r.optInt("bf"), ra = r.optInt("ra"), ba = r.optInt("ba");
            if (bf == 0 || ba == 0) return 0;
            return rf / (bf / 6.0) - ra / (ba / 6.0);
        } catch (Exception e) { return 0; }
    }

    /** The user's unplayed fixture scheduled for today, or null. */
    public JSONObject todaysUserFixture() {
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (!f.optBoolean("played") && f.optInt("day") == day && involvesUser(f)) return f;
            } catch (Exception ignored) {}
        }
        return null;
    }

    /** Next unplayed user fixture (any day), or null. */
    public JSONObject nextUserFixture() {
        JSONObject best = null;
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (!f.optBoolean("played") && involvesUser(f)) {
                    if (best == null || f.optInt("day") < best.optInt("day")) best = f;
                }
            } catch (Exception ignored) {}
        }
        return best;
    }

    public static boolean involvesUser(JSONObject f) {
        return Data.USER_TEAM.equals(f.optString("home")) || Data.USER_TEAM.equals(f.optString("away"));
    }

    public String opponentOf(JSONObject f) {
        return Data.USER_TEAM.equals(f.optString("home")) ? f.optString("away") : f.optString("home");
    }

    // ---------------- team-sheet validator (v2) ----------------

    /** Bowling option = a selected player with bowling rating 60+. */
    public static final int BOWL_OPTION_MIN = 60;
    public static final int MIN_BOWL_OPTIONS = 5;
    public static final int MAX_OVERSEAS = 4;

    /** Every problem with the current XI, in plain words. Empty list = legal team sheet. */
    public List<String> xiProblems() {
        List<String> out = new ArrayList<>();
        try {
            int count = 0, overseas = 0, bowlOpts = 0;
            boolean hasWK = false;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                if (!p.optBoolean("inXI")) continue;
                count++;
                if (p.optBoolean("overseas")) overseas++;
                if ("WK".equals(p.optString("role"))) hasWK = true;
                if (p.optInt("bowl") >= BOWL_OPTION_MIN) bowlOpts++;
                if (p.optBoolean("rested")) out.add(p.optString("name") + " is RESTED — un-rest him or remove him from the XI.");
            }
            if (count != 11) out.add(0, "XI has " + count + "/11 players — select exactly 11.");
            if (!hasWK) out.add("No wicketkeeper (WK) in the XI — pick a WK.");
            if (bowlOpts < MIN_BOWL_OPTIONS) out.add("Only " + bowlOpts + " bowling options (bowl " + BOWL_OPTION_MIN + "+) — need at least " + MIN_BOWL_OPTIONS + ".");
            if (overseas > MAX_OVERSEAS) out.add(overseas + " overseas players in the XI — the limit is " + MAX_OVERSEAS + ".");
        } catch (Exception ignored) {}
        return out;
    }

    public boolean xiLegal() {
        return xiProblems().isEmpty();
    }

    public int xiOverseasCount() {
        int n = 0;
        for (JSONObject p : xi()) if (p.optBoolean("overseas")) n++;
        return n;
    }

    // ---------------- rested system (v2) ----------------

    /** Rest / un-rest a player. Resting removes him from the XI immediately
     *  (the batting order is just the XI list, so it compacts on its own). */
    public void setRested(JSONObject p, boolean rested) {
        try {
            p.put("rested", rested);
            if (rested) p.put("inXI", false);
        } catch (Exception ignored) {}
    }

    // ---------------- watchlist (v2) ----------------

    public boolean isWatched(String name) {
        for (int i = 0; i < watchlist.length(); i++) if (name.equals(watchlist.optString(i))) return true;
        return false;
    }

    public void toggleWatch(String name) {
        try {
            JSONArray n = new JSONArray();
            boolean removed = false;
            for (int i = 0; i < watchlist.length(); i++) {
                String w = watchlist.getString(i);
                if (w.equals(name)) { removed = true; continue; }
                n.put(w);
            }
            if (!removed) n.put(name);
            watchlist = n;
        } catch (Exception ignored) {}
    }

    /** Inbox alert if a watchlisted player produced a headline feat. */
    public void watchlistAlert(String name, String feat, String matchSummary) {
        if (name == null || name.isEmpty() || !isWatched(name)) return;
        addNews("★ WATCHLIST: " + name + " — " + feat + " (" + matchSummary + ")");
    }

    /** Scan a finished innings' cards for watchlist centuries / 5-wicket hauls. */
    public void watchlistCheckCards(JSONArray batCard, JSONArray bowlCard, String matchSummary) {
        try {
            if (batCard != null) for (int i = 0; i < batCard.length(); i++) {
                JSONObject b = batCard.getJSONObject(i);
                if (b.optInt("runs") >= 100)
                    watchlistAlert(b.optString("name"), "scored " + b.optInt("runs") + " (century!)", matchSummary);
            }
            if (bowlCard != null) for (int i = 0; i < bowlCard.length(); i++) {
                JSONObject b = bowlCard.getJSONObject(i);
                if (b.optInt("wkts") >= 5)
                    watchlistAlert(b.optString("name"), "took " + b.optInt("wkts") + " wickets (5-for!)", matchSummary);
            }
        } catch (Exception ignored) {}
    }

    // ---------------- calendar ----------------

    /** Advance one day. Returns a short event string for the Hub news/toast. */
    public String advanceDay() {
        // skipping past an unplayed user fixture: the board sims it without you
        JSONObject skipped = todaysUserFixture();
        if (skipped != null && match == null) {
            simFixture(skipped);
            addNews("You skipped match day — the board simmed " + skipped.optString("summary") + ".");
        }
        day++;
        // season over?
        if (day > 24) {
            return rolloverSeason();
        }
        // auto-sim other teams' fixtures up to (and including) today,
        // but never the user's fixture on its own day
        simOtherFixtures(day, true);
        // daily stamina regen: rested players recover properly (+12), everyone else +2
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try {
                int gain = p.optBoolean("rested") ? RESTED_REGEN : 2;
                p.put("stam", Math.min(100, p.optInt("stam") + gain));
            } catch (Exception ignored) {}
        }
        // Commercial Centre income every 3 days (ledgered, v2)
        if (day % 3 == 0) {
            int income = 25 * facilityLevel(4);
            ledgerCf(income, "Commercial Centre sponsor income");
            addNews("Commercial Centre sponsors paid +" + income + " CF.");
        }
        JSONObject today = todaysUserFixture();
        if (today != null) {
            addNews("MATCH DAY: Lahore Qalandars vs " + opponentOf(today) + " — play it from the Hub!");
            return "Match day vs " + opponentOf(today);
        }
        return "Day " + day;
    }

    public void simOtherFixtures(int uptoDay, boolean includeToday) {
        for (int i = 0; i < fixtures.length(); i++) {
            try {
                JSONObject f = fixtures.getJSONObject(i);
                if (f.optBoolean("played")) continue;
                int fd = f.optInt("day");
                if (fd < uptoDay || (includeToday && fd == uptoDay)) {
                    if (!involvesUser(f)) simFixture(f);
                }
            } catch (Exception ignored) {}
        }
    }

    private List<String> namesFor(String team) {
        List<String> names = new ArrayList<>();
        if (Data.USER_TEAM.equals(team)) {
            List<JSONObject> xi = xi();
            if (xi.size() >= 2) {
                for (JSONObject p : xi) names.add(p.optString("name"));
            } else {
                for (int i = 0; i < Math.min(11, players.length()); i++) names.add(player(i).optString("name"));
            }
        } else {
            for (Object[] p : Data.xiFor(team)) names.add((String) p[0]);
        }
        return names;
    }

    /** Quick-sim a fixture between any two teams and record it.
     *  v2: also generates top-scorer / best-bowler figures so watchlist
     *  centuries and 5-fors can be spotted in auto-simmed fixtures too. */
    public void simFixture(JSONObject f) {
        try {
            String home = f.getString("home"), away = f.getString("away");
            int hs = Data.teamStrength(home), as = Data.teamStrength(away);
            // innings 1 (home bats first)
            int r1 = clamp(115 + rng.nextInt(105) + (hs - 80), 95, 235);
            int w1 = r1 > 205 ? 4 + rng.nextInt(5) : 5 + rng.nextInt(6);
            if (w1 > 10) w1 = 10;
            int b1 = w1 == 10 ? 96 + rng.nextInt(24) : 120;
            // chase
            double chaseChance = 0.46 + (as - hs) * 0.008;
            boolean awayWins = rng.nextDouble() < chaseChance;
            int r2, w2, b2;
            if (awayWins) {
                r2 = r1 + 1 + rng.nextInt(12);
                w2 = 3 + rng.nextInt(6);
                b2 = 96 + rng.nextInt(23);
            } else {
                r2 = Math.max(70, r1 - 1 - rng.nextInt(38));
                w2 = 6 + rng.nextInt(5);
                if (w2 > 10) w2 = 10;
                b2 = w2 == 10 ? 90 + rng.nextInt(30) : 120;
            }
            applyResult(home, away, r1, b1, w1, r2, b2, w2);
            String summary = Data.shortName(home) + " " + r1 + "/" + w1 + " vs " +
                    Data.shortName(away) + " " + r2 + "/" + w2 + " — " +
                    (awayWins ? away : home) + " won";
            // lightweight standout performers for the fixture (v2)
            List<String> hn = namesFor(home), an = namesFor(away);
            String topBat, bestBowl;
            int topRuns, bestWkts;
            if (rng.nextBoolean()) {
                topBat = hn.get(rng.nextInt(Math.min(6, hn.size())));
                bestBowl = an.get(5 + rng.nextInt(Math.max(1, an.size() - 5)));
            } else {
                topBat = an.get(rng.nextInt(Math.min(6, an.size())));
                bestBowl = hn.get(5 + rng.nextInt(Math.max(1, hn.size() - 5)));
            }
            topRuns = 38 + rng.nextInt(92);                       // 38..129 — centuries possible
            bestWkts = rng.nextInt(100) < 12 ? 5 + rng.nextInt(2) // ~12%: a 5-for day
                    : 1 + rng.nextInt(4);
            f.put("topBat", topBat).put("topBatRuns", topRuns);
            f.put("bestBowl", bestBowl).put("bestBowlWkts", bestWkts);
            f.put("played", true);
            f.put("summary", summary);
            if (topRuns >= 100) watchlistAlert(topBat, "scored " + topRuns + " (century!)", summary);
            if (bestWkts >= 5) watchlistAlert(bestBowl, "took " + bestWkts + " wickets (5-for!)", summary);
            if (involvesUser(f)) {
                boolean userWon = (Data.USER_TEAM.equals(home) && !awayWins) ||
                        (Data.USER_TEAM.equals(away) && awayWins);
                onUserMatchFinished(userWon, summary, f);
            }
        } catch (Exception ignored) {}
    }

    /** Record a completed match in the tables. Balls stored raw; all-out counts as 120 for NRR. */
    public void applyResult(String home, String away, int r1, int b1, int w1, int r2, int b2, int w2) {
        try {
            JSONObject H = tables.getJSONObject(home), A = tables.getJSONObject(away);
            H.put("p", H.optInt("p") + 1);
            A.put("p", A.optInt("p") + 1);
            int eb1 = w1 == 10 ? 120 : b1;
            int eb2 = w2 == 10 ? 120 : b2;
            H.put("rf", H.optInt("rf") + r1).put("bf", H.optInt("bf") + eb1)
             .put("ra", H.optInt("ra") + r2).put("ba", H.optInt("ba") + eb2);
            A.put("rf", A.optInt("rf") + r2).put("bf", A.optInt("bf") + eb2)
             .put("ra", A.optInt("ra") + r1).put("ba", A.optInt("ba") + eb1);
            if (r1 > r2) {
                H.put("w", H.optInt("w") + 1).put("pts", H.optInt("pts") + 2);
                A.put("l", A.optInt("l") + 1);
            } else if (r2 > r1) {
                A.put("w", A.optInt("w") + 1).put("pts", A.optInt("pts") + 2);
                H.put("l", A.optInt("l") + 1);
            } else {
                H.put("pts", H.optInt("pts") + 1);
                A.put("pts", A.optInt("pts") + 1);
            }
        } catch (Exception ignored) {}
    }

    /** Shared bookkeeping after ANY user match (played live or simmed). All CF is ledgered. */
    public void onUserMatchFinished(boolean userWon, String summary, JSONObject fixture) {
        try {
            career.put("played", career.optInt("played") + 1);
            boolean homeGame = fixture != null && Data.USER_TEAM.equals(fixture.optString("home"));
            int stadiumBonus = homeGame ? 40 * facilityLevel(0) : 0;
            if (userWon) {
                career.put("won", career.optInt("won") + 1);
                int streak = career.optInt("streak") + 1;
                career.put("streak", streak);
                if (streak > career.optInt("best")) career.put("best", streak);
                ledgerCf(300, "Match prize — win vs " + (fixture != null ? opponentOf(fixture) : "opposition"));
                if (stadiumBonus > 0) ledgerCf(stadiumBonus, "Stadium gate income (home match)");
                addNews("WIN! +300 CF prize" + (stadiumBonus > 0 ? " (+" + stadiumBonus + " gate)" : "") + ". " + summary);
            } else {
                career.put("lost", career.optInt("lost") + 1);
                career.put("streak", 0);
                ledgerCf(120, "Appearance fee — vs " + (fixture != null ? opponentOf(fixture) : "opposition"));
                if (stadiumBonus > 0) ledgerCf(stadiumBonus, "Stadium gate income (home match)");
                addNews("Defeat. +120 CF appearance fee" + (stadiumBonus > 0 ? " (+" + stadiumBonus + " gate)" : "") + ". " + summary);
            }
            if (!homeGame && fixture != null) { // away travel, charged once per away fixture (v2)
                int charged = ledgerExpense(TRAVEL_COST, "Away travel — at " + opponentOf(fixture));
                if (charged > 0) addNews("Away travel cost −" + charged + " CF.");
            }
            // history (newest first, cap 20)
            JSONArray h = new JSONArray();
            h.put((userWon ? "W — " : "L — ") + summary);
            for (int i = 0; i < Math.min(history.length(), 19); i++) h.put(history.getString(i));
            history = h;
            // fatigue + morale for the XI
            for (JSONObject p : xi()) {
                p.put("stam", Math.max(20, p.optInt("stam") - 12));
                int set = p.optInt("set") + (userWon ? 5 : -5);
                p.put("set", Math.max(25, Math.min(99, set)));
            }
        } catch (Exception ignored) {}
    }

    public String rolloverSeason() {
        String champion = null;
        int bestPts = -1;
        double bestNrr = -999;
        String[] all = {"Lahore Qalandars", "Karachi Kings", "Multan Sultans", "Islamabad United",
                "Peshawar Zalmi", "Quetta Gladiators", "Sialkot Stallions", "Hyderabad Hawks"};
        try {
            for (String t : all) {
                JSONObject r = tables.getJSONObject(t);
                int pts = r.optInt("pts");
                double n = nrr(t);
                if (pts > bestPts || (pts == bestPts && n > bestNrr)) {
                    bestPts = pts; bestNrr = n; champion = t;
                }
            }
            if (Data.USER_TEAM.equals(champion)) {
                career.put("titles", career.optInt("titles") + 1);
                ledgerCf(1500, "Title prize — Season " + season + " champions");
                addNews("CHAMPIONS! Lahore Qalandars win Season " + season + "! +1500 CF title prize.");
            } else {
                addNews("Season " + season + " champions: " + champion + ". Lahore go again next season.");
            }
            JSONArray h = new JSONArray();
            h.put("Season " + season + " champion: " + champion);
            for (int i = 0; i < Math.min(history.length(), 19); i++) h.put(history.getString(i));
            history = h;
            // academy prospect (level 2+)
            if (facilityLevel(3) >= 2) {
                int worstIdx = -1, worstRat = 999;
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    if (!p.optBoolean("inXI")) {
                        int rat = rating(p);
                        if (rat < worstRat) { worstRat = rat; worstIdx = i; }
                    }
                }
                if (worstIdx >= 0) {
                    String name = Data.PROSPECTS[rng.nextInt(Data.PROSPECTS.length)];
                    JSONObject p = player(worstIdx);
                    p.put("name", name);
                    p.put("role", rng.nextBoolean() ? "AR" : "Bat");
                    p.put("bat", 66 + rng.nextInt(11));
                    p.put("bowl", 45 + rng.nextInt(30));
                    p.put("stam", 95);
                    p.put("set", 70);
                    p.put("overseas", false); // academy prospects are local
                    p.put("rested", false);
                    addNews("Youth Academy prospect " + name + " joins the squad for Season " + (season + 1) + "!");
                }
            }
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = player(i);
                p.put("stam", 88 + rng.nextInt(12));
            }
            // pre-season charge for the new season (ledgered, v2) — applied before the
            // season counter turns so the ledger keeps a clean "Season N" marker trail
            int charged = ledgerExpense(PRESEASON_CHARGE, "Pre-season charge — Season " + (season + 1));
            if (charged > 0) addNews("Pre-season charge −" + charged + " CF for Season " + (season + 1) + ".");
        } catch (Exception ignored) {}
        season++;
        day = 1;
        match = null;
        resetSeasonTablesAndFixtures();
        addNews("Season " + season + " is here. Fixtures are out — good luck, manager!");
        return "Season " + season + " begins";
    }

    // ---------------- Hub actions ----------------

    /** Cost of one medical recovery session: cheaper as the Medical Centre improves. */
    public int recoveryCost() {
        return Math.max(5, 30 - 5 * (facilityLevel(1) - 1));
    }

    /** Stamina recovered per session: better as the Medical Centre improves. */
    public int recoveryGain() {
        return 10 + 5 * facilityLevel(1);
    }

    /** Runs a recovery session. Returns the stamina gain, or -1 if CF can't cover the cost. */
    public int recovery() {
        int cost = recoveryCost();
        if (cf < cost) return -1;
        ledgerCf(-cost, "Medical recovery session (Medical Lvl " + facilityLevel(1) + ")");
        int gain = recoveryGain();
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try { p.put("stam", Math.min(100, p.optInt("stam") + gain)); } catch (Exception ignored) {}
        }
        return gain;
    }

    public boolean teamTalk() {
        if (talkDay == day) return false;
        talkDay = day;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = player(i);
            try {
                int set = Math.min(99, p.optInt("set") + 8);
                p.put("set", set);
            } catch (Exception ignored) {}
        }
        addNews("Team Talk done — squad Set % boosted for today.");
        return true;
    }

    public boolean upgradeFacility(int idx) {
        int lvl = facilityLevel(idx);
        if (lvl >= Data.FACILITY_MAX) return false;
        int cost = Data.FACILITY_BASE_COST[idx] * lvl;
        if (cf < cost) return false; // purchase blocked — balance never silently negative
        ledgerCf(-cost, Data.FACILITY_NAMES[idx] + " upgrade to Level " + (lvl + 1));
        try {
            facilities.put(idx, lvl + 1);
            if (idx == 2) { // Training Complex: immediate small squad rating boost
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = player(i);
                    p.put("bat", Math.min(99, p.optInt("bat") + 1));
                    p.put("bowl", Math.min(99, p.optInt("bowl") + 1));
                }
            }
            addNews(Data.FACILITY_NAMES[idx] + " upgraded to Level " + (lvl + 1) + "!");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static int rating(JSONObject p) {
        String role = p.optString("role");
        int bat = p.optInt("bat"), bowl = p.optInt("bowl");
        switch (role) {
            case "Bat": return (int) (bat * 0.85 + bowl * 0.15);
            case "Bowl": return (int) (bowl * 0.85 + bat * 0.15);
            case "WK": return (int) (bat * 0.9 + bowl * 0.1) + 2;
            default: return (bat + bowl) / 2 + 3; // AR
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
