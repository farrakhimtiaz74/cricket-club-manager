package io.github.farrakhimtiaz74.cricketmanager;

import android.animation.ValueAnimator;
import android.content.Context;
import android.view.View;
import android.widget.TextView;

/** v21 item 7: the animation system. One small helper, four moves:
 *   - enter(): the screen fade/slide on every render (the move the
 *     Design Batch first inlined in MainActivity.render);
 *   - countUp(): CF / money figures count toward their new value
 *     (Hub money snapshot, HQ funds);
 *   - reveal(): the win-% graph draws progressively (WinGraphView
 *     honours a 0..1 reveal fraction);
 *   - fill(): meter fills animate to their value (GaugeView).
 *  EVERY move is gated by the Reduce Animations setting through the
 *  static reduceAnim flag (MainActivity mirrors the setting at
 *  startup and on toggle): gated off, the final state is applied
 *  immediately — the value is never wrong, just instant. */
public class Anim {

    public static boolean reduceAnim = false;

    /** Screen entry: fade + 14dp slide, 170 ms (the Design Batch
     *  numbers, kept). No-op under Reduce Animations. */
    public static void enter(View v, Context c) {
        if (v == null || reduceAnim) return;
        v.setAlpha(0f);
        v.setTranslationX(Ui.dp(c, 14));
        v.animate().alpha(1f).translationX(0f).setDuration(170).start();
    }

    /** Count a whole-number figure from from->to over ~500 ms,
     *  formatted by the caller's formatter (e.g. "1,150 CF").
     *  Under Reduce Animations the end value is set at once. */
    public interface Formatter {
        String format(int v);
    }

    public static void countUp(final TextView tv, int from, int to, final Formatter f) {
        if (tv == null) return;
        if (reduceAnim || from == to) {
            tv.setText(f.format(to));
            return;
        }
        ValueAnimator a = ValueAnimator.ofInt(from, to);
        a.setDuration(500);
        a.addUpdateListener(anim -> tv.setText(f.format((Integer) anim.getAnimatedValue())));
        a.start();
    }

    /** Drive a WinGraphView's progressive draw from 0 to full over
     *  ~650 ms; the graph settles at reveal=1 (its resting state). */
    public static void reveal(final WinGraphView graph) {
        if (graph == null) return;
        if (reduceAnim) {
            graph.setReveal(1f);
            return;
        }
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(650);
        a.addUpdateListener(anim -> graph.setReveal((Float) anim.getAnimatedValue()));
        a.start();
    }

    /** Animate a GaugeView's fill from its current value to target
     *  over ~450 ms. */
    public static void fill(final GaugeView gv, int target) {
        if (gv == null) return;
        if (reduceAnim) {
            gv.setValue(target);
            return;
        }
        ValueAnimator a = ValueAnimator.ofInt(gv.value, target);
        a.setDuration(450);
        a.addUpdateListener(anim -> gv.setValue((Integer) anim.getAnimatedValue()));
        a.start();
    }
}
