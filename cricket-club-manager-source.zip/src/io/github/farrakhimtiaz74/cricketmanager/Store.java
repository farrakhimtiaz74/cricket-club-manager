package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.content.SharedPreferences;

/** SharedPreferences wrapper — the whole game state lives here as one JSON string.
 *  Batch I: also implements Slots.Kv — career slots, the autoslot backup and
 *  the hardcore record ride in the SAME prefs file under their own keys, so
 *  clear() (live save only) never touches them.
 *  v21 (Save System v2, item 11): the LIVE save is stored through
 *  SaveCodec (GZIP+Base64). load() transparently decodes both the old
 *  plain-JSON form and the compressed form; save() always writes
 *  compressed. The codec lives ONLY here — Slots.Kv get/put stay raw,
 *  so slot JSON, the autoslot and the pre-update backup keep the
 *  plain form Slots.summary() parses. */
public class Store implements Slots.Kv {
    private static final String PREFS = "ccm_game";
    private static final String KEY = "state_v1";
    /** v21 item 11: the automatic pre-update backup key — the raw
     *  career string copied aside on the first launch of a newer
     *  build, before any migration runs. */
    public static final String KEY_PREUPDATE = "preupdate_backup";
    private final SharedPreferences sp;

    public Store(Context c) {
        sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** The decoded career JSON (plain form), or null. */
    public String load() {
        String raw = loadRaw();
        return raw == null ? null : SaveCodec.decode(raw);
    }

    /** The stored career string exactly as it sits in prefs (either
     *  format) — used by the pre-update backup hook, which must copy
     *  the save BEFORE decoding/migration touches it. */
    public String loadRaw() {
        return sp.getString(KEY, null);
    }

    public void save(String json) {
        sp.edit().putString(KEY, SaveCodec.encode(json)).apply();
    }

    public void clear() {
        sp.edit().remove(KEY).apply();
    }

    // ---- Slots.Kv (Batch I) ----
    @Override
    public String get(String k) {
        return sp.getString(k, null);
    }

    @Override
    public void put(String k, String v) {
        sp.edit().putString(k, v).apply();
    }

    @Override
    public void remove(String k) {
        sp.edit().remove(k).apply();
    }
}
