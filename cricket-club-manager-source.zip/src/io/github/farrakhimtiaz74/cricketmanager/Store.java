package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.content.SharedPreferences;

/** SharedPreferences wrapper — the whole game state lives here as one JSON string. */
public class Store {
    private static final String PREFS = "ccm_game";
    private static final String KEY = "state_v1";
    private final SharedPreferences sp;

    public Store(Context c) {
        sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String load() {
        return sp.getString(KEY, null);
    }

    public void save(String json) {
        sp.edit().putString(KEY, json).apply();
    }

    public void clear() {
        sp.edit().remove(KEY).apply();
    }
}
