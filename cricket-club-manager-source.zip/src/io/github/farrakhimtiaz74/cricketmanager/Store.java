package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.content.SharedPreferences;

/** SharedPreferences wrapper — the whole game state lives here as one JSON string.
 *  Batch I: also implements Slots.Kv — career slots, the autoslot backup and
 *  the hardcore record ride in the SAME prefs file under their own keys, so
 *  clear() (live save only) never touches them. */
public class Store implements Slots.Kv {
    private static final String PREFS = "ccm_game";
    private static final String KEY = "state_v1";
    private final SharedPreferences sp;

    public Store(Context c) {
        sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String load() {
        return sp.getString(KEY, null);
    }

    public void save(String json) {
        sp.edit().putString(KEY, json).apply();
    }

    public void clear() {
        sp.edit().remove(KEY).apply();
    }

    // ---- Slots.Kv (Batch I) ----
    @Override
    public String get(String k) {
        return sp.getString(k, null);
    }

    @Override
    public void put(String k, String v) {
        sp.edit().putString(k, v).apply();
    }

    @Override
    public void remove(String k) {
        sp.edit().remove(k).apply();
    }
}
