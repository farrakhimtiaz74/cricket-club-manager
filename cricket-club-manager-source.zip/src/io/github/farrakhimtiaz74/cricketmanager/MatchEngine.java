package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Random;

/** Ball-by-ball T20 engine. All state lives in Game.match (JSON) so a match
 *  survives the app being closed mid-game. Tactics, player ratings and stamina
 *  all feed the outcome weights. */
public class MatchEngine {

    public static final String[] TACTICS = {"Defend", "Build", "Attack", "Slog"};
    public static final String[] RUNNING = {"Hold Ones", "Standard"};
    /** v2 field settings + Batch B (idea 17) named visual presets (used when the
     *  USER is bowling): 0 Attacking, 1 Balanced, 2 Defensive keep their v2
     *  weights; 3 Slips Attack, 4 Ring Field, 5 Boundary Riders extend them. */
    public static final String[] FIELD = {"Attacking", "Balanced", "Defensive",
            "Slips Attack", "Ring Field", "Boundary Riders"};
    /** Batch B (idea 11): Powerplay plans for overs 1–6. Batting: 0 Attacking PP,
     *  1 Balanced, 2 Safe Start. Bowling: 0 Attacking PP, 1 Balanced, 2 Safe PP. */
    public static final String[] PP_BAT = {"Attacking PP", "Balanced", "Safe Start"};
    public static final String[] PP_BOWL = {"Attacking PP", "Balanced", "Safe PP"};
    /** Batch B (idea 20): per-batter bowling plans vs the current striker. */
    public static final String[] BAT_PLANS = {"No plan", "Yorkers", "Short Stuff", "Outside Off", "Straight & Full"};

    private static final Random R = new Random();

    // ---------------- setup ----------------

    public static void startMatch(Game g, JSONObject fixture) {
        try {
            Game.ensureFixtureMeta(fixture, g.season);
            JSONObject m = new JSONObject();
            m.put("opp", g.opponentOf(fixture));
            m.put("fixtureDay", fixture.optInt("day"));
            // Batch F (idea 56): cup ties carry the cup flag + their stage;
            // Batch E (idea 41) playoff ties carry their stage so the finish
            // writes back into the bracket, not the group tables
            boolean cup = fixture.optBoolean("cup");
            if (cup) {
                m.put("cup", true);
                m.put("stageName", fixture.optString("stage"));
            } else if (fixture.has("stage")) {
                m.put("playoff", true);
                m.put("stageName", fixture.optString("stage"));
            }
            // Format parameters (idea 56): the engine reads its limits from
            // the match, so 50-over cup ties just work — 300 balls, a
            // 10-over bowler cap (limit/5 below) and a 10-over powerplay.
            m.put("ballsBase", cup ? 300 : 120);
            m.put("ppBalls", cup ? 60 : 36);
            m.put("home", g.userTeam.equals(fixture.optString("home")));
            // Batch F (ideas 58/59): the ground and the derby flag ride along
            m.put("ground", fixture.optString("ground", Data.groundName(fixture.optString("home"))));
            m.put("groundChar", fixture.optInt("groundChar", Data.groundChar(fixture.optString("home"))));
            m.put("derby", g.isDerby(fixture));
            // Batch I (ideas 82/83): the FRIENDLY flag — 1 = daily challenge,
            // 2 = scenario. finishMatch short-circuits every season hook for
            // friendlies; aiBoost is the opponent's extra strength (cards).
            m.put("friendly", fixture.optInt("friendly", 0));
            m.put("scenarioId", fixture.optInt("scenarioId", -1));
            m.put("challengeDate", fixture.optString("challengeDate", ""));
            m.put("aiBoost", fixture.optInt("aiBoost", 0));
            m.put("phase", "toss");
            m.put("tactic", 1); // Build
            m.put("running", 1); // Standard
            m.put("field", 1); // Balanced (v2)
            m.put("shield", ""); // no shielded batter (v2)
            // Batch H (idea 71): a Fiery press answer arms ONE match — the
            // charge is consumed here so it can never fire twice.
            if (g.pressBoost > 0) {
                m.put("pressAggro", true);
                g.pressBoost = 0;
            }
            m.put("comm", new JSONArray());
            m.put("lastBalls", new JSONArray());
            // ---- Batch B: tactics & match-day state (ideas 11-20) ----
            m.put("ppBat", 1);          // batting Powerplay plan (Balanced)
            m.put("ppBowl", 1);         // bowling Powerplay plan (Balanced)
            m.put("batPlan", 0);        // per-batter bowling plan (none)
            m.put("batPlanFor", "");
            m.put("pepKey", "");        // segment whose pep talk is spent
            m.put("pepBoostKey", "");   // segment where the pep boost is live
            m.put("pepBoostUntil", -1); // ball index where the boost ends
            m.put("pepSide", 0);        // 1 = batting boost, 2 = bowling boost
            m.put("awaitBat", false);   // idea 14: waiting for the next-batter pick
            m.put("autoNextBat", false);// Instant sims use the batting order instead
            // ---- Batch A: conditions for this match ----
            int pitch = fixture.optInt("pitch", 0);
            m.put("pitch", pitch);
            m.put("evening", fixture.optBoolean("evening", false));
            int rainRisk = fixture.optInt("rain", 20);
            m.put("rainRisk", rainRisk);
            m.put("rainDone", false);
            // Rain is pre-rolled once and stored, so a mid-match save resumes
            // with the same weather: rainAtBall = innings-2 ball index (0-based
            // balls bowled) at which the interruption lands, or -1 for none.
            int rainAt = -1;
            if (R.nextInt(100) < rainRisk) rainAt = (cup ? 60 : 24) + R.nextInt(cup ? 150 : 61); // mid-chase window, format-scaled
            m.put("rainAtBall", rainAt);
            g.match = m;
            addComm(g, "Toss time: " + g.userTeam + " vs " + m.getString("opp") + ".");
            addComm(g, "Pitch report: " + Data.PITCH_TYPES[pitch] + " — " + Data.PITCH_DESC[pitch]
                    + (m.optBoolean("evening") ? " Day/night game: dew is expected in the chase." : "")
                    + " Rain risk today: " + rainRisk + "%.");
            addComm(g, "Venue: " + m.getString("ground") + " — a "
                    + Data.GROUND_CHARS[m.optInt("groundChar", 1)] + " deck.");
            if (cup) addComm(g, "🏆 ONE-DAY CUP — 50 overs a side today; bowlers may bowl 10 overs each.");
            if (m.optInt("friendly") == 1) addComm(g, "🎯 DAILY CHALLENGE — an exhibition outside the season. No table, stats or morale effects; win and the reward is yours.");
            if (m.optInt("friendly") == 2) addComm(g, "🎬 SCENARIO — a scripted moment, replayed your way. The season squad is untouched by the result.");
            if (m.optBoolean("derby")) addComm(g, "🔥 DERBY DAY! The rivalry is real — a bumper crowd, and bragging rights on the line.");
            if (m.optBoolean("home")) addComm(g, "The home crowd is right behind " + g.userTeam + " — home advantage in play.");
            if (m.optBoolean("pressAggro")) addComm(g, "🎙 The gaffer's fiery press words are ringing in the dressing room — expect early aggression!");
        } catch (Exception ignored) {}
    }

    /** Batch A migration for an in-progress v2 match: default every new field
     *  (conditions off, full 20-over / 10-wicket limits, empty tracking). */
    public static void migrateMatch(Game g) {
        try {
            JSONObject m = g.match;
            if (m == null) return;
            if (!m.has("pitch")) m.put("pitch", 0);
            if (!m.has("evening")) m.put("evening", false);
            if (!m.has("rainRisk")) m.put("rainRisk", 0);
            if (!m.has("rainAtBall")) m.put("rainAtBall", -1);
            if (!m.has("rainDone")) m.put("rainDone", true); // an old match never gets surprise rain
            if (!m.has("ballsLimit")) m.put("ballsLimit", 120);
            if (!m.has("wktsLimit")) m.put("wktsLimit", 10);
            if (!m.has("parts")) m.put("parts", new JSONArray());
            if (!m.has("fow")) m.put("fow", new JSONArray());
            if (!m.has("overRuns")) m.put("overRuns", new JSONArray());
            if (!m.has("superMode")) m.put("superMode", false);
            // Batch F migration: format/ground/derby defaults for a resumed match
            if (!m.has("ballsBase")) m.put("ballsBase", m.optBoolean("cup") ? 300 : 120);
            if (!m.has("ppBalls")) m.put("ppBalls", m.optBoolean("cup") ? 60 : 36);
            if (!m.has("ground")) m.put("ground", "");
            if (!m.has("groundChar")) m.put("groundChar", 1);
            if (!m.has("derby")) m.put("derby", false);
            // Batch I migration: a resumed pre-v11 match is a season match
            if (!m.has("friendly")) m.put("friendly", 0);
            if (!m.has("scenarioId")) m.put("scenarioId", -1);
            if (!m.has("challengeDate")) m.put("challengeDate", "");
            if (!m.has("aiBoost")) m.put("aiBoost", 0);
            // ---- Batch B migration: default every tactics/plan field, rebuild
            // "in" (has-batted) flags from nextIn, and let ensureRotation()
            // rebuild a missing bowling plan lazily on the next pick. ----
            if (!m.has("ppBat")) m.put("ppBat", 1);
            if (!m.has("ppBowl")) m.put("ppBowl", 1);
            if (!m.has("batPlan")) m.put("batPlan", 0);
            if (!m.has("batPlanFor")) m.put("batPlanFor", "");
            if (!m.has("pepKey")) m.put("pepKey", "");
            if (!m.has("pepBoostKey")) m.put("pepBoostKey", "");
            if (!m.has("pepBoostUntil")) m.put("pepBoostUntil", -1);
            if (!m.has("pepSide")) m.put("pepSide", 0);
            if (!m.has("awaitBat")) m.put("awaitBat", false);
            if (!m.has("autoNextBat")) m.put("autoNextBat", false);
            if (!m.has("matchups")) m.put("matchups", new JSONArray());
            if (!m.has("overBowlers")) m.put("overBowlers", new JSONArray());
            JSONArray bat = m.optJSONArray("batCard");
            if (bat != null) {
                boolean anyIn = false;
                for (int i = 0; i < bat.length(); i++) if (bat.getJSONObject(i).optBoolean("in")) anyIn = true;
                if (!anyIn) {
                    int ni = m.optInt("nextIn", 2);
                    for (int i = 0; i < bat.length(); i++) bat.getJSONObject(i).put("in", i < ni);
                }
            }
        } catch (Exception ignored) {}
    }

    /** After the toss decision: set up innings 1. userBatFirst = Lahore bat first. */
    public static void beginInnings1(Game g, boolean userBatFirst) {
        try {
            JSONObject m = g.match;
            m.put("userBatFirst", userBatFirst);
            setupInnings(g, 1, userBatFirst ? g.userTeam : m.getString("opp"));
            m.put("phase", "play");
            addComm(g, (userBatFirst ? g.userTeam + " bat first." : m.getString("opp") + " bat first.")
                    + " Play! First ball coming up.");
        } catch (Exception ignored) {}
    }

    private static void setupInnings(Game g, int inn, String batTeam) throws Exception {
        JSONObject m = g.match;
        String opp = m.getString("opp");
        String bowlTeam = batTeam.equals(g.userTeam) ? opp : g.userTeam;
        m.put("inn", inn);
        m.put("batTeam", batTeam);
        m.put("bowlTeam", bowlTeam);
        m.put("runs", 0);
        m.put("wkts", 0);
        m.put("balls", 0);
        m.put("striker", 0);
        m.put("nonStriker", 1);
        m.put("nextIn", 2);
        m.put("bowlRot", 0);
        m.put("prevBowler", "");
        m.put("lastBalls", new JSONArray());
        // Batch A per-innings tracking: full limits for a normal innings
        // (the Super Over re-sets these to 6 balls / 2 wickets), plus
        // partnerships, fall-of-wickets and Manhattan over-runs arrays.
        m.put("ballsLimit", m.optInt("ballsBase", 120)); // Batch F: 300 in the cup
        m.put("wktsLimit", 10);
        m.put("parts", new JSONArray());
        m.put("fow", new JSONArray());
        m.put("overRuns", new JSONArray());
        m.put("pShipRuns", 0);
        m.put("pShipBalls", 0);
        // Batch B per-innings state: match-up records (idea 16), the over-by-over
        // bowler record, a fresh rotation plan when Lahore bowl (ideas 12/13),
        // and a clean slate for the next-batter wait + per-batter plan (14/20).
        m.put("matchups", new JSONArray());
        m.put("overBowlers", new JSONArray());
        m.put("rotation", new JSONArray());
        m.put("awaitBat", false);
        m.put("batPlan", 0);
        m.put("batPlanFor", "");
        // batting card
        JSONArray bat = new JSONArray();
        if (batTeam.equals(g.userTeam)) {
            for (JSONObject p : g.xi()) {
                bat.put(card(p.getString("name"), p.optInt("bat"), p.optInt("bowl"), p.optInt("stam")));
            }
        } else {
            for (Object[] p : g.aiXiObjects(opp)) {
                bat.put(card((String) p[0], (Integer) p[1], (Integer) p[2], 85));
            }
        }
        // Batch I (ideas 81/82): difficulty (+ a friendly's aiBoost) bends
        // the AI club's cards — the live-engine twin of Game.simStrength()
        int aiBend = batTeam.equals(g.userTeam) ? 0 : g.aiDelta() + m.optInt("aiBoost");
        if (aiBend != 0) for (int i = 0; i < bat.length(); i++) bendAiCard(bat.getJSONObject(i), aiBend);
        // Batch B (idea 14): the openers are "in"; everyone else is yet to bat
        for (int i = 0; i < bat.length(); i++) bat.getJSONObject(i).put("in", i < 2);
        m.put("batCard", bat);
        // bowling card: best 6 bowlers of the bowling team
        JSONArray bowl = new JSONArray();
        JSONArray src = new JSONArray();
        if (bowlTeam.equals(g.userTeam)) {
            for (JSONObject p : g.xi()) src.put(card(p.getString("name"), p.optInt("bat"), p.optInt("bowl"), p.optInt("stam")));
        } else {
            for (Object[] p : g.aiXiObjects(opp)) src.put(card((String) p[0], (Integer) p[1], (Integer) p[2], 85));
        }
        // Batch I: the same difficulty/boost bend for the bowling source,
        // applied BEFORE the best-6 selection so the pick order bends too
        int bowlBend = bowlTeam.equals(g.userTeam) ? 0 : g.aiDelta() + m.optInt("aiBoost");
        if (bowlBend != 0) for (int i = 0; i < src.length(); i++) bendAiCard(src.getJSONObject(i), bowlBend);
        // simple selection sort by bowling desc, take 6
        for (int i = 0; i < src.length() && bowl.length() < 6; i++) {
            int best = -1, bestVal = -1;
            for (int j = 0; j < src.length(); j++) {
                JSONObject c = src.getJSONObject(j);
                if (c.optBoolean("picked")) continue;
                if (c.optInt("bowl") > bestVal) { bestVal = c.optInt("bowl"); best = j; }
            }
            if (best < 0) break;
            JSONObject c = src.getJSONObject(best);
            c.put("picked", true);
            JSONObject b = new JSONObject();
            b.put("name", c.getString("name"));
            b.put("bowl", c.optInt("bowl"));
            b.put("stam", c.optInt("stam", 85));
            b.put("balls", 0).put("runs", 0).put("wkts", 0);
            bowl.put(b);
        }
        m.put("bowlCard", bowl);
        // Batch B (ideas 12/13): auto-fill the 20-over rotation plan (death
        // overs 17–20 included) when Lahore bowl; the manager can edit it live.
        if (g.userTeam.equals(bowlTeam)) {
            int overs = m.optInt("ballsLimit", 120) / 6;
            m.put("rotation", buildRotation(bowl, new int[bowl.length()], -1, 0, overs, overs / 5));
        }
        pickBowler(g);
    }

    /** Batch I: shift an AI card's bat/bowl by the difficulty delta (plus
     *  a friendly's boost), clamped so no rating leaves the sane range. */
    private static void bendAiCard(JSONObject c, int d) throws Exception {
        c.put("bat", Math.max(35, Math.min(99, c.optInt("bat") + d)));
        c.put("bowl", Math.max(35, Math.min(99, c.optInt("bowl") + d)));
    }

    private static JSONObject card(String name, int bat, int bowl, int stam) throws Exception {
        JSONObject o = new JSONObject();
        o.put("name", name).put("bat", bat).put("bowl", bowl).put("stam", stam);
        o.put("runs", 0).put("balls", 0).put("out", false).put("how", "");
        o.put("in", false); // Batch B (idea 14): has this batter come to the crease?
        return o;
    }

    // ---------------- Batch B: bowling rotation plan (ideas 12 & 13) ----------------

    /** Builds a legal 20-over plan: cycle the bowling card in rating order
     *  (the same habit the old auto-pick had), never back-to-back overs for
     *  one bowler, never more than 4 overs each. used[] seeds overs already
     *  spent (migration), prev is the previous bowler's card index (-1 none),
     *  and slots before startOver are filled with -1 (already bowled). */
    private static JSONArray buildRotation(JSONArray bowl, int[] used, int prev, int startOver,
                                           int totalOvers, int capOvers) throws Exception {
        JSONArray rot = new JSONArray();
        int n = bowl.length();
        int[] counts = used.clone();
        int p = prev;
        int ptr = 0;
        for (int ov = 0; ov < totalOvers; ov++) {
            if (ov < startOver) { rot.put(-1); continue; }
            int chosen = -1;
            for (int k = 0; k < n; k++) {
                int idx = (ptr + k) % n;
                if (counts[idx] < capOvers && idx != p) { chosen = idx; break; }
            }
            if (chosen < 0) for (int i = 0; i < n; i++) if (counts[i] < capOvers) { chosen = i; break; }
            if (chosen < 0) chosen = 0;
            rot.put(chosen);
            counts[chosen]++;
            p = chosen;
            ptr = chosen + 1;
        }
        return rot;
    }

    /** Lazily (re)builds the rotation for a resumed/migrated innings, seeding
     *  the overs each bowler has already spent so the plan stays legal. */
    public static void ensureRotation(Game g) {
        try {
            JSONObject m = g.match;
            if (m == null || !g.userTeam.equals(m.optString("bowlTeam"))) return;
            JSONArray rot = m.optJSONArray("rotation");
            int overs = m.optInt("ballsLimit", 120) / 6;
            if (rot != null && rot.length() == overs) return;
            JSONArray bowl = m.getJSONArray("bowlCard");
            int[] used = new int[bowl.length()];
            for (int i = 0; i < bowl.length(); i++)
                used[i] = (bowl.getJSONObject(i).optInt("balls") + 5) / 6;
            int prev = -1;
            String prevName = m.optString("prevBowler");
            for (int i = 0; i < bowl.length(); i++)
                if (bowl.getJSONObject(i).optString("name").equals(prevName)) prev = i;
            m.put("rotation", buildRotation(bowl, used, prev, m.optInt("balls") / 6, overs, overs / 5));
        } catch (Exception ignored) {}
    }

    /** First over the manager may still (re)plan: the over in progress is locked. */
    public static int firstEditableOver(Game g) {
        int balls = g.match.optInt("balls");
        return balls % 6 == 0 ? balls / 6 : balls / 6 + 1;
    }

    /** Why a planned change is illegal, or null when it is fine. Guards the
     *  4-over cap (balls already bowled + planned overs) and the no
     *  back-to-back-overs rule against both planned and actual neighbours. */
    public static String rotationError(Game g, int overIdx, int bowlIdx) {
        try {
            JSONObject m = g.match;
            if (m.optBoolean("superMode")) return "No bowling plan in a Super Over — the engine picks.";
            if (!g.userTeam.equals(m.optString("bowlTeam"))) return "Your side is batting in this innings.";
            JSONArray bowl = m.getJSONArray("bowlCard");
            if (bowlIdx < 0 || bowlIdx >= bowl.length()) return "No such bowler.";
            int maxOver = m.optInt("ballsLimit", 120) / 6;
            if (overIdx < 0 || overIdx >= maxOver) return "No such over.";
            int fe = firstEditableOver(g);
            if (overIdx < fe) return "Over " + (overIdx + 1) + " has already been bowled.";
            ensureRotation(g);
            JSONArray rot = m.optJSONArray("rotation");
            if (rot == null || rot.length() != maxOver) return "No plan available.";
            String name = bowl.getJSONObject(bowlIdx).optString("name");
            if (overIdx > 0) {
                String prevName;
                if (overIdx - 1 == m.optInt("balls") / 6 && m.optInt("balls") % 6 != 0) {
                    prevName = bowl.getJSONObject(m.optInt("curBowler")).optString("name");
                } else {
                    int pi = rot.optInt(overIdx - 1, -2);
                    prevName = pi >= 0 ? bowl.getJSONObject(pi).optString("name") : m.optString("prevBowler");
                }
                if (name.equals(prevName)) return name + " bowled the previous over — no back-to-back overs.";
            }
            if (overIdx < maxOver - 1 && rot.optInt(overIdx + 1, -2) == bowlIdx)
                return name + " is already down for over " + (overIdx + 2) + " too — no back-to-back overs.";
            int planned = 0;
            for (int j = fe; j < maxOver; j++) if (j != overIdx && rot.optInt(j, -2) == bowlIdx) planned++;
            int capBalls = m.optInt("ballsLimit", 120) / 5; // 4 overs in T20, 10 in the cup
            if (bowl.getJSONObject(bowlIdx).optInt("balls") + (planned + 1) * 6 > capBalls)
                return name + " would exceed the " + (capBalls / 6) + "-over limit.";
            return null;
        } catch (Exception e) {
            return "Plan unavailable.";
        }
    }

    /** Applies a planned change. Returns an error string, or null on success. */
    public static String setRotationOver(Game g, int overIdx, int bowlIdx) {
        String err = rotationError(g, overIdx, bowlIdx);
        if (err != null) return err;
        try {
            g.match.getJSONArray("rotation").put(overIdx, bowlIdx);
            return null;
        } catch (Exception e) {
            return "Plan unavailable.";
        }
    }

    private static void pickBowler(Game g) throws Exception {
        JSONObject m = g.match;
        JSONArray bowl = m.getJSONArray("bowlCard");
        // Batch B (ideas 12/13): the rotation plan picks the next over's bowler.
        // If the planned man is spent (24 balls) or bowled the last over, the
        // engine falls back to the old rotation scan below — never a crash.
        if (g.userTeam.equals(m.optString("bowlTeam")) && !m.optBoolean("superMode")) {
            ensureRotation(g);
            JSONArray rot = m.optJSONArray("rotation");
            int overIdx = m.optInt("balls") / 6;
            if (rot != null && overIdx >= 0 && overIdx < rot.length()) {
                int planned = rot.optInt(overIdx, -1);
                String prevName = m.optString("prevBowler");
                if (planned >= 0 && planned < bowl.length()
                        && bowl.getJSONObject(planned).optInt("balls") < m.optInt("ballsLimit", 120) / 5
                        && !bowl.getJSONObject(planned).optString("name").equals(prevName)) {
                    m.put("curBowler", planned);
                    m.put("bowlRot", planned + 1);
                    return;
                }
            }
        }
        String prev = m.optString("prevBowler");
        int rot = m.optInt("bowlRot", 0);
        int capBalls = m.optInt("ballsLimit", 120) / 5; // Batch F: 24 in T20, 60 in the cup
        for (int k = 0; k < bowl.length(); k++) {
            int idx = (rot + k) % bowl.length();
            JSONObject b = bowl.getJSONObject(idx);
            if (b.optInt("balls") < capBalls && !b.getString("name").equals(prev)) {
                m.put("curBowler", idx);
                m.put("bowlRot", idx + 1);
                return;
            }
        }
        // fallback: anyone with balls left
        for (int i = 0; i < bowl.length(); i++) {
            if (bowl.getJSONObject(i).optInt("balls") < capBalls) { m.put("curBowler", i); return; }
        }
        m.put("curBowler", 0);
    }

    // ---------------- the ball ----------------

    /** Plays exactly one ball. Returns the commentary line for that ball. */
    public static String bowlBall(Game g) {
        try {
            JSONObject m = g.match;
            if (!"play".equals(m.optString("phase"))) return "";
            // Batch B (idea 14): the innings waits for the manager's
            // next-batter pick — sim loops also break on this flag.
            if (m.optBoolean("awaitBat")) return "";
            // Batch A (idea 2): a pre-rolled rain interruption lands here,
            // before the ball is bowled, and may end the chase on the spot.
            if (maybeRain(g)) {
                JSONArray c = m.optJSONArray("comm");
                return c != null && c.length() > 0 ? c.optString(0) : "";
            }
            JSONArray bat = m.getJSONArray("batCard");
            JSONArray bowl = m.getJSONArray("bowlCard");
            JSONObject striker = bat.getJSONObject(m.optInt("striker"));
            JSONObject nonStriker = bat.getJSONObject(m.optInt("nonStriker"));
            JSONObject bowler = bowl.getJSONObject(m.optInt("curBowler"));

            // Batch C (idea 25): morale bends a squad man's effective rating
            // by −3..+3 before the duel is scored (opponents have no morale)
            int effBat = striker.optInt("bat") + g.moraleMod(striker.optString("name"));
            int effBowl = bowler.optInt("bowl") + g.moraleMod(bowler.optString("name"));
            // Batch F (idea 57): home advantage — the user's men know their
            // own deck and crowd: +1 effective bat/bowl in home matches.
            if (m.optBoolean("home")) {
                if (g.playerByName(striker.optString("name")) != null) effBat += 1;
                if (g.playerByName(bowler.optString("name")) != null) effBowl += 1;
            }
            // Batch G (ideas 61/66): the Batting/Bowling Coach adds +1 for
            // the share of the squad his rating covers, and a pre-season
            // camp adds +1 squad-wide while its boost window is open.
            // Both are squad-only: coachBonusFor checks membership itself,
            // the camp bonus is guarded by the same playerByName test.
            if (g.playerByName(striker.optString("name")) != null) effBat += g.campBatBonus();
            if (g.playerByName(bowler.optString("name")) != null) effBowl += g.campBowlBonus();
            effBat += g.coachBonusFor("Batting Coach", striker.optString("name"));
            effBowl += g.coachBonusFor("Bowling Coach", bowler.optString("name"));
            double diff = (effBat - effBowl) / 100.0;
            double w0 = 350, w1 = 320, w2 = 60, w3 = 5, w4 = 125, w6 = 55, wW = 58;
            switch (m.optInt("tactic", 1)) {
                case 0: wW *= 0.55; w4 *= 0.70; w6 *= 0.50; w0 *= 1.10; w1 *= 1.05; break; // Defend
                case 1: wW *= 0.90; w6 *= 0.90; break;                                     // Build
                case 2: wW *= 1.35; w4 *= 1.30; w6 *= 1.40; w0 *= 0.85; w2 *= 1.10; break; // Attack
                case 3: wW *= 1.80; w4 *= 1.35; w6 *= 2.00; w0 *= 0.80; w1 *= 0.80; break; // Slog
            }
            // v2 field setting + Batch B (idea 17) presets — only the USER's
            // bowling plan: attacking presets hunt wickets but leak boundaries;
            // defensive presets dry up boundaries but wickets dry up too.
            if (g.userTeam.equals(m.optString("bowlTeam"))) {
                switch (m.optInt("field", 1)) {
                    case 0: wW *= 1.25; w4 *= 1.10; w6 *= 1.10; w0 *= 0.95; break; // Attacking
                    case 3: wW *= 1.35; w4 *= 1.18; w6 *= 1.05; w0 *= 0.95; break; // Slips Attack
                    case 4: wW *= 1.08; w0 *= 1.08; w1 *= 0.85; w4 *= 0.95; break; // Ring Field
                    case 2: wW *= 0.75; w4 *= 0.85; w6 *= 0.80; w1 *= 1.05; break; // Defensive
                    case 5: wW *= 0.85; w4 *= 0.75; w6 *= 0.70; w1 *= 1.10; w2 *= 1.05; break; // Boundary Riders
                    default: break;                                                 // Balanced
                }
            }
            // v2 shield-a-batter: while shielded, the protected batter's dismissal
            // risk drops sharply (and below, he also gives up strike more often).
            boolean userBatting = g.userTeam.equals(m.optString("batTeam"));
            String shield = m.optString("shield", "");
            boolean shieldedOnStrike = userBatting && !shield.isEmpty()
                    && shield.equals(striker.optString("name"));
            if (shieldedOnStrike) wW *= 0.55;

            // Batch A (idea 3): pitch character feeds the same weights.
            switch (m.optInt("pitch", 0)) {
                case 0: w4 *= 1.15; w6 *= 1.15; wW *= 0.92; break;              // Flat: a road
                case 1:                                                          // Green: seam early, pace rewarded
                    if (m.optInt("balls") < m.optInt("ppBalls", 36)) wW *= 1.20;
                    if (!Data.isSpinner(bowler.optString("name"))) wW *= 1.10;
                    w4 *= 0.94; break;
                case 2: w4 *= 0.90; w6 *= 0.88; w1 *= 1.08; w2 *= 1.05; break;  // Dry: slow and low
                case 3:                                                          // Turning: spin grips
                    if (Data.isSpinner(bowler.optString("name"))) { wW *= 1.30; w4 *= 0.92; w6 *= 0.92; }
                    else wW *= 0.95;
                    break;
            }
            // Batch F (idea 59): the ground's character bends the same
            // weights a touch further, on top of the pitch type.
            switch (m.optInt("groundChar", 1)) {
                case 0: w4 *= 1.05; w6 *= 1.05; break;             // High-scoring ground
                case 2: wW *= 1.05; w4 *= 0.96; w6 *= 0.96; break; // Bowler-friendly ground
                default: break;                                     // Balanced
            }
            // Batch A (idea 4): dew in an evening chase — the ball skids on
            // and bowling gets harder (fewer wickets, a touch more scoring).
            boolean dew = m.optBoolean("evening") && m.optInt("inn") == 2 && !m.optBoolean("superMode");
            if (dew) { wW *= 0.90; w4 *= 1.06; w6 *= 1.06; }

            // ---- Batch B modifiers ----
            boolean userBowling = g.userTeam.equals(m.optString("bowlTeam"));
            int ballsNow = m.optInt("balls");
            // Idea 11: Powerplay plans bite only in overs 1–6. The batting plan
            // applies when Lahore bat, the bowling plan when Lahore bowl.
            if (!m.optBoolean("superMode") && ballsNow < m.optInt("ppBalls", 36)) {
                if (userBatting) {
                    switch (m.optInt("ppBat", 1)) {
                        case 0: wW *= 1.30; w4 *= 1.20; w6 *= 1.25; w0 *= 0.92; break; // Attacking PP
                        case 2: wW *= 0.60; w4 *= 0.85; w6 *= 0.80; w1 *= 1.10; w0 *= 1.05; break; // Safe Start
                        default: break;
                    }
                }
                if (userBowling) {
                    switch (m.optInt("ppBowl", 1)) {
                        case 0: wW *= 1.20; w4 *= 1.12; w6 *= 1.08; break; // Attacking PP bowling
                        case 2: wW *= 0.85; w4 *= 0.80; w6 *= 0.80; w1 *= 1.05; break; // Safe PP bowling
                        default: break;
                    }
                }
            }
            // Idea 20: the per-batter bowling plan, live only while its target
            // is on strike; it clears itself when he is dismissed (below).
            String planFor = m.optString("batPlanFor", "");
            int batPlan = m.optInt("batPlan", 0);
            boolean planActive = userBowling && batPlan > 0 && !planFor.isEmpty()
                    && planFor.equals(striker.optString("name")) && !m.optBoolean("superMode");
            if (planActive) {
                switch (batPlan) {
                    case 1: w0 *= 1.15; w4 *= 0.70; w6 *= 0.60; wW *= 1.15; break; // Yorkers
                    case 2: w4 *= 1.25; w6 *= 1.20; wW *= 1.25; w0 *= 0.90; break; // Short Stuff
                    case 3: w0 *= 1.20; w1 *= 0.90; w4 *= 0.80; wW *= 1.10; break; // Outside Off
                    case 4: w0 *= 1.10; w6 *= 0.75; w4 *= 0.90; wW *= 1.05; w2 *= 0.90; break; // Straight & Full
                }
            }
            // Idea 18: pep-talk boost window (two overs from the talk).
            if (pepBoostActive(m)) {
                if (userBatting && m.optInt("pepSide") == 1) { w4 *= 1.15; w6 *= 1.15; wW *= 0.90; }
                if (userBowling && m.optInt("pepSide") == 2) { wW *= 1.20; w4 *= 0.90; w6 *= 0.90; }
            }
            // Batch H (idea 71): the Fiery press boost — the user's batters
            // come out swinging for the whole first powerplay.
            if (userBatting && m.optBoolean("pressAggro") && ballsNow < m.optInt("ppBalls", 36)
                    && !m.optBoolean("superMode")) {
                w4 *= 1.10; w6 *= 1.12; wW *= 1.06;
            }

            // ---- Batch C modifiers ----
            // Idea 30: specialist tags — situational weights for squad players
            // (tagsOf is empty for opponents, so these only bend Lahore men).
            String sName = striker.optString("name"), bName = bowler.optString("name");
            int limNow = m.optInt("ballsLimit", 120);
            if (g.hasTag(sName, "Finisher") && ballsNow >= limNow - 24) { w4 *= 1.12; w6 *= 1.12; wW *= 0.90; }
            if (g.hasTag(sName, "Anchor") && ballsNow >= m.optInt("ppBalls", 36) && ballsNow < limNow - 30) { wW *= 0.85; w4 *= 0.95; w6 *= 0.93; }
            if (g.hasTag(sName, "Powerplay Specialist") && ballsNow < m.optInt("ppBalls", 36)) { w4 *= 1.12; w6 *= 1.10; wW *= 0.97; }
            if (g.hasTag(bName, "Death Bowler") && ballsNow >= limNow - 24) { wW *= 1.15; w4 *= 0.90; w6 *= 0.88; }
            if (g.hasTag(bName, "Spin Option") && m.optInt("pitch", 0) == 3) wW *= 1.08;
            if (g.hasTag(bName, "Pace Battery") && m.optInt("pitch", 0) == 1) wW *= 1.06;
            // Idea 26: the captain leads the attack from inside the XI
            if (userBowling && g.captainInXi()) wW *= 1.03;

            w4 *= (1 + diff * 0.8);
            w6 *= (1 + diff);
            wW *= (1 - diff * 0.7);
            w1 *= (1 + diff * 0.2);
            if (striker.optInt("stam", 85) < 50) wW *= 1.15;      // tired batter
            if (bowler.optInt("stam", 85) < 50) { w4 *= 1.2; w6 *= 1.2; } // tired bowler
            if (m.optInt("running", 1) == 0) { w2 *= 0.6; w1 *= 1.05; }   // Hold Ones
            int balls = m.optInt("balls");
            int limit = m.optInt("ballsLimit", 120);
            if (balls >= limit - 18) { w4 *= 1.15; w6 *= 1.15; wW *= 1.10; } // death overs
            if (m.optInt("target", 0) > 0 && (m.optInt("inn") == 2 || m.optBoolean("superMode"))) { // chase pressure
                int target = m.optInt("target");
                int need = target - m.optInt("runs");
                int remBalls = limit - balls;
                if (remBalls > 0) {
                    double req = need * 6.0 / remBalls;
                    if (req > 10) { wW *= 1.10; w4 *= 1.10; w6 *= 1.10; }
                    if (req > 13) { wW *= 1.10; w6 *= 1.15; }
                }
            }

            double total = w0 + w1 + w2 + w3 + w4 + w6 + wW;
            double roll = R.nextDouble() * total;
            int outcome; // -1 wicket, else runs
            if ((roll -= w0) < 0) outcome = 0;
            else if ((roll -= w1) < 0) outcome = 1;
            else if ((roll -= w2) < 0) outcome = 2;
            else if ((roll -= w3) < 0) outcome = 3;
            else if ((roll -= w4) < 0) outcome = 4;
            else if ((roll -= w6) < 0) outcome = 6;
            else outcome = -1;

            int runs = m.optInt("runs");
            int wkts = m.optInt("wkts");
            balls++;
            striker.put("balls", striker.optInt("balls") + 1);
            bowler.put("balls", bowler.optInt("balls") + 1);
            String batName = striker.getString("name");
            String bowlName = bowler.getString("name");
            String comm;
            boolean lastRunOut = false; // Batch B: match-up records credit real bowler wickets only

            if (outcome == -1) {
                wkts++;
                double roChance = m.optInt("running", 1) == 0 ? 0.04 : 0.10;
                // Batch C (idea 30): Safe Hands in the fielding XI sharpens run outs
                if (g.userTeam.equals(m.optString("bowlTeam")) && g.xiHasTag("Safe Hands")) roChance += 0.03;
                // Batch G (idea 66): a Fielding Camp sharpens them further, first half only
                if (g.userTeam.equals(m.optString("bowlTeam")) && g.campHalfActive(3)) roChance += 0.03;
                boolean runOut = R.nextDouble() < roChance;
                lastRunOut = runOut;
                String how = runOut ? "run out" : pick(new String[]{"b " + bowlName, "c sub b " + bowlName, "lbw b " + bowlName, "c & b " + bowlName});
                striker.put("out", true);
                striker.put("how", how);
                bowler.put("runs", bowler.optInt("runs")); // no run on a bowled/caught wicket
                if (!runOut) bowler.put("wkts", bowler.optInt("wkts") + 1);
                else { runs += 0; }
                comm = pickComm(WICKET, WICKET_UR).replace("{bat}", batName).replace("{bowl}", bowlName)
                        + " (" + how + ") — " + batName + " scored " + striker.optInt("runs") + " off " + striker.optInt("balls") + ".";
                // Batch J (idea 93): a second (or third) wicket in the
                // SAME over gets its own cluster line, in either language.
                // overWkts is a running counter reset in the over-complete
                // block below (and on the first ball of an innings).
                int wktsThisOver = balls <= 1 ? 1 : m.optInt("overWkts", 0) + 1;
                m.put("overWkts", wktsThisOver);
                if (wktsThisOver == 2) {
                    comm += urduComm ? " Isi over mein dusri wicket — dabao barh gaya!"
                                     : " Two wickets in the over — the pressure jumps!";
                } else if (wktsThisOver >= 3) {
                    comm += urduComm ? " Is over mein teesri wicket! Kya dramai over hai!"
                                     : " Three wickets in the over! What drama!";
                }
                if (m.optBoolean("derby") && R.nextDouble() < 0.18) {
                    comm += " The derby crowd ROARS — this rivalry means everything!";
                }
                pushBall(g, "W");
                // Batch B (idea 14): when Lahore bat, the manager picks who
                // comes in next — the innings parks on awaitBat (unless an
                // Instant sim set autoNextBat, or the innings is ending here).
                // Otherwise the next unused batter in card order walks in.
                int cand = firstUnused(bat);
                boolean inningsEnding = wkts >= m.optInt("wktsLimit", 10) || balls >= limit;
                if (cand >= 0 && !inningsEnding) {
                    if (userBatting && !m.optBoolean("autoNextBat")) {
                        m.put("awaitBat", true);
                        m.put("nextIn", cand);
                    } else {
                        bat.getJSONObject(cand).put("in", true);
                        m.put("striker", cand);
                        int nu = firstUnused(bat);
                        m.put("nextIn", nu >= 0 ? nu : bat.length());
                    }
                } else {
                    m.put("nextIn", bat.length());
                }
                // Batch B (idea 20): the plan dies with its target.
                if (!planFor.isEmpty() && planFor.equals(batName)) {
                    m.put("batPlan", 0);
                    m.put("batPlanFor", "");
                }
            } else {
                runs += outcome;
                striker.put("runs", striker.optInt("runs") + outcome);
                bowler.put("runs", bowler.optInt("runs") + outcome);
                pushBall(g, String.valueOf(outcome));
                String[] pool = outcome == 0 ? DOT : outcome == 1 ? ONE : outcome == 2 ? TWO
                        : outcome == 3 ? ONE : outcome == 4 ? FOUR : SIX;
                // Batch J (idea 93): the Roman Urdu pool mirrors the English one
                String[] poolUr = outcome == 0 ? DOT_UR : outcome == 1 ? ONE_UR : outcome == 2 ? TWO_UR
                        : outcome == 3 ? ONE_UR : outcome == 4 ? FOUR_UR : SIX_UR;
                comm = pickComm(pool, poolUr).replace("{bat}", batName).replace("{bowl}", bowlName);
                if (dew && outcome >= 4 && R.nextDouble() < 0.25)
                    comm += " The dew is making the ball skid on — hard work for the bowlers now.";
                if (outcome % 2 == 1) swapStrike(m);
                // shield rotation: on even-run balls the shielded batter often
                // hands strike to his partner, so he faces fewer balls overall
                else if (shieldedOnStrike && balls % 6 != 0 && R.nextDouble() < 0.5) swapStrike(m);
                int sr = striker.optInt("runs");
                if (sr == 50 || sr == 100) {
                    comm += urduComm
                            ? " " + batName + " ke " + sr + " run mukammal! Crowd josh mein hai."
                            : " " + sr + " up for " + batName + "! The crowd loves it.";
                }
                // Batch E (idea 48): stamp the exact ball a fifty was reached
                // on — the records book's fastest-fifty measure
                if (sr >= 50 && !striker.has("balls50")) striker.put("balls50", striker.optInt("balls"));
            }

            // Batch B (idea 20): the commentary name-checks the plan now and then
            if (planActive && R.nextDouble() < 0.25) {
                comm += " (" + BAT_PLANS[batPlan] + " — the plan against " + batName + ".)";
            }

            m.put("runs", runs);
            m.put("wkts", wkts);
            m.put("balls", balls);

            // ---- Batch A tracking (ideas 6 & 7): Manhattan over-runs,
            // partnerships and fall of wickets. The engine has no extras,
            // so partnership runs always sum exactly to the innings total.
            JSONArray oruns = m.getJSONArray("overRuns");
            int oi = (balls - 1) / 6;
            while (oruns.length() <= oi) oruns.put(0);
            oruns.put(oi, oruns.optInt(oi) + (outcome > 0 ? outcome : 0));
            int pRuns = m.optInt("pShipRuns") + (outcome > 0 ? outcome : 0);
            int pBalls = m.optInt("pShipBalls") + 1;
            if (outcome == -1) {
                JSONObject fe = new JSONObject();
                fe.put("score", runs).put("wkts", wkts).put("name", batName).put("over", oversStrFull(balls));
                m.getJSONArray("fow").put(fe);
                JSONObject pe = new JSONObject();
                pe.put("pair", batName + " & " + nonStriker.optString("name"));
                pe.put("runs", pRuns).put("balls", pBalls);
                m.getJSONArray("parts").put(pe);
                pRuns = 0;
                pBalls = 0;
            }
            m.put("pShipRuns", pRuns);
            m.put("pShipBalls", pBalls);

            // ---- Batch B tracking (idea 16): batter-vs-bowler in this match.
            // Run outs are not credited to the bowler's column.
            JSONArray mu = m.optJSONArray("matchups");
            if (mu == null) { mu = new JSONArray(); m.put("matchups", mu); }
            JSONObject me = null;
            for (int i = 0; i < mu.length(); i++) {
                JSONObject x = mu.getJSONObject(i);
                if (x.optString("bat").equals(batName) && x.optString("bowl").equals(bowlName)) { me = x; break; }
            }
            if (me == null) {
                me = new JSONObject();
                me.put("bat", batName).put("bowl", bowlName).put("balls", 0).put("runs", 0).put("outs", 0);
                mu.put(me);
            }
            me.put("balls", me.optInt("balls") + 1);
            me.put("runs", me.optInt("runs") + (outcome > 0 ? outcome : 0));
            if (outcome == -1 && !lastRunOut) me.put("outs", me.optInt("outs") + 1);

            String line = oversStr(balls - 1) + " — " + comm;
            addComm(g, line);

            // over complete?
            if (balls % 6 == 0) m.put("overWkts", 0); // Batch J: cluster counter resets with the over
            if (balls % 6 == 0 && balls < limit && wkts < m.optInt("wktsLimit", 10)) {
                // Batch B: record who bowled this over (plan checks + display)
                JSONArray ob = m.optJSONArray("overBowlers");
                if (ob == null) { ob = new JSONArray(); m.put("overBowlers", ob); }
                ob.put(bowlName);
                // no strike swap while a next-batter pick is pending: the
                // incoming batter takes strike for the new over (approximation)
                if (!m.optBoolean("awaitBat")) swapStrike(m);
                m.put("prevBowler", bowlName);
                pickBowler(g);
                addComm(g, "End of over " + (balls / 6) + ": " + g.shortFor(m.getString("batTeam"))
                        + " " + runs + "/" + wkts + ".");
            }

            // Innings over? Multi-wicket overs are safe here: each wicket advances
            // nextIn independently, every wicket gets its own commentary line, and
            // endInnings fires the moment wkts hits 10 — even mid-over. All sim
            // loops re-check phase/inn after every ball, so they exit cleanly.
            boolean chaseDone = m.optInt("target", 0) > 0 && runs >= m.optInt("target")
                    && (m.optInt("inn") == 2 || m.optBoolean("superMode"));
            if (wkts >= m.optInt("wktsLimit", 10) || balls >= limit || chaseDone) endInnings(g);
            return line;
        } catch (Exception e) {
            return "";
        }
    }

    public static void simOver(Game g) {
        try {
            JSONObject m = g.match;
            int startBalls = m.optInt("balls");
            int target = startBalls + (6 - startBalls % 6);
            int guard = 0;
            while ("play".equals(m.optString("phase")) && m.optInt("balls") < target && guard++ < 10) {
                bowlBall(g);
                // stop if innings changed, or a next-batter pick is waiting (Batch B)
                if (m.optInt("balls") == 0 || m.optBoolean("awaitBat")) break;
            }
        } catch (Exception ignored) {}
    }

    public static void simInnings(Game g) {
        int guard = 0;
        try {
            JSONObject m = g.match;
            int inn = m.optInt("inn");
            while ("play".equals(m.optString("phase")) && m.optInt("inn") == inn
                    && !m.optBoolean("awaitBat") && guard++ < m.optInt("ballsLimit", 120) + 40) {
                bowlBall(g);
            }
        } catch (Exception ignored) {}
    }

    public static void simMatch(Game g) {
        int guard = 0;
        try {
            int lim = g.match == null ? 120 : g.match.optInt("ballsLimit", 120);
            while (g.match != null && "play".equals(g.match.optString("phase"))
                    && !g.match.optBoolean("awaitBat") && guard++ < lim * 2 + 80) {
                bowlBall(g);
            }
        } catch (Exception ignored) {}
    }

    // ---------------- Batch B: next-batter choice (idea 14) ----------------

    /** First card that has neither batted nor been dismissed, or -1. */
    public static int firstUnused(JSONArray bat) {
        for (int i = 0; i < bat.length(); i++) {
            JSONObject b = bat.optJSONObject(i);
            if (b != null && !b.optBoolean("out") && !b.optBoolean("in")) return i;
        }
        return -1;
    }

    /** The manager's pick walks in. Only legal while awaitBat is set and the
     *  chosen card is unused and not out. Unit-testable selection function. */
    public static boolean chooseNextBatter(Game g, int cardIdx) {
        try {
            JSONObject m = g.match;
            if (m == null || !m.optBoolean("awaitBat")) return false;
            JSONArray bat = m.getJSONArray("batCard");
            if (cardIdx < 0 || cardIdx >= bat.length()) return false;
            JSONObject c = bat.getJSONObject(cardIdx);
            if (c.optBoolean("out") || c.optBoolean("in")) return false;
            c.put("in", true);
            m.put("striker", cardIdx);
            m.put("awaitBat", false);
            int nu = firstUnused(bat);
            m.put("nextIn", nu >= 0 ? nu : bat.length());
            addComm(g, c.optString("name") + " walks out to the middle — the manager's pick.");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------- Batch B: pep talk (idea 18) ----------------

    /** A "segment" is one innings of one kind: pep talks are once per segment
     *  (the Super Over stages are their own segments). */
    public static String pepSegment(JSONObject m) {
        return m.optInt("inn") + (m.optBoolean("superMode") ? "S" + m.optInt("superStage", 1) : "");
    }

    private static boolean pepBoostActive(JSONObject m) {
        return pepSegment(m).equals(m.optString("pepBoostKey", ""))
                && m.optInt("balls") < m.optInt("pepBoostUntil", -1);
    }

    /** Fires the once-per-innings pep talk: a two-over engine boost for the
     *  side Lahore control, plus a +3 Set nudge to the men in the middle (or
     *  the current bowler). Returns the commentary line, or null if spent. */
    public static String pepTalk(Game g) {
        try {
            JSONObject m = g.match;
            if (m == null || !"play".equals(m.optString("phase"))) return null;
            String key = pepSegment(m);
            if (key.equals(m.optString("pepKey", ""))) return null;
            boolean userBat = g.userTeam.equals(m.optString("batTeam"));
            m.put("pepKey", key);
            m.put("pepBoostKey", key);
            m.put("pepBoostUntil", m.optInt("balls") + 12);
            m.put("pepSide", userBat ? 1 : 2);
            if (userBat) {
                JSONArray bat = m.getJSONArray("batCard");
                nudgeSet(g, bat.getJSONObject(m.optInt("striker")).optString("name"));
                nudgeSet(g, bat.getJSONObject(m.optInt("nonStriker")).optString("name"));
            } else {
                JSONArray bowl = m.getJSONArray("bowlCard");
                nudgeSet(g, bowl.getJSONObject(m.optInt("curBowler")).optString("name"));
            }
            String msg = userBat
                    ? "🗣 PEP TALK! The manager fires up the pair in the middle — expect intent for the next two overs."
                    : "🗣 PEP TALK! The bowlers huddle with the manager — hunting season for the next two overs.";
            addComm(g, msg);
            return msg;
        } catch (Exception e) {
            return null;
        }
    }

    private static void nudgeSet(Game g, String name) {
        for (int i = 0; i < g.players.length(); i++) {
            JSONObject p = g.player(i);
            if (name.equals(p.optString("name"))) {
                try { p.put("set", Math.min(99, p.optInt("set") + 3)); } catch (Exception ignored) {}
            }
        }
    }

    // ---------------- Batch B: assistant coach (idea 15) ----------------

    /** A suggestion from simple, real signals while Lahore bowl. Returns
     *  {text, bowlCardIndex} — the index is -1 when the tip carries no
     *  one-tap bowler change. The suggested bowler is always legal for the
     *  next over (rotationError == null), so the UI's Apply cannot fail. */
    public static String[] coachSuggestion(Game g) {
        try {
            JSONObject m = g.match;
            if (m == null || !"play".equals(m.optString("phase")) || m.optBoolean("superMode")) return null;
            if (g.userTeam.equals(m.optString("batTeam"))) return null; // bowling only
            int balls = m.optInt("balls");
            if (balls < 6) return null;
            int nextOver = balls % 6 == 0 ? balls / 6 : balls / 6 + 1;
            if (nextOver >= m.optInt("ballsLimit", 120) / 6) return null;
            JSONArray bowl = m.getJSONArray("bowlCard");
            JSONArray bat = m.getJSONArray("batCard");
            ensureRotation(g);
            JSONObject striker = bat.getJSONObject(m.optInt("striker"));
            JSONObject non = bat.getJSONObject(m.optInt("nonStriker"));
            JSONObject cur = bowl.getJSONObject(m.optInt("curBowler"));

            // candidate helpers, all filtered through the plan's own legality
            int bestRated = -1, bestWkts = -1, bestEcon = -1, spinner = -1, freshest = -1;
            double bestEconVal = 99;
            for (int i = 0; i < bowl.length(); i++) {
                if (rotationError(g, nextOver, i) != null) continue;
                JSONObject b = bowl.getJSONObject(i);
                if (bestRated < 0 || b.optInt("bowl") > bowl.getJSONObject(bestRated).optInt("bowl")) bestRated = i;
                if (bestWkts < 0 || b.optInt("wkts") > bowl.getJSONObject(bestWkts).optInt("wkts")) bestWkts = i;
                if (b.optInt("balls") >= 6) {
                    double econ = b.optInt("runs") * 6.0 / b.optInt("balls");
                    if (econ < bestEconVal) { bestEconVal = econ; bestEcon = i; }
                }
                if (spinner < 0 && Data.isSpinner(b.optString("name"))) spinner = i;
                if (freshest < 0 || b.optInt("balls") < bowl.getJSONObject(freshest).optInt("balls")) freshest = i;
            }

            // 1) a batter is on a tear — bring the strike bowler on
            JSONObject tear = null;
            for (JSONObject b : new JSONObject[]{striker, non}) {
                if (b.optInt("balls") >= 10 && b.optInt("runs") * 1.0 / Math.max(1, b.optInt("balls")) > 1.9) tear = b;
            }
            if (tear != null && bestRated >= 0) {
                return new String[]{tear.optString("name") + " is flying — " + tear.optInt("runs")
                        + " off " + tear.optInt("balls") + ". Bring back " + bowl.getJSONObject(bestRated).optString("name")
                        + ", your strike bowler, and attack him.", String.valueOf(bestRated)};
            }
            // 2) a new batter is fresh to the crease — hunt him early
            JSONObject fresh = striker.optInt("balls") <= non.optInt("balls") ? striker : non;
            if (m.optInt("wkts") > 0 && fresh.optInt("balls") <= 3 && bestWkts >= 0) {
                return new String[]{fresh.optString("name") + " is new to the crease — attack him early with "
                        + bowl.getJSONObject(bestWkts).optString("name") + " before he settles.", String.valueOf(bestWkts)};
            }
            // 3) the pitch is turning and no spinner is on
            if (m.optInt("pitch", 0) == 3 && spinner >= 0 && !Data.isSpinner(cur.optString("name"))) {
                return new String[]{"This pitch is gripping — get " + bowl.getJSONObject(spinner).optString("name")
                        + " on and let the surface do the work.", String.valueOf(spinner)};
            }
            // 4) the current bowler is leaking — rest him for the tightest option
            if (cur.optInt("balls") >= 12 && cur.optInt("runs") * 6.0 / cur.optInt("balls") > 11 && bestEcon >= 0) {
                return new String[]{cur.optString("name") + " is leaking at "
                        + String.format(java.util.Locale.US, "%.1f", cur.optInt("runs") * 6.0 / cur.optInt("balls"))
                        + " an over — rest him and give " + bowl.getJSONObject(bestEcon).optString("name")
                        + " a go; he's been the tightest so far.", String.valueOf(bestEcon)};
            }
            // 5) steady state — keep rotating the fresh legs
            if (freshest >= 0) {
                return new String[]{"Keep the rotation fresh — " + bowl.getJSONObject(freshest).optString("name")
                        + " has overs in the bank and fresh legs.", String.valueOf(freshest)};
            }
            return new String[]{"Bowling plan is on track — no change needed.", "-1"};
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------- Batch B: danger man (idea 19) ----------------

    /** The opposition's highest-rated player (by their best discipline). */
    public static String dangerManName(Game g, String opp) {
        java.util.List<Object[]> xi = g.aiXiObjects(opp);
        String best = "";
        int bestVal = -1;
        for (Object[] p : xi) {
            int v = Math.max((Integer) p[1], (Integer) p[2]);
            if (v > bestVal) { bestVal = v; best = (String) p[0]; }
        }
        return best;
    }

    /** One-line scouting warning, labelled by what the danger man threatens. */
    public static String dangerManLine(Game g, String opp) {
        java.util.List<Object[]> xi = g.aiXiObjects(opp);
        String name = dangerManName(g, opp);
        for (Object[] p : xi) {
            if (name.equals(p[0])) {
                int bat = (Integer) p[1], bowl = (Integer) p[2];
                if (bat >= bowl) {
                    return name + " — rated " + bat + " with the bat, " + opp + "'s highest-rated player. Get him early, or he takes the game away.";
                }
                return name + " — rated " + bowl + " with the ball, " + opp + "'s highest-rated player. His overs are the danger overs — see them off.";
            }
        }
        return name;
    }

    // ---------------- Batch B: match-up record (idea 16) ----------------

    /** One batter-vs-bowler line from this innings' tracked ball data. */
    public static JSONObject matchup(JSONArray matchups, String batName, String bowlName) {
        if (matchups == null) return null;
        for (int i = 0; i < matchups.length(); i++) {
            JSONObject x = matchups.optJSONObject(i);
            if (x != null && x.optString("bat").equals(batName) && x.optString("bowl").equals(bowlName)) return x;
        }
        return null;
    }

    private static void endInnings(Game g) throws Exception {
        JSONObject m = g.match;
        int runs = m.optInt("runs"), wkts = m.optInt("wkts"), balls = m.optInt("balls");
        String batTeam = m.getString("batTeam");
        // Batch B: if the innings ended mid-over, close the over-bowler record
        if (balls % 6 != 0) {
            JSONArray ob = m.optJSONArray("overBowlers");
            if (ob != null) {
                try {
                    ob.put(m.getJSONArray("bowlCard").getJSONObject(m.optInt("curBowler")).optString("name"));
                } catch (Exception ignored) {}
            }
        }
        // Batch A (idea 7): close the final, unbroken partnership
        if (m.optInt("pShipBalls") > 0) {
            JSONArray bat = m.getJSONArray("batCard");
            JSONObject pe = new JSONObject();
            pe.put("pair", bat.getJSONObject(m.optInt("striker")).optString("name") + " & "
                    + bat.getJSONObject(m.optInt("nonStriker")).optString("name"));
            pe.put("runs", m.optInt("pShipRuns")).put("balls", m.optInt("pShipBalls"));
            pe.put("unbroken", true);
            m.getJSONArray("parts").put(pe);
            m.put("pShipRuns", 0);
            m.put("pShipBalls", 0);
        }
        // Batch A (idea 1): a Super Over innings ends here, not in finishMatch
        if (m.optBoolean("superMode")) { endSuperInnings(g, runs, wkts, balls); return; }
        String summary = g.shortFor(batTeam) + " " + runs + "/" + wkts + " (" + oversStrFull(balls) + " ov)";
        if (m.optInt("inn") == 1) {
            m.put("inn1BatTeam", batTeam);
            m.put("inn1Runs", runs).put("inn1Wkts", wkts).put("inn1Balls", balls);
            m.put("inn1Summary", summary);
            m.put("target", runs + 1);
            // keep innings-1 cards for the full-time scorecard + watchlist checks (v2)
            m.put("inn1BatCard", m.getJSONArray("batCard"));
            m.put("inn1BowlCard", m.getJSONArray("bowlCard"));
            // Batch A: keep innings-1 partnerships / FoW / Manhattan data too
            m.put("inn1Parts", m.getJSONArray("parts"));
            m.put("inn1Fow", m.getJSONArray("fow"));
            m.put("inn1OverRuns", m.getJSONArray("overRuns"));
            // Batch B: keep innings-1 match-ups and the over-bowler record too
            m.put("inn1Matchups", m.getJSONArray("matchups"));
            m.put("inn1OverBowlers", m.getJSONArray("overBowlers"));
            // v2 INNINGS BREAK: the match PAUSES here (Sim modes stop too, because
            // every sim loop is gated on phase == "play"). Both XIs recover a
            // little; the user's squad stamina gain is the persistent one.
            // Batch I: a friendly leaves the season squad EXACTLY as it found
            // it — no stamina gain either (ideas 82/83: no season effects).
            if (m.optInt("friendly") == 0) {
                for (JSONObject p : g.xi()) {
                    p.put("stam", Math.min(100, p.optInt("stam") + Game.BREAK_REGEN));
                }
            }
            m.put("phase", "break");
            addComm(g, "Innings break: " + summary + ". Target: " + (runs + 1)
                    + ". Players recover +" + Game.BREAK_REGEN + " stamina.");
        } else if (runs == m.optInt("inn1Runs")) {
            // Batch A (idea 1): scores level — stash the real innings-2 numbers
            // (the Super Over reuses runs/wkts/balls) and go to a Super Over.
            m.put("inn2Runs", runs).put("inn2Wkts", wkts).put("inn2Balls", balls);
            startSuperOver(g, summary);
        } else {
            finishMatch(g, summary);
        }
    }

    // ---------------- Batch A: Super Over (idea 1) ----------------

    private static void startSuperOver(Game g, String inn2Summary) throws Exception {
        JSONObject m = g.match;
        m.put("superPlayed", true);
        m.put("superMode", true);
        m.put("inn2SummaryFull", inn2Summary);
        // keep the tied innings' cards + tracking for the scorecard / watchlist
        m.put("inn2BatCard", m.getJSONArray("batCard"));
        m.put("inn2BowlCard", m.getJSONArray("bowlCard"));
        m.put("inn2Parts", m.getJSONArray("parts"));
        m.put("inn2Fow", m.getJSONArray("fow"));
        m.put("inn2OverRuns", m.getJSONArray("overRuns"));
        m.put("superStage", 1);
        m.put("phase", "superbreak");
        addComm(g, "SCORES LEVEL! " + inn2Summary + " — this one goes to a SUPER OVER! One over, two wickets each.");
    }

    /** Called from the superbreak screen: sets up one Super Over innings
     *  (6 balls, 2 wickets) reusing the normal cards and ball engine.
     *  Stage 1: the side that batted second in the match bats first. */
    public static void startSuperStage(Game g, int stage) {
        try {
            JSONObject m = g.match;
            String batTeam;
            if (stage == 1) {
                batTeam = g.userTeam.equals(m.optString("inn1BatTeam"))
                        ? m.getString("opp") : g.userTeam;
                m.put("super1BatTeam", batTeam);
                m.put("target", 0);
            } else {
                batTeam = g.userTeam.equals(m.optString("super1BatTeam"))
                        ? m.getString("opp") : g.userTeam;
                m.put("target", m.optInt("super1Runs") + 1);
            }
            m.put("superStage", stage);
            setupInnings(g, m.optInt("inn"), batTeam);
            m.put("ballsLimit", 6);
            m.put("wktsLimit", 2);
            m.put("phase", "play");
            addComm(g, stage == 1
                    ? "SUPER OVER — " + batTeam + " bat first. Six balls, two wickets."
                    : "SUPER OVER — " + batTeam + " need " + m.optInt("target") + " from 6 balls to win it!");
        } catch (Exception ignored) {}
    }

    private static void endSuperInnings(Game g, int runs, int wkts, int balls) throws Exception {
        JSONObject m = g.match;
        String batTeam = m.getString("batTeam");
        if (m.optInt("superStage", 1) == 1) {
            m.put("super1Runs", runs);
            m.put("super1Wkts", wkts);
            m.put("superStage", 2);
            m.put("phase", "superbreak");
            addComm(g, "Super Over: " + g.shortFor(batTeam) + " post " + runs + "/" + wkts
                    + " — the other side needs " + (runs + 1) + " from their 6 balls.");
            return;
        }
        int s1 = m.optInt("super1Runs");
        String winnerTeam = runs > s1 ? batTeam : runs < s1 ? m.getString("super1BatTeam") : "";
        m.put("superSummary", "Super Over " + s1 + "–" + runs
                + (winnerTeam.isEmpty() ? " (tied — points shared)" : " — " + winnerTeam + " take it"));
        if (!winnerTeam.isEmpty()) m.put("superWinnerTeam", winnerTeam);
        m.put("superMode", false);
        // restore the real innings-2 cards for the scorecard + watchlist checks
        if (m.has("inn2BatCard")) {
            m.put("batCard", m.getJSONArray("inn2BatCard"));
            m.put("bowlCard", m.getJSONArray("inn2BowlCard"));
        }
        addComm(g, "SUPER OVER DONE: " + m.getString("superSummary") + ".");
        finishMatch(g, m.optString("inn2SummaryFull"));
    }

    // ---------------- Batch A: rain (idea 2) ----------------

    /** Pre-rolled rain interruption for the chase. Applies the overs cut and
     *  the simplified-DLS target revision exactly once, inside bowlBall, so
     *  every sim loop and the save file see the same revised state.
     *  Returns true when the revision itself ends the match. */
    private static boolean maybeRain(Game g) throws Exception {
        JSONObject m = g.match;
        if (m.optBoolean("superMode") || m.optInt("inn") != 2 || m.optBoolean("rainDone")) return false;
        int at = m.optInt("rainAtBall", -1);
        int balls = m.optInt("balls");
        if (at < 0 || balls < at) return false;
        m.put("rainDone", true);
        int limit = m.optInt("ballsLimit", 120);
        int rem = limit - balls;
        int cut = Math.min((2 + R.nextInt(3)) * 6, rem - 30); // lose 2–4 overs, keep 5+ overs of chase
        if (cut < 6) {
            m.put("rainNote", "Brief shower — no overs lost");
            addComm(g, "🌧 A brief shower drifts over — covers on and off, no overs lost. Play resumes.");
            return false;
        }
        int newLimit = limit - cut;
        int wkts = m.optInt("wkts");
        // simplified DLS: resource remaining scales with overs left, discounted by wickets lost
        double wktsFactor = 1 - 0.06 * wkts;
        double resBefore = (rem / (double) limit) * wktsFactor;
        double resAfter = ((newLimit - balls) / (double) limit) * wktsFactor;
        int newTarget = (int) Math.floor(m.optInt("inn1Runs") * (1 - resBefore + resAfter)) + 1;
        if (newTarget < 1) newTarget = 1;
        m.put("ballsLimit", newLimit);
        m.put("target", newTarget);
        m.put("rainNote", "Rain: chase cut to " + (newLimit / 6) + " overs — revised target " + newTarget + " (DLS)");
        addComm(g, "🌧 RAIN BREAK — the covers are on! Play resumes with the chase cut to "
                + (newLimit / 6) + " overs. Revised target (DLS): " + newTarget + ".");
        if (m.optInt("runs") >= newTarget) {
            addComm(g, "The revision leaves " + m.getString("batTeam") + " already past the target — match over!");
            endInnings(g);
            return true;
        }
        return false;
    }

    /** v2: called from the innings-break screen's "Start the Chase" button. */
    public static void startChase(Game g) {
        try {
            JSONObject m = g.match;
            if (!"break".equals(m.optString("phase"))) return;
            String other = m.getString("inn1BatTeam").equals(g.userTeam)
                    ? m.getString("opp") : g.userTeam;
            setupInnings(g, 2, other);
            m.put("phase", "play");
            addComm(g, "The chase begins: " + other + " need " + m.optInt("target") + " to win.");
        } catch (Exception ignored) {}
    }

    // ---------------- Batch I (idea 83): scenario state injection ----------------

    /** Scripts a scenario's starting state through the engine's OWN
     *  structures: setupInnings builds real cards, fabricateInnings fills
     *  them with figures that sum exactly to the scripted score, and the
     *  match then plays with completely normal controls. Called by the
     *  Modes screen right after startMatch (the toss never happens — the
     *  state IS the toss). Rain is disabled: scripted states play clean. */
    public static void injectScenario(Game g, int scenarioId) {
        try {
            JSONObject m = g.match;
            if (m == null) return;
            String opp = m.getString("opp");
            m.put("rainAtBall", -1);
            m.put("rainDone", true);
            if (scenarioId == 3) { injectSuperOver(g); return; }
            // The Chase / The Collapse: the opponents batted first.
            // Defend the Last Over: the user batted first.
            String inn1Team = scenarioId == 1 ? g.userTeam : opp;
            int inn1Runs = scenarioId == 0 ? 179 : scenarioId == 1 ? 156 : 149;
            int inn1Wkts = scenarioId == 0 ? 7 : scenarioId == 1 ? 8 : 9;
            setupInnings(g, 1, inn1Team);
            fabricateInnings(g, inn1Runs, inn1Wkts, 120, 26, 19, 14, 11, true);
            stashInn1(g, inn1Team, inn1Runs, inn1Wkts);
            String chaseTeam = inn1Team.equals(g.userTeam) ? opp : g.userTeam;
            setupInnings(g, 2, chaseTeam);
            if (scenarioId == 0) fabricateInnings(g, 120, 6, 90, 34, 28, 12, 9, false);
            else if (scenarioId == 1) fabricateInnings(g, 145, 7, 114, 41, 22, 8, 5, false);
            else fabricateInnings(g, 45, 5, 36, 8, 6, 2, 3, false);
            m.put("phase", "play");
            pickBowler(g);
            addComm(g, "🎬 SCENARIO — " + Game.SCENARIO_TITLES[scenarioId] + ": " + Game.SCENARIO_DESCS[scenarioId]);
        } catch (Exception ignored) {}
    }

    /** The Super Over Decider: two fabricated, LEVEL innings (152 plays
     *  152), then the engine's own Super Over machinery takes over via
     *  the normal superbreak phase. */
    private static void injectSuperOver(Game g) throws Exception {
        JSONObject m = g.match;
        String opp = m.getString("opp");
        String inn1Team = Math.abs(opp.hashCode()) % 2 == 0 ? g.userTeam : opp;
        setupInnings(g, 1, inn1Team);
        fabricateInnings(g, 152, 8, 120, 31, 24, 9, 7, true);
        stashInn1(g, inn1Team, 152, 8);
        String inn2Team = inn1Team.equals(g.userTeam) ? opp : g.userTeam;
        setupInnings(g, 2, inn2Team);
        fabricateInnings(g, 152, 9, 120, 44, 31, 17, 12, true);
        m.put("inn2Runs", 152).put("inn2Wkts", 9).put("inn2Balls", 120);
        startSuperOver(g, g.shortFor(inn2Team) + " 152/9 (20 ov)");
        addComm(g, "🎬 SCENARIO — Super Over Decider: " + Game.SCENARIO_DESCS[3]);
    }

    /** Mirrors endInnings' innings-1 stash (minus the break pause and
     *  the stamina regen — a friendly never touches the season squad). */
    private static void stashInn1(Game g, String batTeam, int runs, int wkts) throws Exception {
        JSONObject m = g.match;
        m.put("inn1BatTeam", batTeam);
        m.put("inn1Runs", runs).put("inn1Wkts", wkts).put("inn1Balls", 120);
        m.put("inn1Summary", g.shortFor(batTeam) + " " + runs + "/" + wkts + " (20 ov)");
        m.put("target", runs + 1);
        m.put("inn1BatCard", m.getJSONArray("batCard"));
        m.put("inn1BowlCard", m.getJSONArray("bowlCard"));
        m.put("inn1Parts", m.getJSONArray("parts"));
        m.put("inn1Fow", m.getJSONArray("fow"));
        m.put("inn1OverRuns", m.getJSONArray("overRuns"));
        m.put("inn1Matchups", m.getJSONArray("matchups"));
        m.put("inn1OverBowlers", m.getJSONArray("overBowlers"));
    }

    /** Fills the CURRENT innings' cards with a coherent mid/final state:
     *  the first `wkts` cards are out (weighted shares of the remaining
     *  runs/balls), the not-out pair sits at indices wkts / wkts+1 on the
     *  given scores, and bowling figures, over-runs, FoW and partnerships
     *  all sum back to runs/wkts/balls. Bowler balls respect the 4-over
     *  cap (6-over cap in a 300-ball cup — unused by scenarios).
     *  closed=true appends the unbroken partnership (a finished innings);
     *  otherwise it is left live in pShip for endInnings to close. */
    private static void fabricateInnings(Game g, int runs, int wkts, int balls,
                                         int sRuns, int sBalls, int nsRuns, int nsBalls,
                                         boolean closed) throws Exception {
        JSONObject m = g.match;
        JSONArray bat = m.getJSONArray("batCard");
        JSONArray bowl = m.getJSONArray("bowlCard");
        int striker = wkts, nonStriker = wkts + 1;
        int extras = Math.min(6, Math.max(2, runs / 30));
        int dRuns = Math.max(0, runs - sRuns - nsRuns - extras);
        int dBalls = Math.max(0, balls - sBalls - nsBalls);
        int[] share = new int[Math.max(1, wkts)];
        int wsum = 0;
        for (int i = 0; i < wkts; i++) { share[i] = (wkts - i) + 2; wsum += share[i]; }
        JSONArray fow = new JSONArray();
        JSONArray parts = new JSONArray();
        int givenR = 0, givenB = 0, cum = 0;
        for (int i = 0; i < wkts; i++) {
            JSONObject c = bat.getJSONObject(i);
            int r = i == wkts - 1 ? dRuns - givenR
                    : (int) Math.round(dRuns * share[i] / (double) Math.max(1, wsum));
            int b = i == wkts - 1 ? dBalls - givenB
                    : Math.max(2, (int) Math.round(dBalls * share[i] / (double) Math.max(1, wsum)));
            givenR += r; givenB += b; cum += r;
            c.put("runs", r).put("balls", b).put("out", true).put("in", true);
            c.put("how", "b " + bowl.getJSONObject(i % bowl.length()).optString("name"));
            JSONObject fe = new JSONObject();
            fe.put("score", cum + extras * (i + 1) / Math.max(1, wkts)).put("wkts", i + 1)
                    .put("name", c.optString("name")).put("over", oversStrFull(givenB));
            fow.put(fe);
            JSONObject pe = new JSONObject();
            pe.put("pair", bat.getJSONObject(i).optString("name") + " & "
                    + bat.getJSONObject(Math.min(i + 1, bat.length() - 1)).optString("name"));
            pe.put("runs", r + (i == 0 ? extras / 2 : 0)).put("balls", b);
            parts.put(pe);
        }
        JSONObject sc = bat.getJSONObject(striker);
        sc.put("runs", sRuns).put("balls", sBalls).put("out", false).put("in", true);
        JSONObject nc = bat.getJSONObject(nonStriker);
        nc.put("runs", nsRuns).put("balls", nsBalls).put("out", false).put("in", true);
        if (closed) {
            JSONObject pe = new JSONObject();
            pe.put("pair", sc.optString("name") + " & " + nc.optString("name"));
            pe.put("runs", sRuns + nsRuns + extras - extras / 2).put("balls", sBalls + nsBalls);
            pe.put("unbroken", true);
            parts.put(pe);
            m.put("pShipRuns", 0).put("pShipBalls", 0);
        } else {
            m.put("pShipRuns", sRuns + nsRuns).put("pShipBalls", sBalls + nsBalls);
        }
        // bowling figures: overs dealt round the card (never back-to-back,
        // never past the over cap), wickets/runs pro-rata with the last
        // bowler taking the remainder so the sums are exact
        int cap = Math.max(6, m.optInt("ballsLimit", 120) / 5);
        int[] bBalls = new int[bowl.length()];
        JSONArray overBowlers = new JSONArray();
        JSONArray overRuns = new JSONArray();
        int fullOvers = balls / 6, rem = balls % 6;
        int prev = -1;
        for (int o = 0; o < fullOvers; o++) {
            int pick = -1;
            for (int k = 0; k < bowl.length(); k++) {
                int idx = (o + k) % bowl.length();
                if (idx != prev && bBalls[idx] + 6 <= cap) { pick = idx; break; }
            }
            if (pick < 0) pick = prev == 0 ? 1 : 0;
            bBalls[pick] += 6;
            prev = pick;
            overBowlers.put(bowl.getJSONObject(pick).optString("name"));
        }
        if (rem > 0) {
            int pick = -1;
            for (int k = 0; k < bowl.length(); k++) {
                int idx = (fullOvers + k) % bowl.length();
                if (idx != prev && bBalls[idx] + rem <= cap) { pick = idx; break; }
            }
            if (pick < 0) pick = prev == 0 ? 1 : 0;
            bBalls[pick] += rem;
            prev = pick;
        }
        int givenW = 0, givenC = 0;
        int concTarget = Math.max(0, runs - 2); // a couple of byes aren't the bowler's
        for (int i = 0; i < bowl.length(); i++) {
            JSONObject bc = bowl.getJSONObject(i);
            int w = i == bowl.length() - 1 ? wkts - givenW
                    : (int) Math.round(wkts * bBalls[i] / (double) Math.max(1, balls));
            int cn = i == bowl.length() - 1 ? concTarget - givenC
                    : (int) Math.round(concTarget * bBalls[i] / (double) Math.max(1, balls));
            givenW += w; givenC += cn;
            bc.put("balls", bBalls[i]).put("wkts", Math.max(0, w)).put("runs", Math.max(0, cn));
        }
        int givenO = 0;
        for (int o = 0; o < fullOvers; o++) {
            int or = o == fullOvers - 1 ? runs - givenO - (rem > 0 ? runs * rem / Math.max(1, balls) : 0)
                    : (int) Math.round(runs * 6.0 / Math.max(1, balls));
            givenO += or;
            overRuns.put(or);
        }
        if (rem > 0) overRuns.put(runs - givenO);
        m.put("runs", runs).put("wkts", wkts).put("balls", balls);
        m.put("striker", striker).put("nonStriker", nonStriker).put("nextIn", wkts + 2);
        m.put("fow", fow).put("parts", parts);
        m.put("overRuns", overRuns).put("overBowlers", overBowlers);
        m.put("prevBowler", prev >= 0 ? bowl.getJSONObject(prev).optString("name") : "");
        m.put("awaitBat", false);
    }

    private static void finishMatch(Game g, String inn2Summary) throws Exception {
        JSONObject m = g.match;
        // Batch I (ideas 82/83): a FRIENDLY (daily challenge / scenario)
        // skips appearances entirely — its full short-circuit lives below,
        // once the winner is known.
        boolean friendly = m.optInt("friendly") > 0;
        // Batch C (idea 21): appearances are credited FIRST — the post-match
        // bookkeeping below can remove a freshly-injured man from the XI, but
        // he still played this match and keeps his appearance.
        if (!friendly) StatsBook.recordAppearances(g);
        String inn1Team = m.getString("inn1BatTeam");
        String inn2Team = g.userTeam.equals(inn1Team) ? m.getString("opp") : g.userTeam;
        int r1 = m.optInt("inn1Runs"), w1 = m.optInt("inn1Wkts"), b1 = m.optInt("inn1Balls");
        // Batch A: after a Super Over, runs/wkts/balls hold SUPER numbers —
        // the real innings-2 figures were stashed as inn2Runs/inn2Wkts/inn2Balls.
        int r2 = m.has("inn2Runs") ? m.optInt("inn2Runs") : m.optInt("runs");
        int w2 = m.has("inn2Runs") ? m.optInt("inn2Wkts") : m.optInt("wkts");
        int b2 = m.has("inn2Runs") ? m.optInt("inn2Balls") : m.optInt("balls");
        String winner, margin;
        String superWinner = m.optString("superWinnerTeam", "");
        if (!superWinner.isEmpty()) {
            winner = superWinner;
            margin = "via Super Over (" + m.optString("superSummary") + ")";
        } else if (r2 > r1) {
            winner = inn2Team;
            margin = "by " + (10 - w2) + " wickets";
        } else if (r1 > r2) {
            winner = inn1Team;
            margin = "by " + (r1 - r2) + " runs";
        } else {
            winner = "";
            margin = "— match tied";
        }
        String summary = m.getString("inn1Summary") + " vs " + inn2Summary + " — " +
                (winner.isEmpty() ? "Match tied" : winner + " won " + margin)
                + (m.optBoolean("rainDone") && m.has("rainNote") ? " · " + m.optString("rainNote") : "");
        // Batch I: the exact winner ("" = tied) rides the match so Game's
        // context/prediction maths never has to guess it back.
        m.put("winnerTeam", winner);
        // Batch I (idea 85): Super Over Hero — the one badge a friendly may
        // also earn (the Super Over Decider scenario exists for it).
        if (!superWinner.isEmpty() && superWinner.equals(g.userTeam)) g.unlockAchievement("SUPERHERO");
        // Batch I (ideas 82/83): THE FRIENDLY SHORT-CIRCUIT. Nothing below
        // this line may run for a challenge/scenario match: no fixture
        // writeback (a synthetic friendly could otherwise false-match
        // today's real league fixture), no tables, no StatsBook or
        // tournament book, no records, no AI injuries, no watchlist, no
        // POTM money (display only), no morale/stamina/career effects.
        if (friendly) {
            computePotm(g, m, summary, true);
            g.finishFriendly(m, winner, summary);
            m.put("phase", "done");
            m.put("result", summary);
            m.put("userWon", winner.equals(g.userTeam));
            addComm(g, "FULL TIME: " + summary);
            return;
        }
        // write back into tables via the fixture (home/away order)
        boolean written = false;
        for (int i = 0; i < g.fixtures.length(); i++) {
            JSONObject f = g.fixtures.getJSONObject(i);
            if (!f.optBoolean("played") && f.optInt("day") == m.optInt("fixtureDay") && g.involvesUser(f)) {
                String home = f.getString("home"), away = f.getString("away");
                int hr, hb, hw, ar, ab, aw;
                if (home.equals(inn1Team)) { hr = r1; hb = b1; hw = w1; ar = r2; ab = b2; aw = w2; }
                else { hr = r2; hb = b2; hw = w2; ar = r1; ab = b1; aw = w1; }
                // Batch A: a Super Over verdict (or a still-tied Super Over)
                // decides the points when the scores finished level
                String decided = null;
                if (m.has("superWinnerTeam")) decided = winner;
                else if (r1 == r2 && m.optBoolean("superPlayed")) decided = "";
                g.applyResultDecided(home, away, hr, hb, hw, ar, ab, aw, decided);
                f.put("played", true);
                f.put("summary", summary);
                boolean userWon = winner.equals(g.userTeam);
                // Batch G (idea 64): the sponsor's 200+ objective tracks the user's own total
                g.noteSponsorTeamScore(inn1Team.equals(g.userTeam) ? r1 : r2);
                g.onUserMatchFinished(userWon, summary, f);
                written = true;
                break;
            }
        }
        // Batch E (ideas 41/42): a LIVE playoff tie writes back into the
        // bracket instead — the group tables are closed for the season
        if (!written && m.optBoolean("playoff")) {
            for (int i = 0; i < g.playoffFixtures.length(); i++) {
                JSONObject f = g.playoffFixtures.getJSONObject(i);
                if (!f.optBoolean("played") && m.optString("stageName").equals(f.optString("stage"))
                        && g.involvesUser(f)) {
                    String w = winner;
                    if (w.isEmpty()) {
                        // level even after the Super Over: the higher group
                        // seed advances (a playoff must produce a winner)
                        w = g.playoffSeedWinner(f);
                        winner = w;
                        summary = summary + " · " + w + " advance on group seeding";
                    }
                    f.put("played", true);
                    f.put("summary", summary);
                    f.put("winner", w);
                    boolean userWonP = w.equals(g.userTeam);
                    g.updateH2h(g.opponentOf(f), userWonP ? 1 : -1);
                    g.noteSponsorTeamScore(inn1Team.equals(g.userTeam) ? r1 : r2); // Batch G (idea 64)
                    g.onUserMatchFinished(userWonP, summary, f);
                    break;
                }
            }
        }
        // Batch F (idea 56): a LIVE cup tie writes back into the cup
        // bracket instead — group tables stay closed, exactly like playoffs
        if (!written && m.optBoolean("cup")) {
            for (int i = 0; i < g.cupFixtures.length(); i++) {
                JSONObject f = g.cupFixtures.getJSONObject(i);
                if (!f.optBoolean("played") && f.optInt("day") == m.optInt("fixtureDay") && g.involvesUser(f)) {
                    String w = winner;
                    if (w.isEmpty()) {
                        // level even after the Super Over: higher group seed advances
                        w = g.playoffSeedWinner(f);
                        winner = w;
                        summary = summary + " · " + w + " advance on group seeding";
                    }
                    f.put("played", true);
                    f.put("summary", summary);
                    f.put("winner", w);
                    boolean userWonC = w.equals(g.userTeam);
                    g.updateH2h(g.opponentOf(f), userWonC ? 1 : -1);
                    g.onUserMatchFinished(userWonC, summary, f);
                    written = true;
                    break;
                }
            }
        }
        // Batch F (idea 53): the AI club can pick up a knock in a live match too
        g.rollAiInjury(m.optString("opp"));
        // v2 watchlist: centuries and 5-fors from BOTH innings of this match
        g.watchlistCheckCards(m.optJSONArray("inn1BatCard"), m.optJSONArray("inn1BowlCard"), summary);
        g.watchlistCheckCards(m.optJSONArray("batCard"), m.optJSONArray("bowlCard"), summary);
        // Batch C (ideas 21/22/25/29): the record book — batting/bowling
        // credited from the innings cards (appearances were booked at the
        // top of finishMatch), performance morale + milestones inside
        StatsBook.recordMatch(g, m);
        // Batch I (idea 85): with career stats now credited, the player-stat
        // badges (Centurion Club / Five-Star) are judged the same night
        g.checkPlayerAchievements();
        // Batch E (ideas 43/48): the tournament book and the all-time
        // records book feed off the same full innings cards — Batch F: cup
        // matches are a different format and stay out of both books
        if (!m.optBoolean("cup")) {
            g.recordTournMatch(m);
            g.updateRecordsFromMatch(m);
        }
        // Batch A (idea 8): Player of the Match, with a ledgered bonus at home
        computePotm(g, m, summary);
        // Batch H (idea 77): the report was built during onUserMatchFinished
        // (before the POTM existed) — patch it in now
        g.noteLivePotm(m);
        // Batch E: for a playoff tie, park the POTM on the fixture (the
        // Trophy Ceremony reads the Final's) and drive the bracket on
        if (m.optBoolean("playoff")) {
            for (int i = 0; i < g.playoffFixtures.length(); i++) {
                JSONObject f = g.playoffFixtures.getJSONObject(i);
                if (f.optBoolean("played") && m.optString("stageName").equals(f.optString("stage"))) {
                    g.onPlayoffMatchFinished(f, m);
                    break;
                }
            }
        }
        // Batch F: for a cup tie, park the POTM on the fixture and drive
        // the cup bracket on (mirrors the playoff hook above)
        if (m.optBoolean("cup")) {
            for (int i = 0; i < g.cupFixtures.length(); i++) {
                JSONObject f = g.cupFixtures.getJSONObject(i);
                if (f.optBoolean("played") && f.optInt("day") == m.optInt("fixtureDay")) {
                    g.onCupMatchFinished(f, m);
                    break;
                }
            }
        }
        m.put("phase", "done");
        m.put("result", summary);
        m.put("userWon", winner.equals(g.userTeam));
        addComm(g, "FULL TIME: " + summary);
    }

    /** Batch A (idea 8): Player of the Match. Aggregates batting + bowling
     *  across both innings: score = runs + 22/wicket, with small bonuses for a
     *  fifty or a 3-for. A Lahore winner earns a +25 CF ledger bonus.
     *  Batch I: quiet = display-only for friendlies (no news, no POTM
     *  history, NO ledger bonus — the mode reward is the only money). */
    private static void computePotm(Game g, JSONObject m, String summary) {
        computePotm(g, m, summary, false);
    }

    private static void computePotm(Game g, JSONObject m, String summary, boolean quiet) {
        try {
            java.util.Map<String, int[]> stat = new java.util.HashMap<>(); // name -> [runs, ballsFaced, wkts, runsConceded]
            JSONArray[] bats = {m.optJSONArray("inn1BatCard"), m.optJSONArray("batCard")};
            JSONArray[] bowls = {m.optJSONArray("inn1BowlCard"), m.optJSONArray("bowlCard")};
            for (JSONArray bc : bats) {
                if (bc == null) continue;
                for (int i = 0; i < bc.length(); i++) {
                    JSONObject b = bc.getJSONObject(i);
                    int[] s = stat.get(b.optString("name"));
                    if (s == null) { s = new int[4]; stat.put(b.optString("name"), s); }
                    s[0] += b.optInt("runs");
                    s[1] += b.optInt("balls");
                }
            }
            for (JSONArray bw : bowls) {
                if (bw == null) continue;
                for (int i = 0; i < bw.length(); i++) {
                    JSONObject b = bw.getJSONObject(i);
                    int[] s = stat.get(b.optString("name"));
                    if (s == null) { s = new int[4]; stat.put(b.optString("name"), s); }
                    s[2] += b.optInt("wkts");
                    s[3] += b.optInt("runs");
                }
            }
            String bestName = "";
            double bestScore = -1;
            int[] best = null;
            for (java.util.Map.Entry<String, int[]> e : stat.entrySet()) {
                int[] s = e.getValue();
                double score = s[0] + s[2] * 22 + (s[0] >= 50 ? 8 : 0) + (s[2] >= 3 ? 6 : 0);
                if (score > bestScore) { bestScore = score; bestName = e.getKey(); best = s; }
            }
            if (best == null) return;
            StringBuilder desc = new StringBuilder();
            if (best[0] > 0 || best[2] == 0) desc.append(best[0]).append(" (").append(best[1]).append("b)");
            if (best[2] > 0) {
                if (desc.length() > 0) desc.append(" + ");
                desc.append(best[2]).append("/").append(best[3]);
            }
            m.put("potm", bestName);
            m.put("potmDesc", desc.toString());
            boolean userPlayer = false;
            for (int i = 0; i < g.players.length(); i++) {
                if (bestName.equals(g.player(i).optString("name"))) { userPlayer = true; break; }
            }
            m.put("potmUser", userPlayer);
            addComm(g, "🏆 Player of the Match: " + bestName + " — " + desc + ".");
            if (!quiet) {
                g.addNews("🏆 Player of the Match: " + bestName + " — " + desc + " (" + summary + ")");
                g.addPotm(bestName + " — " + desc + " vs " + m.optString("opp") + " (Season " + g.season + ")");
                if (userPlayer) g.ledgerCf(25, "Player of the Match bonus — " + bestName);
            }
        } catch (Exception ignored) {}
    }

    /** Batch A (idea 5): live win probability FOR THE USER, 0–100.
     *  Deliberately simple and transparent: innings 1 leans on projected vs a
     *  160 par score; the chase leans on expected remaining scoring (balls and
     *  wickets resource) vs the target. */
    public static int winPredictor(Game g) {
        try {
            JSONObject m = g.match;
            if (m == null) return 50;
            String phase = m.optString("phase");
            if ("done".equals(phase)) return m.optBoolean("userWon") ? 100 : 0;
            if ("toss".equals(phase)) return 50;
            boolean userBatting = g.userTeam.equals(m.optString("batTeam"));
            double pct;
            if (m.optBoolean("superMode")) {
                if (m.optInt("target", 0) > 0) {
                    int need = m.optInt("target") - m.optInt("runs");
                    int rem = Math.max(1, m.optInt("ballsLimit", 6) - m.optInt("balls"));
                    double batPct = need <= 0 ? 100 : Math.max(2, Math.min(98, 100.0 * rem / (need * 1.6 + rem)));
                    pct = userBatting ? batPct : 100 - batPct;
                } else {
                    double batPct = 50 + (m.optInt("runs") - 10) * 3.0;
                    pct = userBatting ? batPct : 100 - batPct;
                }
            } else if ("break".equals(phase) || m.optInt("inn") == 1) {
                int par = m.optInt("ballsLimit", 120) >= 300 ? 295 : 160; // Batch F: format par
                if (m.optInt("inn") == 1 && !"break".equals(phase)) {
                    double batPct = 50 + (projected(g) - par) * 0.35;
                    pct = userBatting ? batPct : 100 - batPct;
                } else { // innings break: judge the set total against par
                    boolean userChasing = !g.userTeam.equals(m.optString("inn1BatTeam"));
                    double batFirstPct = 50 + (m.optInt("inn1Runs") - par) * 0.35;
                    pct = userChasing ? 100 - batFirstPct : batFirstPct;
                }
            } else {
                int target = m.optInt("target");
                int runs = m.optInt("runs"), wkts = m.optInt("wkts");
                if (runs >= target) return userBatting ? 100 : 0;
                int remBalls = Math.max(0, m.optInt("ballsLimit", 120) - m.optInt("balls"));
                double resOvers = (remBalls / 6.0) * (1 - 0.055 * wkts);
                double expected = runs + resOvers * (m.optInt("ballsLimit", 120) >= 300 ? 6.3 : 8.2);
                // logistic on (expected final score − target); the spread
                // narrows as resources run out, so late-chase margins bite
                double s = 3.5 + 4.5 * Math.sqrt(Math.max(0.05, resOvers));
                double batPct = 100.0 / (1.0 + Math.exp(-(expected - target) / s));
                pct = userBatting ? batPct : 100 - batPct;
            }
            return (int) Math.max(1, Math.min(99, Math.round(pct)));
        } catch (Exception e) { return 50; }
    }

    // ---------------- derived numbers ----------------

    public static double crr(Game g) {
        try {
            JSONObject m = g.match;
            int balls = m.optInt("balls");
            if (balls == 0) return 0;
            return m.optInt("runs") * 6.0 / balls;
        } catch (Exception e) { return 0; }
    }

    public static int projected(Game g) {
        try {
            JSONObject m = g.match;
            int balls = m.optInt("balls"), runs = m.optInt("runs");
            if (m.optInt("inn") == 2 && !m.optBoolean("superMode")) return runs;
            if (balls == 0) return runs + 150;
            // Batch A: respect a rain-cut (or Super Over) balls limit
            int rem = Math.max(0, m.optInt("ballsLimit", 120) - balls);
            return runs + (int) Math.round(crr(g) * rem / 6.0);
        } catch (Exception e) { return 0; }
    }

    /** Simplified DLS par score for the chasing side at the current state. */
    public static int dlsPar(Game g) {
        try {
            JSONObject m = g.match;
            if (m.optInt("inn") != 2 || m.optBoolean("superMode")) return 0;
            int balls = m.optInt("balls"), wkts = m.optInt("wkts");
            int limit = m.optInt("ballsLimit", 120); // Batch A: rain-cut aware
            double oversRem = (limit - balls) / 6.0;
            double resource = 100.0 * (oversRem / (limit / 6.0)) * (1 - 0.085 * wkts);
            if (resource < 0) resource = 0;
            double used = 100.0 - resource;
            return (int) Math.round(m.optInt("inn1Runs") * used / 100.0);
        } catch (Exception e) { return 0; }
    }

    public static String oversStr(int ballsZeroBased) {
        return (ballsZeroBased / 6) + "." + (ballsZeroBased % 6);
    }

    public static String oversStrFull(int balls) {
        return (balls / 6) + "." + (balls % 6);
    }

    // ---------------- small helpers ----------------

    private static void swapStrike(JSONObject m) throws Exception {
        int s = m.optInt("striker"), ns = m.optInt("nonStriker");
        m.put("striker", ns);
        m.put("nonStriker", s);
    }

    private static void pushBall(Game g, String s) throws Exception {
        JSONObject m = g.match;
        JSONArray lb = m.optJSONArray("lastBalls");
        if (lb == null) lb = new JSONArray();
        lb.put(s);
        while (lb.length() > 12) lb.remove(0);
        m.put("lastBalls", lb);
    }

    public static void addComm(Game g, String line) {
        try {
            JSONObject m = g.match;
            JSONArray c = m.optJSONArray("comm");
            if (c == null) c = new JSONArray();
            JSONArray n = new JSONArray();
            n.put(line);
            for (int i = 0; i < Math.min(c.length(), 59); i++) n.put(c.getString(i));
            m.put("comm", n);
        } catch (Exception ignored) {}
    }

    private static String pick(String[] pool) {
        return pool[R.nextInt(pool.length)];
    }

    /** Batch J (idea 93): Roman Urdu commentary. The flag is an APP
     *  setting (Settings.commLang, in the ccm_settings prefs — it
     *  survives career resets), pushed in here by MainActivity at
     *  launch and whenever the Settings toggle flips, because the
     *  engine is static and holds no Context. pickComm swaps the main
     *  per-ball pools (dot/single/two/four/six/wicket + the milestone
     *  and same-over cluster lines in bowlBall); score strings, over
     *  summaries and result text stay English, as do other fixtures'
     *  generated summaries (they never pass through bowlBall). Live
     *  ball-by-ball, staged sims and Highlights all generate through
     *  bowlBall, so all three speak the chosen language. */
    public static boolean urduComm = false;

    private static String pickComm(String[] en, String[] ur) {
        return pick(urduComm ? ur : en);
    }

    private static final String[] DOT_UR = {
        "Swing aur miss! {bat} hawa mein ghooma, {bowl} ki ball nikal gayi.",
        "Dot ball — {bowl} ne seedhi tang ki, {bat} sirf rok saka.",
        "Koi run nahi. {bowl} ka dabao barqarar hai.",
        "Slow ball! {bat} ne aram se dekha aur chhor diya.",
        "Behtareen line, {bowl} ne {bat} ko bandh kar rakha hai.",
        "{bowl} ki gend tez nikli, {bat} be-bas reh gaya."};
    private static final String[] ONE_UR = {
        "{bat} ne gap mein dhakela — aik run asani se.",
        "Halka sa flick, {bat} ne aik run le liya.",
        "Tez single! {bat} ki call par dono bhaag paray.",
        "{bat} ne long-on ki taraf khela, sirf aik run.",
        "{bat} ne naram hathon se khela, single pakka."};
    private static final String[] TWO_UR = {
        "Kya running hai! {bat} ne gehre mein rakha aur do run daur liye.",
        "Do run — {bat} ne wide khela aur wapas ana asan raha."};
    private static final String[] FOUR_UR = {
        "CHAUKA! {bat} ne {bowl} ko covers se bahar phenk diya!",
        "Short ball, aur {bat} ne pull karke chauka jama diya!",
        "Khubsurat shot! {bat} ne mid-off ke upar se chauka mara.",
        "Kinara laga... aur ball boundary tak chali gayi! {bat} kismat wala.",
        "Kya timing hai — {bat} ka chauka, ball rukti hi nahi!"};
    private static final String[] SIX_UR = {
        "CHHAKKA! {bat} ne {bowl} ko long-on ke upar se stadium bahar bhej diya!",
        "Bahut bara chhakka! {bat} ne lambai pehle hi bhanp li thi.",
        "Saaf aur uncha — {bat} ne midwicket par zabardast chhakka jada!"};
    private static final String[] WICKET_UR = {
        "OUT! {bowl} ne kamaal kar diya, {bat} ko wapas jana padega.",
        "WICKET! {bat} gaya — crowd khushi se jhoom utha!",
        "Bari wicket! {bowl} ne {bat} ko phasaya, innings ko zor ka jhatka."};

    private static final String[] DOT = {
        "Beaten! {bat} swings and misses off {bowl}.",
        "Dot ball — {bowl} fires it in and {bat} can only block.",
        "No run. Tight, nagging line from {bowl}.",
        "Slower ball from {bowl}, {bat} watches it through."};
    private static final String[] ONE = {
        "{bat} nudges it into the gap — single taken.",
        "Worked off the pads by {bat}, one run.",
        "Quick single! Sharp running call from {bat}.",
        "{bat} pushes it to long-on for an easy one."};
    private static final String[] TWO = {
        "Good running! {bat} places it wide and they sprint back for two.",
        "Two runs — {bat} drives into the deep and hustles back."};
    private static final String[] FOUR = {
        "FOUR! {bat} creams {bowl} through the covers!",
        "Cracked away! Short from {bowl} and {bat} pulls it to the rope.",
        "Beautiful — {bat} lofts {bowl} over mid-off, one bounce for four.",
        "Edged... and away! Lucky boundary for {bat}."};
    private static final String[] SIX = {
        "SIX! Massive from {bat} — launched over long-on off {bowl}!",
        "HUGE! {bat} picks the length early and deposits it into the stands.",
        "Clean as a whistle — {bat} smokes {bowl} over midwicket for six."};
    private static final String[] WICKET = {
        "OUT! {bowl} strikes and {bat} has to walk back.",
        "GONE! Big wicket for {bowl} — {bat} departs.",
        "WICKET! The crowd erupts as {bat} goes."};
}
