package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Random;

/** Ball-by-ball T20 engine. All state lives in Game.match (JSON) so a match
 *  survives the app being closed mid-game. Tactics, player ratings and stamina
 *  all feed the outcome weights. */
public class MatchEngine {

    public static final String[] TACTICS = {"Defend", "Build", "Attack", "Slog"};
    public static final String[] RUNNING = {"Hold Ones", "Standard"};
    /** v2 field settings (used when the USER is bowling): 0 Attacking, 1 Balanced, 2 Defensive. */
    public static final String[] FIELD = {"Attacking", "Balanced", "Defensive"};

    private static final Random R = new Random();

    // ---------------- setup ----------------

    public static void startMatch(Game g, JSONObject fixture) {
        try {
            JSONObject m = new JSONObject();
            m.put("opp", g.opponentOf(fixture));
            m.put("fixtureDay", fixture.optInt("day"));
            m.put("home", Data.USER_TEAM.equals(fixture.optString("home")));
            m.put("phase", "toss");
            m.put("tactic", 1); // Build
            m.put("running", 1); // Standard
            m.put("field", 1); // Balanced (v2)
            m.put("shield", ""); // no shielded batter (v2)
            m.put("comm", new JSONArray());
            m.put("lastBalls", new JSONArray());
            g.match = m;
            addComm(g, "Toss time: Lahore Qalandars vs " + m.getString("opp") + ".");
        } catch (Exception ignored) {}
    }

    /** After the toss decision: set up innings 1. userBatFirst = Lahore bat first. */
    public static void beginInnings1(Game g, boolean userBatFirst) {
        try {
            JSONObject m = g.match;
            m.put("userBatFirst", userBatFirst);
            setupInnings(g, 1, userBatFirst ? Data.USER_TEAM : m.getString("opp"));
            m.put("phase", "play");
            addComm(g, (userBatFirst ? "Lahore bat first." : m.getString("opp") + " bat first.")
                    + " Play! First ball coming up.");
        } catch (Exception ignored) {}
    }

    private static void setupInnings(Game g, int inn, String batTeam) throws Exception {
        JSONObject m = g.match;
        String opp = m.getString("opp");
        String bowlTeam = batTeam.equals(Data.USER_TEAM) ? opp : Data.USER_TEAM;
        m.put("inn", inn);
        m.put("batTeam", batTeam);
        m.put("bowlTeam", bowlTeam);
        m.put("runs", 0);
        m.put("wkts", 0);
        m.put("balls", 0);
        m.put("striker", 0);
        m.put("nonStriker", 1);
        m.put("nextIn", 2);
        m.put("bowlRot", 0);
        m.put("prevBowler", "");
        m.put("lastBalls", new JSONArray());
        // batting card
        JSONArray bat = new JSONArray();
        if (batTeam.equals(Data.USER_TEAM)) {
            for (JSONObject p : g.xi()) {
                bat.put(card(p.getString("name"), p.optInt("bat"), p.optInt("bowl"), p.optInt("stam")));
            }
        } else {
            for (Object[] p : Data.xiFor(opp)) {
                bat.put(card((String) p[0], (Integer) p[1], (Integer) p[2], 85));
            }
        }
        m.put("batCard", bat);
        // bowling card: best 6 bowlers of the bowling team
        JSONArray bowl = new JSONArray();
        JSONArray src = new JSONArray();
        if (bowlTeam.equals(Data.USER_TEAM)) {
            for (JSONObject p : g.xi()) src.put(card(p.getString("name"), p.optInt("bat"), p.optInt("bowl"), p.optInt("stam")));
        } else {
            for (Object[] p : Data.xiFor(opp)) src.put(card((String) p[0], (Integer) p[1], (Integer) p[2], 85));
        }
        // simple selection sort by bowling desc, take 6
        for (int i = 0; i < src.length() && bowl.length() < 6; i++) {
            int best = -1, bestVal = -1;
            for (int j = 0; j < src.length(); j++) {
                JSONObject c = src.getJSONObject(j);
                if (c.optBoolean("picked")) continue;
                if (c.optInt("bowl") > bestVal) { bestVal = c.optInt("bowl"); best = j; }
            }
            if (best < 0) break;
            JSONObject c = src.getJSONObject(best);
            c.put("picked", true);
            JSONObject b = new JSONObject();
            b.put("name", c.getString("name"));
            b.put("bowl", c.optInt("bowl"));
            b.put("stam", c.optInt("stam", 85));
            b.put("balls", 0).put("runs", 0).put("wkts", 0);
            bowl.put(b);
        }
        m.put("bowlCard", bowl);
        pickBowler(g);
    }

    private static JSONObject card(String name, int bat, int bowl, int stam) throws Exception {
        JSONObject o = new JSONObject();
        o.put("name", name).put("bat", bat).put("bowl", bowl).put("stam", stam);
        o.put("runs", 0).put("balls", 0).put("out", false).put("how", "");
        return o;
    }

    private static void pickBowler(Game g) throws Exception {
        JSONObject m = g.match;
        JSONArray bowl = m.getJSONArray("bowlCard");
        String prev = m.optString("prevBowler");
        int rot = m.optInt("bowlRot", 0);
        for (int k = 0; k < bowl.length(); k++) {
            int idx = (rot + k) % bowl.length();
            JSONObject b = bowl.getJSONObject(idx);
            if (b.optInt("balls") < 24 && !b.getString("name").equals(prev)) {
                m.put("curBowler", idx);
                m.put("bowlRot", idx + 1);
                return;
            }
        }
        // fallback: anyone with balls left
        for (int i = 0; i < bowl.length(); i++) {
            if (bowl.getJSONObject(i).optInt("balls") < 24) { m.put("curBowler", i); return; }
        }
        m.put("curBowler", 0);
    }

    // ---------------- the ball ----------------

    /** Plays exactly one ball. Returns the commentary line for that ball. */
    public static String bowlBall(Game g) {
        try {
            JSONObject m = g.match;
            if (!"play".equals(m.optString("phase"))) return "";
            JSONArray bat = m.getJSONArray("batCard");
            JSONArray bowl = m.getJSONArray("bowlCard");
            JSONObject striker = bat.getJSONObject(m.optInt("striker"));
            JSONObject bowler = bowl.getJSONObject(m.optInt("curBowler"));

            double diff = (striker.optInt("bat") - bowler.optInt("bowl")) / 100.0;
            double w0 = 350, w1 = 320, w2 = 60, w3 = 5, w4 = 125, w6 = 55, wW = 58;
            switch (m.optInt("tactic", 1)) {
                case 0: wW *= 0.55; w4 *= 0.70; w6 *= 0.50; w0 *= 1.10; w1 *= 1.05; break; // Defend
                case 1: wW *= 0.90; w6 *= 0.90; break;                                     // Build
                case 2: wW *= 1.35; w4 *= 1.30; w6 *= 1.40; w0 *= 0.85; w2 *= 1.10; break; // Attack
                case 3: wW *= 1.80; w4 *= 1.35; w6 *= 2.00; w0 *= 0.80; w1 *= 0.80; break; // Slog
            }
            // v2 field setting — only the USER's bowling plan: Attacking hunts wickets
            // but leaks boundaries; Defensive dries up boundaries but wickets dry up too.
            if (Data.USER_TEAM.equals(m.optString("bowlTeam"))) {
                switch (m.optInt("field", 1)) {
                    case 0: wW *= 1.25; w4 *= 1.10; w6 *= 1.10; w0 *= 0.95; break; // Attacking
                    case 2: wW *= 0.75; w4 *= 0.85; w6 *= 0.80; w1 *= 1.05; break; // Defensive
                    default: break;                                                 // Balanced
                }
            }
            // v2 shield-a-batter: while shielded, the protected batter's dismissal
            // risk drops sharply (and below, he also gives up strike more often).
            boolean userBatting = Data.USER_TEAM.equals(m.optString("batTeam"));
            String shield = m.optString("shield", "");
            boolean shieldedOnStrike = userBatting && !shield.isEmpty()
                    && shield.equals(striker.optString("name"));
            if (shieldedOnStrike) wW *= 0.55;

            w4 *= (1 + diff * 0.8);
            w6 *= (1 + diff);
            wW *= (1 - diff * 0.7);
            w1 *= (1 + diff * 0.2);
            if (striker.optInt("stam", 85) < 50) wW *= 1.15;      // tired batter
            if (bowler.optInt("stam", 85) < 50) { w4 *= 1.2; w6 *= 1.2; } // tired bowler
            if (m.optInt("running", 1) == 0) { w2 *= 0.6; w1 *= 1.05; }   // Hold Ones
            int balls = m.optInt("balls");
            if (balls >= 102) { w4 *= 1.15; w6 *= 1.15; wW *= 1.10; }     // death overs
            if (m.optInt("inn") == 2) {                                    // chase pressure
                int target = m.optInt("target");
                int need = target - m.optInt("runs");
                int remBalls = 120 - balls;
                if (remBalls > 0) {
                    double req = need * 6.0 / remBalls;
                    if (req > 10) { wW *= 1.10; w4 *= 1.10; w6 *= 1.10; }
                    if (req > 13) { wW *= 1.10; w6 *= 1.15; }
                }
            }

            double total = w0 + w1 + w2 + w3 + w4 + w6 + wW;
            double roll = R.nextDouble() * total;
            int outcome; // -1 wicket, else runs
            if ((roll -= w0) < 0) outcome = 0;
            else if ((roll -= w1) < 0) outcome = 1;
            else if ((roll -= w2) < 0) outcome = 2;
            else if ((roll -= w3) < 0) outcome = 3;
            else if ((roll -= w4) < 0) outcome = 4;
            else if ((roll -= w6) < 0) outcome = 6;
            else outcome = -1;

            int runs = m.optInt("runs");
            int wkts = m.optInt("wkts");
            balls++;
            striker.put("balls", striker.optInt("balls") + 1);
            bowler.put("balls", bowler.optInt("balls") + 1);
            String batName = striker.getString("name");
            String bowlName = bowler.getString("name");
            String comm;

            if (outcome == -1) {
                wkts++;
                boolean runOut = R.nextDouble() < (m.optInt("running", 1) == 0 ? 0.04 : 0.10);
                String how = runOut ? "run out" : pick(new String[]{"b " + bowlName, "c sub b " + bowlName, "lbw b " + bowlName, "c & b " + bowlName});
                striker.put("out", true);
                striker.put("how", how);
                bowler.put("runs", bowler.optInt("runs")); // no run on a bowled/caught wicket
                if (!runOut) bowler.put("wkts", bowler.optInt("wkts") + 1);
                else { runs += 0; }
                comm = pick(WICKET) .replace("{bat}", batName).replace("{bowl}", bowlName)
                        + " (" + how + ") — " + batName + " scored " + striker.optInt("runs") + " off " + striker.optInt("balls") + ".";
                pushBall(g, "W");
                int next = m.optInt("nextIn");
                if (next < bat.length()) {
                    m.put("striker", next);
                    m.put("nextIn", next + 1);
                }
            } else {
                runs += outcome;
                striker.put("runs", striker.optInt("runs") + outcome);
                bowler.put("runs", bowler.optInt("runs") + outcome);
                pushBall(g, String.valueOf(outcome));
                String[] pool = outcome == 0 ? DOT : outcome == 1 ? ONE : outcome == 2 ? TWO
                        : outcome == 3 ? ONE : outcome == 4 ? FOUR : SIX;
                comm = pick(pool).replace("{bat}", batName).replace("{bowl}", bowlName);
                if (outcome % 2 == 1) swapStrike(m);
                // shield rotation: on even-run balls the shielded batter often
                // hands strike to his partner, so he faces fewer balls overall
                else if (shieldedOnStrike && balls % 6 != 0 && R.nextDouble() < 0.5) swapStrike(m);
                int sr = striker.optInt("runs");
                if (sr == 50 || sr == 100) comm += " " + sr + " up for " + batName + "! The crowd loves it.";
            }

            m.put("runs", runs);
            m.put("wkts", wkts);
            m.put("balls", balls);
            String line = oversStr(balls - 1) + " — " + comm;
            addComm(g, line);

            // over complete?
            if (balls % 6 == 0 && balls < 120 && wkts < 10) {
                swapStrike(m);
                m.put("prevBowler", bowlName);
                pickBowler(g);
                addComm(g, "End of over " + (balls / 6) + ": " + Data.shortName(m.getString("batTeam"))
                        + " " + runs + "/" + wkts + ".");
            }

            // Innings over? Multi-wicket overs are safe here: each wicket advances
            // nextIn independently, every wicket gets its own commentary line, and
            // endInnings fires the moment wkts hits 10 — even mid-over. All sim
            // loops re-check phase/inn after every ball, so they exit cleanly.
            boolean chaseDone = m.optInt("inn") == 2 && runs >= m.optInt("target");
            if (wkts >= 10 || balls >= 120 || chaseDone) endInnings(g);
            return line;
        } catch (Exception e) {
            return "";
        }
    }

    public static void simOver(Game g) {
        try {
            JSONObject m = g.match;
            int startBalls = m.optInt("balls");
            int target = startBalls + (6 - startBalls % 6);
            int guard = 0;
            while ("play".equals(m.optString("phase")) && m.optInt("balls") < target && guard++ < 10) {
                bowlBall(g);
                // stop if innings changed
                if (m.optInt("balls") == 0) break;
            }
        } catch (Exception ignored) {}
    }

    public static void simInnings(Game g) {
        int guard = 0;
        try {
            JSONObject m = g.match;
            int inn = m.optInt("inn");
            while ("play".equals(m.optString("phase")) && m.optInt("inn") == inn && guard++ < 130) {
                bowlBall(g);
            }
        } catch (Exception ignored) {}
    }

    public static void simMatch(Game g) {
        int guard = 0;
        try {
            while (g.match != null && "play".equals(g.match.optString("phase")) && guard++ < 300) {
                bowlBall(g);
            }
        } catch (Exception ignored) {}
    }

    private static void endInnings(Game g) throws Exception {
        JSONObject m = g.match;
        int runs = m.optInt("runs"), wkts = m.optInt("wkts"), balls = m.optInt("balls");
        String batTeam = m.getString("batTeam");
        String summary = Data.shortName(batTeam) + " " + runs + "/" + wkts + " (" + oversStrFull(balls) + " ov)";
        if (m.optInt("inn") == 1) {
            m.put("inn1BatTeam", batTeam);
            m.put("inn1Runs", runs).put("inn1Wkts", wkts).put("inn1Balls", balls);
            m.put("inn1Summary", summary);
            m.put("target", runs + 1);
            // keep innings-1 cards for the full-time scorecard + watchlist checks (v2)
            m.put("inn1BatCard", m.getJSONArray("batCard"));
            m.put("inn1BowlCard", m.getJSONArray("bowlCard"));
            // v2 INNINGS BREAK: the match PAUSES here (Sim modes stop too, because
            // every sim loop is gated on phase == "play"). Both XIs recover a
            // little; the user's squad stamina gain is the persistent one.
            for (JSONObject p : g.xi()) {
                p.put("stam", Math.min(100, p.optInt("stam") + Game.BREAK_REGEN));
            }
            m.put("phase", "break");
            addComm(g, "Innings break: " + summary + ". Target: " + (runs + 1)
                    + ". Players recover +" + Game.BREAK_REGEN + " stamina.");
        } else {
            finishMatch(g, summary);
        }
    }

    /** v2: called from the innings-break screen's "Start the Chase" button. */
    public static void startChase(Game g) {
        try {
            JSONObject m = g.match;
            if (!"break".equals(m.optString("phase"))) return;
            String other = m.getString("inn1BatTeam").equals(Data.USER_TEAM)
                    ? m.getString("opp") : Data.USER_TEAM;
            setupInnings(g, 2, other);
            m.put("phase", "play");
            addComm(g, "The chase begins: " + other + " need " + m.optInt("target") + " to win.");
        } catch (Exception ignored) {}
    }

    private static void finishMatch(Game g, String inn2Summary) throws Exception {
        JSONObject m = g.match;
        String inn1Team = m.getString("inn1BatTeam");
        String inn2Team = m.getString("batTeam");
        int r1 = m.optInt("inn1Runs"), w1 = m.optInt("inn1Wkts"), b1 = m.optInt("inn1Balls");
        int r2 = m.optInt("runs"), w2 = m.optInt("wkts"), b2 = m.optInt("balls");
        String winner, margin;
        if (r2 > r1) {
            winner = inn2Team;
            margin = "by " + (10 - w2) + " wickets";
        } else if (r1 > r2) {
            winner = inn1Team;
            margin = "by " + (r1 - r2) + " runs";
        } else {
            winner = "";
            margin = "— match tied";
        }
        String summary = m.getString("inn1Summary") + " vs " + inn2Summary + " — " +
                (winner.isEmpty() ? "Match tied" : winner + " won " + margin);
        // write back into tables via the fixture (home/away order)
        for (int i = 0; i < g.fixtures.length(); i++) {
            JSONObject f = g.fixtures.getJSONObject(i);
            if (!f.optBoolean("played") && f.optInt("day") == m.optInt("fixtureDay") && Game.involvesUser(f)) {
                String home = f.getString("home"), away = f.getString("away");
                int hr, hb, hw, ar, ab, aw;
                if (home.equals(inn1Team)) { hr = r1; hb = b1; hw = w1; ar = r2; ab = b2; aw = w2; }
                else { hr = r2; hb = b2; hw = w2; ar = r1; ab = b1; aw = w1; }
                g.applyResult(home, away, hr, hb, hw, ar, ab, aw);
                f.put("played", true);
                f.put("summary", summary);
                boolean userWon = winner.equals(Data.USER_TEAM);
                g.onUserMatchFinished(userWon, summary, f);
                break;
            }
        }
        // v2 watchlist: centuries and 5-fors from BOTH innings of this match
        g.watchlistCheckCards(m.optJSONArray("inn1BatCard"), m.optJSONArray("inn1BowlCard"), summary);
        g.watchlistCheckCards(m.optJSONArray("batCard"), m.optJSONArray("bowlCard"), summary);
        m.put("phase", "done");
        m.put("result", summary);
        m.put("userWon", winner.equals(Data.USER_TEAM));
        addComm(g, "FULL TIME: " + summary);
    }

    // ---------------- derived numbers ----------------

    public static double crr(Game g) {
        try {
            JSONObject m = g.match;
            int balls = m.optInt("balls");
            if (balls == 0) return 0;
            return m.optInt("runs") * 6.0 / balls;
        } catch (Exception e) { return 0; }
    }

    public static int projected(Game g) {
        try {
            JSONObject m = g.match;
            int balls = m.optInt("balls"), runs = m.optInt("runs");
            if (m.optInt("inn") == 2) return runs;
            if (balls == 0) return runs + 150;
            return runs + (int) Math.round(crr(g) * (120 - balls) / 6.0);
        } catch (Exception e) { return 0; }
    }

    /** Simplified DLS par score for the chasing side at the current state. */
    public static int dlsPar(Game g) {
        try {
            JSONObject m = g.match;
            if (m.optInt("inn") != 2) return 0;
            int balls = m.optInt("balls"), wkts = m.optInt("wkts");
            double oversRem = (120 - balls) / 6.0;
            double resource = 100.0 * (oversRem / 20.0) * (1 - 0.085 * wkts);
            if (resource < 0) resource = 0;
            double used = 100.0 - resource;
            return (int) Math.round(m.optInt("inn1Runs") * used / 100.0);
        } catch (Exception e) { return 0; }
    }

    public static String oversStr(int ballsZeroBased) {
        return (ballsZeroBased / 6) + "." + (ballsZeroBased % 6);
    }

    public static String oversStrFull(int balls) {
        return (balls / 6) + "." + (balls % 6);
    }

    // ---------------- small helpers ----------------

    private static void swapStrike(JSONObject m) throws Exception {
        int s = m.optInt("striker"), ns = m.optInt("nonStriker");
        m.put("striker", ns);
        m.put("nonStriker", s);
    }

    private static void pushBall(Game g, String s) throws Exception {
        JSONObject m = g.match;
        JSONArray lb = m.optJSONArray("lastBalls");
        if (lb == null) lb = new JSONArray();
        lb.put(s);
        while (lb.length() > 12) lb.remove(0);
        m.put("lastBalls", lb);
    }

    public static void addComm(Game g, String line) {
        try {
            JSONObject m = g.match;
            JSONArray c = m.optJSONArray("comm");
            if (c == null) c = new JSONArray();
            JSONArray n = new JSONArray();
            n.put(line);
            for (int i = 0; i < Math.min(c.length(), 59); i++) n.put(c.getString(i));
            m.put("comm", n);
        } catch (Exception ignored) {}
    }

    private static String pick(String[] pool) {
        return pool[R.nextInt(pool.length)];
    }

    private static final String[] DOT = {
        "Beaten! {bat} swings and misses off {bowl}.",
        "Dot ball — {bowl} fires it in and {bat} can only block.",
        "No run. Tight, nagging line from {bowl}.",
        "Slower ball from {bowl}, {bat} watches it through."};
    private static final String[] ONE = {
        "{bat} nudges it into the gap — single taken.",
        "Worked off the pads by {bat}, one run.",
        "Quick single! Sharp running call from {bat}.",
        "{bat} pushes it to long-on for an easy one."};
    private static final String[] TWO = {
        "Good running! {bat} places it wide and they sprint back for two.",
        "Two runs — {bat} drives into the deep and hustles back."};
    private static final String[] FOUR = {
        "FOUR! {bat} creams {bowl} through the covers!",
        "Cracked away! Short from {bowl} and {bat} pulls it to the rope.",
        "Beautiful — {bat} lofts {bowl} over mid-off, one bounce for four.",
        "Edged... and away! Lucky boundary for {bat}."};
    private static final String[] SIX = {
        "SIX! Massive from {bat} — launched over long-on off {bowl}!",
        "HUGE! {bat} picks the length early and deposits it into the stands.",
        "Clean as a whistle — {bat} smokes {bowl} over midwicket for six."};
    private static final String[] WICKET = {
        "OUT! {bowl} strikes and {bat} has to walk back.",
        "GONE! Big wicket for {bowl} — {bat} departs.",
        "WICKET! The crowd erupts as {bat} goes."};
}
