package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Professional Pack P3 (v16): the PURE half of the broadcast match
 *  centre — pre-match comparison numbers, the ball-by-ball timeline
 *  model, the win-% graph series + turning point, full-time top
 *  performers and derived bowling maidens. No android imports, so
 *  every number here is desktop-tested exactly as it ships.
 *
 *  Data honesty notes:
 *   - The engine persists per-over runs (overRuns) and fall-of-wickets
 *     for BOTH innings, but only the LAST 12 ball outcomes (lastBalls,
 *     trimmed by MatchEngine.pushBall). The timeline therefore shows
 *     real ball chips where lastBalls reaches, and an honest aggregate
 *     (over runs + wicket chips) for earlier overs — never invented
 *     ball outcomes.
 *   - The win-% series is recorded by MatchEngine.recordWp (a
 *     presentation hook: one winPredictor value per completed over,
 *     riding in the match object like every other match field; the
 *     engine's numbers never read it back).
 *   - Maidens are DERIVED, not tracked: an over counts as a maiden
 *     for its bowler when overBowlers[i] is him and overRuns[i] == 0
 *     (the engine has no extras, so a scoreless over is a maiden). */
public class MatchCentre {

    // ---------------- suggestion 26: pre-match comparison -----------

    public static final String[] COMPARE_LABELS = {
            "Top-order batting", "Bowling attack", "All-round strength",
            "Form (last 5)", "Squad depth"};

    private static int ratingFor(String role, int bat, int bowl) {
        // mirrors Game.rating(JSONObject) for the Data.squadFor rows
        if ("Bat".equals(role)) return (int) (bat * 0.85 + bowl * 0.15);
        if ("Bowl".equals(role)) return (int) (bowl * 0.85 + bat * 0.15);
        if ("WK".equals(role)) return (int) (bat * 0.9 + bowl * 0.1) + 2;
        return (bat + bowl) / 2 + 3; // AR
    }

    private static int topAvg(List<Integer> vals, int n) {
        if (vals.isEmpty()) return 0;
        List<Integer> s = new ArrayList<>(vals);
        Collections.sort(s, Collections.reverseOrder());
        int k = Math.min(n, s.size()), sum = 0;
        for (int i = 0; i < k; i++) sum += s.get(i);
        return Math.round(sum / (float) k);
    }

    private static int tailAvg(List<Integer> ratings) {
        // squad depth: the men ranked 12th and below by rating
        if (ratings.isEmpty()) return 0;
        List<Integer> s = new ArrayList<>(ratings);
        Collections.sort(s, Collections.reverseOrder());
        if (s.size() <= 11) return topAvg(s, s.size());
        int sum = 0, n = 0;
        for (int i = 11; i < s.size(); i++) { sum += s.get(i); n++; }
        return Math.round(sum / (float) n);
    }

    /** Last-5 form as a 0–100 score: a win is a full share, a tie half.
     *  No matches played yet reads as a neutral 50. */
    public static int formScore(String form) {
        if (form == null || form.trim().isEmpty()) return 50;
        String[] parts = form.trim().split("\\s+");
        double pts = 0;
        int n = 0;
        for (String p : parts) {
            if (p.isEmpty()) continue;
            n++;
            if ("W".equals(p)) pts += 1;
            else if ("T".equals(p)) pts += 0.5;
        }
        if (n == 0) return 50;
        return Math.round((float) (pts / n) * 100f);
    }

    /** The five comparison rows for userTeam vs opp:
     *  [{label, us, them}] with every value on a 0–100 scale, computed
     *  from the two real squads (the user's live player objects, the
     *  opponent's Data.squadFor 18) and both clubs' recent form. */
    public static JSONArray comparison(Game g, String opp) {
        JSONArray out = new JSONArray();
        try {
            List<Integer> uBat = new ArrayList<>(), uBowl = new ArrayList<>(),
                    uRate = new ArrayList<>();
            for (int i = 0; i < g.players.length(); i++) {
                JSONObject p = g.player(i);
                uBat.add(p.optInt("bat"));
                uBowl.add(p.optInt("bowl"));
                uRate.add(Game.rating(p));
            }
            List<Integer> oBat = new ArrayList<>(), oBowl = new ArrayList<>(),
                    oRate = new ArrayList<>();
            Object[][] rows = Data.squadFor(opp);
            if (rows != null) {
                for (Object[] r : rows) {
                    int bat = (Integer) r[2], bowl = (Integer) r[3];
                    oBat.add(bat);
                    oBowl.add(bowl);
                    oRate.add(ratingFor((String) r[1], bat, bowl));
                }
            }
            int[][] vals = {
                    {topAvg(uBat, 5), topAvg(oBat, 5)},
                    {topAvg(uBowl, 5), topAvg(oBowl, 5)},
                    {topAvg(uRate, 11), topAvg(oRate, 11)},
                    {formScore(g.oppRecentForm(g.userTeam)), formScore(g.oppRecentForm(opp))},
                    {tailAvg(uRate), tailAvg(oRate)},
            };
            for (int i = 0; i < COMPARE_LABELS.length; i++) {
                JSONObject row = new JSONObject();
                row.put("label", COMPARE_LABELS[i]);
                row.put("us", vals[i][0]);
                row.put("them", vals[i][1]);
                out.put(row);
            }
        } catch (Exception ignored) {}
        return out;
    }

    // ---------------- suggestion 22: innings timeline ---------------

    /** FoW "over" strings are oversStrFull(ballsAtFall): "12.2" means
     *  the wicket fell on ball 74. Returns the 0-based over index. */
    public static int fowOverIndex(String overStr) {
        try {
            int dot = overStr.indexOf('.');
            int a = Integer.parseInt(overStr.substring(0, dot));
            int b = Integer.parseInt(overStr.substring(dot + 1));
            int ballsAtFall = a * 6 + b;
            return Math.max(0, (ballsAtFall - 1) / 6);
        } catch (Exception e) { return 0; }
    }

    /** One entry per over: {over (1-based), runs, wkts, names[], balls[],
     *  known}. balls holds the real outcomes where lastBalls reaches
     *  (the final min(12, ballsBowled) balls of the innings), "" for a
     *  ball that was bowled but whose outcome is no longer stored, and
     *  the array is simply shorter for a part-bowled final over.
     *  known == every ball of the over has a stored outcome. */
    public static JSONArray timeline(JSONArray overRuns, JSONArray fow,
                                     JSONArray lastBalls, int ballsBowled) {
        JSONArray out = new JSONArray();
        try {
            int overs = overRuns == null ? 0 : overRuns.length();
            overs = Math.max(overs, (ballsBowled + 5) / 6);
            int stored = lastBalls == null ? 0 : lastBalls.length();
            int coverStart = ballsBowled - stored + 1; // 1-based ball no.
            for (int o = 0; o < overs; o++) {
                JSONObject ov = new JSONObject();
                ov.put("over", o + 1);
                ov.put("runs", overRuns == null ? 0 : overRuns.optInt(o));
                JSONArray names = new JSONArray();
                if (fow != null) {
                    for (int i = 0; i < fow.length(); i++) {
                        JSONObject f = fow.getJSONObject(i);
                        if (fowOverIndex(f.optString("over")) == o) names.put(f.optString("name"));
                    }
                }
                ov.put("wkts", names.length());
                ov.put("names", names);
                JSONArray balls = new JSONArray();
                boolean known = ballsBowled > 0;
                int from = o * 6 + 1, to = Math.min(o * 6 + 6, ballsBowled);
                for (int bn = from; bn <= to; bn++) {
                    if (lastBalls != null && bn >= coverStart) {
                        balls.put(lastBalls.optString(bn - coverStart));
                    } else {
                        balls.put("");
                        known = false;
                    }
                }
                ov.put("balls", balls);
                ov.put("known", known && balls.length() > 0);
                out.put(ov);
            }
        } catch (Exception ignored) {}
        return out;
    }

    // ---------------- suggestion 25: win-% series + turning point ---

    /** The combined graph series for a match: innings 1's recorded
     *  points, then the current innings' — or, at the break / in
     *  innings 2, inn1Wp followed by wpSeries. */
    public static JSONArray graphSeries(JSONObject m) {
        JSONArray out = new JSONArray();
        if (m == null) return out;
        try {
            String phase = m.optString("phase");
            JSONArray cur = m.optJSONArray("wpSeries");
            JSONArray i1 = m.optJSONArray("inn1Wp");
            if ("break".equals(phase)) {
                // wpSeries still holds innings 1's points here (the
                // chase has not been set up yet) — take either, once
                JSONArray s = i1 != null && i1.length() > 0 ? i1 : cur;
                if (s != null) for (int i = 0; i < s.length(); i++) out.put(s.optInt(i));
                return out;
            }
            if (m.optInt("inn") == 2 || "done".equals(phase)) {
                if (i1 != null) for (int i = 0; i < i1.length(); i++) out.put(i1.optInt(i));
                JSONArray i2 = m.optJSONArray("inn2Wp");
                if (i2 != null && i2.length() > 0) {
                    for (int i = 0; i < i2.length(); i++) out.put(i2.optInt(i));
                    return out;
                }
            }
            if (cur != null) for (int i = 0; i < cur.length(); i++) out.put(cur.optInt(i));
        } catch (Exception ignored) {}
        return out;
    }

    public static int[] toIntArray(JSONArray a) {
        if (a == null) return new int[0];
        int[] out = new int[a.length()];
        for (int i = 0; i < a.length(); i++) out[i] = a.optInt(i);
        return out;
    }

    /** The over where the user's win chance swung most, across both
     *  innings' series (measured from a 50% start, point to point).
     *  Returns {inn, over, from, to, swing} or null when there is no
     *  recorded swing at all. */
    public static JSONObject turningPoint(JSONArray inn1, JSONArray inn2) {
        try {
            int prev = 50, bestSwing = 0;
            JSONObject best = null;
            JSONArray[] pools = {inn1, inn2};
            for (int inn = 0; inn < pools.length; inn++) {
                JSONArray s = pools[inn];
                if (s == null) continue;
                for (int i = 0; i < s.length(); i++) {
                    int v = s.optInt(i);
                    int swing = Math.abs(v - prev);
                    if (swing > bestSwing) {
                        bestSwing = swing;
                        best = new JSONObject();
                        best.put("inn", inn + 1);
                        best.put("over", i + 1);
                        best.put("from", prev);
                        best.put("to", v);
                        best.put("swing", swing);
                    }
                    prev = v;
                }
            }
            return best;
        } catch (Exception e) { return null; }
    }

    // ---------------- suggestion 28: top performers -----------------

    /** Top 2 batters (runs, then fewer balls) and the top bowler
     *  (wickets, then fewer runs) across both innings' cards of a
     *  finished (or in-progress) match object. */
    public static JSONObject topPerformers(JSONObject m) {
        JSONObject out = new JSONObject();
        try {
            List<JSONObject> bats = new ArrayList<>(), bowls = new ArrayList<>();
            collectCards(m.optJSONArray("inn1BatCard"), bats, true);
            collectCards(m.optJSONArray("batCard"), bats, true);
            collectCards(m.optJSONArray("inn1BowlCard"), bowls, false);
            collectCards(m.optJSONArray("bowlCard"), bowls, false);
            Collections.sort(bats, (a, b) -> {
                int d = b.optInt("runs") - a.optInt("runs");
                return d != 0 ? d : a.optInt("balls") - b.optInt("balls");
            });
            Collections.sort(bowls, (a, b) -> {
                int d = b.optInt("wkts") - a.optInt("wkts");
                return d != 0 ? d : a.optInt("runs") - b.optInt("runs");
            });
            JSONArray tb = new JSONArray();
            for (int i = 0; i < Math.min(2, bats.size()); i++) tb.put(bats.get(i));
            out.put("bats", tb);
            if (!bowls.isEmpty()) out.put("bowl", bowls.get(0));
        } catch (Exception ignored) {}
        return out;
    }

    private static void collectCards(JSONArray card, List<JSONObject> into, boolean batting) {
        if (card == null) return;
        try {
            for (int i = 0; i < card.length(); i++) {
                JSONObject c = card.getJSONObject(i);
                if (batting && !c.optBoolean("in") && c.optInt("balls") == 0) continue; // never batted
                if (!batting && c.optInt("balls") == 0) continue;                    // never bowled
                into.add(c);
            }
        } catch (Exception ignored) {}
    }

    // ---------------- suggestion 27: derived maidens ----------------

    /** Completed overs bowled by `name` in which no run was scored. */
    public static int maidensFor(JSONArray overBowlers, JSONArray overRuns, String name) {
        if (overBowlers == null || overRuns == null || name == null) return 0;
        int n = 0;
        int lim = Math.min(overBowlers.length(), overRuns.length());
        for (int i = 0; i < lim; i++) {
            if (name.equals(overBowlers.optString(i)) && overRuns.optInt(i) == 0) n++;
        }
        return n;
    }
}
