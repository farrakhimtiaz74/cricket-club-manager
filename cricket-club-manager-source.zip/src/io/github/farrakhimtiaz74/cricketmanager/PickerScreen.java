package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Batch F (ideas 51/52): the new-career team picker. Shown on first
 * launch (no save) and after a confirmed Profile reset — an existing
 * career is never interrupted by it. Each club card shows its group,
 * strength, captain, star men, home ground, biggest rival and starting
 * Club Cash; the custom-club card builds a brand-new identity that
 * takes Lahore Qalandars' league slot with their squad rebranded. */
public class PickerScreen {

 private static final String[] TEAMS = {
 "Lahore Qalandars", "Karachi Kings", "Multan Sultans", "Islamabad United",
 "Peshawar Zalmi", "Quetta Gladiators", "Sialkot Stallions", "Hyderabad Hawks"};

 public static View build(final MainActivity act) {
 LinearLayout root = Ui.col(act);
 LinearLayout head = Ui.card(act);
 head.addView(Ui.gold(act, "NEW CAREER", 13));
 head.addView(Ui.h1(act, "Choose Your Club"));
 head.addView(Ui.small(act, "Eight clubs, one hot seat. Every club brings its full 18-man squad, "
 + "its own captain, home ground and biggest rival. Starting Club Cash is scaled to squad "
 + "strength — a stronger squad starts with a little more in the bank."));
 root.addView(head);
 root.addView(quickStartCard(act)); // P5 (suggestion 42)
 root.addView(settingsCard(act)); // Batch I (ideas 81/90)
 for (final String team : TEAMS) root.addView(teamCard(act, team));
 root.addView(customCard(act));
 root.addView(Ui.small(act, "You can start over with a different club any time from Profile → Reset Career."));
 return root;
 }

 /** P5 (suggestion 42): Quick Start — the default career in ONE tap.
 * It drives the exact same path as picking Lahore by hand below:
 * pickerDifficulty is forced to Manager (1) and hardcore off, then
 * startCareer() stamps them — so a Quick Start career is identical
 * in every default to a manual Lahore pick on Manager. The full
 * picker (all 8 clubs, difficulty, hardcore, custom team) stays
 * right below for everyone else. */
 private static View quickStartCard(final MainActivity act) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "FASTEST WAY IN", 13));
 card.addView(Ui.h2(act, "Quick Start"));
 card.addView(Ui.small(act, "One tap and you are managing: Lahore Qalandars on Manager difficulty, standard rules. "
 + "Every other club and option is below."));
 Button b = Ui.goldBtn(act, "Quick Start — Lahore Qalandars, Manager difficulty");
 b.setOnClickListener(v -> {
 act.pickerDifficulty = 1; // Manager — the default career
 act.pickerHardcore = false;
 act.startCareer("Lahore Qalandars");
 });
 card.addView(b);
 return card;
 }

 /** Batch I (ideas 81/90): difficulty + hardcore for the NEW career.
 * The choices sit on MainActivity and are stamped onto the career
 * the moment a club is picked. */
 private static View settingsCard(final MainActivity act) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "CAREER SETTINGS", 13));
 card.addView(Ui.h2(act, "Difficulty"));
 LinearLayout row = Ui.row(act);
 for (int d = 0; d < 3; d++) {
 final int dd = d;
 Button c = Ui.chip(act, Game.DIFF_NAMES[d], act.pickerDifficulty == d);
 c.setOnClickListener(v -> { act.pickerDifficulty = dd; act.render(); });
 row.addView(c);
 }
 card.addView(row);
 card.addView(Ui.small(act, act.pickerDifficulty == 0
 ? "Casual — softer AI (−4), prizes +25%, wages −20%, the board forgives faster."
 : act.pickerDifficulty == 2
 ? "Legend — sharper AI (+4), prizes −15%, wages +15%, the board cuts deeper, auctions run hotter — but XP pays +25%."
 : "Manager — the classic balance, exactly as the game was tuned."));
 card.addView(Ui.small(act, "Difficulty can be changed later only between seasons (Profile, in the off-season)."));
 Button hc = Ui.chip(act, "Hardcore mode", act.pickerHardcore);
 hc.setOnClickListener(v -> { act.pickerHardcore = !act.pickerHardcore; act.render(); });
 card.addView(hc);
 card.addView(Ui.small(act, act.pickerHardcore
 ? "HARDCORE ON: sacked if board confidence ends a season under 20 (warnings from 40), challenge/scenario rewards halved, and NO undo after loading a career slot. Attempts are remembered forever."
 : "Hardcore off — tap to take the hot seat the hard way."));
 return card;
 }

 private static View teamCard(final MainActivity act, final String team) {
 LinearLayout card = Ui.card(act);
 LinearLayout titleRow = Ui.row(act);
 titleRow.addView(CrestView.forTeam(act, act.g, team, 34));
 TextView tn = Ui.h2(act, team);
 tn.setPadding(Ui.dp(act, 8), 0, 0, 0);
 titleRow.addView(tn);
 card.addView(titleRow); // P1: crest + name lockup, same as the header
 String group = "Group A";
 for (String t : Data.GROUP_B) if (t.equals(team)) group = "Group B";
 card.addView(Ui.small(act, group + " · Strength " + Data.teamStrength(team)
 + " · Captain: " + Data.captainFor(team)));
 card.addView(Ui.small(act, "Star men: " + starNames(team)));
 card.addView(Ui.small(act, "Home: " + Data.groundName(team)
 + " (" + Data.GROUND_CHARS[Data.groundChar(team)] + ") · Biggest rival: " + Data.rivalOf(team)));
 card.addView(Ui.text(act, "Starting Club Cash: " + Game.startingCfFor(team) + " CF", 13, Ui.GOLD, true));
 Button b = Ui.darkBtn(act, "Manage " + team); // P1: eight equal choices — none is "the" primary
 b.setOnClickListener(v -> new android.app.AlertDialog.Builder(act)
 .setTitle("Manage " + team + "?")
 .setMessage("Your career starts in Season 1 with " + team + "'s full 18-man squad, "
 + Game.startingCfFor(team) + " CF and every facility at Level 1."
 + "\n\nDifficulty: " + Game.DIFF_NAMES[act.pickerDifficulty]
 + (act.pickerHardcore ? " · HARDCORE" : ""))
 .setNegativeButton("Cancel", null)
 .setPositiveButton("Start Career", (d, w) -> act.startCareer(team))
 .show());
 card.addView(b);
 return card;
 }

 /** The three biggest names in the squad, by simple combined rating. */
 private static String starNames(String team) {
 Object[][] squad = Data.squadFor(team);
 java.util.List<Object[]> rows = new java.util.ArrayList<>();
 for (Object[] r : squad) rows.add(r);
 java.util.Collections.sort(rows, (a, b) ->
 ((Integer) b[2] + (Integer) b[3]) - ((Integer) a[2] + (Integer) a[3]));
 StringBuilder sb = new StringBuilder();
 for (int i = 0; i < Math.min(3, rows.size()); i++) {
 if (i > 0) sb.append(" · ");
 sb.append(rows.get(i)[0]);
 }
 return sb.toString();
 }

 private static View customCard(final MainActivity act) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.gold(act, "OR BUILD YOUR OWN", 13));
 card.addView(Ui.h2(act, "Create Custom Team"));
 if (!act.customOpen) {
 card.addView(Ui.small(act, "Your own club takes Lahore Qalandars' place in the league — "
 + "their squad is rebranded as yours (the players keep their names), along with "
 + "Gaddafi Stadium and the Karachi rivalry. You choose the name, a 2–3 letter code "
 + "and a badge colour."));
 Button open = Ui.darkBtn(act, "Create Custom Team");
 open.setOnClickListener(v -> { act.customOpen = true; act.render(); });
 card.addView(open);
 return card;
 }
 final EditText nameIn = new EditText(act);
 nameIn.setHint("Team name (e.g. Sargodha Strikers)");
 nameIn.setText(act.customNameDraft);
 nameIn.setTextColor(Ui.INK);
 nameIn.setHintTextColor(Ui.MUTED);
 nameIn.setSingleLine(true);
 card.addView(nameIn);
 final EditText codeIn = new EditText(act);
 codeIn.setHint("Short code, 2–3 letters (e.g. SAR)");
 codeIn.setText(act.customCodeDraft);
 codeIn.setTextColor(Ui.INK);
 codeIn.setHintTextColor(Ui.MUTED);
 codeIn.setSingleLine(true);
 card.addView(codeIn);
 card.addView(Ui.small(act, "Badge colour — tints your club chip in the header and Hub (the app itself stays gold):"));
 LinearLayout sw = Ui.row(act);
 for (int i = 0; i < Data.CUSTOM_COLORS.length; i++) {
 final int idx = i;
 Button s = new Button(act);
 s.setText(Data.CUSTOM_COLOR_NAMES[i]);
 s.setTextSize(11);
 s.setAllCaps(false);
 s.setTextColor(0xFFFFFFFF);
 s.setBackground(Ui.roundStroke(Data.CUSTOM_COLORS[i],
 idx == act.customColorIdx ? Ui.INK : Data.CUSTOM_COLORS[i], 10, act));
 LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(act, 40), 1);
 lp.setMargins(0, 0, Ui.dp(act, 6), Ui.dp(act, 6));
 s.setLayoutParams(lp);
 s.setOnClickListener(v -> {
 // keep the typed name/code across the re-render
 act.customNameDraft = nameIn.getText().toString();
 act.customCodeDraft = codeIn.getText().toString();
 act.customColorIdx = idx;
 act.render();
 });
 sw.addView(s);
 }
 card.addView(sw);
 card.addView(Ui.small(act, "Selected: " + Data.CUSTOM_COLOR_NAMES[act.customColorIdx]
 + " · Strength 82 · Starting Club Cash: 1000 CF"
 + " · Home: Gaddafi Stadium · Rival: Karachi Kings"));
 Button create = Ui.goldBtn(act, "Create My Team");
 create.setOnClickListener(v -> {
 String nm = nameIn.getText().toString().trim();
 String cd = codeIn.getText().toString().trim().toUpperCase();
 if (nm.length() < 3) { act.toast("Give your team a name (3+ characters)"); return; }
 for (String t : TEAMS) {
 if (t.equalsIgnoreCase(nm)) { act.toast("That name belongs to a league club — pick another"); return; }
 }
 if (cd.length() < 2 || cd.length() > 3 || !cd.matches("[A-Z]+")) {
 cd = nm.substring(0, Math.min(3, nm.length())).toUpperCase();
 }
 act.startCareerCustom(nm, cd, Data.CUSTOM_COLORS[act.customColorIdx]);
 });
 card.addView(create);
 return card;
 }
}
