package io.github.farrakhimtiaz74.cricketmanager;

import java.util.LinkedHashMap;
import java.util.Map;

/** Professional Pack P5 (v18, suggestion 44): THE glossary — one
 *  pure map of the game's terms to one-or-two-line plain explanations.
 *  Ui.infoChip(term) opens a sheet with explain(term); the Help
 *  screen's Glossary section lists every term from TERMS. Pure (no
 *  Android) so the desktop tests can prove all twelve terms carry a
 *  real explanation. Wording is checked against the game's actual
 *  rules — no invented effects. */
public class Glossary {

    /** The twelve terms, in Help-display order. */
    public static final String[] TERMS = {
            "CF", "NRR", "POT", "DLS", "Set %", "CRR", "RRR", "XI",
            "Powerplay", "Super Over", "Gate", "Wage bill"};

    private static final Map<String, String> MAP = new LinkedHashMap<>();

    static {
        MAP.put("CF", "Club Cash — the game's money. It comes in from match"
                + " prizes, ticket sales, sponsors and merchandise, and goes"
                + " out on wages, signings, staff and facilities.");
        MAP.put("NRR", "Net Run Rate — how fast a team scores compared with"
                + " how fast it concedes runs, across the season. When teams"
                + " finish level on points, NRR decides who sits higher.");
        MAP.put("POT", "Potential — the rating a player can grow towards as"
                + " he develops each season. Young players climb towards it;"
                + " players past 33 usually decline instead. Scouting reveals"
                + " the exact number.");
        MAP.put("DLS", "The rain rule (a simplified Duckworth-Lewis method)."
                + " When rain shortens a chase, the target is reduced to keep"
                + " the contest fair — the DLS par score shows who is ahead"
                + " at that moment.");
        MAP.put("Set %", "How settled and sharp a player is. It climbs when"
                + " his team wins and after Team Talk and pep talks, and it"
                + " dips after losses.");
        MAP.put("CRR", "Current Run Rate — the runs per over scored so far"
                + " in this innings.");
        MAP.put("RRR", "Required Run Rate — the runs per over the chasing"
                + " team needs from here to reach the target.");
        MAP.put("XI", "Your starting eleven — the 11 players picked for a"
                + " match. A legal XI has exactly 11, a wicketkeeper, at"
                + " least 5 bowling options and at most 4 overseas players.");
        MAP.put("Powerplay", "The first 6 overs of an innings. Fielding"
                + " restrictions apply and scoring usually comes faster —"
                + " plans for these overs live on the match screen.");
        MAP.put("Super Over", "The tie-breaker when scores finish level:"
                + " each side bats one over (6 balls, 2 wickets) and the"
                + " higher total wins. A tied Super Over shares the points.");
        MAP.put("Gate", "Gate income — the money from ticket sales at your"
                + " home matches. A bigger stadium, happier fans and higher"
                + " ticket prices all grow it.");
        MAP.put("Wage bill", "What your players and backroom staff cost in"
                + " wages each week. It is charged on Days 7, 14 and 21 of"
                + " the season.");
    }

    /** The plain explanation for a term, or null if the term is unknown. */
    public static String explain(String term) {
        return term == null ? null : MAP.get(term);
    }
}
