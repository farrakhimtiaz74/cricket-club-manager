package io.github.farrakhimtiaz74.cricketmanager;

/** v21 item 6 (module split, safe subset): the PURE static helpers
 *  extracted from Game.java — manager levels, finance categories,
 *  morale maths and headline surnames. They touch no game state, so
 *  the split is behaviour-identical by construction: Game keeps
 *  one-line delegating wrappers under the original names (every
 *  existing call site compiles and runs unchanged), and this class
 *  is where the logic now lives and is unit-tested directly.
 *
 *  What was NOT split (deliberately, to protect the save format):
 *  Game's state, its JSON (de)serialization, the season/match flow
 *  and the economy mutators stay in Game — they are one cohesive
 *  state machine over the same JSONObject graph, and carving them
 *  apart mid-release would risk the live career for no user gain. */
public class GameMath {

    /** Manager level 1–10 from career XP against the thresholds. */
    public static int levelForXp(int xp, int[] thresholds) {
        int lvl = 1;
        for (int i = 0; i < thresholds.length; i++) if (xp >= thresholds[i]) lvl = i + 1;
        return lvl;
    }

    /** The HQ finance category of a ledger reason string. */
    public static String financeCategory(String reason) {
        String r = reason == null ? "" : reason.toLowerCase(java.util.Locale.ROOT);
        if (r.contains("merchandise")) return "merch";
        if (r.startsWith("gate receipts")) return "gate";
        if (r.contains("sponsor") || r.contains("commercial centre")) return "sponsor";
        if (r.contains("wages")) return "wages";
        if (r.contains("upgrade to level")) return "upgrades";
        if (r.contains("signing") || r.contains("auction") || r.startsWith("transfer")
                || r.contains("contract renewal") || r.contains("release settlement") || r.contains("loan-in")) return "transfers";
        if (r.contains("prize") || r.contains("bonus") || r.contains("appearance fee")
                || r.contains("champions") || r.contains("runners-up") || r.contains("winners")) return "prizes";
        return "other";
    }

    /** Morale is always 0–100. */
    public static int clampMorale(int v) {
        return Math.max(0, Math.min(100, v));
    }

    /** The morale word shown on cards and rows. */
    public static String moraleLabel(int morale) {
        if (morale >= 80) return "High";
        if (morale >= 60) return "Good";
        if (morale >= 40) return "Okay";
        return "Low";
    }

    /** The last word of a name (headline style). */
    public static String surname(String name) {
        if (name == null) return "";
        String[] parts = name.trim().split("\\s+");
        return parts.length > 0 ? parts[parts.length - 1] : name;
    }
}
