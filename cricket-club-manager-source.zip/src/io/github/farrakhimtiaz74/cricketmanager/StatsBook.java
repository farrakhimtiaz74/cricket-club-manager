package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

/** Batch C (ideas 21, 22, 25, 29): the squad's season & career record book.
 *
 *  Stats live ON each player object in Game.players as two objects —
 *  "ss" (season, reset at rollover) and "cs" (career, permanent) — with the
 *  shape built by Game.emptyStats(). This class only ACCUMULATES: it reads
 *  the finished innings cards of a completed match and credits every Lahore
 *  squad member it finds (opponent names simply don't match the squad).
 *
 *  Android-free on purpose (org.json only) so the desktop logic tests can
 *  run the shipped classes directly, exactly like Game/MatchEngine. */
public class StatsBook {

    // ---------------- appearances ----------------

    /** Every XI player is credited a match (season + career). */
    public static void recordAppearances(Game g) {
        for (JSONObject p : g.xi()) {
            bump(p, "m", 1);
        }
    }

    // ---------------- full match cards (played live or Instant-simmed) ----------------

    /** Credits batting + bowling from both innings of a finished match.
     *  m's batCard/bowlCard at full time are the SECOND innings cards (after a
     *  Super Over, MatchEngine restores the real inn-2 cards before finishing,
     *  so Super Over balls never pollute the record book). */
    public static void recordMatch(Game g, JSONObject m) {
        if (m == null) return;
        creditBatCard(g, m.optJSONArray("inn1BatCard"));
        creditBatCard(g, m.optJSONArray("batCard"));
        creditBowlCard(g, m.optJSONArray("inn1BowlCard"));
        creditBowlCard(g, m.optJSONArray("bowlCard"));
        // milestones are judged on the fresh career totals
        for (int i = 0; i < g.players.length(); i++) checkMilestones(g, g.player(i));
    }

    private static void creditBatCard(Game g, JSONArray card) {
        if (card == null) return;
        for (int i = 0; i < card.length(); i++) {
            JSONObject e = card.optJSONObject(i);
            if (e == null) continue;
            JSONObject p = g.playerByName(e.optString("name"));
            if (p == null || !e.optBoolean("in")) continue; // squad only, and only if he batted
            int runs = e.optInt("runs"), balls = e.optInt("balls");
            boolean out = e.optBoolean("out");
            addBatting(p, runs, balls, out);
            pushFormB(p, runs);
            // performance morale (idea 25)
            if (runs >= 100) g.adjustMorale(p.optString("name"), +10);
            else if (runs >= 50) g.adjustMorale(p.optString("name"), +6);
            else if (out && runs == 0) g.adjustMorale(p.optString("name"), -5);
        }
    }

    private static void creditBowlCard(Game g, JSONArray card) {
        if (card == null) return;
        for (int i = 0; i < card.length(); i++) {
            JSONObject e = card.optJSONObject(i);
            if (e == null) continue;
            JSONObject p = g.playerByName(e.optString("name"));
            if (p == null) continue;
            int balls = e.optInt("balls"), runs = e.optInt("runs"), wkts = e.optInt("wkts");
            if (balls <= 0) continue;
            addBowling(p, balls, wkts, runs);
            pushFormW(p, wkts, runs);
            if (wkts >= 5) g.adjustMorale(p.optString("name"), +10);
            else if (wkts >= 3) g.adjustMorale(p.optString("name"), +6);
            else if (balls >= 18 && runs >= 45) g.adjustMorale(p.optString("name"), -4); // expensive spell
        }
    }

    // ---------------- quick-simmed user fixtures ----------------

    /** A simmed fixture only generates a top scorer and a best bowler
     *  (Game.simFixture). If either is a squad man, credit him approximately:
     *  the score at roughly a run-a-ball pace, the spell as a full 4 overs. */
    public static void recordSimStandouts(Game g, JSONObject f) {
        if (f == null) return;
        String topBat = f.optString("topBat", "");
        int topRuns = f.optInt("topBatRuns", 0);
        JSONObject p = g.playerByName(topBat);
        if (p != null && topRuns > 0) {
            addBatting(p, topRuns, Math.max(1, topRuns * 3 / 4), true);
            pushFormB(p, topRuns);
            if (topRuns >= 100) g.adjustMorale(topBat, +10);
            else if (topRuns >= 50) g.adjustMorale(topBat, +6);
        }
        String bestBowl = f.optString("bestBowl", "");
        int bestWkts = f.optInt("bestBowlWkts", 0);
        JSONObject b = g.playerByName(bestBowl);
        if (b != null && bestWkts > 0) {
            addBowling(b, 24, bestWkts, 18 + bestWkts * 4);
            pushFormW(b, bestWkts, 18 + bestWkts * 4);
            if (bestWkts >= 5) g.adjustMorale(bestBowl, +10);
            else if (bestWkts >= 3) g.adjustMorale(bestBowl, +6);
        }
        for (int i = 0; i < g.players.length(); i++) checkMilestones(g, g.player(i));
    }

    // ---------------- the arithmetic ----------------

    private static void addBatting(JSONObject p, int runs, int balls, boolean out) {
        for (String key : new String[]{"ss", "cs"}) {
            JSONObject s = p.optJSONObject(key);
            if (s == null) continue;
            try {
                s.put("inn", s.optInt("inn") + 1);
                s.put("runs", s.optInt("runs") + runs);
                s.put("balls", s.optInt("balls") + balls);
                if (runs > s.optInt("hs")) s.put("hs", runs);
                if (out) s.put("outs", s.optInt("outs") + 1);
                if (runs >= 100) s.put("f100", s.optInt("f100") + 1);
                else if (runs >= 50) s.put("f50", s.optInt("f50") + 1);
            } catch (Exception ignored) {}
        }
    }

    private static void addBowling(JSONObject p, int balls, int wkts, int conc) {
        for (String key : new String[]{"ss", "cs"}) {
            JSONObject s = p.optJSONObject(key);
            if (s == null) continue;
            try {
                s.put("bwBalls", s.optInt("bwBalls") + balls);
                s.put("wkts", s.optInt("wkts") + wkts);
                s.put("conc", s.optInt("conc") + conc);
                int bw = s.optInt("bestW"), br = s.optInt("bestR");
                if (wkts > bw || (wkts == bw && conc < br) || (bw == 0 && br == 0)) {
                    s.put("bestW", wkts);
                    s.put("bestR", conc);
                }
                if (wkts >= 5) s.put("f5", s.optInt("f5") + 1);
                else if (wkts >= 3) s.put("f3", s.optInt("f3") + 1);
            } catch (Exception ignored) {}
        }
    }

    private static void bump(JSONObject p, String field, int by) {
        for (String key : new String[]{"ss", "cs"}) {
            JSONObject s = p.optJSONObject(key);
            if (s == null) continue;
            try { s.put(field, s.optInt(field) + by); } catch (Exception ignored) {}
        }
    }

    // ---------------- form (idea 22) ----------------

    private static void pushFormB(JSONObject p, int runs) {
        try {
            JSONArray f = p.optJSONArray("formB");
            if (f == null) { f = new JSONArray(); p.put("formB", f); }
            f.put(runs);
            while (f.length() > 5) f.remove(0);
        } catch (Exception ignored) {}
    }

    private static void pushFormW(JSONObject p, int wkts, int conc) {
        try {
            JSONArray f = p.optJSONArray("formW");
            if (f == null) { f = new JSONArray(); p.put("formW", f); }
            f.put(wkts + "/" + conc);
            while (f.length() > 5) f.remove(0);
        } catch (Exception ignored) {}
    }

    /** Form trend: +1 hot, 0 steady, −1 cold. Batters are judged on runs,
     *  bowlers on wickets per outing, recent-5 against the season baseline.
     *  Too little data = steady (0). */
    public static int formTrend(JSONObject p) {
        try {
            JSONObject ss = p.optJSONObject("ss");
            boolean bowler = "Bowl".equals(p.optString("role")) || p.optInt("bowl") > p.optInt("bat");
            if (bowler) {
                JSONArray f = p.optJSONArray("formW");
                if (f == null || f.length() < 2 || ss == null) return 0;
                double recent = 0;
                for (int i = 0; i < f.length(); i++) recent += Integer.parseInt(f.optString(i).split("/")[0]);
                recent /= f.length();
                int spells = Math.max(1, ss.optInt("bwBalls") > 0 ? Math.max(1, (int) Math.round(ss.optInt("bwBalls") / 24.0)) : 0);
                double base = ss.optInt("wkts") * 1.0 / Math.max(1, spells);
                if (ss.optInt("bwBalls") == 0) base = recent;
                return recent > base + 0.4 ? 1 : recent < base - 0.4 ? -1 : 0;
            }
            JSONArray f = p.optJSONArray("formB");
            if (f == null || f.length() < 2 || ss == null) return 0;
            double recent = 0;
            for (int i = 0; i < f.length(); i++) recent += f.optInt(i);
            recent /= f.length();
            double base = ss.optInt("inn") >= 2 ? ss.optInt("runs") * 1.0 / ss.optInt("inn") : recent;
            return recent > base * 1.15 + 2 ? 1 : recent < base * 0.85 - 2 ? -1 : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public static String trendArrow(int trend) {
        return trend > 0 ? "↑" : trend < 0 ? "↓" : "→";
    }

    // ---------------- milestones (idea 29) ----------------

    /** Career thresholds; each fires once per player (tracked in "miles") and
     *  posts a Hub news item. Scaled to this game's short seasons: 500 runs
     *  and 50 wickets are the first big ones, 1000/100 the headline ones. */
    public static void checkMilestones(Game g, JSONObject p) {
        try {
            JSONObject cs = p.optJSONObject("cs");
            if (cs == null) return;
            JSONArray miles = p.optJSONArray("miles");
            if (miles == null) { miles = new JSONArray(); p.put("miles", miles); }
            String name = p.optString("name");
            milestone(g, p, miles, "runs500", cs.optInt("runs") >= 500, name + " has passed 500 career runs for " + g.userTeam + "!");
            milestone(g, p, miles, "runs1000", cs.optInt("runs") >= 1000, "🎉 MILESTONE: " + name + " — 1,000 career runs for " + g.userTeam + "!");
            milestone(g, p, miles, "wkts50", cs.optInt("wkts") >= 50, name + " has taken 50 career wickets for " + g.userTeam + "!");
            milestone(g, p, miles, "wkts100", cs.optInt("wkts") >= 100, "🎉 MILESTONE: " + name + " — 100 career wickets for " + g.userTeam + "!");
            milestone(g, p, miles, "matches50", cs.optInt("m") >= 50, "🎉 MILESTONE: " + name + " — 50 career matches for " + g.userTeam + "!");
            milestone(g, p, miles, "tons5", cs.optInt("f100") >= 5, "🎉 MILESTONE: " + name + " — 5 career centuries for " + g.userTeam + "!");
            milestone(g, p, miles, "fivefors2", cs.optInt("f5") >= 2, "🎉 MILESTONE: " + name + " — a 2nd career five-wicket haul for " + g.userTeam + "!");
        } catch (Exception ignored) {}
    }

    private static void milestone(Game g, JSONObject p, JSONArray miles, String key, boolean hit, String news) {
        if (!hit) return;
        for (int i = 0; i < miles.length(); i++) if (key.equals(miles.optString(i))) return;
        try { miles.put(key); } catch (Exception ignored) {}
        g.addNews(news);
    }

    /** Human-readable milestone list for the detail view (idea 29). */
    public static String milestoneText(String key) {
        switch (key) {
            case "runs500": return "500 career runs";
            case "runs1000": return "1,000 career runs";
            case "wkts50": return "50 career wickets";
            case "wkts100": return "100 career wickets";
            case "matches50": return "50 career matches";
            case "tons5": return "5 career centuries";
            case "fivefors2": return "2 career five-fors";
            default: return key;
        }
    }

    // ---------------- display formatting (shared by Team/detail views) ----------------

    public static String batLine(JSONObject s) {
        if (s == null || s.optInt("inn") == 0) return "No innings yet";
        double avg = s.optInt("outs") == 0 ? s.optInt("runs") : s.optInt("runs") * 1.0 / s.optInt("outs");
        double sr = s.optInt("balls") == 0 ? 0 : s.optInt("runs") * 100.0 / s.optInt("balls");
        return s.optInt("inn") + " inn · " + s.optInt("runs") + " runs · HS " + s.optInt("hs")
                + " · Avg " + fmt(avg) + " · SR " + fmt(sr)
                + " · 50s " + s.optInt("f50") + " · 100s " + s.optInt("f100");
    }

    public static String bowlLine(JSONObject s) {
        if (s == null || s.optInt("bwBalls") == 0) return "No overs yet";
        double econ = s.optInt("conc") * 6.0 / s.optInt("bwBalls");
        return overs(s.optInt("bwBalls")) + " ov · " + s.optInt("wkts") + " wkts · Econ " + fmt(econ)
                + " · Best " + s.optInt("bestW") + "/" + s.optInt("bestR")
                + " · 3-fers " + s.optInt("f3") + " · 5-fers " + s.optInt("f5");
    }

    public static String overs(int balls) {
        return (balls / 6) + "." + (balls % 6);
    }

    private static String fmt(double v) {
        return String.format(java.util.Locale.US, "%.1f", v);
    }
}
