package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ProfileScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        LinearLayout card = Ui.card(act);
        card.addView(Ui.gold(act, "MANAGER PROFILE", 13));
        card.addView(Ui.h1(act, "Farrakh — Lahore Qalandars"));
        card.addView(Ui.small(act, "Season " + g.season + " in charge · " + g.cf + " CF in the bank"));
        root.addView(card);

        int played = g.career.optInt("played");
        int won = g.career.optInt("won");
        int lost = g.career.optInt("lost");
        int winPct = played == 0 ? 0 : (int) Math.round(won * 100.0 / played);

        LinearLayout stats = Ui.card(act);
        stats.addView(Ui.h2(act, "Career Record"));
        stats.addView(statRow(act, "Matches played", String.valueOf(played)));
        stats.addView(statRow(act, "Won / Lost", won + " / " + lost));
        stats.addView(statRow(act, "Win %", winPct + "%"));
        stats.addView(statRow(act, "Current win streak", String.valueOf(g.career.optInt("streak"))));
        stats.addView(statRow(act, "Best win streak", String.valueOf(g.career.optInt("best"))));
        stats.addView(statRow(act, "League titles", String.valueOf(g.career.optInt("titles"))));
        root.addView(stats);

        LinearLayout hist = Ui.card(act);
        hist.addView(Ui.h2(act, "Match History"));
        if (g.history.length() == 0) hist.addView(Ui.small(act, "No matches yet — your story starts on match day."));
        for (int i = 0; i < g.history.length(); i++) {
            TextView t = Ui.body(act, "•  " + g.history.optString(i));
            t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
            hist.addView(t);
        }
        root.addView(hist);

        Button reset = Ui.darkBtn(act, "Reset Career (start over)");
        reset.setOnClickListener(v -> new AlertDialog.Builder(act)
                .setTitle("Reset career?")
                .setMessage("All progress, CF, facilities and records will be wiped.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (d, w) -> {
                    act.store.clear();
                    act.g = Game.fresh();
                    act.matchMode = false;
                    act.tab = 0;
                    act.save();
                    act.render();
                    act.toast("New career started");
                })
                .show());
        root.addView(reset);
        return root;
    }

    private static View statRow(MainActivity act, String label, String val) {
        LinearLayout row = Ui.row(act);
        row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
        TextView l = Ui.body(act, label);
        l.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(l);
        row.addView(Ui.gold(act, val, 16));
        return row;
    }
}
