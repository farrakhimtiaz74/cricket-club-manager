package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

public class ProfileScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        LinearLayout card = Ui.card(act);
        card.addView(Ui.gold(act, "MANAGER PROFILE", 13));
        card.addView(Ui.h1(act, "Farrakh — " + g.userTeam));
        card.addView(Ui.small(act, "Season " + g.season + " in charge · " + g.cf + " CF in the bank"));
        if (g.hardcore) card.addView(Ui.text(act, "☠ HARDCORE CAREER", 13, Ui.RED, true));
        root.addView(card);

        // Batch I (ideas 81/90): career settings — difficulty + hardcore
        root.addView(settingsCard(act));

        // Batch J (ideas 91/92/96/100): the app Settings entry — backup &
        // sync codes, sounds, Roman Urdu commentary, big text, What's New
        LinearLayout appCard = Ui.card(act);
        appCard.addView(Ui.h2(act, "💾 Backup, Sync & App Settings"));
        appCard.addView(Ui.small(act, "Export your career as a file or a sync code, import one back, sounds,"
                + " commentary language, text size — all in the Settings screen."));
        Button openSettings = Ui.goldBtn(act, "⚙️ Open App Settings");
        openSettings.setOnClickListener(v -> { act.settingsMode = true; act.render(); });
        appCard.addView(openSettings);
        Button openWn = Ui.darkBtn(act, "🆕 What's New in v12");
        openWn.setOnClickListener(v -> { act.whatsNewMode = true; act.render(); });
        appCard.addView(openWn);
        root.addView(appCard);

        // Batch I (idea 89): result codes, with copy buttons
        root.addView(resultCodeCard(act));

        // Batch I (idea 87): career save slots
        root.addView(slotsCard(act));

        // Batch G (idea 69): manager level, XP bar and the perk ladder
        LinearLayout mgr = Ui.card(act);
        mgr.addView(Ui.h2(act, "Manager Level " + g.managerLevel + (g.managerLevel >= 10 ? " — 🏆 LEGEND" : "")));
        if (g.managerLevel >= 10) {
            mgr.addView(Ui.small(act, g.managerXp + " XP — the top of the ladder. Legend status earned."));
        } else {
            int cur = Game.XP_THRESHOLDS[g.managerLevel - 1];
            int next = g.xpForNextLevel();
            int pct = next <= cur ? 100 : (int) Math.round((g.managerXp - cur) * 100.0 / (next - cur));
            mgr.addView(Ui.small(act, g.managerXp + " XP · " + HqScreen.meter(pct) + " " + pct
                    + "% to Level " + (g.managerLevel + 1) + " (at " + next + " XP)"));
        }
        mgr.addView(Ui.small(act, "XP: +2 per match · +10 per win · +25 per playoff win · +100 per trophy · +5 per player award · +15 per sponsor objective."));
        for (int i = 0; i < Game.PERK_TEXT.length; i++) {
            boolean unlocked = g.managerLevel >= i + 2;
            mgr.addView(Ui.text(act, (unlocked ? "✓ " : "· ") + Game.PERK_TEXT[i], 13,
                    unlocked ? Ui.GREEN : Ui.MUTED, false));
        }
        root.addView(mgr);

        int played = g.career.optInt("played");
        int won = g.career.optInt("won");
        int lost = g.career.optInt("lost");
        int winPct = played == 0 ? 0 : (int) Math.round(won * 100.0 / played);

        LinearLayout stats = Ui.card(act);
        stats.addView(Ui.h2(act, "Career Record"));
        stats.addView(statRow(act, "Matches played", String.valueOf(played)));
        stats.addView(statRow(act, "Won / Lost", won + " / " + lost));
        stats.addView(statRow(act, "Win %", winPct + "%"));
        stats.addView(statRow(act, "Current win streak", String.valueOf(g.career.optInt("streak"))));
        stats.addView(statRow(act, "Best win streak", String.valueOf(g.career.optInt("best"))));
        stats.addView(statRow(act, "League titles", String.valueOf(g.career.optInt("titles"))));
        stats.addView(statRow(act, "One-Day Cups won", String.valueOf(g.career.optInt("cups"))));
        root.addView(stats);

        LinearLayout hist = Ui.card(act);
        hist.addView(Ui.h2(act, "Match History"));
        if (g.history.length() == 0) hist.addView(Ui.small(act, "No matches yet — your story starts on match day."));
        for (int i = 0; i < g.history.length(); i++) {
            TextView t = Ui.body(act, "•  " + g.history.optString(i));
            t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
            hist.addView(t);
        }
        // Batch H (idea 77): share the latest match report from here too
        if (g.lastReport != null) {
            android.widget.Button shareRep = Ui.darkBtn(act, "📤 Share Last Match Report");
            shareRep.setOnClickListener(v -> act.shareReportImage());
            hist.addView(shareRep);
        }
        root.addView(hist);

        // Batch E (idea 48): the all-time Records Book
        LinearLayout rec = Ui.card(act);
        rec.addView(Ui.h2(act, "📖 Records Book"));
        if (g.records.length() == 0) {
            rec.addView(Ui.small(act, "No records yet — they start falling from your first matches of the playoff era."));
        } else {
            recordLine(rec, act, g, "highTotal", "Highest team total");
            recordLine(rec, act, g, "bigWinRuns", "Biggest win (runs)");
            recordLine(rec, act, g, "bigWinWkts", "Biggest win (wickets)");
            recordLine(rec, act, g, "highScore", "Highest individual score");
            recordLine(rec, act, g, "bestBowl", "Best bowling figures");
            recordLine(rec, act, g, "fastest50", "Fastest fifty");
            recordLine(rec, act, g, "mostRunsSeason", "Most runs in a season");
            recordLine(rec, act, g, "mostWktsSeason", "Most wickets in a season");
        }
        root.addView(rec);

        // Batch E (idea 49): Hall of Fame — past champions, title squads' key
        // men, and Lahore Legends inducted when they leave for good
        LinearLayout hofCard = Ui.card(act);
        hofCard.addView(Ui.h2(act, "🏛 Hall of Fame"));
        boolean anyHof = false;
        for (int i = 0; i < g.seasonHistory.length(); i++) {
            JSONObject e = g.seasonHistory.optJSONObject(i);
            if (e == null) continue;
            anyHof = true;
            hofCard.addView(Ui.small(act, "Season " + e.optInt("season") + " champions"));
            hofCard.addView(Ui.text(act, e.optString("champion"), 13,
                    g.userTeam.equals(e.optString("champion")) ? Ui.GOLD : Ui.INK, true));
        }
        for (int i = 0; i < g.hof.length(); i++) {
            JSONObject h = g.hof.optJSONObject(i);
            if (h == null || !("title".equals(h.optString("kind")) || "cup".equals(h.optString("kind")))) continue;
            anyHof = true;
            hofCard.addView(Ui.text(act, ("cup".equals(h.optString("kind")) ? "🏆 " : "⭐ ") + h.optString("line"), 13, Ui.GOLD, false));
            hofCard.addView(Ui.small(act, "Captain: " + h.optString("captain")
                    + (h.optString("potm").isEmpty() ? "" : " · Final POTM: " + h.optString("potm"))));
        }
        boolean legendHead = false;
        for (int i = 0; i < g.hof.length(); i++) {
            JSONObject h = g.hof.optJSONObject(i);
            if (h == null || !"legend".equals(h.optString("kind"))) continue;
            anyHof = true;
            if (!legendHead) { hofCard.addView(Ui.gold(act, g.userTeam + " Legends", 13)); legendHead = true; }
            hofCard.addView(Ui.text(act, "🌟 " + h.optString("name") + " — " + h.optString("line"), 13, Ui.INK, false));
            hofCard.addView(Ui.small(act, "Inducted in Season " + h.optInt("season")));
        }
        if (!anyHof) {
            hofCard.addView(Ui.small(act, "Empty for now — win a Final, or wave off a 50-match / 1,000-run / 50-wicket servant, to start filling it."));
        }
        root.addView(hofCard);

        // Batch H (idea 78): the Trophy Cabinet — every honour, rendered
        // from history + HoF + career counters (no duplicated storage)
        LinearLayout cab = Ui.card(act);
        cab.addView(Ui.h2(act, "🏆 Trophy Cabinet"));
        java.util.List<String> honours = g.trophyCabinetLines();
        if (!honours.isEmpty()) cab.addView(Ui.text(act, honours.get(0), 14, Ui.GOLD, true));
        if (honours.size() <= 1) {
            cab.addView(Ui.small(act, "No silverware yet — the cabinet is waiting for its first trophy."));
        } else {
            for (int i = 1; i < honours.size(); i++) {
                TextView t = Ui.body(act, honours.get(i));
                t.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 2));
                cab.addView(t);
            }
        }
        root.addView(cab);

        // Batch E (idea 50): multi-season history
        LinearLayout sh = Ui.card(act);
        sh.addView(Ui.h2(act, "🗂 Season History"));
        if (g.seasonHistory.length() == 0) {
            sh.addView(Ui.small(act, "No completed seasons yet — history starts with the first season finished in the playoff era."));
        }
        for (int i = 0; i < g.seasonHistory.length(); i++) {
            JSONObject e = g.seasonHistory.optJSONObject(i);
            if (e == null) continue;
            sh.addView(Ui.gold(act, "Season " + e.optInt("season") + " — Champions: " + e.optString("champion"), 13));
            sh.addView(Ui.small(act, g.userTeam + ": " + e.optInt("lahorePos") + posSuffix(e.optInt("lahorePos"))
                    + " in Group " + e.optString("lahoreGroup") + " · P" + e.optInt("lahoreP")
                    + " W" + e.optInt("lahoreW") + " L" + e.optInt("lahoreL")));
            if (!e.optString("topScorer").isEmpty()) sh.addView(Ui.small(act, "Top scorer: " + e.optString("topScorer")));
            if (!e.optString("topWkts").isEmpty()) sh.addView(Ui.small(act, "Top wickets: " + e.optString("topWkts")));
            JSONObject aw = e.optJSONObject("awards");
            if (aw != null) {
                awardHistLine(sh, act, aw, "goldenBat", "Golden Bat");
                awardHistLine(sh, act, aw, "bestBowler", "Best Bowler");
                awardHistLine(sh, act, aw, "mvp", "MVP");
                awardHistLine(sh, act, aw, "emerging", "Emerging");
            }
            // Batch H (idea 76): the season review rides inside the entry
            // (pre-v10 entries simply have no review fields — skipped here)
            for (String rl : g.seasonReviewLines(e)) sh.addView(Ui.small(act, rl));
        }
        root.addView(sh);

        Button reset = Ui.darkBtn(act, "Reset Career (start over)");
        reset.setOnClickListener(v -> new AlertDialog.Builder(act)
                .setTitle("Reset career?")
                .setMessage("All progress, CF, facilities and records will be wiped — then you pick your club for the new career. "
                        + "(Your Career Slots in the section above are NOT wiped.)")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (d, w) -> {
                    act.store.clear();
                    act.g = Game.fresh();
                    // Batch F (idea 51): a fresh career begins at the team picker
                    act.pickerMode = true;
                    act.customOpen = false;
                    act.customNameDraft = "";
                    act.customCodeDraft = "";
                    act.matchMode = false;
                    act.transfersMode = false;
                    act.calendarMode = false; // Batch H
                    act.modesMode = false; // Batch I
                    act.teamDetail = null;
                    act.tab = 0;
                    act.render();
                    act.toast("Pick your club for the new career");
                })
                .show());
        root.addView(reset);
        return root;
    }

    /** Batch I (ideas 81/90): difficulty (changeable only between
     *  seasons) and the hardcore toggle (season starts only). */
    private static View settingsCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "⚙ Career Settings"));
        card.addView(statRow(act, "Difficulty", Game.DIFF_NAMES[g.difficulty]));
        card.addView(Ui.small(act, "Casual: softer AI (−4), prizes +25%, wages −20%, gentler board. "
                + "Legend: sharper AI (+4), prizes −15%, wages +15%, harsher board, hotter auctions, XP +25%."));
        if (g.offseason > 0) {
            LinearLayout row = Ui.row(act);
            for (int d = 0; d < 3; d++) {
                final int dd = d;
                Button c = Ui.chip(act, Game.DIFF_NAMES[d], g.difficulty == d);
                c.setOnClickListener(v -> { act.toast(act.g.setDifficulty(dd)); act.save(); act.render(); });
                row.addView(c);
            }
            card.addView(row);
        } else {
            card.addView(Ui.small(act, "Difficulty can be changed between seasons — finish Season "
                    + g.season + " and the choices unlock here during the off-season."));
        }
        // ---- hardcore (idea 90) ----
        if (g.hardcore) {
            card.addView(Ui.text(act, "☠ HARDCORE IS ON", 14, Ui.RED, true));
            card.addView(Ui.small(act, "Sack line: board confidence under " + g.sackThreshold()
                    + " at a season end (warnings from 40). Daily-challenge and scenario rewards are halved. "
                    + "Slot load-undo is disabled. It cannot be switched off mid-career."));
        } else if (g.canEnableHardcore()) {
            Button hc = Ui.darkBtn(act, "☠ Enable Hardcore Mode");
            hc.setOnClickListener(v -> new AlertDialog.Builder(act)
                    .setTitle("Enable Hardcore?")
                    .setMessage("From now on: sacked if board confidence ends a season under 20 (warnings from 40), "
                            + "challenge/scenario rewards halved, and NO undo after loading a career slot. "
                            + "It cannot be switched off for this career.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Go Hardcore", (d, w) -> {
                        act.toast(act.g.enableHardcore());
                        act.save();
                        act.render();
                    })
                    .show());
            card.addView(hc);
            card.addView(Ui.small(act, "Hardcore can be enabled now — a season start, before any match."));
        } else {
            card.addView(Ui.small(act, "☠ Hardcore: available at a season start (Day 1–2, before any match), "
                    + "in the off-season, or when starting a new career."));
        }
        String rec = Slots.hardcoreRecordLine(act.store.get(Slots.HARDCORE_RECORD));
        if (!rec.isEmpty()) card.addView(Ui.small(act, rec));
        return card;
    }

    /** Batch I (idea 89): the season + career result codes, copyable. */
    private static View resultCodeCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "🧾 Result Code"));
        final String seasonCode = g.seasonResultCode();
        final String careerCode = g.careerResultCode();
        TextView sc = Ui.text(act, seasonCode, 13, Ui.GOLD, true);
        sc.setTextIsSelectable(true);
        card.addView(sc);
        Button copyS = Ui.darkBtn(act, "Copy Season Code");
        copyS.setOnClickListener(v -> { copyText(act, seasonCode); act.toast("Season code copied"); });
        card.addView(copyS);
        TextView cc = Ui.text(act, careerCode, 13, Ui.INK, false);
        cc.setTextIsSelectable(true);
        card.addView(cc);
        Button copyC = Ui.darkBtn(act, "Copy Career Code");
        copyC.setOnClickListener(v -> { copyText(act, careerCode); act.toast("Career code copied"); });
        card.addView(copyC);
        return card;
    }

    private static void copyText(MainActivity act, String s) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager)
                act.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("Result Code", s));
    }

    /** Batch I (idea 87): three career slots + the one-shot load undo.
     *  Slots live outside the live save (Slots.java), so Reset never
     *  wipes them. */
    private static View slotsCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "💾 Career Slots"));
        card.addView(Ui.small(act, "Park this career in a slot and play another — or keep a safe copy before a big auction. "
                + "Loading a slot backs your current career up first, and the load can be undone once (until you play a match)"
                + (g.hardcore ? " — disabled in Hardcore." : ".")));
        for (int n = 1; n <= Slots.SLOT_COUNT; n++) {
            final int slot = n;
            JSONObject s = Slots.summary(act.store.get(Slots.slotKey(n)));
            card.addView(Ui.text(act, "Slot " + n + " — " + Slots.summaryLine(s), 13,
                    s == null ? Ui.MUTED : Ui.INK, s != null));
            LinearLayout row = Ui.row(act);
            Button save = Ui.chip(act, "Save here", false);
            save.setOnClickListener(v -> {
                if (s == null) { act.saveCareerSlot(slot); return; }
                new AlertDialog.Builder(act)
                        .setTitle("Overwrite Slot " + slot + "?")
                        .setMessage(Slots.summaryLine(s) + " will be replaced by your current career.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Overwrite", (d, w) -> act.saveCareerSlot(slot))
                        .show();
            });
            row.addView(save);
            if (s != null) {
                Button load = Ui.chip(act, "Load", false);
                load.setOnClickListener(v -> new AlertDialog.Builder(act)
                        .setTitle("Load Slot " + slot + "?")
                        .setMessage("Your current career (" + g.userTeam + ", Season " + g.season
                                + ") is backed up first" + (g.hardcore ? " — but Hardcore allows NO undo of the load." : ", and the load can be undone once.")
                                + "\n\nLoad: " + Slots.summaryLine(s))
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Load", (d, w) -> act.loadCareerSlot(slot))
                        .show());
                row.addView(load);
            }
            card.addView(row);
        }
        if (!g.hardcore && g.undoArmed && Slots.hasAutoslot(act.store)) {
            Button undo = Ui.goldBtn(act, "↩ Undo Load (restore auto-backup)");
            undo.setOnClickListener(v -> act.undoLoadCareer());
            card.addView(undo);
            card.addView(Ui.small(act, "Available until you play your next match."));
        }
        return card;
    }

    /** Batch E (idea 48): one line per standing record. */
    private static void recordLine(LinearLayout card, MainActivity act, Game g, String key, String label) {
        JSONObject r = g.records.optJSONObject(key);
        if (r == null) return;
        String val;
        switch (key) {
            case "highTotal":
                val = r.optString("team") + " — " + r.optInt("runs") + "/" + r.optInt("wkts") + " vs " + r.optString("vs");
                break;
            case "bigWinRuns":
                val = r.optString("team") + " — by " + r.optInt("margin") + " runs vs " + r.optString("vs");
                break;
            case "bigWinWkts":
                val = r.optString("team") + " — by " + r.optInt("margin") + " wickets vs " + r.optString("vs");
                break;
            case "highScore":
                val = r.optString("player") + " (" + r.optString("team") + ") — " + r.optInt("runs")
                        + (r.optInt("balls") > 0 ? " off " + r.optInt("balls") + " balls" : "");
                break;
            case "bestBowl":
                val = r.optString("player") + " (" + r.optString("team") + ") — " + r.optInt("wkts") + "/" + r.optInt("runs");
                break;
            case "fastest50":
                val = r.optString("player") + " (" + r.optString("team") + ") — fifty off " + r.optInt("balls") + " balls";
                break;
            default:
                val = r.optString("player") + " (" + r.optString("team") + ") — " + r.optInt("value");
                break;
        }
        card.addView(Ui.small(act, label));
        card.addView(Ui.text(act, val + " · Season " + r.optInt("season"), 13, Ui.INK, true));
    }

    /** Batch E (idea 50): one stored award winner inside a season entry. */
    private static void awardHistLine(LinearLayout card, MainActivity act, JSONObject aw, String key, String label) {
        JSONObject a = aw.optJSONObject(key);
        if (a == null) return;
        card.addView(Ui.small(act, label + ": " + a.optString("name") + " (" + a.optString("team")
                + ") — " + a.optString("detail")));
    }

    private static String posSuffix(int n) {
        if (n == 1) return "st";
        if (n == 2) return "nd";
        if (n == 3) return "rd";
        return "th";
    }

    private static View statRow(MainActivity act, String label, String val) {
        LinearLayout row = Ui.row(act);
        row.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4));
        TextView l = Ui.body(act, label);
        l.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(l);
        row.addView(Ui.gold(act, val, 16));
        return row;
    }

    /** Batch G (idea 68): the SACKED screen — the career summary, and the
     *  only way out is a brand-new career at the team picker. */
    public static View buildSacked(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);
        LinearLayout card = Ui.card(act);
        card.addView(Ui.gold(act, "THE BOARD HAS SPOKEN", 13));
        card.addView(Ui.h1(act, "SACKED"));
        // Batch I (idea 90): a hardcore reign is marked — permanently —
        // and the persistent attempts record is shown with it
        if (g.hardcore) {
            card.addView(Ui.text(act, "☠ HARDCORE — ENDED", 15, Ui.RED, true));
            String rec = Slots.hardcoreRecordLine(act.store.get(Slots.HARDCORE_RECORD));
            if (!rec.isEmpty()) card.addView(Ui.small(act, rec));
        }
        card.addView(Ui.body(act, "Board confidence ended Season " + g.season + " at " + g.boardConfidence
                + "/100. The " + g.userTeam + " board has terminated your contract."));
        card.addView(Ui.h2(act, "Your reign at " + g.userTeam));
        card.addView(statRow(act, "Seasons in charge", String.valueOf(g.season)));
        card.addView(statRow(act, "Matches", String.valueOf(g.career.optInt("played"))));
        card.addView(statRow(act, "Won / Lost", g.career.optInt("won") + " / " + g.career.optInt("lost")));
        card.addView(statRow(act, "League titles", String.valueOf(g.career.optInt("titles"))));
        card.addView(statRow(act, "One-Day Cups", String.valueOf(g.career.optInt("cups"))));
        card.addView(statRow(act, "Manager level reached", String.valueOf(g.managerLevel)));
        Button again = Ui.goldBtn(act, "Start New Career");
        again.setOnClickListener(v -> {
            act.store.clear();
            act.g = Game.fresh();
            act.pickerMode = true;
            act.matchMode = false;
            act.transfersMode = false;
            act.modesMode = false; // Batch I
            act.teamDetail = null;
            act.tab = 0;
            act.render();
        });
        card.addView(again);
        root.addView(card);
        return root;
    }
}
