package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Design Batch (v13, item 7c): the momentum bar under the win
 *  predictor — a drawn horizontal split at exactly the predictor's
 *  percentage (Design.momentumSplit, so bar and number never
 *  disagree): the batting-neutral split is USER % vs OPPONENT %, the
 *  user segment in the user's club accent, the opponent in theirs,
 *  short codes at both ends and the split % in the middle. */
public class MomentumView extends View {
    private final String userCode, oppCode;
    private final int userPct, userColor, oppColor;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    public MomentumView(Context c, String userCode, String oppCode, int winPct, int userColor, int oppColor) {
        super(c);
        this.userCode = userCode;
        this.oppCode = oppCode;
        this.userPct = Design.momentumSplit(winPct);
        this.userColor = userColor;
        this.oppColor = oppColor;
        txt.setFakeBoldText(true);
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(getContext(), 26));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float r = Ui.dp(getContext(), 6);
        float split = w * userPct / 100f;
        // opponent segment (base)
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, w, 0, shade(oppColor, 0.75f), oppColor, Shader.TileMode.CLAMP));
        cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
        // user segment
        if (userPct > 0) {
            cv.save();
            cv.clipRect(0, 0, split, h);
            p.setShader(new LinearGradient(0, 0, Math.max(1, split), 0, shade(userColor, 0.7f), userColor, Shader.TileMode.CLAMP));
            cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
            cv.restore();
        }
        p.setShader(null);
        // divider
        p.setColor(0xFFF8FAFC);
        cv.drawRect(split - 1, 0, split + 1, h, p);
        // labels
        txt.setTextSize(Ui.dp(getContext(), 11));
        txt.setColor(0xFFF8FAFC);
        txt.setTextAlign(Paint.Align.LEFT);
        cv.drawText(userCode + " " + userPct + "%", Ui.dp(getContext(), 8), h / 2f + Ui.dp(getContext(), 4), txt);
        txt.setTextAlign(Paint.Align.RIGHT);
        cv.drawText((100 - userPct) + "% " + oppCode, w - Ui.dp(getContext(), 8), h / 2f + Ui.dp(getContext(), 4), txt);
    }

    private static int shade(int argb, float f) {
        int a = (argb >>> 24) & 0xFF, r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        return (a << 24) | ((int) (r * f) << 16) | ((int) (g * f) << 8) | (int) (b * f);
    }
}
