package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Design Batch (v13, item 3): the drawn symbol system. Every status
 *  that used to ride on an emoji or a font glyph gets a tiny Canvas
 *  drawing instead — no font can break them (the v12.1 lesson: a "→"
 *  on the player card rendered as a stray character on a real phone).
 *
 *  ALL EIGHT symbols are genuinely DRAWN here (paths / arcs / rects /
 *  one letter of canvas text for the C and CF medallions):
 *    CAPTAIN  gold medallion with a C
 *    INJURED  white disc with a red medical cross
 *    RESTED   crescent moon (disc + offset cutout)
 *    OVERSEAS globe (circle + meridian ellipse + equator)
 *    STAR     five-point star (watched players)
 *    CONTRACT document (page + folded corner + text lines)
 *    TROPHY   cup with handles, stem and base
 *    COIN     gold CF coin
 *  Status TEXT labels always stay next to them — icons supplement the
 *  words, never replace them. */
public class Icons {
    public static final int CAPTAIN = 0, INJURED = 1, RESTED = 2, OVERSEAS = 3,
            STAR = 4, CONTRACT = 5, TROPHY = 6, COIN = 7;
    // Professional Pack P2 (suggestion 12): nav symbols, drawn in the
    // same style — HOME (roof + door), PERSON (head + shoulders),
    // BUILDING (tower + windows), SHIRT (kit). League reuses TROPHY,
    // World reuses the OVERSEAS globe.
    public static final int HOME = 8, PERSON = 9, BUILDING = 10, SHIRT = 11;
    // v21 (item 17): the premium symbol pass — weather + pitch glyphs
    // drawn at the same weight as the rest of the set (1dp strokes,
    // filled shapes, 20dp badge grid): SUN (clear), CLOUD (overcast),
    // RAIN (showers), PITCH (a prepared strip with crease lines).
    public static final int SUN = 12, RAIN = 13, CLOUD = 14, PITCH = 15;

    /** The weather badge for a fixture's rain risk: 40%+ is RAIN,
     *  15%+ CLOUD, below that SUN. */
    public static int weatherKind(int rainPct) {
        return rainPct >= 40 ? RAIN : rainPct >= 15 ? CLOUD : SUN;
    }

    /** Convenience: the weather badge view for a rain risk. */
    public static View weather(android.content.Context c, int rainPct) {
        return badge(c, weatherKind(rainPct));
    }

    public static class BadgeView extends View {
        private final int kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

        public BadgeView(Context c, int kind) {
            super(c);
            this.kind = kind;
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setFakeBoldText(true);
        }

        @Override
        protected void onMeasure(int w, int h) {
            int s = Ui.dp(getContext(), 20);
            setMeasuredDimension(s, s);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f - 1;
            switch (kind) {
                case CAPTAIN: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Ui.GOLD);
                    cv.drawCircle(cx, cy, r, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFF92400E);
                    p.setStrokeWidth(Ui.dp(getContext(), 1));
                    cv.drawCircle(cx, cy, r - 1, p);
                    txt.setColor(0xFF0F172A);
                    txt.setTextSize(r * 1.15f);
                    cv.drawText("C", cx, cy + r * 0.42f, txt);
                    break;
                }
                case INJURED: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFF8FAFC);
                    cv.drawCircle(cx, cy, r, p);
                    p.setColor(Ui.RED);
                    float a = r * 0.62f, b = r * 0.24f;
                    cv.drawRect(cx - b, cy - a, cx + b, cy + a, p);
                    cv.drawRect(cx - a, cy - b, cx + a, cy + b, p);
                    break;
                }
                case RESTED: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFF93C5FD);
                    cv.drawCircle(cx, cy, r, p);
                    p.setColor(Ui.CARD); // cutout — matches card bg closely enough at 20dp
                    cv.drawCircle(cx + r * 0.45f, cy - r * 0.35f, r * 0.82f, p);
                    break;
                }
                case OVERSEAS: {
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFF38BDF8);
                    p.setStrokeWidth(Ui.dp(getContext(), 1));
                    cv.drawCircle(cx, cy, r - 1, p);
                    RectF oval = new RectF(cx - r * 0.45f, cy - r + 1, cx + r * 0.45f, cy + r - 1);
                    cv.drawOval(oval, p);
                    cv.drawLine(cx - r + 1, cy, cx + r - 1, cy, p);
                    break;
                }
                case STAR: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Ui.GOLD);
                    Path star = new Path();
                    for (int i = 0; i < 10; i++) {
                        double ang = -Math.PI / 2 + i * Math.PI / 5;
                        float rad = i % 2 == 0 ? r : r * 0.45f;
                        float x = cx + (float) Math.cos(ang) * rad;
                        float y = cy + (float) Math.sin(ang) * rad;
                        if (i == 0) star.moveTo(x, y); else star.lineTo(x, y);
                    }
                    star.close();
                    cv.drawPath(star, p);
                    break;
                }
                case CONTRACT: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFE2E8F0);
                    RectF page = new RectF(cx - r * 0.62f, cy - r * 0.85f, cx + r * 0.62f, cy + r * 0.85f);
                    cv.drawRoundRect(page, 2, 2, p);
                    p.setColor(0xFF64748B);
                    for (int i = 0; i < 3; i++) {
                        float y = cy - r * 0.3f + i * r * 0.34f;
                        cv.drawRect(cx - r * 0.4f, y, cx + r * (i == 2 ? 0.05f : 0.4f), y + r * 0.13f, p);
                    }
                    break;
                }
                case TROPHY: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Ui.GOLD);
                    Path cup = new Path();
                    cup.moveTo(cx - r * 0.62f, cy - r * 0.8f);
                    cup.lineTo(cx + r * 0.62f, cy - r * 0.8f);
                    cup.lineTo(cx + r * 0.42f, cy + r * 0.05f);
                    cup.quadTo(cx, cy + r * 0.3f, cx - r * 0.42f, cy + r * 0.05f);
                    cup.close();
                    cv.drawPath(cup, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(Ui.dp(getContext(), 2));
                    cv.drawArc(new RectF(cx - r * 0.95f, cy - r * 0.75f, cx - r * 0.35f, cy - r * 0.05f), 90, 180, false, p);
                    cv.drawArc(new RectF(cx + r * 0.35f, cy - r * 0.75f, cx + r * 0.95f, cy - r * 0.05f), 270, 180, false, p);
                    p.setStyle(Paint.Style.FILL);
                    cv.drawRect(cx - r * 0.11f, cy + r * 0.22f, cx + r * 0.11f, cy + r * 0.55f, p);
                    cv.drawRect(cx - r * 0.45f, cy + r * 0.55f, cx + r * 0.45f, cy + r * 0.8f, p);
                    break;
                }
                case COIN: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Ui.GOLD);
                    cv.drawCircle(cx, cy, r, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFF92400E);
                    p.setStrokeWidth(Ui.dp(getContext(), 1));
                    cv.drawCircle(cx, cy, r * 0.78f, p);
                    txt.setColor(0xFF0F172A);
                    txt.setTextSize(r * 0.72f);
                    cv.drawText("CF", cx, cy + r * 0.27f, txt);
                    break;
                }
                case HOME: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFCBD5E1);
                    Path roof = new Path();
                    roof.moveTo(cx - r * 0.95f, cy - r * 0.15f);
                    roof.lineTo(cx, cy - r * 0.9f);
                    roof.lineTo(cx + r * 0.95f, cy - r * 0.15f);
                    roof.lineTo(cx + r * 0.72f, cy - r * 0.15f);
                    roof.lineTo(cx, cy - r * 0.62f);
                    roof.lineTo(cx - r * 0.72f, cy - r * 0.15f);
                    roof.close();
                    cv.drawPath(roof, p);
                    cv.drawRect(cx - r * 0.62f, cy - r * 0.12f, cx + r * 0.62f, cy + r * 0.85f, p);
                    p.setColor(Ui.BG);
                    cv.drawRect(cx - r * 0.16f, cy + r * 0.25f, cx + r * 0.16f, cy + r * 0.85f, p);
                    break;
                }
                case PERSON: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFCBD5E1);
                    cv.drawCircle(cx, cy - r * 0.38f, r * 0.34f, p);
                    Path sh = new Path();
                    sh.moveTo(cx - r * 0.78f, cy + r * 0.88f);
                    sh.quadTo(cx, cy - r * 0.28f, cx + r * 0.78f, cy + r * 0.88f);
                    sh.close();
                    cv.drawPath(sh, p);
                    break;
                }
                case BUILDING: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFCBD5E1);
                    cv.drawRect(cx - r * 0.55f, cy - r * 0.9f, cx + r * 0.55f, cy + r * 0.9f, p);
                    p.setColor(Ui.BG);
                    for (int wy = 0; wy < 3; wy++) {
                        for (int wx = 0; wx < 2; wx++) {
                            float x = cx - r * 0.32f + wx * r * 0.42f;
                            float y = cy - r * 0.68f + wy * r * 0.42f;
                            cv.drawRect(x, y, x + r * 0.22f, y + r * 0.24f, p);
                        }
                    }
                    break;
                }
                case SHIRT: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFCBD5E1);
                    Path kit = new Path();
                    kit.moveTo(cx - r * 0.3f, cy - r * 0.85f);
                    kit.lineTo(cx - r * 0.95f, cy - r * 0.45f);
                    kit.lineTo(cx - r * 0.68f, cy + r * 0.05f);
                    kit.lineTo(cx - r * 0.5f, cy - r * 0.1f);
                    kit.lineTo(cx - r * 0.5f, cy + r * 0.88f);
                    kit.lineTo(cx + r * 0.5f, cy + r * 0.88f);
                    kit.lineTo(cx + r * 0.5f, cy - r * 0.1f);
                    kit.lineTo(cx + r * 0.68f, cy + r * 0.05f);
                    kit.lineTo(cx + r * 0.95f, cy - r * 0.45f);
                    kit.lineTo(cx + r * 0.3f, cy - r * 0.85f);
                    kit.quadTo(cx, cy - r * 0.5f, cx - r * 0.3f, cy - r * 0.85f);
                    kit.close();
                    cv.drawPath(kit, p);
                    break;
                }
                case SUN: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Ui.GOLD);
                    cv.drawCircle(cx, cy, r * 0.52f, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(Math.max(1.5f, Ui.dp(getContext(), 1)));
                    for (int i = 0; i < 8; i++) {
                        double a = i * Math.PI / 4;
                        float x1 = cx + (float) Math.cos(a) * r * 0.68f;
                        float y1 = cy + (float) Math.sin(a) * r * 0.68f;
                        float x2 = cx + (float) Math.cos(a) * r * 0.95f;
                        float y2 = cy + (float) Math.sin(a) * r * 0.95f;
                        cv.drawLine(x1, y1, x2, y2, p);
                    }
                    break;
                }
                case CLOUD: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFCBD5E1);
                    cv.drawCircle(cx - r * 0.34f, cy + r * 0.12f, r * 0.42f, p);
                    cv.drawCircle(cx + r * 0.05f, cy - r * 0.18f, r * 0.55f, p);
                    cv.drawCircle(cx + r * 0.48f, cy + r * 0.12f, r * 0.40f, p);
                    cv.drawRect(cx - r * 0.72f, cy + r * 0.10f, cx + r * 0.86f, cy + r * 0.52f, p);
                    break;
                }
                case RAIN: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFF94A3B8);
                    cv.drawCircle(cx - r * 0.34f, cy - r * 0.28f, r * 0.40f, p);
                    cv.drawCircle(cx + r * 0.05f, cy - r * 0.55f, r * 0.52f, p);
                    cv.drawCircle(cx + r * 0.48f, cy - r * 0.28f, r * 0.38f, p);
                    cv.drawRect(cx - r * 0.70f, cy - r * 0.30f, cx + r * 0.84f, cy + r * 0.10f, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFF38BDF8);
                    p.setStrokeWidth(Math.max(1.5f, Ui.dp(getContext(), 1)));
                    for (int i = 0; i < 3; i++) {
                        float x = cx - r * 0.45f + i * r * 0.45f;
                        cv.drawLine(x, cy + r * 0.38f, x - r * 0.14f, cy + r * 0.82f, p);
                    }
                    break;
                }
                case PITCH: {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFD6B25E);
                    RectF strip = new RectF(cx - r * 0.38f, cy - r * 0.92f, cx + r * 0.38f, cy + r * 0.92f);
                    cv.drawRoundRect(strip, 2, 2, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFFF8FAFC);
                    p.setStrokeWidth(Ui.dp(getContext(), 1));
                    cv.drawLine(cx - r * 0.38f, cy - r * 0.55f, cx + r * 0.38f, cy - r * 0.55f, p);
                    cv.drawLine(cx - r * 0.38f, cy + r * 0.55f, cx + r * 0.38f, cy + r * 0.55f, p);
                    cv.drawLine(cx - r * 0.16f, cy - r * 0.55f, cx - r * 0.16f, cy - r * 0.30f, p);
                    cv.drawLine(cx + r * 0.16f, cy - r * 0.55f, cx + r * 0.16f, cy - r * 0.30f, p);
                    cv.drawLine(cx - r * 0.16f, cy + r * 0.30f, cx - r * 0.16f, cy + r * 0.55f, p);
                    cv.drawLine(cx + r * 0.16f, cy + r * 0.30f, cx + r * 0.16f, cy + r * 0.55f, p);
                    break;
                }
                default: break;
            }
        }
    }

    // ---------------- Rich Media (v20): morale faces ----------------
    // The reference apps show morale as a FACE; here it joins the
    // MeterChip's value + word (never replaces them — colour and
    // expression are a third signal, not the only one). Simple drawn
    // faces: circle + two eyes + a mouth path, green / gold / red.

    public static final int FACE_HAPPY = 0, FACE_NEUTRAL = 1, FACE_SAD = 2;

    /** Morale band for the face: 60+ happy, 40–59 neutral, under 40
     *  sad — the same thresholds Game.moraleLabel speaks in words
     *  (High/Good · Okay · Low/Very low), so face and word agree. */
    public static int faceForMorale(int morale) {
        if (morale >= 60) return FACE_HAPPY;
        if (morale >= 40) return FACE_NEUTRAL;
        return FACE_SAD;
    }

    public static class FaceView extends View {
        private final int face;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        public FaceView(Context c, int face) {
            super(c);
            this.face = face;
        }

        @Override
        protected void onMeasure(int w, int h) {
            int s = Ui.dp(getContext(), 20);
            setMeasuredDimension(s, s);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f - 1;
            int col = face == FACE_HAPPY ? 0xFF22C55E : face == FACE_NEUTRAL ? 0xFFF59E0B : 0xFFEF4444;
            p.setStyle(Paint.Style.FILL);
            p.setColor(col);
            cv.drawCircle(cx, cy, r, p);
            // eyes (dark on the coloured face)
            p.setColor(0xFF0F172A);
            float er = r * 0.13f, ey = cy - r * 0.22f, ex = r * 0.36f;
            cv.drawCircle(cx - ex, ey, er, p);
            cv.drawCircle(cx + ex, ey, er, p);
            // mouth: smile / straight / frown arc
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1.4f, r * 0.14f));
            float mw = r * 0.44f;
            if (face == FACE_HAPPY) {
                cv.drawArc(new RectF(cx - mw, cy - r * 0.05f, cx + mw, cy + r * 0.62f), 20, 140, false, p);
            } else if (face == FACE_SAD) {
                cv.drawArc(new RectF(cx - mw, cy + r * 0.28f, cx + mw, cy + r * 0.95f), 200, 140, false, p);
            } else {
                cv.drawLine(cx - mw * 0.8f, cy + r * 0.38f, cx + mw * 0.8f, cy + r * 0.38f, p);
            }
        }
    }

    /** A morale face sized for inline use beside a meter. */
    public static FaceView face(Context c, int morale) {
        FaceView f = new FaceView(c, faceForMorale(morale));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                Ui.dp(c, 20), Ui.dp(c, 20));
        lp.setMargins(0, 0, Ui.dp(c, 6), 0);
        f.setLayoutParams(lp);
        return f;
    }

    // ---------------- v20.1 (item 8): drawn mini flags ----------------
    // Simplified geometric flags for the World rankings rows — bold
    // bands, crosses, discs and stars at 24×17dp, keyed by the
    // canonical nation code (Design.nationCode). Deliberately simple:
    // a chip that reads as the flag at arm's length, drawn like every
    // other icon in the app (no emoji, no assets).

    public static class FlagView extends View {
        private final String code;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        public FlagView(Context c, String code) {
            super(c);
            this.code = code == null ? "" : code;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(Ui.dp(getContext(), 24), Ui.dp(getContext(), 17));
        }

        private void band(Canvas cv, float x0, float y0, float x1, float y1, int col) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(col);
            cv.drawRect(x0, y0, x1, y1, p);
        }

        private void disc(Canvas cv, float cx, float cy, float r, int col) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(col);
            cv.drawCircle(cx, cy, r, p);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float r = Ui.dp(getContext(), 2);
            // clip to a small rounded rect, then paint the design flat
            android.graphics.Path clip = new android.graphics.Path();
            clip.addRoundRect(new RectF(0, 0, w, h), r, r, android.graphics.Path.Direction.CW);
            cv.save();
            cv.clipPath(clip);
            switch (code) {
                case "PAK":
                    band(cv, 0, 0, w, h, 0xFF01411C);
                    band(cv, 0, 0, w * 0.26f, h, 0xFFF8FAFC);
                    disc(cv, w * 0.60f, h * 0.5f, h * 0.26f, 0xFFF8FAFC);
                    disc(cv, w * 0.66f, h * 0.44f, h * 0.21f, 0xFF01411C);
                    disc(cv, w * 0.74f, h * 0.30f, h * 0.055f, 0xFFF8FAFC);
                    break;
                case "IND":
                    band(cv, 0, 0, w, h / 3f, 0xFFF6952E);
                    band(cv, 0, h / 3f, w, 2 * h / 3f, 0xFFF8FAFC);
                    band(cv, 0, 2 * h / 3f, w, h, 0xFF138808);
                    disc(cv, w / 2f, h / 2f, h * 0.11f, 0xFF000080);
                    break;
                case "ENG":
                    band(cv, 0, 0, w, h, 0xFFF8FAFC);
                    band(cv, w * 0.44f, 0, w * 0.56f, h, 0xFFCE1124);
                    band(cv, 0, h * 0.40f, w, h * 0.60f, 0xFFCE1124);
                    break;
                case "AUS":
                    band(cv, 0, 0, w, h, 0xFF0B2A5B);
                    disc(cv, w * 0.26f, h * 0.72f, h * 0.13f, 0xFFF59E0B);
                    disc(cv, w * 0.68f, h * 0.28f, h * 0.07f, 0xFFF8FAFC);
                    disc(cv, w * 0.78f, h * 0.52f, h * 0.07f, 0xFFF8FAFC);
                    disc(cv, w * 0.62f, h * 0.74f, h * 0.07f, 0xFFF8FAFC);
                    break;
                case "WI":
                    band(cv, 0, 0, w, h, 0xFF63003B);
                    disc(cv, w / 2f, h / 2f, h * 0.27f, 0xFFF59E0B);
                    disc(cv, w / 2f, h / 2f, h * 0.10f, 0xFF0F172A);
                    break;
                case "SL":
                    band(cv, 0, 0, w, h, 0xFF8D153A);
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFFF59E0B);
                    p.setStrokeWidth(Math.max(1.2f, h * 0.07f));
                    cv.drawRect(h * 0.16f, h * 0.16f, w - h * 0.16f, h * 0.84f, p);
                    disc(cv, w / 2f, h / 2f, h * 0.15f, 0xFFF59E0B);
                    break;
                case "AFG":
                    band(cv, 0, 0, w / 3f, h, 0xFF111111);
                    band(cv, w / 3f, 0, 2 * w / 3f, h, 0xFFD32011);
                    band(cv, 2 * w / 3f, 0, w, h, 0xFF007A36);
                    break;
                case "ZIM": {
                    int[] cols = {0xFF319208, 0xFFFFD200, 0xFFEF3340, 0xFF111111,
                            0xFFEF3340, 0xFFFFD200, 0xFF319208};
                    for (int i = 0; i < cols.length; i++) {
                        band(cv, 0, h * i / 7f, w, h * (i + 1) / 7f, cols[i]);
                    }
                    android.graphics.Path tri = new android.graphics.Path();
                    tri.moveTo(0, 0); tri.lineTo(w * 0.38f, h / 2f); tri.lineTo(0, h);
                    tri.close();
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFF8FAFC);
                    cv.drawPath(tri, p);
                    disc(cv, w * 0.13f, h / 2f, h * 0.09f, 0xFFEF3340);
                    break;
                }
                case "IRE":
                    band(cv, 0, 0, w / 3f, h, 0xFF169B62);
                    band(cv, w / 3f, 0, 2 * w / 3f, h, 0xFFF8FAFC);
                    band(cv, 2 * w / 3f, 0, w, h, 0xFFFF883E);
                    break;
                case "NZ":
                    band(cv, 0, 0, w, h, 0xFF00247D);
                    disc(cv, w * 0.66f, h * 0.26f, h * 0.075f, 0xFFEF4444);
                    disc(cv, w * 0.76f, h * 0.46f, h * 0.075f, 0xFFEF4444);
                    disc(cv, w * 0.64f, h * 0.64f, h * 0.075f, 0xFFEF4444);
                    disc(cv, w * 0.78f, h * 0.76f, h * 0.075f, 0xFFEF4444);
                    break;
                case "SA":
                    band(cv, 0, 0, w, h * 0.34f, 0xFFE03C31);
                    band(cv, 0, h * 0.34f, w, h * 0.66f, 0xFFF8FAFC);
                    band(cv, 0, h * 0.66f, w, h, 0xFF001489);
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFF007749);
                    p.setStrokeWidth(h * 0.30f);
                    android.graphics.Path yPath = new android.graphics.Path();
                    yPath.moveTo(0, 0); yPath.lineTo(w * 0.42f, h / 2f);
                    yPath.lineTo(0, h); yPath.moveTo(w * 0.42f, h / 2f);
                    yPath.lineTo(w, h / 2f);
                    cv.drawPath(yPath, p);
                    p.setColor(0xFFF59E0B);
                    p.setStrokeWidth(h * 0.07f);
                    cv.drawPath(yPath, p);
                    break;
                case "BAN":
                    band(cv, 0, 0, w, h, 0xFF006A4E);
                    disc(cv, w * 0.46f, h / 2f, h * 0.30f, 0xFFF42A41);
                    break;
                default:
                    band(cv, 0, 0, w, h, 0xFF334155);
                    disc(cv, w / 2f, h / 2f, h * 0.16f, 0xFFF8FAFC);
                    break;
            }
            cv.restore();
            // hairline frame so pale flags (ENG/IRE) read on the card
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFF475569);
            p.setStrokeWidth(1f);
            cv.drawRoundRect(new RectF(0.5f, 0.5f, w - 0.5f, h - 0.5f), r, r, p);
        }
    }

    /** A flag chip sized for rankings rows. */
    public static FlagView flag(Context c, String code) {
        FlagView f = new FlagView(c, code);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                Ui.dp(c, 24), Ui.dp(c, 17));
        lp.setMargins(0, 0, Ui.dp(c, 8), 0);
        f.setLayoutParams(lp);
        return f;
    }

    /** A badge view sized for inline use. */
    public static BadgeView badge(Context c, int kind) {
        BadgeView b = new BadgeView(c, kind);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                Ui.dp(c, 20), Ui.dp(c, 20));
        lp.setMargins(0, 0, Ui.dp(c, 4), 0);
        b.setLayoutParams(lp);
        return b;
    }

    /** Badge + micro label, the standard status cluster unit. */
    public static LinearLayout labelled(Context c, int kind, String label, int labelColor) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, Ui.dp(c, 2), Ui.dp(c, 10), 0);
        row.setLayoutParams(lp);
        row.addView(badge(c, kind));
        TextView t = Ui.text(c, label, 11, labelColor, true);
        row.addView(t);
        return row;
    }
}
