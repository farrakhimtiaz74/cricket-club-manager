package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Design Batch (v13, item 9a): a player's initials disc — a circle
 *  tinted by his ROLE colour (Design.roleColor) with his initials in
 *  white. Gives every squad member a face-substitute that no font or
 *  image asset can break. */
public class AvatarView extends View {
    private final String initials;
    private final int bg;
    private final int sizeDp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AvatarView(Context c, String name, String role, int sizeDp) {
        super(c);
        this.initials = Design.initials(name);
        this.bg = Design.roleColor(role);
        this.sizeDp = sizeDp;
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setFakeBoldText(true);
        txt.setColor(0xFFFFFFFF);
    }

    @Override
    protected void onMeasure(int w, int h) {
        int s = Ui.dp(getContext(), sizeDp);
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(cx, cy) - 1;
        p.setStyle(Paint.Style.FILL);
        p.setColor(bg);
        cv.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFFFFFFFF);
        p.setAlpha(70);
        p.setStrokeWidth(Ui.dp(getContext(), 1));
        cv.drawCircle(cx, cy, r - 1, p);
        txt.setTextSize(r * 0.78f);
        cv.drawText(initials, cx, cy + r * 0.28f, txt);
    }
}
