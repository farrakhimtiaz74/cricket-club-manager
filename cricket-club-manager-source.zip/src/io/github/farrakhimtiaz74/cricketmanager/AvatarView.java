package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Design Batch (v13, item 9a): a player's initials disc — a circle
 *  tinted by his ROLE colour (Design.roleColor) with his initials in
 *  white. Gives every squad member a face-substitute that no font or
 *  image asset can break.
 *
 *  v21 (item 14): forPlayer() upgrades the disc to a REAL portrait —
 *  one of four GENERIC FICTIONAL faces (never the named player's
 *  likeness), graded in his club's colours by the asset pipeline and
 *  assigned deterministically by name (Design.avatarIndex). The
 *  initials disc remains as the total fallback: a missing asset can
 *  never blank a row. */
public class AvatarView extends View {
    private final String initials;
    private final int bg;
    private final int sizeDp;
    private android.graphics.Bitmap portrait;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AvatarView(Context c, String name, String role, int sizeDp) {
        super(c);
        this.initials = Design.initials(name);
        this.bg = Design.roleColor(role);
        this.sizeDp = sizeDp;
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setFakeBoldText(true);
        txt.setColor(0xFFFFFFFF);
    }

    /** The v21 portrait avatar for a player of `team` — his
     *  deterministic fictional portrait, or the initials disc when
     *  the asset cannot load. */
    public static AvatarView forPlayer(Context c, String name, String role, String team, int sizeDp) {
        AvatarView v = new AvatarView(c, name, role, sizeDp);
        v.portrait = Art.avatarBitmap(c, name, team, Math.max(96, sizeDp * 3));
        return v;
    }

    /** RecycleList rebind hook (item 9): re-point this view at a new
     *  player without rebuilding it. */
    public void bindPlayer(Context c, String name, String role, String team) {
        portrait = Art.avatarBitmap(c, name, team, Math.max(96, sizeDp * 3));
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int s = Ui.dp(getContext(), sizeDp);
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(cx, cy) - 1;
        if (portrait != null) {
            // the fictional portrait, centre-cropped into the disc
            android.graphics.Path clip = new android.graphics.Path();
            clip.addCircle(cx, cy, r, android.graphics.Path.Direction.CW);
            cv.save();
            cv.clipPath(clip);
            float s = Math.max(2 * r / portrait.getWidth(), 2 * r / portrait.getHeight());
            float dw = portrait.getWidth() * s, dh = portrait.getHeight() * s;
            cv.drawBitmap(portrait, null,
                    new android.graphics.RectF(cx - dw / 2f, cy - dh / 2f, cx + dw / 2f, cy + dh / 2f), p);
            cv.restore();
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFFFFFFFF);
            p.setAlpha(70);
            p.setStrokeWidth(Ui.dp(getContext(), 1));
            cv.drawCircle(cx, cy, r - 1, p);
            p.setAlpha(255);
            return;
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(bg);
        cv.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFFFFFFFF);
        p.setAlpha(70);
        p.setStrokeWidth(Ui.dp(getContext(), 1));
        cv.drawCircle(cx, cy, r - 1, p);
        txt.setTextSize(r * 0.78f);
        cv.drawText(initials, cx, cy + r * 0.28f, txt);
    }
}
