package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/** Professional Pack P5 (suggestions 43/44): the Help screen —
 *  reached from Profile and from Settings. Short guides ride in the
 *  P2 collapsibles; every number in them is the game's real value
 *  (Manager-difficulty figures, as the screen itself says): 300 CF a
 *  league win, wages on Days 7/14/21, a 22-man squad cap, the window
 *  on Days 13–15 with a 25 CF release fee, scouting at 40 CF, 1,500 /
 *  500 CF playoff prizes, 1,000 / 300 CF cup prizes from Season 2,
 *  the sack below 10 board confidence at a season's end. The
 *  Glossary section lists Glossary.TERMS verbatim — the same map the
 *  info chips open. */
public class HelpScreen {

    public static View build(final MainActivity act) {
        LinearLayout root = Ui.col(act);
        root.addView(Ui.subHeader(act, "Help & Guides",
                "Short guides, in plain words — figures are the standard Manager ones",
                v -> {
                    act.helpMode = false;
                    if (act.helpFromSettings) { act.settingsMode = true; }
                    else { act.tab = 4; }
                    act.render();
                }));

        root.addView(Ui.sectionHeader(act, "GUIDES"));
        guide(act, root, "Getting Started", true, new String[]{
                "Day 1: open the Team tab and check your XI — Auto-pick Best XI builds a legal side in one tap.",
                "Advance Day on the Hub until match day, then play the match ball by ball — or sim it.",
                "After each match, read the Coach's Corner tip on the Hub: it flags your most urgent problem.",
                "A season is 24 days of group matches, then the playoffs. Finish in your group's top two to reach them."});
        guide(act, root, "Picking Your XI", false, new String[]{
                "Pick exactly 11 players — no more, no fewer.",
                "One of them must be a wicketkeeper (WK).",
                "At least 5 must be bowling options (Bowl rating 60 or more).",
                "No more than 4 overseas players.",
                "Rested, injured and loaned-out players cannot play. Resting a tired man wins back 12 stamina a day."});
        guide(act, root, "Club Cash & Wages", false, new String[]{
                "You start with 700–1,200 CF, scaled to your club's strength.",
                "Winning a league match pays 300 CF, and Player of the Match adds 25 CF when he is yours.",
                "Home matches earn gate money from tickets, and a signed sponsor pays every week.",
                "Wages — players and staff together — are charged on Days 7, 14 and 21. Run short and the board and the squad both notice."});
        guide(act, root, "Transfers & the Auction", false, new String[]{
                "Between seasons you keep or release players, renew contracts, then bid in the auction against the other clubs.",
                "Your squad can hold at most 22 players.",
                "A mid-season window opens on Days 13–15: up to 2 signings, and releasing a player then costs 25 CF.",
                "Scouting costs 40 CF and reveals a player's true potential — less with a staff Scout on board.",
                "Free agents can be signed at any time from the Transfers screen."});
        guide(act, root, "Playoffs & the Cup", false, new String[]{
                "The top two in each group reach the playoffs: Qualifier (1st v 1st), Eliminator (2nd v 2nd), then the Final.",
                "Winning the Final pays 1,500 CF; the losing finalists get 500 CF.",
                "From Season 2, a 50-over One-Day Cup runs between the group stage and the playoffs — 1,000 CF to the winners, 300 to the runners-up."});
        guide(act, root, "Board Confidence & the Sack", false, new String[]{
                "The board rates you from 0 to 100. Wins, trophies and meeting your season objective push it up; losses and unpaid wages drag it down.",
                "Meeting the board's season objective pays +200 CF and +10 confidence.",
                "Drop under 25 and you get a warning. End a season under 10 and you are sacked — the career ends. In Hardcore the line is 20."});
        guide(act, root, "Backup & Sync Codes", false, new String[]{
                "Your career is saved on this phone only — there is no account and nothing is ever uploaded.",
                "In Settings, under Data, tap Create my career code and keep the code somewhere safe.",
                "On any phone with the game, paste that code into Continue from a career code to pick up the same career.",
                "Importing backs up your current career first, and you can undo it until you play a season match."});

        root.addView(Ui.sectionHeader(act, "GLOSSARY"));
        LinearLayout gloss = Ui.col(act);
        for (String term : Glossary.TERMS) {
            gloss.addView(Ui.listRow(act, null, term, Glossary.explain(term), null, null));
        }
        root.addView(Ui.collapsible(act, "ALL 12 TERMS, EXPLAINED", gloss, false));

        root.addView(Ui.sectionHeader(act, "THE WELCOME TOUR"));
        LinearLayout tour = Ui.card(act);
        tour.addView(Ui.body(act, "New here once, or just want the tour again?"));
        Button replay = Ui.darkBtn(act, "Replay the welcome");
        replay.setOnClickListener(v -> {
            act.helpMode = false;
            act.settingsMode = false;
            act.onboardingStep = 0;
            act.onboardingMode = true; // view-only: no career is touched
            act.render();
        });
        tour.addView(replay);
        root.addView(tour);
        return root;
    }

    /** One guide: its lines in a collapsible (P2 pattern). */
    private static void guide(MainActivity act, LinearLayout root, String title,
                              boolean open, String[] lines) {
        LinearLayout col = Ui.col(act);
        for (String s : lines) col.addView(Ui.body(act, "•  " + s));
        root.addView(Ui.collapsible(act, title.toUpperCase(), col, open));
    }
}
