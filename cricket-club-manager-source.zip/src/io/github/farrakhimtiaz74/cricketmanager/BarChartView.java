package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Design Batch (v13, item 8): the HQ Finances categories as a drawn
 *  bar chart — one horizontal bar per ledger category from
 *  Game.financeTotals(): income bars green, expense bars red, each
 *  scaled to the largest absolute category, signed value at the bar's
 *  end. Replaces the wall of same-looking text lines (the lines stay
 *  below the chart for the exact split). */
public class BarChartView extends View {
    private final String[] labels;
    private final int[] values;
    private final int maxAbs;
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lab = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint val = new Paint(Paint.ANTI_ALIAS_FLAG);

    public BarChartView(Context c, String[] labels, int[] values) {
        super(c);
        this.labels = labels;
        this.values = values;
        int m = 1;
        for (int v : values) m = Math.max(m, Math.abs(v));
        this.maxAbs = m;
        lab.setColor(Ui.MUTED);
        lab.setTextSize(Ui.dp(c, 10));
        val.setFakeBoldText(true);
        val.setTextSize(Ui.dp(c, 10));
    }

    private float rowH() { return Ui.dp(getContext(), 30); }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), (int) (rowH() * labels.length) + Ui.dp(getContext(), 4));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth();
        float rh = rowH();
        float barH = Ui.dp(getContext(), 11);
        for (int i = 0; i < labels.length; i++) {
            float y = i * rh;
            cv.drawText(labels[i], 0, y + Ui.dp(getContext(), 10), lab);
            int v = values[i];
            float bw = Math.max(Ui.dp(getContext(), 3), (w - Ui.dp(getContext(), 74)) * Math.abs(v) / (float) maxAbs);
            bar.setColor(v < 0 ? Ui.RED : Ui.GREEN);
            cv.drawRect(0, y + Ui.dp(getContext(), 15), bw, y + Ui.dp(getContext(), 15) + barH, bar);
            val.setColor(v < 0 ? Ui.RED : Ui.GREEN);
            val.setTextAlign(Paint.Align.LEFT);
            cv.drawText((v >= 0 ? "+" : "−") + Math.abs(v), bw + Ui.dp(getContext(), 6),
                    y + Ui.dp(getContext(), 15) + barH - 1, val);
        }
    }
}
