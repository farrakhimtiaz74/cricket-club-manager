package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/** Batch J (idea 98): the two CSV stat exports, built as pure text from
 *  the same books the UI reads — the Batch E tournament book (all teams)
 *  and the Batch C season-stats objects on the user's own squad — so a
 *  spreadsheet always agrees with the League and Team tabs. Pure Java:
 *  the screens hand the string to the share sheet (file in cache via
 *  ShareProvider, text fallback in MainActivity.shareTextFile). */
public class CsvExport {

    /** RFC-4180 quoting: quote when the value carries a comma, a quote
     *  or a newline, and double any inner quotes. Applied to every cell,
     *  not just names — cheap and always safe. */
    public static String esc(String s) {
        if (s == null) s = "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    private static void row(StringBuilder sb, Object... cells) {
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(esc(String.valueOf(cells[i])));
        }
        sb.append('\n');
    }

    private static String f1(double v) { return String.format(Locale.US, "%.1f", v); }
    private static String f2(double v) { return String.format(Locale.US, "%.2f", v); }

    /** (a) Tournament player stats, every team, MVP order — mirrors the
     *  📊 Tournament Leaders card (idea 43). */
    public static String tournamentCsv(Game g) {
        StringBuilder sb = new StringBuilder();
        row(sb, "Player", "Team", "Runs", "Balls Faced", "Outs", "50s", "100s",
                "Wickets", "Balls Bowled", "Runs Conceded", "3-fors", "5-fors",
                "Strike Rate", "Economy", "MVP Points");
        List<JSONObject> rows = new ArrayList<>();
        try {
            Iterator<String> it = g.tournBook.keys();
            while (it.hasNext()) {
                String name = it.next();
                JSONObject e = g.tournBook.getJSONObject(name);
                JSONObject r = new JSONObject(e.toString());
                r.put("name", name);
                rows.add(r);
            }
        } catch (Exception ignored) {}
        Collections.sort(rows, (a, b) -> Integer.compare(Game.mvpPoints(b), Game.mvpPoints(a)));
        for (JSONObject e : rows) {
            int balls = e.optInt("balls"), bwBalls = e.optInt("bwBalls");
            row(sb, e.optString("name"), e.optString("team"),
                    e.optInt("runs"), balls, e.optInt("outs"), e.optInt("f50"), e.optInt("f100"),
                    e.optInt("wkts"), bwBalls, e.optInt("conc"), e.optInt("f3"), e.optInt("f5"),
                    balls == 0 ? "0.0" : f1(e.optInt("runs") * 100.0 / balls),
                    bwBalls == 0 ? "0.00" : f2(e.optInt("conc") * 6.0 / bwBalls),
                    Game.mvpPoints(e));
        }
        return sb.toString();
    }

    /** (b) The user's squad season stats — the Batch C `ss` objects
     *  (idea 21), in squad order. Average = runs per dismissal (a not-out
     *  season so far reads as the raw runs, cricket convention aside). */
    public static String squadCsv(Game g) {
        StringBuilder sb = new StringBuilder();
        row(sb, "Player", "Role", "Age", "Matches", "Innings", "Runs", "Balls Faced", "Highest Score",
                "50s", "100s", "Average", "Strike Rate",
                "Wickets", "Balls Bowled", "Runs Conceded", "Best Wickets", "Best Runs",
                "Economy", "3-fors", "5-fors");
        for (int i = 0; i < g.players.length(); i++) {
            JSONObject p = g.players.optJSONObject(i);
            if (p == null) continue;
            JSONObject ss = p.optJSONObject("ss");
            if (ss == null) ss = new JSONObject();
            int balls = ss.optInt("balls"), bwBalls = ss.optInt("bwBalls"), outs = ss.optInt("outs");
            double avg = outs > 0 ? ss.optInt("runs") * 1.0 / outs : ss.optInt("runs");
            row(sb, p.optString("name"), p.optString("role"), p.optInt("age"),
                    ss.optInt("m"), ss.optInt("inn"), ss.optInt("runs"), balls, ss.optInt("hs"),
                    ss.optInt("f50"), ss.optInt("f100"),
                    f1(avg), balls == 0 ? "0.0" : f1(ss.optInt("runs") * 100.0 / balls),
                    ss.optInt("wkts"), bwBalls, ss.optInt("conc"), ss.optInt("bestW"), ss.optInt("bestR"),
                    bwBalls == 0 ? "0.00" : f2(ss.optInt("conc") * 6.0 / bwBalls),
                    ss.optInt("f3"), ss.optInt("f5"));
        }
        return sb.toString();
    }
}
