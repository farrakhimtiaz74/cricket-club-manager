package io.github.farrakhimtiaz74.cricketmanager;

/** Batch J (ideas 92–96): APP-LEVEL settings — deliberately NOT part of
 *  the career save. They live in their own SharedPreferences file
 *  ("ccm_settings", adapted in MainActivity) so they survive career
 *  resets, slot loads and sync-code imports, exactly like the Batch I
 *  slots survive in their own keys. All logic sits here, pure over a
 *  tiny key-value interface (the Slots pattern), so the defaults, the
 *  What's-New version comparison and every gating predicate are
 *  desktop-testable without Android.
 *
 *  Keys: last_seen_version (idea 92), comm_lang (idea 93: 0 English,
 *  1 Roman Urdu), sound_on + volume (idea 94), big_text + reduce_anim
 *  (idea 95). The commentary/match SPEED itself stays a career field
 *  (Game.speed, Batch A) — the Settings screen edits it there; only the
 *  reduce-animations override of it lives here (effectiveSpeed). */
public class Settings {

    public interface Kv {
        String get(String k);
        void put(String k, String v);
        void remove(String k);
    }

    public static final String K_LAST_SEEN = "last_seen_version";
    public static final String K_COMM_LANG = "comm_lang";
    public static final String K_SOUND_ON = "sound_on";
    public static final String K_VOLUME = "volume";
    public static final String K_BIG_TEXT = "big_text";
    public static final String K_REDUCE_ANIM = "reduce_anim";

    public static final int LANG_ENGLISH = 0;
    public static final int LANG_ROMAN_URDU = 1;
    public static final int VOL_LOW = 0, VOL_MED = 1, VOL_HIGH = 2;

    private final Kv kv;

    public Settings(Kv kv) {
        this.kv = kv;
    }

    // ---- raw access (string-encoded, Slots-style) ----

    private int getInt(String k, int def) {
        try {
            String s = kv == null ? null : kv.get(k);
            return s == null ? def : Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private boolean getBool(String k, boolean def) {
        String s = kv == null ? null : kv.get(k);
        if (s == null) return def;
        return "1".equals(s.trim()) || "true".equalsIgnoreCase(s.trim());
    }

    private void putInt(String k, int v) {
        if (kv != null) kv.put(k, String.valueOf(v));
    }

    private void putBool(String k, boolean v) {
        if (kv != null) kv.put(k, v ? "1" : "0");
    }

    // ---- idea 92: What's New show-once ----

    public int lastSeenVersion() { return getInt(K_LAST_SEEN, 0); }
    public void setLastSeenVersion(int v) { putInt(K_LAST_SEEN, v); }

    /** Show the What's New banner/screen when the stored version is
     *  behind the running build. A stored version AHEAD of the build
     *  (downgrade) never re-shows it. */
    public static boolean shouldShowWhatsNew(int storedVersion, int currentVersion) {
        return currentVersion > 0 && storedVersion < currentVersion;
    }

    // ---- idea 93: commentary language ----

    public int commLang() { return getInt(K_COMM_LANG, LANG_ENGLISH); }
    public void setCommLang(int lang) { putInt(K_COMM_LANG, lang == LANG_ROMAN_URDU ? 1 : 0); }
    public boolean urduComm() { return commLang() == LANG_ROMAN_URDU; }

    // ---- idea 94: sound effects ----

    public boolean soundOn() { return getBool(K_SOUND_ON, true); }
    public void setSoundOn(boolean on) { putBool(K_SOUND_ON, on); }
    public int volume() {
        int v = getInt(K_VOLUME, VOL_MED);
        return v < VOL_LOW ? VOL_LOW : v > VOL_HIGH ? VOL_HIGH : v;
    }
    public void setVolume(int v) { putInt(K_VOLUME, v < VOL_LOW ? VOL_LOW : v > VOL_HIGH ? VOL_HIGH : v); }

    /** ToneGenerator volume (0–100) for the Low/Med/High steps. */
    public static int volumePercent(int vol) {
        return vol <= VOL_LOW ? 30 : vol == VOL_MED ? 60 : 100;
    }

    // sound events for one played ball, from the match's lastBalls chips
    public static final int SND_NONE = 0, SND_TICK = 1, SND_FOUR = 2, SND_SIX = 3, SND_WICKET = 4;

    public static int soundEventFor(String lastBall) {
        if (lastBall == null) return SND_NONE;
        switch (lastBall) {
            case "W": return SND_WICKET;
            case "6": return SND_SIX;
            case "4": return SND_FOUR;
            case "0": case "1": case "2": case "3": return SND_TICK;
            default: return SND_NONE;
        }
    }

    /** The sound gate: sounds only ever play on LIVE paths (ball-by-ball
     *  taps, staged auto steps, Highlights steps, the full-time jingle).
     *  Instant whole-match sims pass livePath=false and stay silent, so
     *  the user never gets a wall of beeps. */
    public static boolean soundPlays(boolean soundOn, boolean livePath) {
        return soundOn && livePath;
    }

    // ---- idea 95: big text + reduce animations ----

    public boolean bigText() { return getBool(K_BIG_TEXT, false); }
    public void setBigText(boolean on) { putBool(K_BIG_TEXT, on); }
    public boolean reduceAnim() { return getBool(K_REDUCE_ANIM, false); }
    public void setReduceAnim(boolean on) { putBool(K_REDUCE_ANIM, on); }

    /** The Ui text-scale factor: 1.0 normal, 1.25 with Big Text on. */
    public static float textScale(boolean bigText) {
        return bigText ? 1.25f : 1.0f;
    }

    /** Reduce Animations forces every staged sim to Instant (Game.speed
     *  semantics: 0 = Instant, 1 = 1x, 2 = 2x), whatever the career's
     *  saved speed says. */
    public static int effectiveSpeed(int gameSpeed, boolean reduceAnim) {
        return reduceAnim ? 0 : gameSpeed;
    }

    /** Staged (Handler-driven) stepping exists only when animations are
     *  allowed; with Reduce Animations on, sims resolve synchronously and
     *  Highlights jump straight key-ball to key-ball. */
    public static boolean stagedAllowed(boolean reduceAnim) {
        return !reduceAnim;
    }
}
