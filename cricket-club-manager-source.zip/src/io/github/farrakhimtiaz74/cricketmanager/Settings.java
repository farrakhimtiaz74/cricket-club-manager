package io.github.farrakhimtiaz74.cricketmanager;

/** Batch J (ideas 92–96): APP-LEVEL settings — deliberately NOT part of
 *  the career save. They live in their own SharedPreferences file
 *  ("ccm_settings", adapted in MainActivity) so they survive career
 *  resets, slot loads and sync-code imports, exactly like the Batch I
 *  slots survive in their own keys. All logic sits here, pure over a
 *  tiny key-value interface (the Slots pattern), so the defaults, the
 *  What's-New version comparison and every gating predicate are
 *  desktop-testable without Android.
 *
 *  Keys: last_seen_version (idea 92), comm_lang (idea 93: 0 English,
 *  1 Roman Urdu), sound_on + volume (idea 94), big_text + reduce_anim
 *  (idea 95). The Audio Pack (v19) adds the mixer keys: ch_match /
 *  ch_crowd / ch_ui / ch_music / ch_voice (0-100), quiet_mode and
 *  voice_on — all read through the same Kv. The commentary/match SPEED itself stays a career field
 *  (Game.speed, Batch A) — the Settings screen edits it there; only the
 *  reduce-animations override of it lives here (effectiveSpeed). */
public class Settings {

    public interface Kv {
        String get(String k);
        void put(String k, String v);
        void remove(String k);
    }

    public static final String K_LAST_SEEN = "last_seen_version";
    public static final String K_COMM_LANG = "comm_lang";
    public static final String K_SOUND_ON = "sound_on";
    public static final String K_VOLUME = "volume";
    public static final String K_BIG_TEXT = "big_text";
    public static final String K_REDUCE_ANIM = "reduce_anim";
    // Professional Pack P5 (suggestion 41): the first-launch welcome
    // tour's seen flag — app-level like everything here, so it survives
    // career resets and is never part of the career save.
    public static final String K_ONBOARDING_SEEN = "onboarding_seen";

    public static final int LANG_ENGLISH = 0;
    public static final int LANG_ROMAN_URDU = 1;
    public static final int VOL_LOW = 0, VOL_MED = 1, VOL_HIGH = 2;

    private final Kv kv;

    public Settings(Kv kv) {
        this.kv = kv;
    }

    // ---- raw access (string-encoded, Slots-style) ----

    private int getInt(String k, int def) {
        try {
            String s = kv == null ? null : kv.get(k);
            return s == null ? def : Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private boolean getBool(String k, boolean def) {
        String s = kv == null ? null : kv.get(k);
        if (s == null) return def;
        return "1".equals(s.trim()) || "true".equalsIgnoreCase(s.trim());
    }

    private void putInt(String k, int v) {
        if (kv != null) kv.put(k, String.valueOf(v));
    }

    private void putBool(String k, boolean v) {
        if (kv != null) kv.put(k, v ? "1" : "0");
    }

    // ---- idea 92: What's New show-once ----

    public int lastSeenVersion() { return getInt(K_LAST_SEEN, 0); }
    public void setLastSeenVersion(int v) { putInt(K_LAST_SEEN, v); }

    /** Show the What's New banner/screen when the stored version is
     *  behind the running build. A stored version AHEAD of the build
     *  (downgrade) never re-shows it. */
    public static boolean shouldShowWhatsNew(int storedVersion, int currentVersion) {
        return currentVersion > 0 && storedVersion < currentVersion;
    }

    // ---- idea 93: commentary language ----

    public int commLang() { return getInt(K_COMM_LANG, LANG_ENGLISH); }
    public void setCommLang(int lang) { putInt(K_COMM_LANG, lang == LANG_ROMAN_URDU ? 1 : 0); }
    public boolean urduComm() { return commLang() == LANG_ROMAN_URDU; }

    // ---- idea 94: sound effects ----

    public boolean soundOn() { return getBool(K_SOUND_ON, true); }
    public void setSoundOn(boolean on) { putBool(K_SOUND_ON, on); }
    public int volume() {
        int v = getInt(K_VOLUME, VOL_MED);
        return v < VOL_LOW ? VOL_LOW : v > VOL_HIGH ? VOL_HIGH : v;
    }
    public void setVolume(int v) { putInt(K_VOLUME, v < VOL_LOW ? VOL_LOW : v > VOL_HIGH ? VOL_HIGH : v); }

    /** Master volume (0–100) for the Low/Med/High steps — the Audio
     *  Pack mixer scales every channel by this. */
    public static int volumePercent(int vol) {
        return vol <= VOL_LOW ? 30 : vol == VOL_MED ? 60 : 100;
    }

    // sound events for one played ball, from the match's lastBalls chips
    public static final int SND_NONE = 0, SND_TICK = 1, SND_FOUR = 2, SND_SIX = 3, SND_WICKET = 4;

    public static int soundEventFor(String lastBall) {
        if (lastBall == null) return SND_NONE;
        switch (lastBall) {
            case "W": return SND_WICKET;
            case "6": return SND_SIX;
            case "4": return SND_FOUR;
            case "0": case "1": case "2": case "3": return SND_TICK;
            default: return SND_NONE;
        }
    }

    /** The sound gate: sounds only ever play on LIVE paths (ball-by-ball
     *  taps, staged auto steps, Highlights steps, the full-time jingle).
     *  Instant whole-match sims pass livePath=false and stay silent, so
     *  the user never gets a wall of beeps. */
    public static boolean soundPlays(boolean soundOn, boolean livePath) {
        return soundOn && livePath;
    }

    // ---- Audio Pack (v19): the mixer (suggestions 23-25) ----
    // Five channels, each 0-100 in prefs; Quiet Mode lets only big
    // events through; the voice toggle arms the spoken score updates
    // (suggestions 21-22, OFF by default). v21 (item 2 + deletion D1):
    // the voice is now the bundled Voice Pack clip library stitched
    // by VoiceLine — the Android system-TTS path is gone. All
    // app-level, like every other key in this file — the career save
    // never sees them.

    public static final String K_CH_MATCH = "ch_match";
    public static final String K_CH_CROWD = "ch_crowd";
    public static final String K_CH_UI = "ch_ui";
    public static final String K_CH_MUSIC = "ch_music";
    public static final String K_CH_VOICE = "ch_voice";
    public static final String K_QUIET = "quiet_mode";
    public static final String K_VOICE_ON = "voice_on";

    public static final int CH_MATCH = 0, CH_CROWD = 1, CH_UI = 2, CH_MUSIC = 3, CH_VOICE = 4;
    public static final String[] CH_NAMES = {"Match", "Crowd", "UI", "Music", "Voice"};
    private static final String[] CH_KEYS = {K_CH_MATCH, K_CH_CROWD, K_CH_UI, K_CH_MUSIC, K_CH_VOICE};
    private static final int[] CH_DEFAULTS = {90, 80, 60, 50, 100};

    public int channelVol(int ch) {
        if (ch < 0 || ch > 4) return 0;
        int v = getInt(CH_KEYS[ch], CH_DEFAULTS[ch]);
        return v < 0 ? 0 : v > 100 ? 100 : v;
    }

    public void setChannelVol(int ch, int v) {
        if (ch < 0 || ch > 4) return;
        putInt(CH_KEYS[ch], v < 0 ? 0 : v > 100 ? 100 : v);
    }

    public boolean quietMode() { return getBool(K_QUIET, false); }
    public void setQuietMode(boolean on) { putBool(K_QUIET, on); }
    public boolean voiceOn() { return getBool(K_VOICE_ON, false); }
    public void setVoiceOn(boolean on) { putBool(K_VOICE_ON, on); }

    /** Playback gain 0..100 for a channel: the legacy Low/Med/High
     *  master step scales every channel equally. */
    public int channelPercent(int ch) {
        return volumePercent(volume()) * channelVol(ch) / 100;
    }

    /** The Audio Pack gate, pure so the whole truth table is testable:
     *  master off blocks everything; a live-path requirement blocks
     *  sim paths; a silent channel blocks its own sounds; Quiet Mode
     *  blocks anything that is not a big event. */
    public static boolean audioGate(boolean masterOn, boolean quiet,
                                    boolean liveRequired, boolean livePath,
                                    int chanVol, boolean bigEvent) {
        if (!masterOn) return false;
        if (liveRequired && !livePath) return false;
        if (chanVol <= 0) return false;
        if (quiet && !bigEvent) return false;
        return true;
    }

    // ---- idea 95: big text + reduce animations ----

    public boolean bigText() { return getBool(K_BIG_TEXT, false); }
    public void setBigText(boolean on) { putBool(K_BIG_TEXT, on); }
    public boolean reduceAnim() { return getBool(K_REDUCE_ANIM, false); }
    public void setReduceAnim(boolean on) { putBool(K_REDUCE_ANIM, on); }

    /** The Ui text-scale factor: 1.0 normal, 1.25 with Big Text on. */
    public static float textScale(boolean bigText) {
        return bigText ? 1.25f : 1.0f;
    }

    /** Reduce Animations forces every staged sim to Instant (Game.speed
     *  semantics: 0 = Instant, 1 = 1x, 2 = 2x), whatever the career's
     *  saved speed says. */
    public static int effectiveSpeed(int gameSpeed, boolean reduceAnim) {
        return reduceAnim ? 0 : gameSpeed;
    }

    /** Staged (Handler-driven) stepping exists only when animations are
     *  allowed; with Reduce Animations on, sims resolve synchronously and
     *  Highlights jump straight key-ball to key-ball. */
    public static boolean stagedAllowed(boolean reduceAnim) {
        return !reduceAnim;
    }

    // ---- P5 (suggestion 41): first-launch onboarding ----

    public boolean onboardingSeen() { return getBool(K_ONBOARDING_SEEN, false); }
    public void setOnboardingSeen(boolean seen) { putBool(K_ONBOARDING_SEEN, seen); }

    /** The welcome tour shows ONLY on a true first launch: no career
     *  exists yet AND the tour has never been finished or skipped. An
     *  existing career never triggers it, and the Help screen's replay
     *  is a separate view-only path that bypasses this predicate. */
    public static boolean shouldShowOnboarding(boolean hasCareer, boolean seen) {
        return !hasCareer && !seen;
    }

    // ---- v21: theme engine (item 10) + version bookkeeping (item 11) ----

    public static final String K_THEME_LOOK = "theme_look";
    public static final String K_APP_VERSION = "app_version";
    public static final String[] THEME_NAMES = {"Club", "Midnight", "Classic Gold"};

    /** The app look: 0 Club (per-club theme pack), 1 Midnight,
     *  2 Classic Gold. Clamped to the known range. */
    public int themeLook() {
        int v = getInt(K_THEME_LOOK, Design.THEME_CLUB);
        return v < 0 ? 0 : v > 2 ? 2 : v;
    }

    public void setThemeLook(int v) { putInt(K_THEME_LOOK, v < 0 ? 0 : v > 2 ? 2 : v); }

    /** The last versionCode that launched the app (0 = never
     *  recorded). Drives the pre-update backup: when the running
     *  build is newer, MainActivity copies the career into the
     *  pre-update backup key BEFORE any migration runs. */
    public int appVersion() { return getInt(K_APP_VERSION, 0); }
    public void setAppVersion(int v) { putInt(K_APP_VERSION, v); }

    /** True when a RECORDED version is behind the running build.
     *  (MainActivity's backup hook additionally treats a stored 0
     *  with an existing save as an upgrade — the key is new in v21,
     *  so pre-v21 installs have nothing recorded.) */
    public static boolean isUpgrade(int storedVersion, int currentVersion) {
        return currentVersion > 0 && storedVersion > 0 && storedVersion < currentVersion;
    }
}
