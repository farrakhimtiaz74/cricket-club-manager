package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HqScreen {
 public static View build(final MainActivity act) {
 final Game g = act.g;
 LinearLayout root = Ui.col(act);

 // P2 (suggestion 14): category headers group the HQ tab
 root.addView(Ui.sectionHeader(act, "CLUB"));
 LinearLayout head = Ui.card(act);
 head.addView(Ui.gold(act, "HEADQUARTERS", 13));
 LinearLayout cashRow = Ui.row(act);
 cashRow.addView(Icons.badge(act, Icons.COIN));
 cashRow.addView(Ui.h2(act, "Club Cash: " + g.cf + " CF"));
 head.addView(cashRow);
 head.addView(Ui.small(act, "Win matches and grow the club. Every facility maxes at Level " + Data.FACILITY_MAX + "."));
 root.addView(head);

 // Batch G (ideas 67/70/68): the board and the fans, at a glance
 // Design Batch (item 8): the ASCII block meters are now DRAWN gauges
 // v20.1 (item 2): both meters are Ui.meterRow — the same slim
 // component the Hub uses, label + number + word above a 10dp bar.
 LinearLayout bf = Ui.card(act);
 bf.addView(Ui.h2(act, "Board & Fans"));
 bf.addView(Ui.meterRow(act, "Board Confidence", g.boardConfidence, null));
 if (g.boardWarning()) {
 bf.addView(Ui.text(act, "THE BOARD IS LOSING PATIENCE… end the season under 10 and you are sacked.", 13, Ui.RED, true));
 }
 bf.addView(Ui.small(act, "Board objective (Season " + g.boardObjectiveSeason + "): " + g.boardObjectiveText
 + " — meet it for +10 confidence and +200 CF."));
 bf.addView(Ui.meterRow(act, "Fan Mood", g.fanMood, g.fanMoodLabel()));
 bf.addView(Ui.small(act, "Happy fans fill the ground (80+ mood: +8% crowd); angry ones stay home (under 35: −10%)."));
 root.addView(bf);

 // Batch G (idea 64): sponsorship
 root.addView(Ui.sectionHeader(act, "DEALS & STAFF"));
 View sp = sponsorCard(act);
 if (sp != null) root.addView(sp);

 // Batch G (idea 66): pre-season training camp
 View cc = campCard(act);
 if (cc != null) root.addView(cc);

 // Batch G (idea 61): backroom staff
 root.addView(staffCard(act));

 // Batch G (idea 63): ticket pricing
 LinearLayout tk = Ui.card(act);
 tk.addView(Ui.h2(act, "Ticket Pricing"));
 tk.addView(Ui.text(act, "Current: " + g.ticketTierName() + " — gate x" + g.ticketMultiplier()
 + " · crowd " + (g.ticketAttendanceShift() >= 0 ? "+" : "") + g.ticketAttendanceShift() + "%", 14, Ui.GOLD, true));
 tk.addView(Ui.small(act, "Dearer seats pay more per fan but empty the stands and cool the mood; Cheap seats please the fans."));
 LinearLayout trow = Ui.row(act);
 Button cheaper = Ui.darkBtn(act, "◀ Cheaper");
 cheaper.setEnabled(g.ticketTier > 0);
 cheaper.setOnClickListener(v -> { act.g.setTicketTier(act.g.ticketTier - 1); act.save(); act.render(); });
 Button dearer = Ui.darkBtn(act, "Pricier ▶");
 dearer.setEnabled(g.ticketTier < 4);
 dearer.setOnClickListener(v -> { act.g.setTicketTier(act.g.ticketTier + 1); act.save(); act.render(); });
 LinearLayout.LayoutParams thalf = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1);
 cheaper.setLayoutParams(thalf);
 dearer.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 trow.addView(cheaper);
 trow.addView(dearer);
 tk.addView(trow);
 root.addView(tk);

 // Batch D (ideas 31–40): Transfers & Contracts sub-screen entry
 LinearLayout tr = Ui.card(act);
 tr.addView(Ui.h2(act, "Transfers & Contracts"));
 String tState;
 if (g.offseason == 1) tState = "OFF-SEASON Step 1: retain, release & renew — action needed!";
 else if (g.offseason == 2) tState = "OFF-SEASON Step 2: the auction is LIVE — action needed!";
 else if (g.transferWindowOpen()) tState = "Mid-season window OPEN — " + g.windowSigns + "/" + Game.WINDOW_MAX_SIGNINGS + " signings used.";
 else tState = "Window opens Day " + Game.WINDOW_OPEN_DAY + " · Free agents signable any time · Wages " + g.weeklyWages() + " CF/week.";
 tr.addView(Ui.small(act, tState));
 if (g.poachOffer != null) {
 tr.addView(Ui.text(act, g.poachOffer.optString("team") + " have bid "
 + g.poachOffer.optInt("fee") + " CF for " + g.poachOffer.optString("name") + "!", 13, Ui.RED, true));
 }
 Button open = Ui.goldBtn(act, "Open Transfers");
 open.setOnClickListener(v -> { act.transfersMode = true; act.render(); });
 tr.addView(open);
 root.addView(tr);

 root.addView(Ui.sectionHeader(act, "FACILITIES"));
 int facHeaderIdx = root.getChildCount() - 1; // v20: the campus map inserts right under this
 final View[] facViews = new View[Data.FACILITY_NAMES.length]; // v20: hotspot scroll targets
 for (int i = 0; i < Data.FACILITY_NAMES.length; i++) {
 final int idx = i;
 int lvl = g.facilityLevel(idx);
 LinearLayout card = Ui.card(act);
 facViews[idx] = card;
 card.addView(Ui.h2(act, Data.FACILITY_NAMES[idx]));
 // Batch G (idea 62): a 10-segment bar + tier name + the numbers
 // v20.1 (item 11): the level FIGURES print in the display face
 // (the ●/○ pips stay text glyphs, as before)
 StringBuilder pips = new StringBuilder("Level ");
 for (int k = 0; k < Data.FACILITY_MAX; k++) pips.append(k < lvl ? "●" : "○");
 LinearLayout lvlRow = Ui.row(act);
 lvlRow.addView(Ui.gold(act, pips.toString(), 14));
 TextView lvlNum = Ui.display(act, " " + lvl + "/" + Data.FACILITY_MAX, 14, Ui.GOLD);
 lvlRow.addView(lvlNum);
 lvlRow.addView(Ui.gold(act, " · " + g.facilityTier(lvl), 14));
 card.addView(lvlRow);
 card.addView(Ui.small(act, Data.FACILITY_EFFECT[idx]));
 card.addView(Ui.text(act, "Now: " + g.facilityBenefit(idx, lvl), 13, Ui.INK, false));
 if (lvl >= Data.FACILITY_MAX) {
 card.addView(Ui.text(act, "MAX LEVEL — WORLD CLASS", 14, Ui.GREEN, true));
 } else {
 card.addView(Ui.small(act, "Next (Level " + (lvl + 1) + " · " + g.facilityTier(lvl + 1) + "): "
 + g.facilityBenefit(idx, lvl + 1)));
 final int cost = g.facilityUpgradeCost(idx);
 Button up = Ui.goldBtn(act, "Upgrade — " + cost + " CF");
 up.setEnabled(g.cf >= cost);
 if (g.cf < cost) up.setText("Upgrade — " + cost + " CF (not enough)");
 up.setOnClickListener(v -> {
 if (act.g.upgradeFacility(idx)) {
 act.save();
 act.toast(Data.FACILITY_NAMES[idx] + " upgraded!");
 } else {
 act.toast("Not enough CF");
 }
 act.render();
 });
 card.addView(up);
 }
 root.addView(card);
 }

 // Rich Media (v20): THE CAMPUS — the generated aerial artwork of
 // the grounds with a tappable label over each building (stadium
 // top-centre, medical left, training right, academy bottom-left,
 // commercial bottom-right). A tap scrolls this same screen to
 // that facility's card below: the map is a way INTO the list,
 // and the full list stays right here under it. If the art fails
 // to decode, the section simply doesn't render.
 android.graphics.Bitmap campusBmp = Art.bitmap(act, Art.CAMPUS, 1080);
 if (campusBmp != null) {
 LinearLayout campusCard = Ui.card(act);
 campusCard.addView(Ui.h2(act, "The Grounds"));
 CampusView campus = new CampusView(act, campusBmp, g);
 campus.setOnHotspot(idx -> act.scrollToViewDelayed(facViews[idx]));
 campusCard.addView(campus);
 campusCard.addView(Ui.small(act, "Tap a building to jump to its card — every facility is also in the list below."));
 root.addView(campusCard, facHeaderIdx + 1);
 }

 // Batch G: Finances — this season's ledger, categorised
 // Design Batch (item 8): a drawn bar chart over the exact lines
 // P2 (suggestions 14/16): the per-category detail lines fold into
 // a collapsible under the chart + season net (both stay visible)
 root.addView(Ui.sectionHeader(act, "MONEY"));
 LinearLayout fin = Ui.card(act);
 fin.addView(Ui.h2(act, "Finances — Season " + g.season));
 org.json.JSONObject ft = g.financeTotals();
 // P4 (suggestion 37): the dashboard — three figure tiles first
 // (income / spending / net, Present.financeSummary over the same
 // financeTotals the chart and detail use, so they always agree)
 int[] fs = Present.financeSummary(ft);
 LinearLayout tiles = Ui.row(act);
 tiles.addView(finTile(act, "INCOME", "+" + fs[0], Ui.GREEN));
 tiles.addView(finTile(act, "SPENDING", "−" + fs[1], Ui.RED));
 tiles.addView(finTile(act, "NET", signed(fs[2]), fs[2] >= 0 ? Ui.GOLD : Ui.RED));
 fin.addView(tiles);
 fin.addView(new BarChartView(act,
 new String[]{"Prizes", "Gate", "Merch", "Sponsor", "Wages", "Transfers", "Upgrades", "Other"},
 new int[]{ft.optInt("prizes"), ft.optInt("gate"), ft.optInt("merch"), ft.optInt("sponsor"),
 ft.optInt("wages"), ft.optInt("transfers"), ft.optInt("upgrades"), ft.optInt("other")}));
 // P4: the wage bill, as a line with its share of season income
 fin.addView(Ui.text(act, "Wage bill: " + g.weeklyWages() + " CF/week · season wages "
 + Math.abs(ft.optInt("wages")) + " CF = " + Present.wageSharePct(ft) + "% of season income",
 13, Ui.INK, false));
 // P4: the season's biggest single lines, in and out
 org.json.JSONObject bigIn = null, bigOut = null;
 for (int i = 0; i < g.ledger.length(); i++) {
 org.json.JSONObject e = g.ledger.optJSONObject(i);
 if (e == null || e.optInt("season") != g.season) continue;
 if (bigIn == null || e.optInt("amt") > bigIn.optInt("amt")) bigIn = e;
 if (bigOut == null || e.optInt("amt") < bigOut.optInt("amt")) bigOut = e;
 }
 if (bigIn != null && bigIn.optInt("amt") > 0) {
 fin.addView(Ui.listRow(act, Icons.badge(act, Icons.COIN), bigIn.optString("reason"),
 "Biggest single income · Day " + bigIn.optInt("day"), "+" + bigIn.optInt("amt") + " CF", null));
 }
 if (bigOut != null && bigOut.optInt("amt") < 0) {
 fin.addView(Ui.listRow(act, Icons.badge(act, Icons.CONTRACT), bigOut.optString("reason"),
 "Biggest single expense · Day " + bigOut.optInt("day"), bigOut.optInt("amt") + " CF", null));
 }
 LinearLayout finLines = Ui.col(act);
 finLines.addView(Ui.small(act, "Prize money: " + signed(ft.optInt("prizes")) + " CF"));
 finLines.addView(Ui.small(act, "Gate receipts: " + signed(ft.optInt("gate")) + " CF"));
 finLines.addView(Ui.small(act, "Merchandise: " + signed(ft.optInt("merch")) + " CF"));
 finLines.addView(Ui.small(act, "Sponsor & commercial: " + signed(ft.optInt("sponsor")) + " CF"));
 finLines.addView(Ui.small(act, "Wages: " + signed(ft.optInt("wages")) + " CF (players " + ft.optInt("playerWages")
 + " · staff " + ft.optInt("staffWages")
 + (ft.optInt("wageDiscount") > 0 ? " · manager discount −" + ft.optInt("wageDiscount") : "") + ")"));
 finLines.addView(Ui.small(act, "Transfers & signings: " + signed(ft.optInt("transfers")) + " CF"));
 finLines.addView(Ui.small(act, "Facility upgrades: " + signed(ft.optInt("upgrades")) + " CF"));
 finLines.addView(Ui.small(act, "Other: " + signed(ft.optInt("other")) + " CF"));
 fin.addView(Ui.collapsible(act, "CATEGORY DETAIL", finLines, false));
 root.addView(fin);

 // Batch C (idea 24): physio room — the injury list, tied to Medical Centre
 LinearLayout physio = Ui.card(act);
 physio.addView(Ui.h2(act, "Physio Room"));
 boolean anyInj = false;
 for (int i = 0; i < g.players.length(); i++) {
 org.json.JSONObject p = g.player(i);
 if (p.optInt("injured", 0) > 0) {
 anyInj = true;
 physio.addView(Ui.text(act, "•  " + p.optString("name") + " — " + p.optString("injType")
 + " · " + p.optInt("injured") + " day(s) left", 13, Ui.RED, false));
 }
 }
 if (!anyInj) physio.addView(Ui.small(act, "Full squad fit — nobody in treatment."));
 physio.addView(Ui.small(act, "Medical Centre is Level " + g.facilityLevel(1)
 + ": higher levels shorten new injuries and improve Recovery sessions."));
 root.addView(physio);

 // v2 Club Cash ledger: every CF movement, newest first, survives restarts + rollovers
 LinearLayout ledgerCard = Ui.card(act);
 ledgerCard.addView(Ui.h2(act, "Club Cash Ledger"));
 if (g.ledger.length() == 0) {
 ledgerCard.addView(Ui.small(act, "No transactions yet."));
 }
 for (int i = 0; i < g.ledger.length(); i++) {
 org.json.JSONObject e = g.ledger.optJSONObject(i);
 if (e == null) continue;
 int amt = e.optInt("amt");
 String line = (amt >= 0 ? "+" : "−") + Math.abs(amt) + " CF · " + e.optString("reason")
 + " (S" + e.optInt("season") + " · Day " + e.optInt("day") + ")";
 TextView t = Ui.text(act, line, 13, amt >= 0 ? Ui.GREEN : Ui.RED, false);
 t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
 ledgerCard.addView(t);
 }
 root.addView(ledgerCard);
 // Rich Media (v20): a pending campus hotspot scroll (set when a
 // hotspot tap re-rendered us — the direct path scrolls without a
 // re-render, this covers any future deep-link into a facility)
 if (act.hqScrollTarget >= 0 && act.hqScrollTarget < facViews.length
 && facViews[act.hqScrollTarget] != null) {
 View target = facViews[act.hqScrollTarget];
 act.hqScrollTarget = -1;
 act.scrollToViewDelayed(target);
 }
 return root;
 }

 // ---------------- Batch G helpers (shared with the Hub) ----------------

 /** A 10-block meter for a 0..100 value. */
 public static String meter(int v) {
 StringBuilder sb = new StringBuilder();
 int filled = Math.max(0, Math.min(10, v / 10));
 for (int i = 0; i < 10; i++) sb.append(i < filled ? "▓" : "░");
 return sb.toString();
 }

 public static String signed(int amt) {
 return (amt >= 0 ? "+" : "−") + Math.abs(amt);
 }

 /** P4 (suggestion 37): one dashboard figure tile — micro label
 *  over a display-type figure, weighted a third of the row. */
 private static View finTile(MainActivity act, String label, String value, int color) {
 LinearLayout t = Ui.col(act);
 t.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 t.addView(Ui.micro(act, label));
 t.addView(Ui.display(act, value, 17, color));
 t.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 6));
 return t;
 }

 /** Idea 64: the deal picker while offers are open; the current deal otherwise. */
 public static View sponsorCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Sponsorship"));
 if (g.sponsorOffers.length() > 0) {
 card.addView(Ui.small(act, "Three deals for Season " + g.season + " — pick ONE. The objective bonus pays once, only if you hit it; missing it costs nothing."));
 for (int i = 0; i < g.sponsorOffers.length(); i++) {
 final int idx = i;
 org.json.JSONObject d = g.sponsorOffers.optJSONObject(i);
 if (d == null) continue;
 card.addView(Ui.text(act, d.optString("brand") + " — " + d.optInt("lump") + " CF now + "
 + d.optInt("weekly") + " CF/week", 13, Ui.INK, true));
 card.addView(Ui.small(act, "Objective: " + d.optString("objText") + " → +" + d.optInt("bonus") + " CF bonus"));
 Button pick = Ui.darkBtn(act, "Sign with " + d.optString("brand")); // P1: candidate action, not a screen primary
 pick.setOnClickListener(v -> { act.toast(act.g.chooseSponsor(idx)); act.save(); act.render(); });
 card.addView(pick);
 }
 Button none = Ui.darkBtn(act, "No sponsor — Board Grant (50 CF + 5/week, no objective)");
 none.setOnClickListener(v -> { act.toast(act.g.chooseSponsor(3)); act.save(); act.render(); });
 card.addView(none);
 } else {
 card.addView(Ui.small(act, g.sponsorLine()));
 }
 return card;
 }

 /** Idea 66: the camp picker while a choice is pending; the live boost line otherwise. */
 public static View campCard(final MainActivity act) {
 final Game g = act.g;
 if (!g.campPending && g.campLine().isEmpty()) return null;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Pre-Season Training Camp"));
 if (g.campPending) {
 card.addView(Ui.small(act, "One focus, " + Game.CAMP_COST + " CF. Batting/Bowling boosts last your first 8 matches; Fitness tops up stamina and halves injury risk until Day 12; Fielding sharpens run-outs until Day 12."));
 String[] desc = {"+1 batting for the early season", "+1 bowling for the early season",
 "Full stamina now + injury risk halved", "Sharper fielding + run-outs"};
 for (int i = 0; i < 4; i++) {
 final int focus = i;
 Button b = Ui.darkBtn(act, Game.CAMP_NAMES[i] + " — " + Game.CAMP_COST + " CF (" + desc[i] + ")"); // P1
 b.setEnabled(g.cf >= Game.CAMP_COST);
 b.setOnClickListener(v -> { act.toast(act.g.chooseCamp(focus)); act.save(); act.render(); });
 card.addView(b);
 }
 Button skip = Ui.darkBtn(act, "Skip camp (free)");
 skip.setOnClickListener(v -> { act.g.skipCamp(); act.save(); act.toast("Camp skipped"); act.render(); });
 card.addView(skip);
 } else {
 card.addView(Ui.small(act, g.campLine()));
 }
 return card;
 }

 /** Idea 61: the five backroom roles, their holders, and the market. */
 public static View staffCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Backroom Staff"));
 card.addView(Ui.small(act, "One holder per role. Signing fee = 2x the weekly wage; staff wages ride the weekly wage bill. Firing is free."));
 String[] effect = {
 "Team Talk morale +6 (not +4); at 85+, morale can lift ratings +4",
 "+1 effective batting for the share of the squad his rating covers",
 "+1 effective bowling for the share of the squad his rating covers",
 "Fewer, shorter injuries; faster healing; better Recovery sessions",
 "Cheaper scout reports, tighter POT ranges, better free agents"};
 for (int ri = 0; ri < Game.STAFF_ROLES.length; ri++) {
 final String role = Game.STAFF_ROLES[ri];
 org.json.JSONObject s = g.staffMember(role);
 card.addView(Ui.text(act, role, 14, Ui.GOLD, true));
 card.addView(Ui.small(act, effect[ri]));
 if (s != null) {
 card.addView(Ui.text(act, s.optString("name") + " — rating " + s.optInt("rating")
 + " · " + s.optInt("wage") + " CF/week", 13, Ui.GREEN, false));
 Button fire = Ui.dangerBtn(act, "Release " + s.optString("name")); // P1: destructive = danger
 fire.setOnClickListener(v -> { act.toast(act.g.fireStaff(role)); act.save(); act.render(); });
 card.addView(fire);
 } else {
 card.addView(Ui.small(act, "Vacant — candidates:"));
 for (int i = 0; i < g.staffCandidates.length(); i++) {
 org.json.JSONObject c = g.staffCandidates.optJSONObject(i);
 if (c == null || !role.equals(c.optString("role"))) continue;
 final int idx = i;
 int fee = 2 * c.optInt("wage");
 card.addView(Ui.text(act, "•  " + c.optString("name") + " — rating " + c.optInt("rating")
 + " · " + c.optInt("wage") + " CF/week · sign for " + fee + " CF", 13, Ui.INK, false));
 Button hire = Ui.darkBtn(act, "Hire " + c.optString("name") + " — " + fee + " CF"); // P1
 hire.setEnabled(g.cf >= fee);
 hire.setOnClickListener(v -> { act.toast(act.g.hireStaff(idx)); act.save(); act.render(); });
 card.addView(hire);
 }
 }
 }
 return card;
 }
}
