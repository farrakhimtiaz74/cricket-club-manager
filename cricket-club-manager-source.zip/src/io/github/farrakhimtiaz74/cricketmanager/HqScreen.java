package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HqScreen {
    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        LinearLayout head = Ui.card(act);
        head.addView(Ui.gold(act, "HEADQUARTERS", 13));
        head.addView(Ui.h2(act, "Club Cash: " + g.cf + " CF"));
        head.addView(Ui.small(act, "Win matches and grow the club. Every facility maxes at Level " + Data.FACILITY_MAX + "."));
        root.addView(head);

        for (int i = 0; i < Data.FACILITY_NAMES.length; i++) {
            final int idx = i;
            int lvl = g.facilityLevel(idx);
            LinearLayout card = Ui.card(act);
            card.addView(Ui.h2(act, Data.FACILITY_NAMES[idx]));
            StringBuilder pips = new StringBuilder("Level ");
            for (int k = 0; k < Data.FACILITY_MAX; k++) pips.append(k < lvl ? "●" : "○");
            TextView lvlTv = Ui.gold(act, pips.toString() + "  " + lvl + "/" + Data.FACILITY_MAX, 14);
            card.addView(lvlTv);
            card.addView(Ui.small(act, Data.FACILITY_EFFECT[idx]));
            if (lvl >= Data.FACILITY_MAX) {
                card.addView(Ui.text(act, "MAX LEVEL", 14, Ui.GREEN, true));
            } else {
                final int cost = Data.FACILITY_BASE_COST[idx] * lvl;
                Button up = Ui.goldBtn(act, "Upgrade — " + cost + " CF");
                up.setEnabled(g.cf >= cost);
                if (g.cf < cost) up.setText("Upgrade — " + cost + " CF (not enough)");
                up.setOnClickListener(v -> {
                    if (act.g.upgradeFacility(idx)) {
                        act.save();
                        act.toast(Data.FACILITY_NAMES[idx] + " upgraded!");
                    } else {
                        act.toast("Not enough CF");
                    }
                    act.render();
                });
                card.addView(up);
            }
            root.addView(card);
        }

        // v2 Club Cash ledger: every CF movement, newest first, survives restarts + rollovers
        LinearLayout ledgerCard = Ui.card(act);
        ledgerCard.addView(Ui.h2(act, "Club Cash Ledger"));
        if (g.ledger.length() == 0) {
            ledgerCard.addView(Ui.small(act, "No transactions yet."));
        }
        for (int i = 0; i < g.ledger.length(); i++) {
            org.json.JSONObject e = g.ledger.optJSONObject(i);
            if (e == null) continue;
            int amt = e.optInt("amt");
            String line = (amt >= 0 ? "+" : "−") + Math.abs(amt) + " CF · " + e.optString("reason")
                    + "  (S" + e.optInt("season") + " · Day " + e.optInt("day") + ")";
            TextView t = Ui.text(act, line, 13, amt >= 0 ? Ui.GREEN : Ui.RED, false);
            t.setPadding(0, Ui.dp(act, 3), 0, Ui.dp(act, 3));
            ledgerCard.addView(t);
        }
        root.addView(ledgerCard);
        return root;
    }
}
