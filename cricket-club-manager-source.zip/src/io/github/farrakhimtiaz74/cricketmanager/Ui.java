package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Programmatic view factory: dark slate + gold look of the web game.
 *  BG #0f172a, card #1e293b, gold #f59e0b. */
public class Ui {
    public static final int BG = Color.rgb(15, 23, 42);       // #0f172a
    public static final int CARD = Color.rgb(30, 41, 59);     // #1e293b
    public static final int CARD2 = Color.rgb(51, 65, 85);    // lighter slate
    public static final int GOLD = Color.rgb(245, 158, 11);   // #f59e0b
    public static final int INK = Color.rgb(241, 245, 249);
    public static final int MUTED = Color.rgb(148, 163, 184);
    public static final int GREEN = Color.rgb(34, 197, 94);
    public static final int RED = Color.rgb(239, 68, 68);
    public static final int LINE = Color.rgb(71, 85, 105);

    public static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable roundStroke(int color, int stroke, int radiusDp, Context c) {
        GradientDrawable g = round(color, radiusDp, c);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    public static TextView h1(Context c, String s) { return text(c, s, 22, INK, true); }
    public static TextView h2(Context c, String s) { return text(c, s, 17, INK, true); }
    public static TextView body(Context c, String s) { return text(c, s, 14, INK, false); }
    public static TextView small(Context c, String s) { return text(c, s, 12, MUTED, false); }
    public static TextView gold(Context c, String s, float sp) { return text(c, s, sp, GOLD, true); }

    /** A rounded dark card container (vertical). */
    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD, 16, c));
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(c, 12));
        l.setLayoutParams(lp);
        return l;
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** Gold filled primary button. */
    public static Button goldBtn(Context c, String label) {
        Button b = new Button(c);
        b.setText(label);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.rgb(15, 23, 42));
        b.setBackground(round(GOLD, 12, c));
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 48));
        lp.setMargins(0, dp(c, 4), 0, dp(c, 4));
        b.setLayoutParams(lp);
        return b;
    }

    /** Dark outlined secondary button. */
    public static Button darkBtn(Context c, String label) {
        Button b = new Button(c);
        b.setText(label);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(INK);
        b.setBackground(roundStroke(CARD2, LINE, 12, c));
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 44));
        lp.setMargins(0, dp(c, 4), 0, dp(c, 4));
        b.setLayoutParams(lp);
        return b;
    }

    /** Small pill/chip button used for filters and tactics. */
    public static Button chip(Context c, String label, boolean active) {
        Button b = new Button(c);
        b.setText(label);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setTextColor(active ? Color.rgb(15, 23, 42) : MUTED);
        b.setBackground(active ? round(GOLD, 20, c) : roundStroke(CARD, LINE, 20, c));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(c, 36));
        lp.setMargins(0, 0, dp(c, 8), dp(c, 8));
        b.setLayoutParams(lp);
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        return b;
    }

    public static View spacer(Context c, int hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, hDp)));
        return v;
    }

    /** Thin attribute bar (0-100). */
    public static View bar(Context c, int value, int color) {
        LinearLayout track = new LinearLayout(c);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(round(CARD2, 4, c));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 7));
        tlp.setMargins(0, dp(c, 3), 0, dp(c, 3));
        track.setLayoutParams(tlp);
        View fill = new View(c);
        fill.setBackground(round(color, 4, c));
        int w = Math.max(4, value);
        fill.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w));
        View rest = new View(c);
        rest.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 100 - w));
        track.addView(fill);
        track.addView(rest);
        return track;
    }
}
