package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Programmatic view factory: dark slate + gold look of the web game.
 *  BG #0f172a, card #1e293b, gold #f59e0b.
 *  Batch J (idea 95): TEXT_SCALE is the Big Text factor — set once from
 *  the app settings (Settings.textScale: 1.0 or 1.25) by MainActivity
 *  before any view is built, and re-applied + re-rendered when toggled.
 *  Every text size created through this factory flows through scale(),
 *  so one factor lifts the whole app.
 *
 *  Design Batch (v13, item 1): THE design system. Every screen builds
 *  from these tokens and factories — no screen hand-rolls its own card
 *  radius, padding or button look any more:
 *    colours  BG / CARD / CARD2 / CARD_TOP / GOLD / GOLD_BRIGHT /
 *             GOLD_DEEP / PITCH (Stadium Night green) / INK / MUTED /
 *             GREEN / RED / LINE
 *    radii    R_CARD 16 · R_BTN 12 · R_CHIP 20
 *    spacing  SP1 4 · SP2 8 · SP3 12 · SP4 16 (dp)
 *    type     display() 26 bold mono for score/CF figures, h1 22,
 *             h2 17, body 14, small 12, micro 10.5 — all through
 *             scale() so Big Text multiplies everything (item 4).
 *  Cards carry a two-tone depth: a vertical gradient (CARD_TOP →
 *  CARD) with a 1dp LINE stroke, drawn as a LayerDrawable over a
 *  darker base so the bottom edge reads as a soft shadow, plus real
 *  elevation where the platform allows (item 5). Buttons carry
 *  pressed states (StateListDrawable, item 10).
 *
 *  Professional Pack P1 (v14): the DISCIPLINE pass on top of v13.
 *  SP5/SP6 extend the spacing scale for section-level gaps; card()
 *  bottom margin grows SP3 → SP4 so screens breathe; dangerBtn()
 *  joins the factories (red outline, for destructive actions only);
 *  and the audit rules live here so future screens inherit them:
 *  at most ONE goldBtn per card, gold only for a screen's true
 *  primary action, every other colour carrying meaning. */
public class Ui {
    public static float TEXT_SCALE = 1.0f;

    public static float scale(float sp) { return sp * TEXT_SCALE; }

    // ---- colour tokens ----
    public static final int BG = Color.rgb(15, 23, 42);       // #0f172a
    public static final int CARD = Color.rgb(30, 41, 59);     // #1e293b
    public static final int CARD_TOP = Color.rgb(38, 52, 74); // card gradient top
    public static final int CARD2 = Color.rgb(51, 65, 85);    // lighter slate
    public static final int GOLD = Color.rgb(245, 158, 11);   // #f59e0b
    public static final int GOLD_BRIGHT = Color.rgb(251, 191, 36); // foil highlight
    public static final int GOLD_DEEP = Color.rgb(217, 119, 6);    // pressed gold
    public static final int PITCH = Color.rgb(20, 83, 45);    // Stadium Night green #14532d
    public static final int PITCH_DEEP = Color.rgb(10, 46, 26);
    public static final int INK = Color.rgb(241, 245, 249);
    public static final int MUTED = Color.rgb(148, 163, 184);
    public static final int GREEN = Color.rgb(34, 197, 94);
    public static final int RED = Color.rgb(239, 68, 68);
    public static final int LINE = Color.rgb(71, 85, 105);

    // ---- radius + spacing tokens ----
    public static final int R_CARD = 16, R_BTN = 12, R_CHIP = 20;
    public static final int SP1 = 4, SP2 = 8, SP3 = 12, SP4 = 16;
    // P1 (suggestion 1/8): section-level gaps — the grid now runs
    // 4/8/12/16/24/32 and major sections separate at SP5.
    public static final int SP5 = 24, SP6 = 32;

    public static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    /** Channel blend of two ARGB colours (t = weight of b, 0..1) —
     *  how the header band picks up the user's club accent tint. */
    public static int blend(int a, int b, float t) {
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return (((int) (aa + (ba - aa) * t)) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable roundStroke(int color, int stroke, int radiusDp, Context c) {
        GradientDrawable g = round(color, radiusDp, c);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    /** Gold-foil gradient (item 2): reserved for primary actions and
     *  trophy/title elements — bright centre, deep edges. */
    public static GradientDrawable goldFoil(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{GOLD_DEEP, GOLD_BRIGHT, GOLD});
        g.setCornerRadius(dp(c, R_BTN));
        return g;
    }

    private static GradientDrawable goldFoilPressed(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{GOLD_DEEP, GOLD_DEEP, GOLD_DEEP});
        g.setCornerRadius(dp(c, R_BTN));
        return g;
    }

    /** The Stadium Night header band (item 2): deep slate sliding into
     *  a pitch-green tint, warmed by the club accent, with the gold
     *  rule drawn as its bottom stroke layer in MainActivity.
     *
     *  v20.1 (items 5/6): REBUILT palette — the v20 band blended navy
     *  into pitch GREEN on both ends, which over a red-accent club
     *  read as a muddy brown→teal wash and buried the artwork. Now:
     *  deep NAVY base, the club's PRIMARY accent sweeping in from the
     *  left, its SECONDARY warming the right, gold rule below (drawn
     *  in MainActivity). No green anywhere in the band. */
    public static GradientDrawable headerBand(Context c, int accent) {
        return headerBand(c, accent, accent, false);
    }

    /** v20.1: the two-accent variant — primary from the left,
     *  secondary from the right (Lahore gold→green, Islamabad
     *  red→orange, Karachi blue→gold), over navy. */
    public static GradientDrawable headerBand(Context c, int accent, int accent2, boolean overArt) {
        int a = overArt ? 0xC4000000 : 0xFF000000; // ~77% alpha over art, opaque standalone
        int left = (blend(BG, accent, 0.52f) & 0x00FFFFFF) | a;
        int mid = (BG & 0x00FFFFFF) | a;
        int right = (blend(BG, accent2, 0.34f) & 0x00FFFFFF) | a;
        return new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{left, mid, right});
    }

    /** Card background with depth (item 5): gradient face + hairline
     *  stroke over a darker base offset 2dp down = a soft fake shadow;
     *  real elevation is added by card() on top. */
    public static LayerDrawable cardBg(Context c) {
        GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{CARD_TOP, CARD});
        face.setCornerRadius(dp(c, R_CARD));
        face.setStroke(dp(c, 1), LINE);
        GradientDrawable base = new GradientDrawable();
        base.setColor(Color.rgb(8, 13, 24));
        base.setCornerRadius(dp(c, R_CARD));
        LayerDrawable ld = new LayerDrawable(new android.graphics.drawable.Drawable[]{base, face});
        ld.setLayerInset(1, 0, 0, 0, dp(c, 2));
        return ld;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(scale(sp)); // Batch J (idea 95): Big Text factor
        t.setTextColor(color);
        // Rich Media (v20): the bundled Barlow faces carry body text —
        // Regular for plain, Medium for bold — with the platform
        // defaults as the standing fallback when the font asset fails.
        Typeface bodyF = Art.bodyFont(c);
        if (bold) {
            Typeface medF = Art.bodyMedFont(c);
            if (medF != null) t.setTypeface(medF);
            else if (bodyF != null) t.setTypeface(bodyF, Typeface.BOLD);
            else t.setTypeface(Typeface.DEFAULT_BOLD);
        } else if (bodyF != null) {
            t.setTypeface(bodyF);
        }
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    // ---- type scale (item 4) ----
    // Rich Media (v20): headings wear the bundled Rajdhani SemiBold —
    // the condensed display face is what gives the app its broadcast
    // voice; platform bold remains the fallback.
    public static TextView h1(Context c, String s) {
        TextView t = text(c, s, 22, INK, true);
        Typeface d = Art.displaySbFont(c);
        if (d != null) t.setTypeface(d);
        return t;
    }
    public static TextView h2(Context c, String s) {
        TextView t = text(c, s, 17, INK, true);
        Typeface d = Art.displaySbFont(c);
        if (d != null) t.setTypeface(d);
        return t;
    }
    public static TextView body(Context c, String s) { return text(c, s, 14, INK, false); }
    public static TextView small(Context c, String s) { return text(c, s, 12, MUTED, false); }
    public static TextView micro(Context c, String s) { return text(c, s, 10.5f, MUTED, false); }
    public static TextView gold(Context c, String s, float sp) { return text(c, s, sp, GOLD, true); }

    /** Display numerals: the bundled Rajdhani Bold — scores, CF and
     *  table columns (v20; was bold monospace in v13 — Rajdhani's
     *  tabular figures keep columns aligned the same way). */
    public static TextView display(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color, true);
        Typeface d = Art.displayFont(c);
        if (d != null) t.setTypeface(d);
        else t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        return t;
    }

    /** Rich Media (v20): button labels in the display face — applied
     *  by every button factory below; default bold is the fallback. */
    private static void displayFace(Context c, Button b) {
        Typeface d = Art.displaySbFont(c);
        if (d != null) b.setTypeface(d);
    }

    /** A reusable bottom-sheet-style panel background (item 5): card
     *  face with only the TOP corners rounded — the sheet slides up
     *  over a dim layer inside MainActivity's root frame. */
    public static GradientDrawable sheetBg(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{CARD_TOP, CARD});
        g.setCornerRadii(new float[]{dp(c, 20), dp(c, 20), dp(c, 20), dp(c, 20), 0, 0, 0, 0});
        g.setStroke(dp(c, 1), LINE);
        return g;
    }

    /** A rounded dark card container (vertical) — THE card factory. */
    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(cardBg(c));
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        // item 5: real elevation shadow (API 21+) over the drawn depth
        try {
            l.setElevation(dp(c, 3));
            l.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(c, R_CARD));
                }
            });
            l.setClipToOutline(true);
        } catch (Exception ignored) {}
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(c, SP4)); // P1: SP3 → SP4 — cards breathe
        l.setLayoutParams(lp);
        return l;
    }

    /** A group header band (items 5/6): gold label over a deep band
     *  with a gold rule — section headers read as one system across
     *  Hub categories, League and Profile. */
    public static LinearLayout sectionHeader(Context c, String title) {
        LinearLayout wrap = col(c);
        TextView t = text(c, title, 13, GOLD, true);
        t.setPadding(dp(c, 2), dp(c, SP2), 0, dp(c, SP1));
        wrap.addView(t);
        View rule = new View(c);
        rule.setBackgroundColor(GOLD);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 2));
        rp.setMargins(0, 0, 0, dp(c, SP3)); // P1: sections sit further apart
        rule.setLayoutParams(rp);
        wrap.addView(rule);
        return wrap;
    }

    /** The consistent empty state (item 10): a drawn icon in a dim
     *  disc + one line — never a blank gap. */
    public static LinearLayout emptyState(Context c, int iconKind, String line) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(0, dp(c, SP3), 0, dp(c, SP3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        l.setLayoutParams(lp);
        Icons.BadgeView b = new Icons.BadgeView(c, iconKind);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(c, 34), dp(c, 34));
        b.setLayoutParams(blp);
        l.addView(b);
        TextView t = small(c, line);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(c, SP2), 0, 0);
        l.addView(t);
        return l;
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** Audio Pack (suggestion 13): the shared button-click hook.
     *  MainActivity installs a touch listener here; every button
     *  factory attaches it (ACTION_DOWN, never consuming) so a soft
     *  click sounds on primary controls without any caller changing
     *  its own OnClickListener. The engine throttles repeats. */
    public static View.OnTouchListener clickTouch;

    private static void hookClick(Button b) {
        if (clickTouch != null) b.setOnTouchListener(clickTouch);
    }

    /** Gold filled primary button — foil gradient + pressed state. */
    public static Button goldBtn(Context c, String label) {
        Button b = new Button(c);
        hookClick(b);
        b.setText(label);
        b.setTextSize(scale(15));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        displayFace(c, b); // v20: Rajdhani SemiBold when the font asset loaded
        b.setTextColor(Color.rgb(15, 23, 42));
        StateListDrawable sd = new StateListDrawable();
        sd.addState(new int[]{android.R.attr.state_pressed}, goldFoilPressed(c));
        sd.addState(new int[]{}, goldFoil(c));
        b.setBackground(sd);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 48));
        lp.setMargins(0, dp(c, SP1), 0, dp(c, SP1));
        b.setLayoutParams(lp);
        return b;
    }

    /** Dark outlined secondary button — lighter slate when pressed. */
    public static Button darkBtn(Context c, String label) {
        Button b = new Button(c);
        hookClick(b);
        b.setText(label);
        b.setTextSize(scale(14));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        displayFace(c, b);
        b.setTextColor(INK);
        StateListDrawable sd = new StateListDrawable();
        GradientDrawable pressed = round(CARD, R_BTN, c);
        pressed.setStroke(dp(c, 1), GOLD);
        sd.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sd.addState(new int[]{}, roundStroke(CARD2, LINE, R_BTN, c));
        b.setBackground(sd);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 44));
        lp.setMargins(0, dp(c, SP1), 0, dp(c, SP1));
        b.setLayoutParams(lp);
        return b;
    }

    /** P1 (suggestion 9): the danger button — red OUTLINE, red text,
     *  red-tint fill when pressed. Reserved for destructive actions
     *  (Reset Career, Release player, Fire staff) so red always means
     *  "this cannot be undone" and nothing else shouts in red. */
    public static Button dangerBtn(Context c, String label) {
        Button b = new Button(c);
        hookClick(b);
        b.setText(label);
        b.setTextSize(scale(14));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        displayFace(c, b);
        b.setTextColor(RED);
        StateListDrawable sd = new StateListDrawable();
        GradientDrawable pressed = round(Color.rgb(69, 26, 32), R_BTN, c);
        pressed.setStroke(dp(c, 1), RED);
        sd.addState(new int[]{android.R.attr.state_pressed}, pressed);
        GradientDrawable idle = round(CARD, R_BTN, c);
        idle.setStroke(dp(c, 1), RED);
        sd.addState(new int[]{}, idle);
        b.setBackground(sd);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 44));
        lp.setMargins(0, dp(c, SP1), 0, dp(c, SP1));
        b.setLayoutParams(lp);
        return b;
    }

    /** Small pill/chip button used for filters and tactics. */
    public static Button chip(Context c, String label, boolean active) {
        Button b = new Button(c);
        hookClick(b);
        b.setText(label);
        b.setTextSize(scale(13));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        displayFace(c, b);
        b.setAllCaps(false);
        b.setTextColor(active ? Color.rgb(15, 23, 42) : MUTED);
        b.setBackground(active ? round(GOLD, R_CHIP, c) : roundStroke(CARD, LINE, R_CHIP, c));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(c, 36));
        lp.setMargins(0, 0, dp(c, SP2), dp(c, SP2));
        b.setLayoutParams(lp);
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        return b;
    }

    public static View spacer(Context c, int hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, hDp)));
        return v;
    }

    // ================= Professional Pack P2 (v15) =================
    // Layout, layers & categories: the sub-screen header, the
    // collapsible section and the one list-row pattern.

    /** Suggestion 13/19: THE sub-screen header — a back chevron (the
     *  "‹" punctuation glyph, rendered as text everywhere), the screen
     *  title in h1, an optional context subtitle under it (suggestion
     *  19), and at most ONE right-side action. Every sub-screen opens
     *  with this and nothing else. */
    public static LinearLayout subHeader(Context c, String title, String subtitle,
                                         View right, View.OnClickListener back) {
        LinearLayout wrap = col(c);
        LinearLayout row = row(c);
        TextView chev = text(c, "‹", 30, GOLD, true);
        chev.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(c, 34), dp(c, 44));
        clp.setMargins(0, 0, dp(c, 2), 0);
        chev.setLayoutParams(clp);
        if (back != null) chev.setOnClickListener(back);
        row.addView(chev);
        LinearLayout titles = col(c);
        titles.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        titles.addView(h1(c, title));
        if (subtitle != null && !subtitle.isEmpty()) titles.addView(small(c, subtitle));
        row.addView(titles);
        if (right != null) row.addView(right);
        wrap.addView(row);
        wrap.setPadding(0, dp(c, SP1), 0, dp(c, SP3));
        return wrap;
    }

    public static LinearLayout subHeader(Context c, String title, View.OnClickListener back) {
        return subHeader(c, title, null, null, back);
    }

    public static LinearLayout subHeader(Context c, String title, String subtitle,
                                         View.OnClickListener back) {
        return subHeader(c, title, subtitle, null, back);
    }

    /** Suggestion 16: a collapsible section — a category-style header
     *  row (gold label + a geometric chevron) over content that shows
     *  or hides IN PLACE. Toggling never re-renders the screen, so the
     *  open state naturally lives only as long as the screen visit —
     *  no save, no prefs, exactly as specified. */
    public static LinearLayout collapsible(final Context c, String title,
                                           View content, boolean defaultOpen) {
        final LinearLayout wrap = col(c);
        LinearLayout head = row(c);
        head.setPadding(0, dp(c, SP2), 0, dp(c, SP2));
        TextView t = text(c, title, 13, GOLD, true);
        t.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        head.addView(t);
        final TextView chev = text(c, defaultOpen ? "▾" : "▸", 14, MUTED, true);
        head.addView(chev);
        wrap.addView(head);
        View rule = new View(c);
        rule.setBackgroundColor(LINE);
        rule.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 1)));
        wrap.addView(rule);
        final LinearLayout body = col(c);
        body.addView(content);
        body.setVisibility(defaultOpen ? View.VISIBLE : View.GONE);
        wrap.addView(body);
        head.setOnClickListener(v -> {
            boolean open = body.getVisibility() != View.VISIBLE;
            body.setVisibility(open ? View.VISIBLE : View.GONE);
            chev.setText(open ? "▾" : "▸");
        });
        return wrap;
    }

    /** Suggestion 18: THE list row — a left visual, two text lines
     *  (title + subtitle), a right-aligned value, and a hairline
     *  divider under it. Transfers listings, Search results, Modes
     *  lists and Calendar/League fixture rows all speak this shape. */
    public static LinearLayout listRow(Context c, View left, String title, String subtitle,
                                       String rightValue, View.OnClickListener tap) {
        LinearLayout wrap = col(c);
        LinearLayout row = row(c);
        row.setPadding(0, dp(c, SP2), 0, dp(c, SP2));
        if (left != null) {
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            llp.setMargins(0, 0, dp(c, SP3), 0);
            left.setLayoutParams(llp);
            row.addView(left);
        }
        LinearLayout texts = col(c);
        texts.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        texts.addView(text(c, title, 14, INK, true));
        if (subtitle != null && !subtitle.isEmpty()) texts.addView(small(c, subtitle));
        row.addView(texts);
        if (rightValue != null && !rightValue.isEmpty()) {
            TextView rv = display(c, rightValue, 13, GOLD);
            rv.setGravity(Gravity.END);
            row.addView(rv);
        }
        if (tap != null) row.setOnClickListener(tap);
        wrap.addView(row);
        View div = new View(c);
        div.setBackgroundColor(CARD2);
        div.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 1)));
        wrap.addView(div);
        return wrap;
    }

    // ================= v20.1 — FIX + POLISH =================
    // The shared slim meter and the segmented control.

    /** Item 2: THE slim meter row — a label line (micro label left,
     *  the value + word right-aligned in DISPLAY type) ABOVE a slim
     *  GaugeView. The number is always printed, never under the fill;
     *  Hub Board/Fans and the HQ Board & Fans card both build on
     *  this one component, so the two can never drift apart again. */
    public static LinearLayout meterRow(Context c, String label, int value, String word) {
        int v = Design.clamp100(value);
        LinearLayout col = col(c);
        LinearLayout lab = row(c);
        TextView l = micro(c, label.toUpperCase());
        l.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        lab.addView(l);
        TextView val = display(c, v + "/100" + (word == null || word.isEmpty() ? "" : " · " + word),
                12.5f, Design.gaugeColor(v));
        val.setGravity(Gravity.END);
        lab.addView(val);
        col.addView(lab);
        GaugeView gv = new GaugeView(c, v);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 10));
        glp.setMargins(0, dp(c, 3), 0, dp(c, 7));
        gv.setLayoutParams(glp);
        col.addView(gv);
        return col;
    }

    /** Item 8: a segmented control — ONE rounded track, equal
     *  segments, the selected one filled gold. Replaces loose pill
     *  rows (the World format / category switches). */
    public interface SegListener { void onSeg(int i); }

    public static LinearLayout segmented(Context c, String[] labels, int selected,
                                         final SegListener lis) {
        LinearLayout track = new LinearLayout(c);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(roundStroke(CARD2, LINE, R_CHIP, c));
        track.setPadding(dp(c, 3), dp(c, 3), dp(c, 3), dp(c, 3));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 40));
        tlp.setMargins(0, 0, 0, dp(c, SP2));
        track.setLayoutParams(tlp);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean sel = i == selected;
            TextView tv = text(c, labels[i], 13, sel ? Color.rgb(15, 23, 42) : MUTED, true);
            Typeface d = Art.displaySbFont(c);
            if (d != null) tv.setTypeface(d);
            tv.setGravity(Gravity.CENTER);
            if (sel) tv.setBackground(round(GOLD, R_CHIP, c));
            tv.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
            tv.setOnClickListener(v -> { if (lis != null) lis.onSeg(idx); });
            track.addView(tv);
        }
        return track;
    }

    /** Thin attribute bar (0-100). */
    public static View bar(Context c, int value, int color) {        LinearLayout track = new LinearLayout(c);        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(round(CARD2, 4, c));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 7));
        tlp.setMargins(0, dp(c, 3), 0, dp(c, 3));
        track.setLayoutParams(tlp);
        View fill = new View(c);
        fill.setBackground(round(color, 4, c));
        int w = Math.max(4, Math.min(100, value)); // v20.1: clamp both ends (was max-only)
        fill.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w));
        View rest = new View(c);
        rest.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 100 - w));
        track.addView(fill);
        track.addView(rest);
        return track;
    }

    // ================= Professional Pack P5 (v18) =================
    // Onboarding, help & trust: the info chip and the trust pill.

    /** Suggestion 44: THE info chip — a small circle-i badge beside a
     *  term (NRR, POT, DLS, Set %, CRR, RRR). Tapping opens the sheet
     *  with Glossary's one-or-two-line plain explanation. The chip is
     *  drawn (a stroked circle + text "i"), never a font symbol, so it
     *  renders the same on every phone. */
    public static View infoChip(final MainActivity act, final String term) {
        LinearLayout chip = new LinearLayout(act);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.addView(infoBadgeView(act, term));
        chip.addView(text(act, term, 12, GOLD, true));
        chip.setPadding(dp(act, 2), dp(act, 2), dp(act, 2), dp(act, 2));
        chip.setOnClickListener(v -> openGlossary(act, term));
        return chip;
    }

    /** Suggestion 44, tight-space variant: ONLY the circle-i badge —
     *  for spots where the term is already printed beside it (the
     *  league table's NRR column header, the Set % attribute label). */
    public static View infoBadge(final MainActivity act, final String term) {
        View badge = infoBadgeView(act, term);
        badge.setOnClickListener(v -> openGlossary(act, term));
        return badge;
    }

    private static TextView infoBadgeView(Context c, String term) {
        TextView badge = text(c, "i", 10, GOLD, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(roundStroke(CARD2, GOLD, 9, c));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(c, 17), dp(c, 17));
        blp.setMargins(0, 0, dp(c, 4), 0);
        badge.setLayoutParams(blp);
        return badge;
    }

    /** The glossary sheet every info chip/badge opens. */
    private static void openGlossary(MainActivity act, String term) {
        LinearLayout col = col(act);
        col.addView(h2(act, term));
        String ex = Glossary.explain(term);
        col.addView(body(act, ex == null ? "No explanation yet." : ex));
        Button close = darkBtn(act, "Close");
        close.setOnClickListener(x -> act.hideSheet());
        col.addView(close);
        act.showSheet(col);
    }

    /** Suggestion 49: a small static pill (the About trust chips) —
     *  stroked slate with quiet ink text; not a button. */
    public static TextView pill(Context c, String s) {
        TextView t = text(c, s, 12, INK, true);
        t.setBackground(roundStroke(CARD2, LINE, R_CHIP, c));
        t.setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, dp(c, SP2), dp(c, SP2));
        t.setLayoutParams(lp);
        return t;
    }

    // ================= v21: the Kit (item 5) =================
    // The component library, formalized. Ui's factories were already
    // the de-facto kit every screen builds with; v21 names the
    // canonical set (kitCard / kitRow / kitMeter / kitChip /
    // kitSegmented / kitHeader / kitButton), so new and rebuilt
    // screens (Hub dashboard, MatchDay, Team, World, League,
    // Profile slots) construct through ONE vocabulary — and adds the
    // two v21 pieces: glass panels and foil text (item 17), plus the
    // theme-aware foil button (item 10: silver under Midnight).

    /** Canonical card — the standard card shell. */
    public static LinearLayout kitCard(Context c) {
        return card(c);
    }

    /** Item 17: a GLASS panel — translucent slate face over the art
     *  beneath it, a pale hairline and the same soft shadow recipe
     *  as cardBg. For hero cards that sit on artwork. */
    public static LayerDrawable glassBg(Context c) {
        GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xD9243448, 0xD9162233});
        face.setCornerRadius(dp(c, R_CARD));
        face.setStroke(dp(c, 1), 0x59FFFFFF);
        GradientDrawable base = new GradientDrawable();
        base.setColor(0xB0080D18);
        base.setCornerRadius(dp(c, R_CARD));
        LayerDrawable ld = new LayerDrawable(new android.graphics.drawable.Drawable[]{base, face});
        ld.setLayerInset(1, 0, 0, 0, dp(c, 2));
        return ld;
    }

    public static LinearLayout kitGlassCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(glassBg(c));
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        try {
            l.setElevation(dp(c, 3));
            l.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(c, R_CARD));
                }
            });
            l.setClipToOutline(true);
        } catch (Exception ignored) {}
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(c, SP4));
        l.setLayoutParams(lp);
        return l;
    }

    /** Canonical row (badge + title + subtitle + right value). */
    public static LinearLayout kitRow(Context c, View left, String title, String subtitle,
                                      String rightValue, View.OnClickListener click) {
        return listRow(c, left, title, subtitle, rightValue, click);
    }

    /** Canonical meter (label + clamped gauge + value/word). */
    public static LinearLayout kitMeter(Context c, String label, int value, String word) {
        return meterRow(c, label, value, word);
    }

    /** Canonical chip. */
    public static Button kitChip(Context c, String label, boolean active) {
        return chip(c, label, active);
    }

    /** Canonical segmented control. */
    public static LinearLayout kitSegmented(Context c, String[] labels, int selected,
                                            SegListener lis) {
        return segmented(c, labels, selected, lis);
    }

    /** Canonical section header. */
    public static LinearLayout kitHeader(Context c, String title) {
        return sectionHeader(c, title);
    }

    /** A foil gradient in an arbitrary accent (themed buttons). */
    public static GradientDrawable foil(Context c, int accent) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{blend(accent, 0xFF000000, 0.25f), blend(accent, 0xFFFFFFFF, 0.30f), accent});
        g.setCornerRadius(dp(c, R_BTN));
        return g;
    }

    /** Canonical button: primary = foil in the THEME accent (gold
     *  normally, silver under Midnight, club colour under Club);
     *  secondary = the quiet dark button. */
    public static Button kitButton(Context c, String label, boolean primary, Game g) {
        if (!primary) return darkBtn(c, label);
        Button b = goldBtn(c, label);
        if (Design.themeMode != Design.THEME_CLASSIC) {
            b.setBackground(foil(c, Design.themedAccent(g)));
        }
        b.setTextColor(0xFF0F172A);
        return b;
    }

    /** Item 17: gold-foil gradient TEXT for screen titles — the
     *  display font filled with a bright-centre foil shader in the
     *  theme accent. Measured eagerly so the shader spans the text. */
    public static TextView foilText(Context c, String s, float sp, int accent) {
        TextView t = display(c, s, sp, accent);
        float w = Math.max(1f, t.getPaint().measureText(s));
        t.getPaint().setShader(new android.graphics.LinearGradient(0, 0, w, 0,
                new int[]{blend(accent, 0xFF000000, 0.22f), blend(accent, 0xFFFFFFFF, 0.38f), accent},
                null, android.graphics.Shader.TileMode.CLAMP));
        return t;
    }
}
