package io.github.farrakhimtiaz74.cricketmanager;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    public Game g;
    public Store store;
    public int tab = 0; // 0 Hub, 1 Team, 2 League, 3 World, 4 Profile, 5 HQ
    public boolean matchMode = false;
    public String teamFilter = "All";
    public int worldFormat = 0;
    public int worldCat = 0;

    private LinearLayout contentCol;
    private TextView headerMeta;
    private Button[] navBtns = new Button[6];
    private LinearLayout navBar;

    private static final String[] TABS = {"Hub", "Team", "League", "World", "Profile", "HQ"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new Store(this);
        String saved = store.load();
        g = saved == null ? Game.fresh() : Game.fromJson(saved);
        if (g.match != null) matchMode = true;
        save();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        // header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 8));
        LinearLayout hcol = Ui.col(this);
        TextView title = Ui.text(this, "Cricket Club Manager", 19, Ui.INK, true);
        headerMeta = Ui.small(this, "");
        hcol.addView(title);
        hcol.addView(headerMeta);
        LinearLayout.LayoutParams hcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        hcol.setLayoutParams(hcp);
        header.addView(hcol);
        TextView cfChip = Ui.gold(this, "", 16);
        cfChip.setBackground(Ui.roundStroke(Ui.CARD, Ui.GOLD, 12, this));
        cfChip.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        cfChip.setTag("cfChip");
        header.addView(cfChip);
        header.setTag(cfChip);
        root.addView(header);
        this.headerCf = cfChip;

        // scrollable content
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        scroll.setFillViewport(true);
        contentCol = Ui.col(this);
        contentCol.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 16));
        scroll.addView(contentCol);
        root.addView(scroll);
        this.scrollView = scroll;

        // bottom nav
        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setBackgroundColor(Ui.CARD);
        navBar.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 10));
        for (int i = 0; i < 6; i++) {
            final int idx = i;
            Button b = new Button(this);
            b.setText(TABS[i]);
            b.setTextSize(12);
            b.setAllCaps(false);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            b.setLayoutParams(new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
            b.setOnClickListener(v -> {
                matchMode = false;
                tab = idx;
                render();
            });
            navBtns[i] = b;
            navBar.addView(b);
        }
        root.addView(navBar);

        setContentView(root);
        render();
    }

    private TextView headerCf;
    private ScrollView scrollView;

    public void save() {
        store.save(g.toJson());
        if (headerMeta != null) {
            headerMeta.setText("Lahore Qalandars · Season " + g.season + " · Day " + g.day);
        }
        if (headerCf != null) headerCf.setText(g.cf + " CF");
    }

    public void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    public void render() {
        save();
        contentCol.removeAllViews();
        scrollView.scrollTo(0, 0);
        // nav styling
        for (int i = 0; i < 6; i++) {
            boolean active = !matchMode && tab == i;
            navBtns[i].setTextColor(active ? Ui.GOLD : Ui.MUTED);
            navBtns[i].setTypeface(null, active ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            navBtns[i].setBackground(active ? Ui.round(Ui.BG, 10, this) : null);
        }
        navBar.setVisibility(matchMode ? View.GONE : View.VISIBLE);
        View v;
        if (matchMode) {
            v = MatchScreen.build(this);
        } else {
            switch (tab) {
                case 1: v = TeamScreen.build(this); break;
                case 2: v = LeagueScreen.build(this); break;
                case 3: v = WorldScreen.build(this); break;
                case 4: v = ProfileScreen.build(this); break;
                case 5: v = HqScreen.build(this); break;
                default: v = HubScreen.build(this);
            }
        }
        contentCol.addView(v);
    }

    /** v2: match day is BLOCKED when the team sheet is illegal — this dialog
     *  lists the exact problems and jumps straight to the Team tab to fix them. */
    public void showXiBlocked(java.util.List<String> problems) {
        StringBuilder msg = new StringBuilder("Your team sheet is not legal yet:\n");
        for (String p : problems) msg.append("\n•  ").append(p);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Team Sheet Blocked")
                .setMessage(msg.toString())
                .setPositiveButton("Fix in Team Tab", (d, w) -> { tab = 1; render(); })
                .setNegativeButton("Close", null)
                .show();
    }

    public void startMatch(JSONObject fixture) {
        MatchEngine.startMatch(g, fixture);
        matchMode = true;
        save();
        render();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (g != null) save();
    }
}
