package io.github.farrakhimtiaz74.cricketmanager;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    public Game g;
    public Store store;
    public int tab = 0; // 0 Hub, 1 Team, 2 League, 3 World, 4 Profile, 5 HQ
    public boolean matchMode = false;
    public String teamFilter = "All";
    public int worldFormat = 0;
    public int worldCat = 0;
    // Batch C: Team tab detail view + comparison picker state
    public String teamDetail = null;   // player name in the detail view, or null for the list
    public boolean compareMode = false;
    public String compareA = "";
    public String compareB = "";
    // Batch D: Transfers & Contracts sub-screen (from HQ / Hub), nav unchanged
    public boolean transfersMode = false;
    // Batch H (idea 79): the season calendar sub-screen, nav unchanged
    public boolean calendarMode = false;
    // Batch I (ideas 81–90): the Modes & Challenges sub-screen, nav unchanged
    public boolean modesMode = false;
    // Batch J (ideas 92/96/97): Settings, What's New and Search sub-screens
    public boolean settingsMode = false;
    public boolean whatsNewMode = false;
    public boolean searchMode = false;
    // Professional Pack P5 (suggestions 41/43): the first-launch
    // welcome tour (before the picker; replayable view-only from Help)
    // and the Help sub-screen (entered from Profile or Settings —
    // helpFromSettings picks the back target).
    public boolean onboardingMode = false;
    public int onboardingStep = 0;
    public boolean helpMode = false;
    public boolean helpFromSettings = false;
    public String searchQuery = "";
    public String importDraft = "";
    public String syncCodeShown = null;
    /** Batch J: APP-LEVEL settings (ideas 92–96) — own prefs file
     *  (ccm_settings), deliberately NOT the career save, so they survive
     *  career resets, slot loads and sync imports. The adapter is here;
     *  the logic and defaults live in the pure Settings class. */
    public Settings settings;
    public int appVersionCode = 22;
    public String appVersionName = "20.1";
    // Rich Media Edition (v20): the TITLE / MAIN MENU entry state.
    // menuMode shows MenuScreen over the (hidden) header + nav;
    // careerExists is set ONCE from the real save at launch (and
    // kept current by start/reset) — it, not pickerMode, decides
    // whether Continue Career exists, because pickerMode is also
    // raised mid-flow when a career-holding user opens the picker
    // from the menu. settingsFromMenu / pickerFromMenu make the
    // Settings back chevron and the picker's back button return to
    // the menu instead of dropping into the tabs.
    public boolean menuMode = false;
    public boolean careerExists = false;
    public boolean settingsFromMenu = false;
    public boolean pickerFromMenu = false;
    /** v20: HQ campus hotspot target — HqScreen scrolls its facility
     *  list to this card at the end of its next build (-1 = none). */
    public int hqScrollTarget = -1;
    private LinearLayout headerRoot;
    // Design Batch (v13): overlay machinery — the root is a FrameLayout
    // so the bottom sheet (item 5) and the confetti burst (item 10)
    // float above the scrolling app; bugSlot hosts the sticky match
    // score-bug (item 7) between the header and the ScrollView.
    private android.widget.FrameLayout frame;
    private LinearLayout sheetLayer;
    private LinearLayout bugSlot;
    // Professional Pack P2: stickySlot hosts a screen's fixed filter
    // chips (suggestion 15) between the bug slot and the ScrollView;
    // actionSlot hosts a screen's pinned action bar (suggestion 20)
    // between the ScrollView and the bottom nav. render() clears
    // both; screens re-park their bars on every build.
    private LinearLayout stickySlot;
    private LinearLayout actionSlot;
    private LinearLayout headerBand;
    private LinearLayout headerCrestSlot;
    private String headerTeamShown = "";
    private String celebratedKey = "";
    // Audio Pack (v19): the synthesized sound engine replaces the
    // Batch J ToneGenerator beeps. snd* fields are the render-diff
    // baselines the celebration/signing sounds key off (the same
    // pattern as the hardcore sack counting in render()).
    public SoundEngine snd;
    private int sndAch = -1, sndLevel = -1, sndTitles = -1, sndLedgerLen = -1;
    private String sndRainNote = "";
    // Batch I (ideas 81/90): new-career choices made on the team picker
    public int pickerDifficulty = 1; // 0 Casual, 1 Manager, 2 Legend
    public boolean pickerHardcore = false;
    // Batch F (ideas 51/52): the new-career team picker (first launch, or
    // after a Profile reset). While it is up, nothing is persisted — the
    // career only exists once a club is chosen.
    public boolean pickerMode = false;
    public boolean customOpen = false;
    public int customColorIdx = 0;
    public String customNameDraft = "";
    public String customCodeDraft = "";
    /** Batch E (idea 44): "As It Stands" live-table toggle on the match screen. */
    public boolean showAsItStands = false;
    /** Professional Pack P2 (suggestion 15): the Transfers section
     *  filter — All / Window / Free Agents / Loans / Release. Lives on
     *  the activity so it survives re-renders, like teamFilter. */
    public String transfersFilter = "All";
    /** Professional Pack P4 (suggestions 32/33): Team presentation
     *  state — Cards/Rows view, the in-memory squad sort and the
     *  player-detail tab. Runtime only, like teamFilter. */
    public String teamViewMode = "Cards";
    public String teamSort = "Rating";
    public String teamDetailTab = "Overview";

    private LinearLayout contentCol;
    private TextView headerMeta;
    // P2 (suggestion 12): nav items are icon + label columns now —
    // items carry the tap + active pill, indicators the gold top bar,
    // labels the text state.
    private LinearLayout[] navItems = new LinearLayout[6];
    private TextView[] navLabels = new TextView[6];
    private View[] navIndicators = new View[6];
    private LinearLayout navBar;
    private static final int[] NAV_ICONS = {Icons.HOME, Icons.SHIRT, Icons.TROPHY,
            Icons.OVERSEAS, Icons.PERSON, Icons.BUILDING};

    private static final String[] TABS = {"Hub", "Team", "League", "World", "Profile", "HQ"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Batch J: app settings BEFORE any view exists — the Big Text
        // factor must be in place before the first Ui.text() call, and
        // the commentary language before the first ball is bowled.
        final android.content.SharedPreferences spJ =
                getSharedPreferences("ccm_settings", MODE_PRIVATE);
        settings = new Settings(new Settings.Kv() {
            @Override public String get(String k) { return spJ.getString(k, null); }
            @Override public void put(String k, String v) { spJ.edit().putString(k, v).apply(); }
            @Override public void remove(String k) { spJ.edit().remove(k).apply(); }
        });
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            appVersionCode = pi.versionCode;
            appVersionName = pi.versionName;
        } catch (Exception ignored) {}
        Ui.TEXT_SCALE = Settings.textScale(settings.bigText());
        MatchEngine.urduComm = settings.urduComm();
        // Audio Pack (v19): the engine is lazy — creating it here costs
        // nothing until the first sound; the Ui button factories get
        // their shared click hook (suggestion 13).
        snd = new SoundEngine(this, settings);
        Ui.clickTouch = (v, e) -> {
            if (e.getAction() == android.view.MotionEvent.ACTION_DOWN && snd != null) snd.uiClick();
            return false; // never consume — the real click still fires
        };
        store = new Store(this);
        String saved = store.load();
        pickerMode = saved == null; // Batch F: no save = pick a club first
        careerExists = saved != null; // v20: the menu's Continue door keys off the real save
        menuMode = saved != null; // v20: with a career, the app opens on the main menu
        // P5 (suggestion 41): the welcome tour precedes the picker on a
        // true first launch only — no career + tour never seen
        onboardingMode = Settings.shouldShowOnboarding(saved != null, settings.onboardingSeen());
        g = saved == null ? Game.fresh() : Game.fromJson(saved);
        if (g.match != null) matchMode = true;
        save();

        frame = new android.widget.FrameLayout(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        frame.addView(root, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // header — Design Batch (item 2): the Stadium Night band,
        // a floodlit gradient tinted by the club accent with a thin
        // gold rule under it; the club crest rides on the left.
        // v20: kept in a field so the main menu can hide it (the menu
        // is full-bleed art; the header returns with the tabs).
        LinearLayout header = new LinearLayout(this);
        headerRoot = header;
        header.setOrientation(LinearLayout.VERTICAL);
        headerBand = new LinearLayout(this);
        headerBand.setOrientation(LinearLayout.HORIZONTAL);
        headerBand.setGravity(Gravity.CENTER_VERTICAL);
        headerBand.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 6));
        // v20.1 (item 5): the band height is EXPLICIT — 64dp — never
        // wrap-content. On Farrakh's phone the v20 band ballooned to
        // ~29% of the screen; a fixed height keeps crest + title +
        // meta + CF pill in one compact strip on every tab.
        headerBand.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 64)));
        headerBand.setBackground(Ui.headerBand(this, Ui.GOLD));
        headerCrestSlot = Ui.col(this);
        LinearLayout.LayoutParams crestLp = new LinearLayout.LayoutParams(
                Ui.dp(this, 30), Ui.dp(this, 34));
        crestLp.setMargins(0, 0, Ui.dp(this, 10), 0);
        headerCrestSlot.setLayoutParams(crestLp);
        headerBand.addView(headerCrestSlot);
        LinearLayout hcol = Ui.col(this);
        TextView title = Ui.text(this, "Cricket Club Manager", 19, Ui.INK, true);
        headerMeta = Ui.small(this, "");
        hcol.addView(title);
        hcol.addView(headerMeta);
        LinearLayout.LayoutParams hcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        hcol.setLayoutParams(hcp);
        headerBand.addView(hcol);
        // item 4: the CF pill is a display numeral now
        TextView cfChip = Ui.display(this, "", 16, Ui.GOLD);
        cfChip.setBackground(Ui.roundStroke(Ui.CARD, Ui.GOLD, 12, this));
        cfChip.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        cfChip.setTag("cfChip");
        headerBand.addView(cfChip);
        header.addView(headerBand);
        View goldRule = new View(this);
        goldRule.setBackgroundColor(Ui.GOLD);
        goldRule.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 2)));
        header.addView(goldRule);
        root.addView(header);
        this.headerCf = cfChip;

        // Design Batch (item 7a): the sticky score-bug slot — MatchScreen
        // fills it during live play; it sits OUTSIDE the ScrollView so it
        // never scrolls away.
        bugSlot = Ui.col(this);
        bugSlot.setVisibility(View.GONE);
        root.addView(bugSlot);

        // P2 (suggestion 15): the sticky filter-chip slot — Team and
        // Transfers park their chip rows here so the filters stay on
        // screen while the list scrolls beneath them.
        stickySlot = Ui.col(this);
        stickySlot.setVisibility(View.GONE);
        stickySlot.setBackgroundColor(Ui.BG);
        stickySlot.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), 0);
        root.addView(stickySlot);

        // scrollable content
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        scroll.setFillViewport(true);
        contentCol = Ui.col(this);
        contentCol.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 16));
        scroll.addView(contentCol);
        root.addView(scroll);
        this.scrollView = scroll;

        // P2 (suggestion 20): the pinned action-bar slot — Team,
        // Transfers and the live Match screen park their slim primary
        // bars here, above the bottom nav, always reachable.
        actionSlot = Ui.col(this);
        actionSlot.setVisibility(View.GONE);
        root.addView(actionSlot);

        // bottom nav — P2 (suggestion 12): each tab is a drawn Icons
        // symbol over its label, with a gold top indicator bar and a
        // pill background on the active tab (styled in render()).
        // v20.1 (item 9): the carbon checker texture is GONE — it read
        // as noise behind the nav on device. Clean dark glass instead:
        // a solid deep-navy bar under a 1dp hairline. Icons, labels and
        // the gold active indicator are unchanged.
        View navHairline = new View(this);
        navHairline.setBackgroundColor(Ui.LINE);
        navHairline.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 1)));
        root.addView(navHairline);
        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setBackgroundColor(0xFF0B1220);
        navBar.setPadding(Ui.dp(this, 4), Ui.dp(this, 2), Ui.dp(this, 4), Ui.dp(this, 8));
        for (int i = 0; i < 6; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            item.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 3));
            item.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            View ind = new View(this);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(Ui.dp(this, 26), Ui.dp(this, 3));
            ilp.setMargins(0, 0, 0, Ui.dp(this, 3));
            ind.setLayoutParams(ilp);
            item.addView(ind);
            Icons.BadgeView icon = new Icons.BadgeView(this, NAV_ICONS[i]);
            icon.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 20), Ui.dp(this, 20)));
            item.addView(icon);
            TextView lab = Ui.text(this, TABS[i], 12, Ui.MUTED, false);
            lab.setGravity(Gravity.CENTER);
            item.addView(lab);
            item.setOnClickListener(v -> {
                matchMode = false;
                menuMode = false; // v20: a nav tap always lands in the tabs
                settingsFromMenu = false;
                transfersMode = false; // Batch D: nav always leaves the Transfers sub-screen
                calendarMode = false; // Batch H: nav leaves the calendar too
                modesMode = false; // Batch I: nav leaves Modes too
                settingsMode = false; // Batch J: nav leaves Settings / What's New / Search too
                whatsNewMode = false;
                searchMode = false;
                helpMode = false; // P5: nav leaves Help too
                teamDetail = null; // Batch C: nav always lands on the tab's home view
                tab = idx;
                render();
            });
            navItems[i] = item;
            navLabels[i] = lab;
            navIndicators[i] = ind;
            navBar.addView(item);
        }
        root.addView(navBar);

        setContentView(frame);
        render();
        showSplash(frame); // Professional Pack P1 (suggestion 5)
    }

    /** P1 (suggestion 5): the branded launch moment — the club crest,
     *  the app name and the tagline over the app's own background, for
     *  ~900ms on a cold start. A plain view swap inside the root frame
     *  (no new Activity, no window flags); Reduce Animations skips it
     *  entirely, and it never blocks input beyond its brief life.
     *
     *  Rich Media (v20): the splash now opens on the stadium ARTWORK,
     *  full-bleed under a dark scrim, with the crest ART (or the drawn
     *  crest as fallback) and the title in the bundled display face —
     *  the same picture the main menu behind it carries, so splash →
     *  menu reads as one continuous title screen. */
    private void showSplash(final android.widget.FrameLayout frame) {
        if (!animOk()) return;
        final android.widget.FrameLayout splash = new android.widget.FrameLayout(this);
        android.graphics.Bitmap bg = Art.bitmap(this, Art.STADIUM, 1080);
        if (bg != null) {
            android.widget.ImageView iv = new android.widget.ImageView(this);
            iv.setImageBitmap(bg);
            iv.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            splash.addView(iv, new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            View scrim = new View(this);
            scrim.setBackgroundColor(0x8C0F172A);
            splash.addView(scrim, new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            splash.setBackgroundColor(Ui.BG);
        }
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        android.graphics.Bitmap crest = Art.crestBitmap(this, g, g.userTeam, 288);
        if (crest != null) {
            android.widget.ImageView civ = new android.widget.ImageView(this);
            civ.setImageBitmap(crest);
            civ.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 94)));
            col.addView(civ);
        } else {
            col.addView(CrestView.forTeam(this, g, g.userTeam, 84));
        }
        TextView nm = Ui.display(this, "CRICKET CLUB MANAGER", 24, Ui.INK);
        nm.setGravity(Gravity.CENTER);
        nm.setPadding(0, Ui.dp(this, 14), 0, 0);
        col.addView(nm);
        TextView tg = Ui.small(this, "Manage. Win. Lift the trophy.");
        tg.setGravity(Gravity.CENTER);
        tg.setPadding(0, Ui.dp(this, 4), 0, 0);
        col.addView(tg);
        splash.addView(col, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        frame.addView(splash, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        autoHandler.postDelayed(() -> frame.removeView(splash), 900);
    }

    private TextView headerCf;
    private ScrollView scrollView;

    // ---------------- Batch A (idea 10): staged auto-play pacing ----------------
    // Sim buttons at 1x/2x run through this Handler loop (one ball per tick);
    // Instant keeps the old fully-synchronous sims. startAuto toggles.
    public final android.os.Handler autoHandler = new android.os.Handler();
    public String autoMode = null; // "over" | "innings" | "match"
    private int autoTargetBalls = -1;
    private int autoStartInn = -1;

    private final Runnable autoStep = new Runnable() {
        @Override
        public void run() {
            if (autoMode == null || !matchMode || g.match == null) { autoMode = null; return; }
            JSONObject m = g.match;
            if (!"play".equals(m.optString("phase"))) { autoMode = null; render(); return; }
            MatchEngine.bowlBall(g);
            // Batch J (idea 94): staged steps are a LIVE path — each stepped
            // ball sounds, and the ball that ends the match gets the jingle
            if ("done".equals(m.optString("phase"))) {
                playEndJingle(g.userTeam.equals(m.optString("winnerTeam")));
            } else {
                playBallSound(true);
            }
            save();
            // Batch B (idea 14): a staged sim pauses for the next-batter pick
            if (m.optBoolean("awaitBat")) { autoMode = null; render(); return; }
            boolean stop = !"play".equals(m.optString("phase"));
            if (!stop && "over".equals(autoMode)
                    && (m.optInt("balls") >= autoTargetBalls || m.optInt("balls") == 0)) stop = true;
            if (!stop && "innings".equals(autoMode) && m.optInt("inn") != autoStartInn) stop = true;
            if (stop) { autoMode = null; render(); return; }
            render();
            autoHandler.postDelayed(this, g.speed == 2 ? 140 : 320);
        }
    };

    public void startAuto(String mode) {
        if (g.match == null || !"play".equals(g.match.optString("phase"))) return;
        if (g.match.optBoolean("awaitBat")) return; // Batch B: pick the next batter first
        if (mode.equals(autoMode)) { stopAuto(); render(); return; } // tap again to stop
        autoMode = mode;
        autoStartInn = g.match.optInt("inn");
        int b = g.match.optInt("balls");
        autoTargetBalls = b + (6 - b % 6);
        autoHandler.removeCallbacks(autoStep);
        autoHandler.postDelayed(autoStep, g.speed == 2 ? 140 : 320);
        render();
    }

    public void stopAuto() {
        autoMode = null;
        autoHandler.removeCallbacks(autoStep);
    }

    public void save() {
        // Batch F: in the picker there is no career to persist yet
        if (!pickerMode) store.save(g.toJson());
        if (headerMeta != null) {
            headerMeta.setText(g.userTeam + " · Season " + g.season + " · Day " + g.day);
        }
        if (headerCf != null) {
            headerCf.setText(g.cf + " CF");
            // Batch F (idea 52): a custom club tints the header chip
            if (g.customTeam) headerCf.setBackground(Ui.roundStroke(Ui.CARD, g.teamColor(), 12, this));
        }
        // Design Batch (item 2): the band + crest follow the club —
        // rebuilt only when the team (or its custom colour) changes.
        // Rich Media (v20): the matchday pitch art ghosts through the
        // band under the gradient (Art.headerBg keeps the gradient
        // alone as the fallback when the art fails).
        if (headerBand != null && g != null) {
            String key = g.userTeam + "|" + g.teamColor();
            if (!key.equals(headerTeamShown)) {
                headerTeamShown = key;
                headerBand.setBackground(Art.headerBg(this, Design.accentFor(g),
                        g.customTeam ? Ui.GOLD : Design.clubSecondary(g.userTeam)));
                headerCrestSlot.removeAllViews();
                headerCrestSlot.addView(CrestView.forTeam(this, g, g.userTeam, 30));
            }
        }
    }

    // ---------------- Design Batch (v13): overlay machinery ----------------

    /** Motion gate (item 10): Reduce Animations kills transitions,
     *  the sheet slide and confetti in one place. */
    public boolean animOk() {
        return settings == null || !settings.reduceAnim();
    }

    /** Item 7a: MatchScreen parks its score-bug here during live play;
     *  render() clears it for every other screen. */
    public void setBug(View v) {
        if (bugSlot == null) return;
        bugSlot.removeAllViews();
        if (v == null) {
            bugSlot.setVisibility(View.GONE);
        } else {
            bugSlot.addView(v);
            bugSlot.setVisibility(View.VISIBLE);
        }
    }

    /** P2 (suggestion 15): a screen parks its filter-chip row here so
     *  it stays fixed while the content scrolls. render() clears it;
     *  the screen re-parks on every build, so chips always reflect
     *  current state after any action. */
    public void setSticky(View v) {
        if (stickySlot == null) return;
        stickySlot.removeAllViews();
        if (v == null) {
            stickySlot.setVisibility(View.GONE);
        } else {
            stickySlot.addView(v);
            stickySlot.setVisibility(View.VISIBLE);
        }
    }

    /** P2 (suggestion 20): a screen parks its pinned action bar here —
     *  below the scroll area, above the bottom nav, so the primary
     *  action never scrolls away and never overlaps the nav.
     *
     *  v20.1 (item 1 — the XI-bar leak): this method is named
     *  parkActionBar and must NEVER be renamed back. Activity already
     *  has a setActionBar method taking an android.widget.Toolbar,
     *  and for a NULL argument Java picks the MORE SPECIFIC overload —
     *  so render()'s old null clear bound to the framework method (a
     *  no-op here) while View arguments reached this one. Result:
     *  bars parked fine but never cleared, and the Team XI bar
     *  rendered on every tab in Farrakh's v20 screenshots. Proven in
     *  the shipped v20 dex: render() invoked the Toolbar overload.
     *  The desktop wiring test bans any setActionBar call token in
     *  all sources so this cannot return. */
    public void parkActionBar(View v) {
        if (actionSlot == null) return;
        actionSlot.removeAllViews();
        if (v == null) {
            actionSlot.setVisibility(View.GONE);
        } else {
            actionSlot.addView(v);
            actionSlot.setVisibility(View.VISIBLE);
        }
    }

    /** Item 5: the bottom sheet — a slide-up panel over a dim layer in
     *  the root frame (a true BottomSheetDialog needs the design
     *  library; this overlay is the framework equivalent). Tap the dim
     *  or the sheet's own close control to dismiss. */
    public void showSheet(View content) {
        hideSheet();
        sheetLayer = new LinearLayout(this);
        sheetLayer.setOrientation(LinearLayout.VERTICAL);
        sheetLayer.setBackgroundColor(0xB30B1120);
        sheetLayer.setOnClickListener(v -> hideSheet());
        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        sheetLayer.addView(spacer);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(Ui.sheetBg(this));
        panel.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 18));
        panel.setOnClickListener(v -> {}); // taps on the panel don't dismiss
        // grab handle
        View grab = new View(this);
        grab.setBackground(Ui.round(Ui.MUTED, 3, this));
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 4));
        glp.gravity = Gravity.CENTER_HORIZONTAL;
        glp.setMargins(0, 0, 0, Ui.dp(this, 10));
        grab.setLayoutParams(glp);
        panel.addView(grab);
        panel.addView(content);
        sheetLayer.addView(panel);
        frame.addView(sheetLayer, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (animOk()) {
            panel.setTranslationY(Ui.dp(this, 60));
            panel.setAlpha(0f);
            panel.animate().translationY(0).alpha(1f).setDuration(200).start();
        }
    }

    public void hideSheet() {
        if (sheetLayer != null && frame != null) frame.removeView(sheetLayer);
        sheetLayer = null;
    }

    /** Item 10: the title/cup confetti burst — one-shot per honour
     *  (celebratedKey), non-blocking, and never under Reduce Anim. */
    public void celebrate(String key) {
        if (!animOk() || frame == null || key == null || key.equals(celebratedKey)) return;
        celebratedKey = key;
        final ConfettiView cv = new ConfettiView(this, Design.accentFor(g));
        frame.addView(cv, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        autoHandler.postDelayed(() -> { if (frame != null) frame.removeView(cv); }, 1750);
    }

    /** Fires the burst when the Hub shows the trophy ceremony for OUR
     *  title, or the League tab shows our cup win — once each. */
    private void maybeCelebrate() {
        if (g == null || pickerMode || menuMode || onboardingMode || helpMode || g.sacked) return;
        boolean onHub = !matchMode && !transfersMode && !calendarMode && !modesMode
                && !settingsMode && !whatsNewMode && !searchMode && tab == 0;
        boolean onLeague = !matchMode && !transfersMode && !calendarMode && !modesMode
                && !settingsMode && !whatsNewMode && !searchMode && tab == 2;
        if (onHub && g.ceremony != null && g.userTeam.equals(g.ceremony.optString("champion"))) {
            celebrate("T" + g.ceremony.optInt("season"));
        } else if (onLeague && g.userTeam.equals(g.cupChampion) && g.cupFixtures.length() > 0) {
            celebrate("C" + g.season);
        }
    }

    public void toast(String s) {
        // Audio Pack (suggestion 14): a refused purchase anywhere in
        // the app speaks the same language — Game's action methods all
        // return "Not enough CF — ..." and every screen toasts it.
        if (snd != null && s != null && s.startsWith("Not enough CF")) {
            snd.playUi(SoundSynth.UI_BLOCKED);
        }
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    public void render() {
        // Batch I (idea 90): a hardcore sack is counted ONCE into the
        // persistent record that lives outside the career save — the flag
        // rides in the save itself, so re-renders never double-count.
        if (g != null && g.sacked && g.hardcore && !g.hardcoreCounted) {
            g.hardcoreCounted = true;
            store.put(Slots.HARDCORE_RECORD, Slots.hardcoreRecordUpdate(
                    store.get(Slots.HARDCORE_RECORD), g.season, g.career.optInt("titles") > 0));
        }
        save();
        hideSheet();
        setBug(null);
        setSticky(null);
        // v20.1 (item 1): the action slot clears through parkActionBar —
        // the v20 null clear bound to the framework Toolbar overload
        // and silently did nothing, so the last screen's bar leaked
        // onto every tab. Team / Match / Transfers park their bars
        // AFTER this clear, inside their build methods, so theirs
        // still show.
        parkActionBar(null);
        contentCol.removeAllViews();
        scrollView.scrollTo(0, 0);
        // Rich Media (v20): the main menu is FULL-BLEED — the app
        // header hides and the content padding collapses while it is
        // up; both restore the moment a door is taken.
        if (headerRoot != null) headerRoot.setVisibility(menuMode ? View.GONE : View.VISIBLE);
        if (menuMode) {
            contentCol.setPadding(0, 0, 0, 0);
        } else {
            contentCol.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 16));
        }
        // nav styling — P2 (suggestion 12): gold label + gold top
        // indicator + pill on the active tab; quiet slate otherwise
        for (int i = 0; i < 6; i++) {
            boolean active = !matchMode && !menuMode && !transfersMode && !calendarMode && !modesMode && !settingsMode && !whatsNewMode && !searchMode && !helpMode && !onboardingMode && !pickerMode && !g.sacked && tab == i;
            navLabels[i].setTextColor(active ? Ui.GOLD : Ui.MUTED);
            navLabels[i].setTypeface(null, active ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            navIndicators[i].setBackgroundColor(active ? Ui.GOLD : 0x00000000);
            navItems[i].setBackground(active ? Ui.round(Ui.BG, 10, this) : null);
        }
        navBar.setVisibility(matchMode || menuMode || pickerMode || onboardingMode || g.sacked ? View.GONE : View.VISIBLE);
        View v;
        if (g.sacked) {
            v = ProfileScreen.buildSacked(this); // Batch G (idea 68): the career is over
        } else if (onboardingMode) {
            v = OnboardingScreen.build(this); // P5 (suggestion 41): the welcome, before the picker
        } else if (menuMode) {
            v = MenuScreen.build(this); // Rich Media (v20): the title / main menu
        } else if (pickerMode) {
            v = PickerScreen.build(this); // Batch F (ideas 51/52)
        } else if (matchMode) {
            v = MatchScreen.build(this);
        } else if (transfersMode) {
            v = TransfersScreen.build(this); // Batch D sub-screen
        } else if (calendarMode) {
            v = CalendarScreen.build(this); // Batch H sub-screen
        } else if (modesMode) {
            v = ModesScreen.build(this); // Batch I sub-screen (ideas 81–90)
        } else if (settingsMode) {
            v = SettingsScreen.build(this); // Batch J sub-screen (ideas 91, 93–96, 99, 100)
        } else if (whatsNewMode) {
            v = WhatsNewScreen.build(this); // Batch J (idea 92)
        } else if (searchMode) {
            v = SearchScreen.build(this); // Batch J (idea 97)
        } else if (helpMode) {
            v = HelpScreen.build(this); // P5 (suggestions 43/44)
        } else {
            switch (tab) {
                case 1: v = TeamScreen.build(this); break;
                case 2: v = LeagueScreen.build(this); break;
                case 3: v = WorldScreen.build(this); break;
                case 4: v = ProfileScreen.build(this); break;
                case 5: v = HqScreen.build(this); break;
                default: v = HubScreen.build(this);
            }
        }
        contentCol.addView(v);
        // Design Batch (item 10): a short fade/slide on every screen
        // change — skipped entirely under Reduce Animations
        if (animOk()) {
            v.setAlpha(0f);
            v.setTranslationX(Ui.dp(this, 14));
            v.animate().alpha(1f).translationX(0f).setDuration(170).start();
        }
        maybeCelebrate();
        audioSync(); // Audio Pack: loops + celebration diff-sounds
    }

    /** v2: match day is BLOCKED when the team sheet is illegal — this dialog
     *  lists the exact problems and jumps straight to the Team tab to fix them. */
    public void showXiBlocked(java.util.List<String> problems) {
        if (snd != null) snd.playUi(SoundSynth.UI_BLOCKED); // Audio Pack: the blocked thud
        StringBuilder msg = new StringBuilder("Your team sheet is not legal yet:\n");
        for (String p : problems) msg.append("\n•  ").append(p);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Team Sheet Blocked")
                .setMessage(msg.toString())
                .setPositiveButton("Fix in Team Tab", (d, w) -> { tab = 1; render(); })
                .setNegativeButton("Close", null)
                .show();
    }

    /** Batch I (ideas 81/90): the picker's difficulty + hardcore choices
     *  are stamped onto the brand-new career. */
    private void applyPickerSettings() {
        g.difficulty = pickerDifficulty;
        if (pickerHardcore) {
            g.hardcore = true;
            g.addNews("☠ HARDCORE career: the sack line is " + g.sackThreshold()
                    + " board confidence, warnings start at 40, challenge/scenario rewards are halved, "
                    + "and slot load-undo is disabled. Good luck — you'll need it.");
        }
    }

    /** Batch F (idea 51): the picker chose a club — build that career. */
    public void startCareer(String team) {
        g = Game.freshForTeam(team);
        applyPickerSettings(); // Batch I
        careerExists = true; // v20: a career now exists for the menu
        pickerFromMenu = false;
        menuMode = false;
        pickerMode = false;
        matchMode = false;
        transfersMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast("You are the new manager of " + team + "!");
    }

    /** Batch F (idea 52): the picker created a custom club. */
    public void startCareerCustom(String name, String code, int color) {
        g = Game.freshCustom(name, code, color);
        applyPickerSettings(); // Batch I
        careerExists = true; // v20
        pickerFromMenu = false;
        menuMode = false;
        pickerMode = false;
        customOpen = false;
        matchMode = false;
        transfersMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast(name + " are in the league — good luck, manager!");
    }

    /** P5 (suggestion 41): the welcome tour is finished or skipped —
     *  the seen flag lands in the app prefs (never the career save),
     *  and the app lands wherever it was heading: the team picker on a
     *  first launch, or straight back to the tabs when the tour was
     *  replayed view-only from Help over a live career. */
    public void finishOnboarding() {
        settings.setOnboardingSeen(true);
        onboardingMode = false;
        onboardingStep = 0;
        // Rich Media (v20): the tour now lands on the main menu (the
        // picker is one tap further, behind New Career) — unless the
        // career is over, where the sacked screen owns the display.
        if (!g.sacked) menuMode = true;
        render();
    }

    /** P5 (suggestions 43/44): open Help, remembering whether Settings
     *  or Profile sent us, so the back chevron returns to the sender. */
    public void openHelp(boolean fromSettings) {
        helpFromSettings = fromSettings;
        settingsMode = false;
        helpMode = true;
        render();
    }

    // ---------------- Batch I (idea 87): career slots ----------------

    public void saveCareerSlot(int n) {
        if (Slots.saveSlot(store, n, g)) {
            toast("Career saved to Slot " + n);
        }
        render();
    }

    /** Confirm-gated by the Profile UI. The live career is backed up into
     *  the autoslot first (Slots.loadSlot), so a mistaken load is
     *  recoverable once via undoLoadCareer(). */
    public void loadCareerSlot(int n) {
        Game loaded = Slots.loadSlot(store, n, g);
        if (loaded == null) { toast("Slot " + n + " is empty"); return; }
        g = loaded;
        careerExists = true; // v20
        matchMode = g.match != null;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast("Loaded Slot " + n + " — " + g.userTeam + ", Season " + g.season);
    }

    public void undoLoadCareer() {
        Game restored = Slots.undoLoad(store, g);
        if (restored == null) { toast("Nothing to undo"); render(); return; }
        g = restored;
        matchMode = g.match != null;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast("Load undone — your previous career is back");
    }

    // ---------------- Batch J (ideas 91/96/100): backup, sync, reset ----------------

    /** The Profile reset flow, shared with the Settings screen's safe
     *  reset (idea 96): wipes ONLY the live career (Store.clear removes
     *  state_v1) — slots, the autoslot, the hardcore record and all app
     *  settings survive — and lands on the team picker. */
    public void resetCareerToPicker() {
        stopAuto();
        store.clear();
        g = Game.fresh();
        careerExists = false; // v20: the menu loses its Continue door
        pickerFromMenu = false;
        menuMode = true; // v20: a reset lands on the main menu
        pickerMode = true;
        customOpen = false;
        customNameDraft = "";
        customCodeDraft = "";
        matchMode = false;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        settingsMode = false;
        whatsNewMode = false;
        searchMode = false;
        helpMode = false;
        teamDetail = null;
        syncCodeShown = null;
        importDraft = "";
        tab = 0;
        render();
        toast("Pick your club for the new career");
    }

    /** Imports a validated career JSON (idea 91 via idea 100's codes, or
     *  a pasted .json backup). Mirrors loadCareerSlot exactly: the live
     *  career is backed up into the autoslot first (skipped for a
     *  hardcore career out OR in — no undo there), so Profile → Career
     *  Slots → Undo Load recovers it until a season match is played.
     *  Only the live save is replaced: slot_1..3 and hardcore_record
     *  keys are never touched. */
    public void importCareerJson(String json) {
        stopAuto();
        boolean backup = g != null && !g.hardcore;
        if (backup) store.put(Slots.AUTOSLOT, g.toJson());
        Game loaded = Game.fromJson(json);
        loaded.undoArmed = backup && !loaded.hardcore;
        g = loaded;
        careerExists = true; // v20
        matchMode = g.match != null;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        settingsMode = false;
        whatsNewMode = false;
        searchMode = false;
        teamDetail = null;
        syncCodeShown = null;
        importDraft = "";
        tab = 0;
        save();
        render();
        toast("Career imported — " + g.userTeam + ", Season " + g.season);
    }

    /** Shares a text payload as a real file (cache/share/ via the Batch H
     *  provider, so receivers get an attachment), falling back to a plain
     *  text share if the file write fails. Used by the career backup
     *  (idea 91), the sync code (idea 100) and the CSV exports (idea 98).
     *  No permission is involved: cache dir + a temporary URI grant. */
    public void shareTextFile(String name, String content, String mime) {
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "share");
            if (!dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, name);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(content.getBytes("UTF-8"));
            fos.close();
            android.net.Uri uri = android.net.Uri.parse(
                    "content://" + ShareProvider.AUTHORITY + "/" + name);
            android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
            it.setType(mime);
            it.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            it.putExtra(android.content.Intent.EXTRA_TEXT, content);
            it.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(it, "Share " + name));
        } catch (Exception e) {
            try {
                android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
                it.setType("text/plain");
                it.putExtra(android.content.Intent.EXTRA_TEXT, content);
                startActivity(android.content.Intent.createChooser(it, "Share"));
            } catch (Exception ignored) { toast("Sharing isn't available right now"); }
        }
    }

    /** Idea 91: the whole career save as a keepable .json file. */
    public void exportCareerFile() {
        shareTextFile("cricket-club-manager-career.json", g.toJson(), "application/json");
    }

    // ---------------- Audio Pack (v19): synthesized sound ----------------
    // SoundSynth generates every sound as PCM at runtime (NO audio
    // files, NO permissions); SoundEngine plays them. This section is
    // the match/event wiring: ball sounds with crowd context, the
    // full-time moment, rain, the late-chase tension loop, voice
    // score updates, and the per-render sync that runs the ambience /
    // music loops and the celebration diff-sounds. The idea-94 gate
    // semantics are unchanged: match sounds fire ONLY on live paths
    // (ball taps, staged auto steps, Highlights steps); Instant sims
    // never call in.

    /** Legacy Batch J shim: maps the old SND_* events onto the engine
     *  so any older caller keeps working. */
    public void playTone(int event) {
        if (snd == null) return;
        switch (event) {
            case Settings.SND_WICKET: snd.playLive(SoundSynth.STING_WICKET); break;
            case Settings.SND_SIX: snd.playLive(SoundSynth.BAT2); break;
            case Settings.SND_FOUR: snd.playLive(SoundSynth.BAT2); break;
            case Settings.SND_TICK: snd.playLive(SoundSynth.BAT0); break;
            default: break;
        }
    }

    /** The dismissal "how" from the newest commentary line — the
     *  engine appends "(b X)" / "(lbw b X)" / "(run out)" to wicket
     *  lines, so the UI can pick stumps vs pads without the match
     *  JSON growing an audio field. */
    private String lastDismissalHow(JSONObject m) {
        org.json.JSONArray c = m.optJSONArray("comm");
        if (c == null) return null;
        for (int i = c.length() - 1; i >= 0 && i >= c.length() - 3; i--) {
            String line = c.optString(i);
            int a = line.lastIndexOf('('), b = line.lastIndexOf(')');
            if (a >= 0 && b > a) return line.substring(a + 1, b);
        }
        return null;
    }

    /** Did the batter who faced this ball cross 50 or 100 with it?
     *  Only his runs changed on the ball, so checking both men at the
     *  crease against (runs - outcome) finds exactly the crossing. */
    private boolean milestoneCrossed(JSONObject m, int outcomeRuns) {
        if (outcomeRuns <= 0) return false;
        org.json.JSONArray bat = m.optJSONArray("bat");
        if (bat == null) return false;
        int[] crease = {m.optInt("striker", -1), m.optInt("nonStriker", -1)};
        for (int idx : crease) {
            if (idx < 0 || idx >= bat.length()) continue;
            int r = bat.optJSONObject(idx).optInt("runs");
            int prev = r - outcomeRuns;
            if ((prev < 50 && r >= 50) || (prev < 100 && r >= 100)) return true;
        }
        return false;
    }

    /** A chase is "close late" for the tension loop: second innings
     *  (or a Super Over), at most 3 overs left, and the target still
     *  genuinely in reach-or-danger (need <= 60, game alive). */
    private boolean tensionState(JSONObject m) {
        if (m == null || !"play".equals(m.optString("phase"))) return false;
        if (m.optBoolean("superMode")) return true;
        if (m.optInt("inn") != 2) return false;
        int limit = m.optInt("ballsLimit", 120);
        int rem = limit - m.optInt("balls");
        int need = m.optInt("target", 0) - m.optInt("runs");
        return rem > 0 && rem <= 18 && need > 0 && need <= 60;
    }

    /** The sound picture for the ball just played, read off the
     *  match state. livePath restates the idea-94 gate so no future
     *  caller can wire a sim path in by accident. */
    public void playBallSound(boolean livePath) {
        if (snd == null || g == null || g.match == null) return;
        if (!Settings.soundPlays(settings.soundOn(), livePath)) return;
        JSONObject m = g.match;
        org.json.JSONArray lb = m.optJSONArray("lastBalls");
        if (lb == null || lb.length() == 0) return;
        String last = lb.optString(lb.length() - 1);
        boolean userBatting = g.userTeam.equals(m.optString("batTeam"));
        boolean home = m.optBoolean("home");
        int outcome = -1;
        try { outcome = Integer.parseInt(last); } catch (Exception ignored) {}
        if ("W".equals(last)) {
            int kind = SoundSynth.dismissalKind(lastDismissalHow(m));
            if (kind == 1) snd.playLive(SoundSynth.STUMPS);        // bowled
            else if (kind == 2) snd.playLive(SoundSynth.PADS);     // lbw
            if (userBatting) {
                // our wicket: the home crowd groans; away it is a
                // smaller dip (the same groan — their crowd is not
                // ours to swell, and the bed carries the difference)
                snd.playLive(SoundSynth.GROAN);
            } else {
                // our wicket with the ball: sting + the crowd's side
                snd.playLive(SoundSynth.STING_WICKET);
                snd.playLive(home ? SoundSynth.SWELL2 : SoundSynth.SWELL1);
            }
        } else if (outcome >= 0) {
            int w = SoundSynth.batWeightFor(last);
            if (w >= 0) snd.playLive(SoundSynth.batIdForWeight(w));
            if (outcome == 4 || outcome == 6) {
                if (userBatting) {
                    snd.playLive(outcome == 6 ? SoundSynth.SWELL2 : SoundSynth.SWELL1);
                } else if (!home) {
                    // their crowd celebrates a boundary against us
                    snd.playLive(SoundSynth.SWELL1);
                }
            }
            if (milestoneCrossed(m, outcome)) {
                snd.playLive(SoundSynth.APPLAUSE);
                snd.playLive(SoundSynth.SWELL1);
            }
        }
        // rain: the note appears in the render the shower lands —
        // patter over the break, then it stops itself
        String note = m.optString("rainNote", "");
        if (!note.equals(sndRainNote)) {
            sndRainNote = note;
            if (!note.isEmpty()) snd.rainBurst();
        }
        snd.setTension(tensionState(m));
        maybeVoiceUpdate(m, last);
    }

    /** Voice score updates (suggestions 21-22): at the innings break,
     *  after overs 15 and 18 of a chase, and at full time — real
     *  state, English text, only when the user enabled voice. The
     *  triggers key off state transitions this method can see on the
     *  live path: break phase entry, chase balls == 90 / 108. */
    private String sndVoiceKey = "";
    private void maybeVoiceUpdate(JSONObject m, String lastBall) {
        if (snd == null || !settings.voiceOn()) return;
        String key = null, text = null;
        String phase = m.optString("phase");
        if ("break".equals(phase)) {
            key = "break" + m.optInt("inn1Runs");
            text = g.userTeam.equals(m.optString("batTeam"))
                    ? "Innings break. The target is " + m.optInt("target") + "."
                    : "Innings break. " + m.optString("opp") + " set a target of " + m.optInt("target") + ".";
        } else if ("done".equals(phase)) {
            key = "done" + m.optString("summary");
            text = m.optString("summary");
        } else if ("play".equals(phase) && m.optInt("inn") == 2 && !m.optBoolean("superMode")) {
            int balls = m.optInt("balls");
            int need = m.optInt("target", 0) - m.optInt("runs");
            int rem = m.optInt("ballsLimit", 120) - balls;
            if ((balls == 90 || balls == 108) && need > 0 && rem > 0) {
                key = "chase" + balls + ":" + need;
                String batTeam = m.optString("batTeam");
                text = batTeam + " need " + need + " off " + rem + " balls.";
            }
        }
        if (key != null && !key.equals(sndVoiceKey)) {
            sndVoiceKey = key;
            final String say = text;
            // after any sting on the same ball, not over it
            autoHandler.postDelayed(() -> snd.speak(say), 650);
        }
    }

    /** Full-time: the win moment gets the jingle, the biggest crowd
     *  swell and the cash chime (the prize posts here); a loss gets
     *  the groan. Fired from the same live paths as before. */
    public void playEndJingle(final boolean won) {
        if (snd == null) return;
        if (!Settings.soundPlays(settings.soundOn(), true)) return;
        snd.playLive(SoundSynth.WHISTLE); // Rich Media (v20): the full-time whistle (real file)
        if (won) {
            snd.playLive(SoundSynth.STING_WIN);
            snd.playLive(SoundSynth.SWELL3);
            autoHandler.postDelayed(() -> snd.playUi(SoundSynth.CASH), 300);
        } else {
            snd.playLive(SoundSynth.GROAN);
        }
        if (g != null && g.match != null) maybeVoiceUpdate(g.match, "");
        snd.setTension(false);
    }

    /** Auction feedback (suggestion 15): a tick for a live raise, the
     *  gavel + confirm when the hammer falls for the user. Errors are
     *  the toast's job (the Not-enough-CF thud lives there). */
    public void auctionSound(String result) {
        if (snd == null || result == null) return;
        if (result.startsWith("SOLD!")) {
            snd.playUi(SoundSynth.GAVEL);
            snd.playUi(SoundSynth.UI_CONFIRM);
        } else if (result.contains("counter") || result.startsWith("You are the highest")) {
            snd.bidTick();
        }
    }

    /** Per-channel test buttons in Settings (suggestion 23). */
    public void testChannel(int ch) {
        if (snd == null) return;
        switch (ch) {
            case Settings.CH_MATCH: snd.playDirect(SoundSynth.BAT2); break;
            case Settings.CH_CROWD: snd.playDirect(SoundSynth.SWELL2); break;
            case Settings.CH_UI: snd.playDirect(SoundSynth.UI_CONFIRM); break;
            case Settings.CH_MUSIC: snd.playDirect(SoundSynth.STING_WIN); break;
            case Settings.CH_VOICE:
                if (settings.voiceOn()) snd.speak("Lahore need 24 off 12 balls.");
                else toast("Turn Voice score updates on first");
                break;
            default: break;
        }
    }

    /** Per-render audio sync: ambience + music loops follow the
     *  screen, and state diffs the game cannot announce (it has no
     *  Android side) fire their one-shots — achievements, level-ups,
     *  titles, signings. Baselines are set silently on first sight. */
    public void audioSync() {
        if (snd == null || g == null) return;
        boolean inMatch = matchMode && g.match != null
                && !"done".equals(g.match.optString("phase"));
        if (inMatch) {
            JSONObject m = g.match;
            // Rich Media (v20): the bed is a real crowd FILE now, in
            // three flavours — home / away / derby recordings picked
            // by the same flags the v19 synth bed read.
            snd.setBed(true,
                    m.optBoolean("derby") ? SoundEngine.BED_DERBY
                            : m.optBoolean("home") ? SoundEngine.BED_HOME : SoundEngine.BED_AWAY,
                    m.optBoolean("derby") ? 0.7f : m.optBoolean("home") ? 0.55f : 0.35f);
            snd.setMusic(2);
        } else {
            snd.setBed(false, SoundEngine.BED_HOME, 0);
            snd.setTension(false);
            snd.setMusic(g.sacked ? 0 : 1);
        }
        int ach = g.achievements == null ? 0 : g.achievements.length();
        int titles = g.career == null ? 0
                : g.career.optInt("titles") + g.career.optInt("cups");
        int ledgerLen = g.ledger == null ? 0 : g.ledger.length();
        if (sndAch < 0) {
            sndAch = ach; sndLevel = g.managerLevel; sndTitles = titles; sndLedgerLen = ledgerLen;
            return;
        }
        if (ach > sndAch) snd.playUi(SoundSynth.STING_ACHIEVE);
        if (g.managerLevel > sndLevel) snd.playUi(SoundSynth.STING_LEVELUP);
        if (titles > sndTitles) {
            snd.playUi(SoundSynth.STING_TITLE);
            snd.playUi(SoundSynth.SWELL3);
        }
        if (ledgerLen > sndLedgerLen && g.ledger != null) {
            for (int i = sndLedgerLen; i < ledgerLen; i++) {
                String r = g.ledger.optJSONObject(i).optString("reason").toLowerCase(java.util.Locale.US);
                if (r.contains("signing") || r.contains("loan-in") || r.contains("transfer —")) {
                    snd.playUi(SoundSynth.UI_CONFIRM);
                    break;
                }
            }
        }
        sndAch = ach; sndLevel = g.managerLevel; sndTitles = titles; sndLedgerLen = ledgerLen;
    }

    public void startMatch(JSONObject fixture) {
        MatchEngine.startMatch(g, fixture);
        matchMode = true;
        save();
        render();
    }

    /** Rich Media (v20): scroll the content area to a view once the
     *  current layout has settled — the HQ campus hotspots use it to
     *  jump the facility list to the tapped building's card. The
     *  offset walks the view's own parent chain, so nested cards land
     *  correctly; failures are silent (the list is right there). */
    public void scrollToViewDelayed(final View v) {
        if (scrollView == null || v == null) return;
        scrollView.post(() -> {
            try {
                int y = 0;
                View p = v;
                while (p != null && p != contentCol) {
                    y += p.getTop();
                    Object parent = p.getParent();
                    p = parent instanceof View ? (View) parent : null;
                }
                scrollView.smoothScrollTo(0, Math.max(0, y - Ui.dp(MainActivity.this, 64)));
            } catch (Exception ignored) {}
        });
    }

    // ---------------- Batch H (idea 77): the match report card + sharing ----

    /** View the drawn report card in-app. */
    public void showReportCard() {
        if (g.lastReport == null) { toast("No match report yet — finish a match first"); return; }
        try {
            android.graphics.Bitmap bmp = ReportCard.render(g, g.lastReport);
            android.widget.ImageView iv = new android.widget.ImageView(this);
            iv.setImageBitmap(bmp);
            iv.setAdjustViewBounds(true);
            iv.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Match Report Card")
                    .setView(iv)
                    .setPositiveButton("Share Image", (d, w) -> shareReportImage())
                    .setNeutralButton("Share Text", (d, w) -> shareReportText())
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) {
            toast("Could not draw the report card");
        }
    }

    /** Share the report as a PNG through the share sheet. The image rides
     *  a content:// URI from our own tiny cache provider (ShareProvider —
     *  a provider entry is NOT a permission; the app stays at zero
     *  permissions). Any failure falls back to the text share. */
    public void shareReportImage() {
        if (g.lastReport == null) { toast("No match report yet — finish a match first"); return; }
        try {
            android.graphics.Bitmap bmp = ReportCard.render(g, g.lastReport);
            java.io.File dir = new java.io.File(getCacheDir(), "reports");
            if (!dir.exists()) dir.mkdirs();
            java.io.File out = new java.io.File(dir, "report-s" + g.lastReport.optInt("season")
                    + "-d" + g.lastReport.optInt("fixtureDay") + ".png");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
            bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            android.net.Uri uri = android.net.Uri.parse("content://" + ShareProvider.AUTHORITY + "/" + out.getName());
            android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
            it.setType("image/png");
            it.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            it.putExtra(android.content.Intent.EXTRA_TEXT, g.reportText(g.lastReport));
            it.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(it, "Share match report"));
        } catch (Exception e) {
            shareReportText(); // the guaranteed path
        }
    }

    /** Share the report as formatted text — always works, no files. */
    public void shareReportText() {
        if (g.lastReport == null) { toast("No match report yet — finish a match first"); return; }
        android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
        it.setType("text/plain");
        it.putExtra(android.content.Intent.EXTRA_SUBJECT, "Match Report — " + g.userTeam);
        it.putExtra(android.content.Intent.EXTRA_TEXT, g.reportText(g.lastReport));
        startActivity(android.content.Intent.createChooser(it, "Share match report"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopAuto();
        if (snd != null) snd.stopLoops(); // Audio Pack: silence loops when the app leaves the screen
        if (g != null) save();
    }

    @Override
    protected void onResume() {
        super.onResume();
        audioSync(); // Audio Pack: loops follow the screen again
    }

    @Override
    protected void onDestroy() {
        if (snd != null) snd.release(); // Audio Pack: free the tracks + TTS
        super.onDestroy();
    }
}
