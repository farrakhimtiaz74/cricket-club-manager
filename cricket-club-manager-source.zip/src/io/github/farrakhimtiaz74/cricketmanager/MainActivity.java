package io.github.farrakhimtiaz74.cricketmanager;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    public Game g;
    public Store store;
    public int tab = 0; // 0 Hub, 1 Team, 2 League, 3 World, 4 Profile, 5 HQ
    public boolean matchMode = false;
    public String teamFilter = "All";
    public int worldFormat = 0;
    public int worldCat = 0;
    // Batch C: Team tab detail view + comparison picker state
    public String teamDetail = null;   // player name in the detail view, or null for the list
    public boolean compareMode = false;
    public String compareA = "";
    public String compareB = "";
    // Batch D: Transfers & Contracts sub-screen (from HQ / Hub), nav unchanged
    public boolean transfersMode = false;
    // Batch H (idea 79): the season calendar sub-screen, nav unchanged
    public boolean calendarMode = false;
    // Batch I (ideas 81–90): the Modes & Challenges sub-screen, nav unchanged
    public boolean modesMode = false;
    // Batch J (ideas 92/96/97): Settings, What's New and Search sub-screens
    public boolean settingsMode = false;
    public boolean whatsNewMode = false;
    public boolean searchMode = false;
    public String searchQuery = "";
    public String importDraft = "";
    public String syncCodeShown = null;
    /** Batch J: APP-LEVEL settings (ideas 92–96) — own prefs file
     *  (ccm_settings), deliberately NOT the career save, so they survive
     *  career resets, slot loads and sync imports. The adapter is here;
     *  the logic and defaults live in the pure Settings class. */
    public Settings settings;
    public int appVersionCode = 12;
    public String appVersionName = "12.0";
    private android.media.ToneGenerator toneGen;
    // Batch I (ideas 81/90): new-career choices made on the team picker
    public int pickerDifficulty = 1; // 0 Casual, 1 Manager, 2 Legend
    public boolean pickerHardcore = false;
    // Batch F (ideas 51/52): the new-career team picker (first launch, or
    // after a Profile reset). While it is up, nothing is persisted — the
    // career only exists once a club is chosen.
    public boolean pickerMode = false;
    public boolean customOpen = false;
    public int customColorIdx = 0;
    public String customNameDraft = "";
    public String customCodeDraft = "";
    /** Batch E (idea 44): "As It Stands" live-table toggle on the match screen. */
    public boolean showAsItStands = false;

    private LinearLayout contentCol;
    private TextView headerMeta;
    private Button[] navBtns = new Button[6];
    private LinearLayout navBar;

    private static final String[] TABS = {"Hub", "Team", "League", "World", "Profile", "HQ"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Batch J: app settings BEFORE any view exists — the Big Text
        // factor must be in place before the first Ui.text() call, and
        // the commentary language before the first ball is bowled.
        final android.content.SharedPreferences spJ =
                getSharedPreferences("ccm_settings", MODE_PRIVATE);
        settings = new Settings(new Settings.Kv() {
            @Override public String get(String k) { return spJ.getString(k, null); }
            @Override public void put(String k, String v) { spJ.edit().putString(k, v).apply(); }
            @Override public void remove(String k) { spJ.edit().remove(k).apply(); }
        });
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            appVersionCode = pi.versionCode;
            appVersionName = pi.versionName;
        } catch (Exception ignored) {}
        Ui.TEXT_SCALE = Settings.textScale(settings.bigText());
        MatchEngine.urduComm = settings.urduComm();
        store = new Store(this);
        String saved = store.load();
        pickerMode = saved == null; // Batch F: no save = pick a club first
        g = saved == null ? Game.fresh() : Game.fromJson(saved);
        if (g.match != null) matchMode = true;
        save();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        // header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 8));
        LinearLayout hcol = Ui.col(this);
        TextView title = Ui.text(this, "Cricket Club Manager", 19, Ui.INK, true);
        headerMeta = Ui.small(this, "");
        hcol.addView(title);
        hcol.addView(headerMeta);
        LinearLayout.LayoutParams hcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        hcol.setLayoutParams(hcp);
        header.addView(hcol);
        TextView cfChip = Ui.gold(this, "", 16);
        cfChip.setBackground(Ui.roundStroke(Ui.CARD, Ui.GOLD, 12, this));
        cfChip.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        cfChip.setTag("cfChip");
        header.addView(cfChip);
        header.setTag(cfChip);
        root.addView(header);
        this.headerCf = cfChip;

        // scrollable content
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        scroll.setFillViewport(true);
        contentCol = Ui.col(this);
        contentCol.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 16));
        scroll.addView(contentCol);
        root.addView(scroll);
        this.scrollView = scroll;

        // bottom nav
        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setBackgroundColor(Ui.CARD);
        navBar.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 10));
        for (int i = 0; i < 6; i++) {
            final int idx = i;
            Button b = new Button(this);
            b.setText(TABS[i]);
            b.setTextSize(Ui.scale(12)); // Batch J (idea 95): nav follows Big Text too
            b.setAllCaps(false);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            b.setLayoutParams(new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
            b.setOnClickListener(v -> {
                matchMode = false;
                transfersMode = false; // Batch D: nav always leaves the Transfers sub-screen
                calendarMode = false; // Batch H: nav leaves the calendar too
                modesMode = false; // Batch I: nav leaves Modes too
                settingsMode = false; // Batch J: nav leaves Settings / What's New / Search too
                whatsNewMode = false;
                searchMode = false;
                teamDetail = null; // Batch C: nav always lands on the tab's home view
                tab = idx;
                render();
            });
            navBtns[i] = b;
            navBar.addView(b);
        }
        root.addView(navBar);

        setContentView(root);
        render();
    }

    private TextView headerCf;
    private ScrollView scrollView;

    // ---------------- Batch A (idea 10): staged auto-play pacing ----------------
    // Sim buttons at 1x/2x run through this Handler loop (one ball per tick);
    // Instant keeps the old fully-synchronous sims. startAuto toggles.
    public final android.os.Handler autoHandler = new android.os.Handler();
    public String autoMode = null; // "over" | "innings" | "match"
    private int autoTargetBalls = -1;
    private int autoStartInn = -1;

    private final Runnable autoStep = new Runnable() {
        @Override
        public void run() {
            if (autoMode == null || !matchMode || g.match == null) { autoMode = null; return; }
            JSONObject m = g.match;
            if (!"play".equals(m.optString("phase"))) { autoMode = null; render(); return; }
            MatchEngine.bowlBall(g);
            // Batch J (idea 94): staged steps are a LIVE path — each stepped
            // ball sounds, and the ball that ends the match gets the jingle
            if ("done".equals(m.optString("phase"))) {
                playEndJingle(g.userTeam.equals(m.optString("winnerTeam")));
            } else {
                playBallSound(true);
            }
            save();
            // Batch B (idea 14): a staged sim pauses for the next-batter pick
            if (m.optBoolean("awaitBat")) { autoMode = null; render(); return; }
            boolean stop = !"play".equals(m.optString("phase"));
            if (!stop && "over".equals(autoMode)
                    && (m.optInt("balls") >= autoTargetBalls || m.optInt("balls") == 0)) stop = true;
            if (!stop && "innings".equals(autoMode) && m.optInt("inn") != autoStartInn) stop = true;
            if (stop) { autoMode = null; render(); return; }
            render();
            autoHandler.postDelayed(this, g.speed == 2 ? 140 : 320);
        }
    };

    public void startAuto(String mode) {
        if (g.match == null || !"play".equals(g.match.optString("phase"))) return;
        if (g.match.optBoolean("awaitBat")) return; // Batch B: pick the next batter first
        if (mode.equals(autoMode)) { stopAuto(); render(); return; } // tap again to stop
        autoMode = mode;
        autoStartInn = g.match.optInt("inn");
        int b = g.match.optInt("balls");
        autoTargetBalls = b + (6 - b % 6);
        autoHandler.removeCallbacks(autoStep);
        autoHandler.postDelayed(autoStep, g.speed == 2 ? 140 : 320);
        render();
    }

    public void stopAuto() {
        autoMode = null;
        autoHandler.removeCallbacks(autoStep);
    }

    public void save() {
        // Batch F: in the picker there is no career to persist yet
        if (!pickerMode) store.save(g.toJson());
        if (headerMeta != null) {
            headerMeta.setText(g.userTeam + " · Season " + g.season + " · Day " + g.day);
        }
        if (headerCf != null) {
            headerCf.setText(g.cf + " CF");
            // Batch F (idea 52): a custom club tints the header chip
            if (g.customTeam) headerCf.setBackground(Ui.roundStroke(Ui.CARD, g.teamColor(), 12, this));
        }
    }

    public void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    public void render() {
        // Batch I (idea 90): a hardcore sack is counted ONCE into the
        // persistent record that lives outside the career save — the flag
        // rides in the save itself, so re-renders never double-count.
        if (g != null && g.sacked && g.hardcore && !g.hardcoreCounted) {
            g.hardcoreCounted = true;
            store.put(Slots.HARDCORE_RECORD, Slots.hardcoreRecordUpdate(
                    store.get(Slots.HARDCORE_RECORD), g.season, g.career.optInt("titles") > 0));
        }
        save();
        contentCol.removeAllViews();
        scrollView.scrollTo(0, 0);
        // nav styling
        for (int i = 0; i < 6; i++) {
            boolean active = !matchMode && !transfersMode && !calendarMode && !modesMode && !settingsMode && !whatsNewMode && !searchMode && !pickerMode && !g.sacked && tab == i;
            navBtns[i].setTextColor(active ? Ui.GOLD : Ui.MUTED);
            navBtns[i].setTypeface(null, active ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            navBtns[i].setBackground(active ? Ui.round(Ui.BG, 10, this) : null);
        }
        navBar.setVisibility(matchMode || pickerMode || g.sacked ? View.GONE : View.VISIBLE);
        View v;
        if (g.sacked) {
            v = ProfileScreen.buildSacked(this); // Batch G (idea 68): the career is over
        } else if (pickerMode) {
            v = PickerScreen.build(this); // Batch F (ideas 51/52)
        } else if (matchMode) {
            v = MatchScreen.build(this);
        } else if (transfersMode) {
            v = TransfersScreen.build(this); // Batch D sub-screen
        } else if (calendarMode) {
            v = CalendarScreen.build(this); // Batch H sub-screen
        } else if (modesMode) {
            v = ModesScreen.build(this); // Batch I sub-screen (ideas 81–90)
        } else if (settingsMode) {
            v = SettingsScreen.build(this); // Batch J sub-screen (ideas 91, 93–96, 99, 100)
        } else if (whatsNewMode) {
            v = WhatsNewScreen.build(this); // Batch J (idea 92)
        } else if (searchMode) {
            v = SearchScreen.build(this); // Batch J (idea 97)
        } else {
            switch (tab) {
                case 1: v = TeamScreen.build(this); break;
                case 2: v = LeagueScreen.build(this); break;
                case 3: v = WorldScreen.build(this); break;
                case 4: v = ProfileScreen.build(this); break;
                case 5: v = HqScreen.build(this); break;
                default: v = HubScreen.build(this);
            }
        }
        contentCol.addView(v);
    }

    /** v2: match day is BLOCKED when the team sheet is illegal — this dialog
     *  lists the exact problems and jumps straight to the Team tab to fix them. */
    public void showXiBlocked(java.util.List<String> problems) {
        StringBuilder msg = new StringBuilder("Your team sheet is not legal yet:\n");
        for (String p : problems) msg.append("\n•  ").append(p);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Team Sheet Blocked")
                .setMessage(msg.toString())
                .setPositiveButton("Fix in Team Tab", (d, w) -> { tab = 1; render(); })
                .setNegativeButton("Close", null)
                .show();
    }

    /** Batch I (ideas 81/90): the picker's difficulty + hardcore choices
     *  are stamped onto the brand-new career. */
    private void applyPickerSettings() {
        g.difficulty = pickerDifficulty;
        if (pickerHardcore) {
            g.hardcore = true;
            g.addNews("☠ HARDCORE career: the sack line is " + g.sackThreshold()
                    + " board confidence, warnings start at 40, challenge/scenario rewards are halved, "
                    + "and slot load-undo is disabled. Good luck — you'll need it.");
        }
    }

    /** Batch F (idea 51): the picker chose a club — build that career. */
    public void startCareer(String team) {
        g = Game.freshForTeam(team);
        applyPickerSettings(); // Batch I
        pickerMode = false;
        matchMode = false;
        transfersMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast("You are the new manager of " + team + "!");
    }

    /** Batch F (idea 52): the picker created a custom club. */
    public void startCareerCustom(String name, String code, int color) {
        g = Game.freshCustom(name, code, color);
        applyPickerSettings(); // Batch I
        pickerMode = false;
        customOpen = false;
        matchMode = false;
        transfersMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast(name + " are in the league — good luck, manager!");
    }

    // ---------------- Batch I (idea 87): career slots ----------------

    public void saveCareerSlot(int n) {
        if (Slots.saveSlot(store, n, g)) {
            toast("Career saved to Slot " + n);
        }
        render();
    }

    /** Confirm-gated by the Profile UI. The live career is backed up into
     *  the autoslot first (Slots.loadSlot), so a mistaken load is
     *  recoverable once via undoLoadCareer(). */
    public void loadCareerSlot(int n) {
        Game loaded = Slots.loadSlot(store, n, g);
        if (loaded == null) { toast("Slot " + n + " is empty"); return; }
        g = loaded;
        matchMode = g.match != null;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast("Loaded Slot " + n + " — " + g.userTeam + ", Season " + g.season);
    }

    public void undoLoadCareer() {
        Game restored = Slots.undoLoad(store, g);
        if (restored == null) { toast("Nothing to undo"); render(); return; }
        g = restored;
        matchMode = g.match != null;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        teamDetail = null;
        tab = 0;
        save();
        render();
        toast("Load undone — your previous career is back");
    }

    // ---------------- Batch J (ideas 91/96/100): backup, sync, reset ----------------

    /** The Profile reset flow, shared with the Settings screen's safe
     *  reset (idea 96): wipes ONLY the live career (Store.clear removes
     *  state_v1) — slots, the autoslot, the hardcore record and all app
     *  settings survive — and lands on the team picker. */
    public void resetCareerToPicker() {
        stopAuto();
        store.clear();
        g = Game.fresh();
        pickerMode = true;
        customOpen = false;
        customNameDraft = "";
        customCodeDraft = "";
        matchMode = false;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        settingsMode = false;
        whatsNewMode = false;
        searchMode = false;
        teamDetail = null;
        syncCodeShown = null;
        importDraft = "";
        tab = 0;
        render();
        toast("Pick your club for the new career");
    }

    /** Imports a validated career JSON (idea 91 via idea 100's codes, or
     *  a pasted .json backup). Mirrors loadCareerSlot exactly: the live
     *  career is backed up into the autoslot first (skipped for a
     *  hardcore career out OR in — no undo there), so Profile → Career
     *  Slots → Undo Load recovers it until a season match is played.
     *  Only the live save is replaced: slot_1..3 and hardcore_record
     *  keys are never touched. */
    public void importCareerJson(String json) {
        stopAuto();
        boolean backup = g != null && !g.hardcore;
        if (backup) store.put(Slots.AUTOSLOT, g.toJson());
        Game loaded = Game.fromJson(json);
        loaded.undoArmed = backup && !loaded.hardcore;
        g = loaded;
        matchMode = g.match != null;
        transfersMode = false;
        calendarMode = false;
        modesMode = false;
        settingsMode = false;
        whatsNewMode = false;
        searchMode = false;
        teamDetail = null;
        syncCodeShown = null;
        importDraft = "";
        tab = 0;
        save();
        render();
        toast("Career imported — " + g.userTeam + ", Season " + g.season);
    }

    /** Shares a text payload as a real file (cache/share/ via the Batch H
     *  provider, so receivers get an attachment), falling back to a plain
     *  text share if the file write fails. Used by the career backup
     *  (idea 91), the sync code (idea 100) and the CSV exports (idea 98).
     *  No permission is involved: cache dir + a temporary URI grant. */
    public void shareTextFile(String name, String content, String mime) {
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "share");
            if (!dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, name);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(content.getBytes("UTF-8"));
            fos.close();
            android.net.Uri uri = android.net.Uri.parse(
                    "content://" + ShareProvider.AUTHORITY + "/" + name);
            android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
            it.setType(mime);
            it.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            it.putExtra(android.content.Intent.EXTRA_TEXT, content);
            it.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(it, "Share " + name));
        } catch (Exception e) {
            try {
                android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
                it.setType("text/plain");
                it.putExtra(android.content.Intent.EXTRA_TEXT, content);
                startActivity(android.content.Intent.createChooser(it, "Share"));
            } catch (Exception ignored) { toast("Sharing isn't available right now"); }
        }
    }

    /** Idea 91: the whole career save as a keepable .json file. */
    public void exportCareerFile() {
        shareTextFile("cricket-club-manager-career.json", g.toJson(), "application/json");
    }

    // ---------------- Batch J (idea 94): sound effects ----------------
    // Framework ToneGenerator on the music stream — synthesized tones,
    // NO audio files, NO permissions. Every call is wrapped so a missing
    // or busy audio path fails silently. Sounds fire ONLY on live paths
    // (ball taps, staged auto steps, Highlights steps, full-time
    // jingle); Instant sims never call in (Settings.soundPlays gate).

    private android.media.ToneGenerator ensureToneGen() {
        if (toneGen == null) {
            try {
                toneGen = new android.media.ToneGenerator(
                        android.media.AudioManager.STREAM_MUSIC,
                        Settings.volumePercent(settings.volume()));
            } catch (Exception e) {
                toneGen = null;
            }
        }
        return toneGen;
    }

    /** Volume changed in Settings: drop the generator so the next tone
     *  is built at the new level. */
    public void resetToneGen() {
        try { if (toneGen != null) toneGen.release(); } catch (Exception ignored) {}
        toneGen = null;
    }

    public void playTone(int event) {
        if (!Settings.soundPlays(settings.soundOn(), true)) return;
        android.media.ToneGenerator tg = ensureToneGen();
        if (tg == null) return;
        try {
            switch (event) {
                case Settings.SND_WICKET: tg.startTone(android.media.ToneGenerator.TONE_SUP_ERROR, 220); break;
                case Settings.SND_SIX: tg.startTone(android.media.ToneGenerator.TONE_PROP_PROMPT, 200); break;
                case Settings.SND_FOUR: tg.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 130); break;
                case Settings.SND_TICK: tg.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 45); break;
                default: break;
            }
        } catch (Exception ignored) {}
    }

    /** The sound for the ball just played, read off the match's
     *  lastBalls chips. livePath restates the idea-94 gate so no future
     *  caller can wire a sim path in by accident. */
    public void playBallSound(boolean livePath) {
        if (!Settings.soundPlays(settings.soundOn(), livePath)) return;
        if (g == null || g.match == null) return;
        org.json.JSONArray lb = g.match.optJSONArray("lastBalls");
        if (lb == null || lb.length() == 0) return;
        playTone(Settings.soundEventFor(lb.optString(lb.length() - 1)));
    }

    /** Full-time: a two-tone jingle on a win, one low buzz otherwise. */
    public void playEndJingle(final boolean won) {
        if (!Settings.soundPlays(settings.soundOn(), true)) return;
        if (won) {
            playTone(Settings.SND_FOUR);
            autoHandler.postDelayed(() -> playTone(Settings.SND_SIX), 170);
        } else {
            playTone(Settings.SND_WICKET);
        }
    }

    public void startMatch(JSONObject fixture) {
        MatchEngine.startMatch(g, fixture);
        matchMode = true;
        save();
        render();
    }

    // ---------------- Batch H (idea 77): the match report card + sharing ----

    /** View the drawn report card in-app. */
    public void showReportCard() {
        if (g.lastReport == null) { toast("No match report yet — finish a match first"); return; }
        try {
            android.graphics.Bitmap bmp = ReportCard.render(g, g.lastReport);
            android.widget.ImageView iv = new android.widget.ImageView(this);
            iv.setImageBitmap(bmp);
            iv.setAdjustViewBounds(true);
            iv.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Match Report Card")
                    .setView(iv)
                    .setPositiveButton("Share Image", (d, w) -> shareReportImage())
                    .setNeutralButton("Share Text", (d, w) -> shareReportText())
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) {
            toast("Could not draw the report card");
        }
    }

    /** Share the report as a PNG through the share sheet. The image rides
     *  a content:// URI from our own tiny cache provider (ShareProvider —
     *  a provider entry is NOT a permission; the app stays at zero
     *  permissions). Any failure falls back to the text share. */
    public void shareReportImage() {
        if (g.lastReport == null) { toast("No match report yet — finish a match first"); return; }
        try {
            android.graphics.Bitmap bmp = ReportCard.render(g, g.lastReport);
            java.io.File dir = new java.io.File(getCacheDir(), "reports");
            if (!dir.exists()) dir.mkdirs();
            java.io.File out = new java.io.File(dir, "report-s" + g.lastReport.optInt("season")
                    + "-d" + g.lastReport.optInt("fixtureDay") + ".png");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
            bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            android.net.Uri uri = android.net.Uri.parse("content://" + ShareProvider.AUTHORITY + "/" + out.getName());
            android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
            it.setType("image/png");
            it.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            it.putExtra(android.content.Intent.EXTRA_TEXT, g.reportText(g.lastReport));
            it.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(it, "Share match report"));
        } catch (Exception e) {
            shareReportText(); // the guaranteed path
        }
    }

    /** Share the report as formatted text — always works, no files. */
    public void shareReportText() {
        if (g.lastReport == null) { toast("No match report yet — finish a match first"); return; }
        android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_SEND);
        it.setType("text/plain");
        it.putExtra(android.content.Intent.EXTRA_SUBJECT, "Match Report — " + g.userTeam);
        it.putExtra(android.content.Intent.EXTRA_TEXT, g.reportText(g.lastReport));
        startActivity(android.content.Intent.createChooser(it, "Share match report"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopAuto();
        if (g != null) save();
    }
}
