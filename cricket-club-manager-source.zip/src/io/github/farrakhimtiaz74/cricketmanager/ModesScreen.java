package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import org.json.JSONObject;

/** Batch I (ideas 81–90): Modes & Challenges — the sub-screen behind the
 *  Hub's Manager Actions card. Daily challenge (82), scenarios (83),
 *  weekly quests (84), achievements (85), the prediction record (86)
 *  and Quick Season (88) live here; career slots (87) live in Profile,
 *  difficulty (81) is set on the picker / in Profile, and hardcore (90)
 *  shows its badge wherever it matters. All state lives in Game; this
 *  screen is a renderer + launcher, like CalendarScreen. */
public class ModesScreen {

    public static View build(final MainActivity act) {
        final Game g = act.g;
        LinearLayout root = Ui.col(act);

        LinearLayout head = Ui.card(act);
        head.addView(Ui.gold(act, "MODES & CHALLENGES", 13));
        head.addView(Ui.h2(act, "🎮 Play it your way"));
        head.addView(Ui.small(act, "Difficulty: " + Game.DIFF_NAMES[g.difficulty]
                + (g.hardcore ? " · ☠ HARDCORE" : "")
                + " — difficulty is picked at a new career and can be changed in Profile during the off-season. "
                + "Friendlies (challenge + scenarios) never touch your season: no table, stats, morale or stamina effects."));
        Button close = Ui.darkBtn(act, "✖ Close Modes");
        close.setOnClickListener(v -> { act.modesMode = false; act.render(); });
        head.addView(close);
        root.addView(head);

        root.addView(challengeCard(act));
        root.addView(scenarioCard(act));
        root.addView(questCard(act));
        root.addView(predictionCard(act));
        root.addView(achievementCard(act));
        root.addView(quickSeasonCard(act));
        return root;
    }

    // ---- 82: daily challenge ----

    private static View challengeCard(final MainActivity act) {
        final Game g = act.g;
        final String today = Game.todayStr();
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "🎯 Daily Challenge"));
        String opp = g.challengeOpponentFor(today);
        boolean attempted = today.equals(g.lastChallengeDate);
        boolean friendlyLive = g.match != null && g.match.optInt("friendly") == 1;
        card.addView(Ui.body(act, "Today: " + g.userTeam + " vs " + opp + " (their strength +2)"));
        card.addView(Ui.small(act, "One exhibition per real day. Win it for +" + g.modeReward(75)
                + " CF" + (g.hardcore ? " (hardcore: halved)" : "") + " — lose and it's just pride. "
                + "Your current XI plays; the team-sheet rules apply."));
        card.addView(Ui.small(act, "Challenge record — streak: " + g.challengeStreak
                + " · total wins: " + g.challengeWins));
        if (friendlyLive) {
            card.addView(Ui.text(act, "⏳ Today's challenge is in progress — finish it from the Hub.", 13, Ui.GOLD, true));
        } else if (attempted) {
            card.addView(Ui.text(act, "W".equals(g.challengeResult)
                    ? "✓ Won today — reward banked. A new challenge arrives tomorrow."
                    : g.challengeResult.isEmpty()
                        ? "Today's attempt was launched — check the Hub for the live match."
                        : "✗ Lost today. A new challenge arrives tomorrow.", 13,
                    "W".equals(g.challengeResult) ? Ui.GREEN : Ui.MUTED, true));
        } else {
            Button play = Ui.goldBtn(act, "Play Today's Challenge");
            play.setOnClickListener(v -> {
                java.util.List<String> problems = g.xiProblems();
                if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                g.startChallengeAttempt(today);
                act.modesMode = false;
                act.startMatch(g.challengeFixture(today));
            });
            card.addView(play);
        }
        return card;
    }

    // ---- 83: scenarios ----

    private static View scenarioCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "🎬 Scenarios"));
        card.addView(Ui.small(act, "Scripted moments, played live with full tactics. First win of each pays +"
                + g.modeReward(50) + " CF" + (g.hardcore ? " (hardcore: halved)" : "")
                + "; replays are free, for pride and practice."));
        boolean busy = g.match != null;
        for (int id = 0; id < Game.SCENARIO_TITLES.length; id++) {
            final int sid = id;
            JSONObject st = g.scenarioState(id);
            boolean done = st != null && st.optBoolean("done");
            card.addView(Ui.text(act, (done ? "✓ " : "· ") + Game.SCENARIO_TITLES[id], 14,
                    done ? Ui.GREEN : Ui.INK, true));
            card.addView(Ui.small(act, Game.SCENARIO_DESCS[id]));
            if (done) card.addView(Ui.small(act, "Best clear: " + st.optString("summary")));
            Button play = Ui.darkBtn(act, done ? "Replay — " + Game.SCENARIO_TITLES[id] : "Play — " + Game.SCENARIO_TITLES[id]);
            play.setEnabled(!busy);
            play.setOnClickListener(v -> {
                java.util.List<String> problems = g.xiProblems();
                if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
                act.modesMode = false;
                act.startMatch(g.scenarioFixture(sid));
                MatchEngine.injectScenario(act.g, sid);
                act.save();
                act.render();
            });
            card.addView(play);
        }
        if (busy) card.addView(Ui.small(act, "Finish the match in progress before launching a scenario."));
        return card;
    }

    // ---- 84: weekly quests ----

    private static View questCard(final MainActivity act) {
        final Game g = act.g;
        g.ensureQuests();
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "🎯 Weekly Quests"));
        if (g.quests.length() == 0) {
            card.addView(Ui.small(act, "Quests run in the league weeks (Days 1–21 of a season). None are live right now — "
                    + "the off-season, cup week and the playoffs run quest-free."));
        } else {
            card.addView(Ui.small(act, "Season " + g.season + " · Week " + Math.max(1, g.questWeekKey % 10)
                    + " — each completed quest pays +40 CF the moment it lands. Unfinished quests lapse at week's end."));
            for (int i = 0; i < g.quests.length(); i++) {
                JSONObject q = g.quests.optJSONObject(i);
                if (q == null) continue;
                boolean done = q.optBoolean("done");
                card.addView(Ui.text(act, (done ? "✓ " : "· ") + q.optString("text")
                        + " — " + q.optInt("progress") + "/" + q.optInt("target"), 13,
                        done ? Ui.GREEN : Ui.INK, done));
            }
        }
        return card;
    }

    // ---- 86: prediction record (the picks themselves live on the Hub) ----

    private static View predictionCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "🔮 Prediction Game"));
        card.addView(Ui.small(act, "Before each of your league, cup and playoff matches, the Hub match-day card offers two picks: "
                + "the winner, and the top scorer. Both right pays +60 CF; the winner alone pays +15 CF. Picks lock at the toss."));
        if (g.prediction != null) {
            JSONObject p = g.prediction;
            card.addView(Ui.text(act, "Pending vs " + p.optString("opp") + ": "
                    + (p.optString("winnerPick").isEmpty() ? "no picks made yet"
                        : "winner — " + p.optString("winnerPick")
                            + (p.optString("scorerPick").isEmpty() ? "" : " · top scorer — " + p.optString("scorerPick"))),
                    13, Ui.GOLD, false));
        }
        card.addView(Ui.text(act, "Record: " + g.predSettled + " settled · winner right " + g.predWins
                + " · both right " + g.predBoth, 13, Ui.INK, true));
        return card;
    }

    // ---- 85: achievements ----

    private static View achievementCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        int n = 0;
        for (String[] a : Game.ACH) if (g.achUnlocked(a[0])) n++;
        card.addView(Ui.h2(act, "🏅 Achievements — " + n + "/" + Game.ACH.length));
        card.addView(Ui.small(act, "Per career; they survive seasons. Each unlock posts to the news and pays +10 manager XP."));
        for (String[] a : Game.ACH) {
            JSONObject e = g.achievements.optJSONObject(a[0]);
            boolean un = e != null;
            card.addView(Ui.text(act, (un ? "🏅 " : "🔒 ") + a[1]
                    + (un ? " — Season " + e.optInt("season") : ""), 13, un ? Ui.GOLD : Ui.MUTED, un));
            card.addView(Ui.small(act, a[2]));
        }
        return card;
    }

    // ---- 88: quick season ----

    private static View quickSeasonCard(final MainActivity act) {
        final Game g = act.g;
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, "⏩ Quick Season"));
        boolean blocked = g.offseason > 0 || g.match != null || g.playoffPhase > 0 || g.cupPhase != 0;
        if (blocked) {
            card.addView(Ui.small(act, g.offseason > 0
                    ? "Unavailable in the off-season — finish Transfers first."
                    : g.match != null ? "Finish the match in progress first."
                    : "The group stage is already over — knockouts are never auto-played."));
            return card;
        }
        int remaining = 0;
        for (int i = 0; i < g.fixtures.length(); i++)
            if (!g.fixtures.optJSONObject(i).optBoolean("played")) remaining++;
        final int rem = remaining;
        card.addView(Ui.small(act, "Sims ALL " + rem + " remaining group-stage fixtures at once — yours included, with "
                + "standouts, injuries, morale and stats credited exactly like normal sims. It stops at the end of the "
                + "group stage: the cup, playoffs, ceremony and off-season are always played by hand. (The mid-season "
                + "transfer window days pass simmed.)"));
        Button go = Ui.goldBtn(act, "⏩ Quick-Sim the Group Stage");
        go.setOnClickListener(v -> {
            java.util.List<String> problems = g.xiProblems();
            if (!problems.isEmpty()) { act.showXiBlocked(problems); return; }
            new AlertDialog.Builder(act)
                    .setTitle("Quick Season?")
                    .setMessage("This will sim all " + rem + " remaining group fixtures right now — including every one of "
                            + "your matches — and stop at the " + (g.season >= 2 ? "One-Day Cup" : "playoffs") + ". "
                            + "It cannot be undone.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Sim it", (d, w) -> {
                        String out = act.g.quickSeason();
                        act.save();
                        act.modesMode = false;
                        act.toast(out);
                        act.render();
                    })
                    .show();
        });
        card.addView(go);
        return card;
    }
}
