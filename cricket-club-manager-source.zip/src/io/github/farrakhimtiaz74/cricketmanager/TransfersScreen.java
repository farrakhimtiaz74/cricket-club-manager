package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/** Batch D (ideas 31–40): Transfers & Contracts — a sub-screen reached
 * from HQ (and from the Hub during the off-season / when an offer lands).
 * The 6-tab bottom nav is untouched; MainActivity.transfersMode swaps this
 * in for the tab content.
 *
 * What shows depends on the calendar:
 * - Off-season phase 1 (Game.offseason == 1): retain / release (free),
 * renew out-of-contract men, then "Confirm Squad → Auction".
 * - Off-season phase 2 (offseason == 2): the live auction lot with
 * Bid / Pass / Skip — state lives in Game.auction, so leaving and
 * coming back (or restarting the app) resumes the same lot.
 * - In season: the mid-season window (Days 13–15) with its listings and
 * paid releases, the always-open free-agent pool, loans both ways,
 * and the Contracts & Wages ledger view. Poach offers get a decision
 * card here too (and on the Hub). */
public class TransfersScreen {

 public static View build(final MainActivity act) {
 final Game g = act.g;
 LinearLayout root = Ui.col(act);

 // P2 (suggestions 13/19): the standard sub-screen header — the
 // subtitle carries the live window context from real state
 String sub;
 if (g.offseason == 1) sub = "Season " + g.season + " · Off-season — retain & renew, then the auction";
 else if (g.offseason == 2) sub = "Season " + g.season + " · Off-season — the auction is live";
 else if (g.transferWindowOpen()) sub = "Season " + g.season + " · Window closes Day " + Game.WINDOW_CLOSE_DAY;
 else sub = "Season " + g.season + " · Window opens Day " + Game.WINDOW_OPEN_DAY + " · Free agents any day";
 root.addView(Ui.subHeader(act, "Transfers & Contracts", sub,
 v -> { act.transfersMode = false; act.render(); }));

 // ---------- header / status ----------
 LinearLayout head = Ui.card(act);
 head.addView(Ui.h2(act, g.cf + " CF · Squad " + g.players.length() + "/" + Game.SQUAD_CAP));
 String phase;
 if (g.offseason == 1) phase = "OFF-SEASON — Step 1 of 2: retain, release & renew. Then confirm the squad to open the auction.";
 else if (g.offseason == 2) phase = "OFF-SEASON — Step 2 of 2: the auction. Finish it (or skip) to start Season " + g.season + ".";
 else if (g.transferWindowOpen()) phase = "Mid-season window OPEN (Day " + g.day + " of " + Game.WINDOW_CLOSE_DAY + ") — "
 + g.windowSigns + "/" + Game.WINDOW_MAX_SIGNINGS + " signings used.";
 else if (g.windowSeason != g.season && g.day < Game.WINDOW_OPEN_DAY) phase = "Window closed — the mid-season window opens on Day " + Game.WINDOW_OPEN_DAY + ".";
 else phase = "Window closed for this season — the next business is the off-season auction.";
 head.addView(Ui.small(act, phase));
 head.addView(Ui.small(act, "Wage bill: " + g.weeklyWages() + " CF/week · next due Day " + g.nextWageDay()
 + " · Wages are charged on Days 7, 14 and 21."));
 root.addView(head);

 // ---------- poach offer (idea 40) ----------
 if (g.poachOffer != null) root.addView(poachCard(act));

 // ---------- phase sections ----------
 if (g.offseason == 1) {
 root.addView(Ui.sectionHeader(act, "OFF-SEASON — RETAIN & RENEW"));
 root.addView(phaseOne(act));
 } else if (g.offseason == 2) {
 root.addView(Ui.sectionHeader(act, "OFF-SEASON — THE AUCTION"));
 root.addView(auctionCard(act));
 } else {
 // P2 (suggestion 15): STICKY section chips — parked in the
 // sticky slot outside the ScrollView, filtering which market
 // sections render. render() re-parks them on every rebuild, so
 // the active chip always matches act.transfersFilter.
 LinearLayout chipWrap = new LinearLayout(act);
 chipWrap.setOrientation(LinearLayout.HORIZONTAL);
 final String[] tFilters = {"All", "Window", "Free Agents", "Loans", "Release"};
 for (final String f : tFilters) {
 Button c = Ui.chip(act, f, f.equals(act.transfersFilter));
 c.setOnClickListener(v -> { act.transfersFilter = f; act.render(); });
 chipWrap.addView(c);
 }
 act.setSticky(chipWrap);
 root.addView(Ui.sectionHeader(act, "THE MARKET"));
 if ("All".equals(act.transfersFilter) || "Window".equals(act.transfersFilter)) root.addView(windowCard(act));
 if ("All".equals(act.transfersFilter) || "Free Agents".equals(act.transfersFilter)) root.addView(freeAgentsCard(act));
 if ("All".equals(act.transfersFilter) || "Loans".equals(act.transfersFilter)) root.addView(loansCard(act));
 if ("All".equals(act.transfersFilter) || "Release".equals(act.transfersFilter)) root.addView(releaseCard(act));
 }

 root.addView(Ui.sectionHeader(act, "CONTRACTS & WAGES"));
 root.addView(contractsCard(act));

 // P2 (suggestion 20): the pinned budget bar — money and squad
 // room, always reachable while you shop the market or bid
 LinearLayout bar = new LinearLayout(act);
 bar.setOrientation(LinearLayout.HORIZONTAL);
 bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
 bar.setBackgroundColor(Ui.CARD);
 bar.setPadding(Ui.dp(act, 14), Ui.dp(act, 8), Ui.dp(act, 14), Ui.dp(act, 8));
 TextView bStat = Ui.display(act, "Budget: " + g.cf + " CF · Squad " + g.players.length()
 + "/" + Game.SQUAD_CAP + " · Wages " + g.weeklyWages() + " CF/wk", 13, Ui.GOLD); // v20.1 (item 11): figures in the display face
 bar.addView(bStat);
 act.parkActionBar(bar);
 return root;
 }

 // ================= poach offer =================

 public static LinearLayout poachCard(final MainActivity act) {
 final Game g = act.g;
 final JSONObject o = g.poachOffer;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.text(act, "TRANSFER OFFER", 13, Ui.RED, true));
 card.addView(Ui.h2(act, o.optString("team") + " bid " + o.optInt("fee") + " CF for " + o.optString("name")));
 JSONObject p = g.playerByName(o.optString("name"));
 card.addView(Ui.small(act, (p == null ? "" : "Rating " + Game.rating(p) + " · morale " + p.optInt("morale", 70)
 + " · final year of his contract. ")
 + "Offer lapses after Day " + o.optInt("expDay") + " if ignored — no penalty."));
 LinearLayout row = Ui.row(act);
 Button accept = Ui.goldBtn(act, "Accept +" + o.optInt("fee") + " CF");
 accept.setOnClickListener(v -> { act.toast(act.g.acceptPoach()); act.save(); act.render(); });
 Button reject = Ui.darkBtn(act, "Reject");
 reject.setOnClickListener(v -> { act.toast(act.g.rejectPoach()); act.save(); act.render(); });
 accept.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 reject.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(accept);
 row.addView(reject);
 card.addView(row);
 return card;
 }

 // ================= off-season phase 1: retain / release / renew =================

 private static View phaseOne(final MainActivity act) {
 final Game g = act.g;
 LinearLayout root = Ui.col(act);
 LinearLayout intro = Ui.card(act);
 intro.addView(Ui.h2(act, "Retain & Renew — Season " + g.season));
 intro.addView(Ui.small(act, "Releasing is FREE now, and released men join the auction pool (you can win them back). "
 + "Anyone still OUT OF CONTRACT when you confirm leaves for free into the same pool. The season cannot start until you confirm."));
 root.addView(intro);

 for (int i = 0; i < g.players.length(); i++) {
 final JSONObject p = g.player(i);
 final String name = p.optString("name");
 LinearLayout card = Ui.card(act);
 int contract = p.optInt("contract", 1);
 card.addView(Ui.text(act, name + " · " + p.optString("role") + " · Rating " + Game.rating(p)
 + " · Age " + p.optInt("age", 0), 15, Ui.INK, true));
 if (p.optBoolean("loanIn")) {
 card.addView(Ui.small(act, "Loan player — he returned to his parent club at rollover."));
 root.addView(card);
 continue;
 }
 if (contract <= 0) {
 card.addView(Ui.text(act, "OUT OF CONTRACT — renew now or he leaves for free", 13, Ui.RED, true));
 LinearLayout row = Ui.row(act);
 for (int yrs = 1; yrs <= 3; yrs++) {
 final int y = yrs;
 final int fee = g.renewFeePerYear(p) * y;
 Button b = Ui.darkBtn(act, y + " yr · " + fee + " CF");
 b.setEnabled(g.cf >= fee);
 b.setOnClickListener(v -> { act.toast(act.g.renewPlayer(name, y)); act.save(); act.render(); });
 b.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(b);
 }
 card.addView(row);
 } else {
 card.addView(Ui.small(act, "Contract: " + contract + " season" + (contract > 1 ? "s" : "")
 + " left" + (contract == 1 ? " — FINAL YEAR" : "") + " · Wage " + p.optInt("wage", 0) + " CF/week"
 + " · Morale " + p.optInt("morale", 70) + " · " + g.potDisplay(p)));
 }
 LinearLayout row = Ui.row(act);
 Button rel = Ui.dangerBtn(act, "Release (free)"); // P1
 rel.setOnClickListener(v -> { act.toast(act.g.releasePlayer(name)); act.save(); act.render(); });
 rel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(rel);
 if (p.optInt("age", 99) <= 23 && !p.optBoolean("loanOut")) {
 Button loan = Ui.darkBtn(act, "Loan Out");
 loan.setOnClickListener(v -> { act.toast(act.g.loanOutPlayer(name)); act.save(); act.render(); });
 loan.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(loan);
 }
 if (p.optBoolean("loanOut")) {
 card.addView(Ui.text(act, "ON LOAN for Season " + g.season, 12, Ui.GOLD, true));
 }
 card.addView(row);
 root.addView(card);
 }

 Button confirm = Ui.goldBtn(act, "Confirm Squad → Start the Auction");
 confirm.setOnClickListener(v -> { act.toast(act.g.confirmOffseason()); act.save(); act.render(); });
 root.addView(confirm);
 return root;
 }

 // ================= off-season phase 2: the auction =================

 private static View auctionCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 JSONObject lot = g.auctionLot();
 if (g.auction == null || lot == null) {
 card.addView(Ui.h2(act, "Auction"));
 card.addView(Ui.small(act, "The auction has finished — the season is under way."));
 return card;
 }
 int idx = g.auction.optInt("idx");
 int total = g.auctionPool().length();
 card.addView(Ui.gold(act, "AUCTION — LOT " + (idx + 1) + " OF " + total, 13));
 // P4 (suggestion 36): the lot leads as a market card (suggestion
 // 35's header: avatar, rating, potential bar), then the bidding
 // panel: status block, budget gauge, quick-bid chips, history.
 card.addView(marketBlock(act, lot, ""));
 int curBid = g.auction.optInt("curBid");
 int inc = g.auction.optInt("inc");
 String leader = g.auction.optString("leader");
 String leadTxt = leader.isEmpty() ? "No bids yet — opening at " + (curBid + inc) + " CF"
 : "USER".equals(leader) ? "YOU lead at " + curBid + " CF"
 : leader + " lead at " + curBid + " CF";
 LinearLayout status = Ui.col(act);
 LinearLayout bidRow = Ui.row(act);
 if (!leader.isEmpty() && !"USER".equals(leader)) {
 bidRow.addView(CrestView.forTeam(act, g, leader, 20));
 View bg = new View(act);
 bg.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 7), 1));
 bidRow.addView(bg);
 }
 TextView cb = Ui.display(act, curBid + " CF", 20, Ui.GOLD);
 bidRow.addView(cb);
 TextView cbLab = Ui.micro(act, "  CURRENT BID");
 bidRow.addView(cbLab);
 status.addView(bidRow);
 status.addView(Ui.text(act, leadTxt, 14, "USER".equals(leader) ? Ui.GREEN : Ui.GOLD, true));
 status.addView(Ui.small(act, Present.roomStillIn(g.auction)
 ? "The room is still live — at least one rival can raise over the next bid."
 : "The room has gone quiet — the next bid closes this lot."));
 // budget remaining, gauged against the reconstructed start
 JSONArray log0 = g.auction.optJSONArray("log");
 int base = Present.auctionBase(g.cf, log0);
 int pct = base > 0 ? Math.max(0, Math.min(100, g.cf * 100 / base)) : 100;
 status.addView(new MeterChip(act, "Budget", pct, g.cf + " CF"));
 status.addView(Ui.small(act, "Budget left: " + g.cf + " CF of the ~" + base + " CF you brought to this auction."));
 card.addView(status);
 JSONObject budgets = g.auction.optJSONObject("budgets");
 if (budgets != null) {
 card.addView(Ui.small(act, "Rival budgets left — Karachi " + budgets.optInt("Karachi Kings")
 + " · Islamabad " + budgets.optInt("Islamabad United")
 + " · Multan " + budgets.optInt("Multan Sultans") + " CF"));
 }
 final int nextBid = curBid + inc;
 Button bid = Ui.goldBtn(act, "Bid " + nextBid + " CF");
 bid.setEnabled(g.cf >= nextBid && !"USER".equals(leader) && !g.squadFull());
 if (g.squadFull()) bid.setText("Bid — squad full (" + Game.SQUAD_CAP + ")");
 else if (g.cf < nextBid) bid.setText("Bid " + nextBid + " CF (not enough)");
 bid.setOnClickListener(v -> { String res = act.g.auctionBid(); act.auctionSound(res); act.toast(res); act.save(); act.render(); });
 card.addView(bid);
 // P4: quick-bid chips — consecutive standard bids through the
 // existing auctionBid() until the raise reaches the chip amount,
 // the lot settles, or a bid is refused. No new auction rules.
 LinearLayout qb = Ui.row(act);
 qb.addView(Ui.micro(act, "QUICK BID"));
 for (final int amt : new int[]{10, 25, 50}) {
 Button c = Ui.chip(act, "+" + amt, false);
 c.setEnabled(!"USER".equals(leader) && !g.squadFull() && g.cf > curBid);
 c.setOnClickListener(v -> quickBid(act, amt));
 qb.addView(c);
 }
 card.addView(qb);
 LinearLayout row = Ui.row(act);
 Button pass = Ui.darkBtn(act, "Pass");
 pass.setOnClickListener(v -> { act.toast(act.g.auctionPass()); act.save(); act.render(); });
 pass.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(pass);
 if (!g.scouted.has(lot.optString("name"))) {
 Button scout = Ui.darkBtn(act, "Scout — " + g.scoutCost() + " CF");
 scout.setEnabled(g.cf >= g.scoutCost());
 final JSONObject l = lot;
 scout.setOnClickListener(v -> { act.toast(act.g.scoutPlayer(l.optString("name"), l.optInt("pot", 0))); act.save(); act.render(); });
 scout.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(scout);
 }
 card.addView(row);
 JSONArray log = g.auction.optJSONArray("log");
 if (log != null && log.length() > 0) {
 // P4 (suggestion 36): the auction log records SETTLED lots, not
 // individual bids — the panel shows the last five results as
 // the history, and the live bid state in the status block above
 card.addView(Ui.small(act, "Auction history — settled lots:"));
 for (int i = Math.max(0, log.length() - 5); i < log.length(); i++) card.addView(Ui.small(act, "•  " + log.optString(i)));
 }
 // remaining lots
 JSONArray pool = g.auctionPool();
 if (idx + 1 < pool.length()) {
 StringBuilder rest = new StringBuilder("Still to come: ");
 for (int i = idx + 1; i < pool.length(); i++) {
 if (i > idx + 1) rest.append(" · ");
 rest.append(pool.optJSONObject(i).optString("name"));
 }
 card.addView(Ui.small(act, rest.toString()));
 }
 Button skip = Ui.darkBtn(act, "Skip Auction — start the season");
 skip.setOnClickListener(v -> { act.toast(act.g.skipAuction()); act.save(); act.render(); });
 card.addView(skip);
 card.addView(Ui.small(act, "Closing the app mid-auction is safe — this exact lot and bid resume when you return."));
 return card;
 }

 // ================= in-season: window, free agents, loans, releases =================

 private static View windowCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Mid-Season Window"));
 if (!g.transferWindowOpen()) {
 card.addView(Ui.small(act, g.windowSeason == g.season
 ? "The window has shut for this season."
 : "Opens on Day " + Game.WINDOW_OPEN_DAY + " (season midpoint) for 3 days — up to "
 + Game.WINDOW_MAX_SIGNINGS + " signings at fixed prices."));
 return card;
 }
 card.addView(Ui.small(act, "Fixed asking prices, no bidding war. Signings used: "
 + g.windowSigns + "/" + Game.WINDOW_MAX_SIGNINGS + ". Window shuts after Day " + Game.WINDOW_CLOSE_DAY + "."));
 for (int i = 0; i < g.windowList.length(); i++) {
 final int idx = i;
 final JSONObject p = g.windowList.optJSONObject(i);
 if (p == null) continue;
 // P4 (suggestion 35): listings are market cards now
 card.addView(marketBlock(act, p, p.optInt("price") + " CF"));
 card.addView(Ui.small(act, "From " + p.optString("team") + " · Asking " + p.optInt("price") + " CF"));
 LinearLayout row = Ui.row(act);
 Button buy = Ui.darkBtn(act, "Buy — " + p.optInt("price") + " CF"); // P1: one of several listings in one card
 buy.setEnabled(g.cf >= p.optInt("price") && !g.squadFull() && g.windowSigns < Game.WINDOW_MAX_SIGNINGS);
 buy.setOnClickListener(v -> { act.toast(act.g.buyWindowPlayer(idx)); act.save(); act.render(); });
 buy.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(buy);
 row.addView(scoutBtn(act, p));
 card.addView(row);
 }
 if (g.windowList.length() == 0) card.addView(Ui.small(act, "All listings sold."));
 return card;
 }

 private static View freeAgentsCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Free Agents"));
 card.addView(Ui.small(act, "Unsigned and signable any day of the year. The pool drifts — one name rotates out every few days."));
 for (int i = 0; i < g.faPool.length(); i++) {
 final int idx = i;
 final JSONObject p = g.faPool.optJSONObject(i);
 if (p == null) continue;
 final int fee = g.faFee(p);
 // P4 (suggestion 35): listings are market cards now — the
 // signing fee is the card's right-aligned display figure
 card.addView(marketBlock(act, p, fee + " CF"));
 LinearLayout row = Ui.row(act);
 Button sign = Ui.darkBtn(act, "Sign — " + fee + " CF"); // P1
 sign.setEnabled(g.cf >= fee && !g.squadFull());
 sign.setOnClickListener(v -> { act.toast(act.g.signFreeAgent(idx)); act.save(); act.render(); });
 sign.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(sign);
 row.addView(scoutBtn(act, p));
 card.addView(row);
 }
 if (g.faPool.length() == 0) card.addView(Ui.small(act, "Nobody is unsigned right now — check back in a few days."));
 return card;
 }

 private static View loansCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Loans"));
 // currently out
 boolean anyOut = false;
 for (int i = 0; i < g.players.length(); i++) {
 JSONObject p = g.player(i);
 if (p.optBoolean("loanOut")) {
 anyOut = true;
 card.addView(Ui.text(act, "•  " + p.optString("name") + " — out on loan, returns at rollover (sharper, morale up)", 13, Ui.GOLD, false));
 }
 if (p.optBoolean("loanIn")) {
 card.addView(Ui.text(act, "•  " + p.optString("name") + " — here on loan, returns to his club at rollover", 13, Ui.GOLD, false));
 }
 }
 if (!anyOut && !g.hasActiveLoanIn()) card.addView(Ui.small(act, "No active loans."));
 // loan out
 card.addView(Ui.small(act, "Loan OUT a youngster (23 or under) for the rest of the season — first-team cricket elsewhere, back improved:"));
 boolean anyElig = false;
 for (int i = 0; i < g.players.length(); i++) {
 final JSONObject p = g.player(i);
 if (p.optBoolean("loanOut") || p.optBoolean("loanIn") || p.optInt("age", 99) > 23) continue;
 anyElig = true;
 LinearLayout row = Ui.row(act);
 TextView n = Ui.text(act, p.optString("name") + " · Age " + p.optInt("age", 0) + " · Rating " + Game.rating(p), 13, Ui.INK, false);
 n.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(n);
 Button b = Ui.darkBtn(act, "Loan Out");
 final String nm = p.optString("name");
 b.setOnClickListener(v -> { act.toast(act.g.loanOutPlayer(nm)); act.save(); act.render(); });
 row.addView(b);
 card.addView(row);
 }
 if (!anyElig) card.addView(Ui.small(act, "No eligible youngsters (23 or under) available right now."));
 // loan in
 card.addView(Ui.small(act, "Loan IN one youngster for " + Game.LOAN_IN_FEE + " CF (no wages) — window or off-season only:"));
 if (g.hasActiveLoanIn()) {
 card.addView(Ui.small(act, "Your loan slot is taken for this season."));
 } else if (g.loanList.length() == 0) {
 card.addView(Ui.small(act, "No loan candidates available."));
 } else {
 for (int i = 0; i < g.loanList.length(); i++) {
 final int idx = i;
 final JSONObject p = g.loanList.optJSONObject(i);
 if (p == null) continue;
 LinearLayout row = Ui.row(act);
 TextView n = Ui.text(act, p.optString("name") + " · " + p.optString("role") + " · Age " + p.optInt("age", 0)
 + " · Rating " + Game.rating(p), 13, Ui.INK, false);
 n.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(n);
 Button b = Ui.darkBtn(act, "Loan In");
 b.setEnabled((g.transferWindowOpen() || g.offseason > 0) && g.cf >= Game.LOAN_IN_FEE && !g.squadFull());
 b.setOnClickListener(v -> { act.toast(act.g.loanInPlayer(idx)); act.save(); act.render(); });
 row.addView(b);
 card.addView(row);
 }
 }
 return card;
 }

 private static View releaseCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Release a Player"));
 if (!g.transferWindowOpen()) {
 card.addView(Ui.small(act, "In-season releases open during the transfer window (Days "
 + Game.WINDOW_OPEN_DAY + "–" + Game.WINDOW_CLOSE_DAY + ", " + Game.RELEASE_FEE_WINDOW
 + " CF settlement). Off-season releases are free."));
 return card;
 }
 card.addView(Ui.small(act, "Window is open — releasing costs a " + Game.RELEASE_FEE_WINDOW + " CF settlement."));
 for (int i = 0; i < g.players.length(); i++) {
 final JSONObject p = g.player(i);
 if (p.optBoolean("loanIn") || p.optBoolean("loanOut")) continue;
 LinearLayout row = Ui.row(act);
 TextView n = Ui.text(act, p.optString("name") + " · Rating " + Game.rating(p), 13, Ui.INK, false);
 n.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 row.addView(n);
 Button b = Ui.dangerBtn(act, "Release"); // P1
 final String nm = p.optString("name");
 b.setOnClickListener(v -> { act.toast(act.g.releasePlayer(nm)); act.save(); act.render(); });
 row.addView(b);
 card.addView(row);
 }
 return card;
 }

 // ================= contracts & wages =================

 private static View contractsCard(final MainActivity act) {
 final Game g = act.g;
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, "Contracts & Wages"));
 card.addView(Ui.small(act, "Total wage bill: " + g.weeklyWages() + " CF/week · due Days 7, 14, 21"
 + (g.wageShortStreak > 0 ? " · one short-paid week on record" : "")));
 for (int i = 0; i < g.players.length(); i++) {
 JSONObject p = g.player(i);
 StringBuilder s = new StringBuilder(p.optString("name"));
 s.append(" · ");
 if (p.optBoolean("loanIn")) s.append("on loan (no wage)");
 else if (p.optBoolean("loanOut")) s.append("loaned out (host club pays)");
 else {
 int c = p.optInt("contract", 1);
 s.append(c <= 0 ? "OUT OF CONTRACT" : c == 1 ? "final year" : c + " seasons left");
 s.append(" · ").append(p.optInt("wage", 0)).append("CF/wk");
 }
 int c = p.optInt("contract", 1);
 TextView t = Ui.text(act, s.toString(), 13,
 !p.optBoolean("loanIn") && !p.optBoolean("loanOut") && c <= 1 ? Ui.RED : Ui.MUTED, false);
 t.setPadding(0, Ui.dp(act, 2), 0, Ui.dp(act, 2));
 card.addView(t);
 }
 return card;
 }

 // ================= shared bits =================

 /** P4 (suggestion 35): THE market card — avatar + name/role/age,
 *  the rating as a display figure, a potential bar (Present.potBar:
 *  solid = current rating, pale = potential, a band while the POT
 *  is only a scouted range), the scout verdict when filed, and the
 *  fee/asking figure right-aligned in display type with the wage
 *  beside it. Free agents, window listings and auction lots all
 *  render through this one block. */
 private static View marketBlock(final MainActivity act, JSONObject p, String figure) {
 final Game g = act.g;
 LinearLayout col = Ui.col(act);
 col.setPadding(0, Ui.dp(act, 6), 0, Ui.dp(act, 2));
 LinearLayout top = Ui.row(act);
 AvatarView av = AvatarView.forPlayer(act, p.optString("name"), p.optString("role"), p.optString("team"), 40); // v21 item 14
 LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(Ui.dp(act, 40), Ui.dp(act, 40));
 avLp.setMargins(0, 0, Ui.dp(act, 10), 0);
 av.setLayoutParams(avLp);
 top.addView(av);
 LinearLayout nc = Ui.col(act);
 nc.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 nc.addView(Ui.text(act, p.optString("name") + (p.optBoolean("overseas") ? " · OVERSEAS" : " · Local"), 15, Ui.INK, true));
 nc.addView(Ui.small(act, p.optString("role") + " · Age " + p.optInt("age", 0)
 + " · Bat " + p.optInt("bat") + " · Bowl " + p.optInt("bowl")));
 top.addView(nc);
 TextView rat = Ui.display(act, String.valueOf(Game.rating(p)), 20, Ui.GOLD);
 rat.setGravity(android.view.Gravity.END);
 top.addView(rat);
 col.addView(top);
 int[] pb = Present.potBar(g, p);
 PotBarView bar = new PotBarView(act, pb[0], pb[1], pb[2]);
 LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(
 ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 10));
 bLp.setMargins(0, Ui.dp(act, 6), 0, Ui.dp(act, 2));
 bar.setLayoutParams(bLp);
 col.addView(bar);
 String potLine = "Rating " + pb[0] + " → " + g.potDisplay(p);
 JSONObject rep = g.scoutReport(p.optString("name"));
 if (rep != null) potLine += " · Scout: Grade " + rep.optString("grade") + " — " + rep.optString("verdict");
 LinearLayout potRow = Ui.row(act);
 TextView potTxt = Ui.small(act, potLine);
 potTxt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 potRow.addView(potTxt);
 potRow.addView(Ui.infoChip(act, "POT")); // P5 (suggestion 44)
 col.addView(potRow);
 if (figure != null && !figure.isEmpty()) {
 LinearLayout fr = Ui.row(act);
 TextView w = Ui.small(act, p.optInt("wage", 0) > 0 ? "Wage " + p.optInt("wage", 0) + " CF/wk" : "");
 w.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 fr.addView(w);
 TextView fv = Ui.display(act, figure, 15, Ui.GOLD);
 fv.setGravity(android.view.Gravity.END);
 fr.addView(fv);
 col.addView(fr);
 }
 View div = new View(act);
 div.setBackgroundColor(Ui.CARD2);
 div.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 1)));
 col.addView(div);
 return col;
 }

 /** P4 (suggestion 36): a quick bid is just the standard bid,
 *  tapped repeatedly — consecutive auctionBid() calls until the
 *  current bid has risen by the chip amount, the lot settles, or
 *  a bid is refused (no state change). The auction's own rules —
 *  one AI response per bid, hammer when the room goes quiet — are
 *  untouched. */
 private static void quickBid(final MainActivity act, int amount) {
 Game g = act.g;
 if (g.auction == null) return;
 int startCur = g.auction.optInt("curBid");
 int idx0 = g.auction.optInt("idx");
 String msg = "";
 for (int n = 0; n < 24; n++) {
 int beforeCur = g.auction.optInt("curBid");
 msg = g.auctionBid();
 if (g.auction == null || g.auction.optInt("idx") != idx0) break;
 int cur = g.auction.optInt("curBid");
 if (cur == beforeCur) break;
 if (cur - startCur >= amount) break;
 }
 act.auctionSound(msg); // Audio Pack: tick per raise (engine-throttled), gavel on a win
 act.toast(msg);
 act.save();
 act.render();
 }

 private static Button scoutBtn(final MainActivity act, final JSONObject p) {
 Button b;
 if (act.g.scouted.has(p.optString("name"))) {
 b = Ui.darkBtn(act, "Scouted");
 b.setEnabled(false);
 } else {
 b = Ui.darkBtn(act, "Scout " + act.g.scoutCost() + " CF");
 b.setEnabled(act.g.cf >= act.g.scoutCost());
 b.setOnClickListener(v -> { act.toast(act.g.scoutPlayer(p.optString("name"), p.optInt("pot", 0))); act.save(); act.render(); });
 }
 b.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
 return b;
 }
}
