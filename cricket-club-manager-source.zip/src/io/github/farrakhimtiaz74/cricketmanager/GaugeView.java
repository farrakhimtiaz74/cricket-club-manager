package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Design Batch (v13, item 8): a drawn 0–100 gauge — rounded track,
 *  gradient fill in the value's colour (Design.gaugeColor) and a pale
 *  marker line at the value. Replaces the ASCII ▓░ block meters the
 *  HQ screenshot showed for Board Confidence and Fan Mood.
 *
 *  v20.1 (items 2/12b): the track is SLIM (10dp — the v20 Hub meters
 *  read as giant orange capsules) and the fill width comes from
 *  Design.gaugeFillWidth, which clamps the value AND the result to
 *  the track, so no screen can blob or bleed again. The number and
 *  the word are the callers' job (Ui.meterRow prints them beside /
 *  above the bar, never under the fill). */
public class GaugeView extends View {
    int value; // v21: mutable so Anim.fill can animate the fill
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GaugeView(Context c, int value) {
        super(c);
        this.value = Design.clamp100(value);
    }

    /** v21 item 7: set the fill value (Anim.fill drives this). */
    public void setValue(int v) {
        value = Design.clamp100(v);
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(getContext(), 10));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float r = h / 2f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF0B1220);
        cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
        if (value > 0) {
            int col = Design.gaugeColor(value);
            float fw = Design.gaugeFillWidth((int) w, value);
            if (fw < h) fw = Math.min(h, w); // a sliver still reads as a capsule cap
            p.setShader(new LinearGradient(0, 0, fw, 0,
                    col, lighten(col), Shader.TileMode.CLAMP));
            cv.drawRoundRect(new RectF(0, 0, fw, h), r, r, p);
            p.setShader(null);
            // value marker at the fill's leading edge (never past the track)
            p.setColor(0xFFF8FAFC);
            float mx = Math.min(w - 2, fw);
            cv.drawRect(mx - 1, 1.5f, mx + 1, h - 1.5f, p);
        }
    }

    private static int lighten(int argb) {
        int a = (argb >>> 24) & 0xFF, r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        r += (255 - r) * 0.35f; g += (255 - g) * 0.35f; b += (255 - b) * 0.35f;
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
