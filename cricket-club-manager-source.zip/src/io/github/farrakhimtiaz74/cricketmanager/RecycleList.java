package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** v21 item 9: smooth lists via VIEW RECYCLING. The app is built on
 *  one outer ScrollView per screen, so a nested ListView would fight
 *  the host scroll; instead this helper keeps a fixed POOL of row
 *  views and rebinds them across a sliding window of the data:
 *
 *   - the first `window` rows are built once into pooled views;
 *   - "Show more" advances the window — the SAME pooled views are
 *     detached, re-bound to the next slice and re-attached, so a
 *     100-row ranking costs ~24 row builds, not 100;
 *   - screens rebuild on state change as before (render() owns the
 *     lifecycle), but each render only ever constructs the window.
 *
 *  Binder contract: create() builds a fresh row view; bind() fills
 *  an existing row view with item `index` (it must reset EVERY
 *  field it sets — pooled views carry the previous row's state). */
public class RecycleList {

    public interface Binder<T> {
        View create(Context c);
        void bind(View row, T item, int index);
    }

    public static <T> LinearLayout build(final Context c, final List<T> items,
                                         final int window, final Binder<T> binder,
                                         String moreLabel) {
        final LinearLayout host = Ui.col(c);
        final List<View> pool = new ArrayList<>();
        final int[] shown = {Math.min(window, items.size())};
        for (int i = 0; i < shown[0]; i++) {
            View row = binder.create(c);
            binder.bind(row, items.get(i), i);
            pool.add(row);
            host.addView(row);
        }
        if (items.size() > window) {
            final TextView more = Ui.darkBtn(c, moreLabel != null ? moreLabel
                    : "Show more (" + (items.size() - shown[0]) + " more)");
            more.setOnClickListener(v -> {
                int from = shown[0];
                int to = Math.min(items.size(), from + window);
                // recycle: detach the whole pool, rebind it to the
                // next window, re-attach. The slice that does not
                // fit the pool gets fresh views (growth only).
                for (View row : pool) host.removeView(row);
                for (int i = from; i < to; i++) {
                    int slot = i - from;
                    View row;
                    if (slot < pool.size()) {
                        row = pool.get(slot);
                    } else {
                        row = binder.create(c);
                        pool.add(row);
                    }
                    binder.bind(row, items.get(i), i);
                    host.addView(row, host.getChildCount() - 1); // keep the footer last
                }
                shown[0] = to;
                if (to >= items.size()) {
                    host.removeView(more);
                } else {
                    more.setText("Show more (" + (items.size() - to) + " more)");
                }
            });
            host.addView(more);
        }
        return host;
    }

    /** Convenience for the common host layout params. */
    public static void attach(LinearLayout parent, View list) {
        parent.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }
}
