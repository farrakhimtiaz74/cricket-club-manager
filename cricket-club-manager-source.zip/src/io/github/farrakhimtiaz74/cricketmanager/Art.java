package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Rich Media Edition (v20): the bundled-media helper. Every hero
 *  image, texture, crest and font ships as a REAL file under assets/
 *  (produced by tools/make_assets.py) and is loaded through here:
 *   - bitmaps decode via the AssetManager, downsampled to a target
 *     width bucket so a low-end phone never holds a full-size hero in
 *     memory, and cached per (asset, bucket);
 *   - EVERY failure returns null — each call site falls back to the
 *     v19 flat/drawn look, so a missing or corrupt asset can never
 *     crash or blank the app;
 *   - typefaces are created once from assets/fonts/ and cached.
 *  Asset names are part of the build contract: the desktop tests
 *  cross-check this table against the APK's assets listing. */
public class Art {

    // ---- the asset manifest (paths inside assets/) ----
    public static final String STADIUM = "art/art_stadium.webp";
    public static final String CAMPUS = "art/art_campus.webp";
    public static final String TROPHY = "art/art_trophy.webp";
    public static final String PITCH = "art/art_pitch.webp";
    public static final String TEX_GRASS = "art/tex_grass.webp";
    public static final String TEX_CARBON = "art/tex_carbon.webp";
    public static final String TEX_GOLD = "art/tex_gold.webp";
    public static final String FONT_DISPLAY = "fonts/font_display.ttf";
    public static final String FONT_DISPLAY_SB = "fonts/font_display_sb.ttf";
    public static final String FONT_BODY = "fonts/font_body.ttf";
    public static final String FONT_BODY_MED = "fonts/font_body_med.ttf";

    /** Club crest artwork key (original art, club colours + initials —
     *  see tools/make_assets.py). Null for a custom club or any club
     *  without art: the drawn CrestView is the standing fallback. */
    public static String crestAsset(String team) {
        if (team == null) return null;
        switch (team) {
            case "Lahore Qalandars": return "art/crest_lahore.webp";
            case "Karachi Kings": return "art/crest_karachi.webp";
            case "Islamabad United": return "art/crest_islamabad.webp";
            case "Multan Sultans": return "art/crest_multan.webp";
            case "Peshawar Zalmi": return "art/crest_peshawar.webp";
            case "Quetta Gladiators": return "art/crest_quetta.webp";
            case "Sialkot Stallions": return "art/crest_sialkot.webp";
            case "Hyderabad Hawks": return "art/crest_hyderabad.webp";
            default: return null;
        }
    }

    private static final Map<String, Bitmap> CACHE = new HashMap<>();
    private static Typeface display, displaySb, body, bodyMed;
    private static boolean fontsTried = false;

    /** Decode an asset bitmap downsampled so its width lands in the
     *  target bucket (the largest power-of-two sample that keeps it
     *  at or above targetW). Null on any failure. */
    public static Bitmap bitmap(Context c, String asset, int targetW) {
        if (c == null || asset == null) return null;
        String key = asset + "@" + targetW;
        Bitmap hit = CACHE.get(key);
        if (hit != null) return hit;
        Bitmap out = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = c.getAssets().open(asset);
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();
            int sample = 1;
            if (targetW > 0 && bounds.outWidth > 0) {
                while (bounds.outWidth / (sample * 2) >= targetW) sample *= 2;
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            InputStream in2 = c.getAssets().open(asset);
            out = BitmapFactory.decodeStream(in2, null, o);
            in2.close();
        } catch (Exception ignored) {
            out = null;
        }
        if (out != null) CACHE.put(key, out);
        return out;
    }

    /** The crest bitmap for a club in a fixture — resolves the user's
     *  custom club to null (drawn fallback), like Design does. */
    public static Bitmap crestBitmap(Context c, Game g, String team, int targetW) {
        if (g != null && g.customTeam && team != null && team.equals(g.userTeam)) return null;
        String asset = crestAsset(team);
        return asset == null ? null : bitmap(c, asset, targetW);
    }

    /** A bitmap as a drawable at the given alpha (0–255). */
    public static Drawable drawable(Context c, String asset, int targetW, int alpha) {
        Bitmap b = bitmap(c, asset, targetW);
        if (b == null) return null;
        BitmapDrawable d = new BitmapDrawable(c.getResources(), b);
        d.setAlpha(alpha);
        return d;
    }

    /** The MainActivity header treatment: pitch art under the Stadium
     *  Night gradient (the gradient stays dominant, the art ghosts
     *  through). Falls back to the bare gradient when art is missing. */
    public static Drawable headerBg(Context c, int accent) {
        Drawable grad = Ui.headerBand(c, accent);
        Bitmap b = bitmap(c, PITCH, 720);
        if (b == null) return grad;
        BitmapDrawable art = new BitmapDrawable(c.getResources(), b);
        art.setAlpha(70);
        art.setGravity(android.view.Gravity.FILL);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{art, grad});
        return ld;
    }

    // ---------------- fonts ----------------

    private static void loadFonts(Context c) {
        if (fontsTried) return;
        fontsTried = true;
        try { display = Typeface.createFromAsset(c.getAssets(), FONT_DISPLAY); } catch (Exception ignored) {}
        try { displaySb = Typeface.createFromAsset(c.getAssets(), FONT_DISPLAY_SB); } catch (Exception ignored) {}
        try { body = Typeface.createFromAsset(c.getAssets(), FONT_BODY); } catch (Exception ignored) {}
        try { bodyMed = Typeface.createFromAsset(c.getAssets(), FONT_BODY_MED); } catch (Exception ignored) {}
    }

    /** Rajdhani Bold — headings' big sibling: score figures, CF, the
     *  menu title. Null when the asset failed (callers fall back). */
    public static Typeface displayFont(Context c) { loadFonts(c); return display; }

    /** Rajdhani SemiBold — h1/h2 headings and button labels. */
    public static Typeface displaySbFont(Context c) { loadFonts(c); return displaySb; }

    /** Barlow Regular — body text. */
    public static Typeface bodyFont(Context c) { loadFonts(c); return body; }

    /** Barlow Medium — bold body text. */
    public static Typeface bodyMedFont(Context c) { loadFonts(c); return bodyMed; }
}
