package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Rich Media Edition (v20): the bundled-media helper. Every hero
 *  image, texture, crest and font ships as a REAL file under assets/
 *  (produced by tools/make_assets.py) and is loaded through here:
 *   - bitmaps decode via the AssetManager, downsampled to a target
 *     width bucket so a low-end phone never holds a full-size hero in
 *     memory, and cached per (asset, bucket);
 *   - EVERY failure returns null — each call site falls back to the
 *     v19 flat/drawn look, so a missing or corrupt asset can never
 *     crash or blank the app;
 *   - typefaces are created once from assets/fonts/ and cached.
 *  Asset names are part of the build contract: the desktop tests
 *  cross-check this table against the APK's assets listing. */
public class Art {

    // ---- the asset manifest (paths inside assets/) ----
    public static final String STADIUM = "art/art_stadium.webp";
    public static final String CAMPUS = "art/art_campus.webp";
    public static final String TROPHY = "art/art_trophy.webp";
    public static final String PITCH = "art/art_pitch.webp";
    public static final String TEX_GRASS = "art/tex_grass.webp";
    public static final String TEX_CARBON = "art/tex_carbon.webp";
    public static final String TEX_GOLD = "art/tex_gold.webp";
    public static final String FONT_DISPLAY = "fonts/font_display.ttf";
    public static final String FONT_DISPLAY_SB = "fonts/font_display_sb.ttf";
    public static final String FONT_BODY = "fonts/font_body.ttf";
    public static final String FONT_BODY_MED = "fonts/font_body_med.ttf";

    // ---- v21 additions (tools/make_assets21.py) ----
    /** Item 13: the realistic set (raw2 re-encodes). */
    public static final String INTERIOR = "art/art_interior.webp";
    public static final String DRESSING = "art/art_dressing.webp";
    public static final String NETS = "art/art_nets.webp";
    /** Item 15: the two original competition emblems. */
    public static final String EMBLEM_LEAGUE = "art/emblem_league.webp";
    public static final String EMBLEM_CUP = "art/emblem_cup.webp";
    /** Item 4: the animated splash frame count + accessor. */
    public static final int SPLASH_FRAMES = 14;

    public static String splashAsset(int i) {
        return "art/splash_" + (i < 10 ? "0" : "") + i + ".webp";
    }

    /** Item 1: the club's theme-pack banner (club-graded stadium
     *  art). A custom club (no pack of its own) falls back to the
     *  Lahore pack's art — the header gradient still recolours it
     *  with the club's picked colour via the accent path. */
    public static String themeAsset(String team) {
        String slug = Design.teamSlug(team);
        return "art/theme_" + (slug == null ? "lahore" : slug) + ".webp";
    }

    /** Item 1: the club's theme-pack panel art (versus cards etc.). */
    public static String themePanelAsset(String team) {
        String slug = Design.teamSlug(team);
        return slug == null ? null : "art/themepanel_" + slug + ".webp";
    }

    /** Item 16: the accurate flag asset for a nation tag/name. */
    public static String flagAsset(String tagOrName) {
        String code = Design.nationCode(tagOrName);
        return code.isEmpty() ? null
                : "art/flag_" + code.toLowerCase(java.util.Locale.ROOT) + ".webp";
    }

    /** Item 3: the metallic card frame for a player's rating tier. */
    public static String frameAsset(int rating) {
        return "art/frame_" + Design.TIER_NAMES[Design.tierFor(rating)]
                .toLowerCase(java.util.Locale.ROOT) + ".webp";
    }

    /** Item 14: the graded fictional-portrait avatar for a player
     *  (deterministic per name — see Design.avatarAsset). */
    public static Bitmap avatarBitmap(Context c, String name, String team, int targetW) {
        return bitmap(c, Design.avatarAsset(name, team), targetW);
    }

    /** Club crest artwork key (original art, club colours + initials —
     *  see tools/make_assets.py). Null for a custom club or any club
     *  without art: the drawn CrestView is the standing fallback. */
    public static String crestAsset(String team) {
        if (team == null) return null;
        switch (team) {
            case "Lahore Qalandars": return "art/crest_lahore.webp";
            case "Karachi Kings": return "art/crest_karachi.webp";
            case "Islamabad United": return "art/crest_islamabad.webp";
            case "Multan Sultans": return "art/crest_multan.webp";
            case "Peshawar Zalmi": return "art/crest_peshawar.webp";
            case "Quetta Gladiators": return "art/crest_quetta.webp";
            case "Sialkot Stallions": return "art/crest_sialkot.webp";
            case "Hyderabad Hawks": return "art/crest_hyderabad.webp";
            default: return null;
        }
    }

    private static final Map<String, Bitmap> CACHE = new HashMap<>();
    private static Typeface display, displaySb, body, bodyMed;
    private static boolean fontsTried = false;

    /** Decode an asset bitmap downsampled so its width lands in the
     *  target bucket (the largest power-of-two sample that keeps it
     *  at or above targetW). Null on any failure. */
    public static Bitmap bitmap(Context c, String asset, int targetW) {
        if (c == null || asset == null) return null;
        String key = asset + "@" + targetW;
        Bitmap hit = CACHE.get(key);
        if (hit != null) return hit;
        Bitmap out = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = c.getAssets().open(asset);
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();
            int sample = 1;
            if (targetW > 0 && bounds.outWidth > 0) {
                while (bounds.outWidth / (sample * 2) >= targetW) sample *= 2;
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            InputStream in2 = c.getAssets().open(asset);
            out = BitmapFactory.decodeStream(in2, null, o);
            in2.close();
        } catch (Exception ignored) {
            out = null;
        }
        if (out != null) CACHE.put(key, out);
        return out;
    }

    /** Decode an asset bitmap WITH its alpha channel (tier frames,
     *  emblems — anything whose transparency is the point). The
     *  plain bitmap() path prefers RGB_565 for photos; this one
     *  forces ARGB_8888. Same downsample + cache discipline. */
    public static Bitmap bitmapAlpha(Context c, String asset, int targetW) {
        if (c == null || asset == null) return null;
        String key = asset + "@a" + targetW;
        Bitmap hit = CACHE.get(key);
        if (hit != null) return hit;
        Bitmap out = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = c.getAssets().open(asset);
            BitmapFactory.decodeStream(in, null, bounds);
            in.close();
            int sample = 1;
            if (targetW > 0 && bounds.outWidth > 0) {
                while (bounds.outWidth / (sample * 2) >= targetW) sample *= 2;
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            InputStream in2 = c.getAssets().open(asset);
            out = BitmapFactory.decodeStream(in2, null, o);
            in2.close();
        } catch (Exception ignored) {
            out = null;
        }
        if (out != null) CACHE.put(key, out);
        return out;
    }

    /** The crest bitmap for a club in a fixture — resolves the user's
     *  custom club to null (drawn fallback), like Design does. */
    public static Bitmap crestBitmap(Context c, Game g, String team, int targetW) {
        if (g != null && g.customTeam && team != null && team.equals(g.userTeam)) return null;
        String asset = crestAsset(team);
        return asset == null ? null : bitmap(c, asset, targetW);
    }

    /** A bitmap as a drawable at the given alpha (0–255). */
    public static Drawable drawable(Context c, String asset, int targetW, int alpha) {
        Bitmap b = bitmap(c, asset, targetW);
        if (b == null) return null;
        BitmapDrawable d = new BitmapDrawable(c.getResources(), b);
        d.setAlpha(alpha);
        return d;
    }

    /** The MainActivity header treatment: pitch art under the
     *  Stadium Night gradient. Falls back to the bare gradient when
     *  art is missing.
     *
     *  v20.1 (item 5): the v20 version layered the art UNDER a fully
     *  OPAQUE gradient — the art could never show through, and the
     *  band read as a flat muddy wash. Now the gradient over the art
     *  is the translucent variant (Ui.headerBand overArt), so the
     *  pitch genuinely ghosts through the navy; without art the
     *  opaque variant stands alone. Two-accent: the club's primary
     *  sweeps from the left, its secondary warms the right. */
    public static Drawable headerBg(Context c, int accent) {
        return headerBg(c, accent, accent);
    }

    public static Drawable headerBg(Context c, int accent, int accent2) {
        Bitmap b = bitmap(c, PITCH, 720);
        if (b == null) return Ui.headerBand(c, accent, accent2, false);
        BitmapDrawable art = new BitmapDrawable(c.getResources(), b);
        art.setGravity(android.view.Gravity.FILL);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{
                art, Ui.headerBand(c, accent, accent2, true)});
        return ld;
    }

    /** v21 (items 1 + 10): the header over the USER'S CLUB theme-pack
     *  banner, tinted by the theme engine's resolved accents
     *  (Club look = the club's own colours; Midnight/Classic override
     *  from the Settings switch). Falls back to the pitch treatment,
     *  then to the bare gradient. */
    public static Drawable headerBg(Context c, Game g) {
        int accent = Design.themedAccent(g);
        int accent2 = Design.themedAccent2(g);
        Bitmap b = g == null ? null : bitmap(c, themeAsset(g.userTeam), 900);
        if (b == null) return headerBg(c, accent, accent2);
        BitmapDrawable art = new BitmapDrawable(c.getResources(), b);
        art.setGravity(android.view.Gravity.FILL);
        return new LayerDrawable(new Drawable[]{
                art, Ui.headerBand(c, accent, accent2, true)});
    }

    // ---------------- fonts ----------------

    private static void loadFonts(Context c) {
        if (fontsTried) return;
        fontsTried = true;
        try { display = Typeface.createFromAsset(c.getAssets(), FONT_DISPLAY); } catch (Exception ignored) {}
        try { displaySb = Typeface.createFromAsset(c.getAssets(), FONT_DISPLAY_SB); } catch (Exception ignored) {}
        try { body = Typeface.createFromAsset(c.getAssets(), FONT_BODY); } catch (Exception ignored) {}
        try { bodyMed = Typeface.createFromAsset(c.getAssets(), FONT_BODY_MED); } catch (Exception ignored) {}
    }

    /** Rajdhani Bold — headings' big sibling: score figures, CF, the
     *  menu title. Null when the asset failed (callers fall back). */
    public static Typeface displayFont(Context c) { loadFonts(c); return display; }

    /** Rajdhani SemiBold — h1/h2 headings and button labels. */
    public static Typeface displaySbFont(Context c) { loadFonts(c); return displaySb; }

    /** Barlow Regular — body text. */
    public static Typeface bodyFont(Context c) { loadFonts(c); return body; }

    /** Barlow Medium — bold body text. */
    public static Typeface bodyMedFont(Context c) { loadFonts(c); return bodyMed; }
}
