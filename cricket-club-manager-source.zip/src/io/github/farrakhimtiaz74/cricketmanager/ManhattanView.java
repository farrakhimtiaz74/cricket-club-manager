package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import org.json.JSONArray;

/** Batch A (idea 6): Manhattan chart — runs per over drawn natively as
 *  bars (no external libs). Gold bars are the big overs (12+). */
public class ManhattanView extends View {
    private final int[] overs;
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint val = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lab = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ManhattanView(Context c, JSONArray overRuns) {
        super(c);
        overs = new int[overRuns == null ? 0 : overRuns.length()];
        for (int i = 0; i < overs.length; i++) overs[i] = overRuns.optInt(i);
        val.setTextAlign(Paint.Align.CENTER);
        val.setTextSize(Ui.dp(c, 9));
        lab.setTextAlign(Paint.Align.CENTER);
        lab.setTextSize(Ui.dp(c, 9));
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), Ui.dp(getContext(), 118));
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        if (overs.length == 0) return;
        int max = 6;
        for (int v : overs) max = Math.max(max, v);
        float labelH = Ui.dp(getContext(), 14);
        float valH = Ui.dp(getContext(), 13);
        float chartH = getHeight() - labelH - valH;
        float slot = getWidth() / (float) overs.length;
        float bw = slot * 0.62f;
        for (int i = 0; i < overs.length; i++) {
            float h = Math.max(Ui.dp(getContext(), 2), chartH * overs[i] / max);
            float x = i * slot + (slot - bw) / 2;
            float top = valH + chartH - h;
            bar.setColor(overs[i] >= 12 ? Ui.GOLD : Ui.CARD2);
            cv.drawRect(x, top, x + bw, valH + chartH, bar);
            val.setColor(Ui.INK);
            cv.drawText(String.valueOf(overs[i]), i * slot + slot / 2, top - Ui.dp(getContext(), 3), val);
            lab.setColor(Ui.MUTED);
            cv.drawText(String.valueOf(i + 1), i * slot + slot / 2, getHeight() - Ui.dp(getContext(), 3), lab);
        }
    }
}
