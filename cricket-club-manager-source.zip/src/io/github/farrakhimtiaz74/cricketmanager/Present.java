package io.github.farrakhimtiaz74.cricketmanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Professional Pack P4 (v17): the PURE half of the squad / money /
 *  league presentation pass — role key-stats, squad sorting, league
 *  form dots + position movement, finance tile maths, calendar week
 *  maths and the auction budget reconstruction. No android imports,
 *  so every number here is desktop-tested exactly as it ships.
 *
 *  Data honesty notes:
 *   - Catches / stumpings are NOT tracked in the season stats object,
 *     so a wicket-keeper's third key figure is his high score.
 *   - League MOVEMENT replays the GROUP fixtures only, up to the
 *     round (match day) before the most recent one: points from the
 *     winner field (summary-tail fallback, same derivation as
 *     Game.oppRecentForm) and an approximate NRR from the stored
 *     scores (balls faced default to a full 120 when a fixture does
 *     not store them; all out = 120). It orders the PREVIOUS table —
 *     nothing else reads it.
 *   - The auction starting budget is not a stored field; it is
 *     reconstructed as current CF + everything the auction log says
 *     the user has already spent on won lots this auction. */
public class Present {

    /** v20.1 (item 3/12c): the squad Cards-view card height is a
     *  CONSTANT, never wrap-content — v20's card let a stretched
     *  child drive its height and rendered as one giant empty card
     *  on Farrakh's phone. TeamScreen assigns exactly this height;
     *  the desktop tests pin the value. */
    public static final int PLAYER_CARD_HEIGHT_DP = 124;

    // ---- 31: role key stats -------------------------------------------
    /** The three labelled mini-figures a compact player card shows,
     *  chosen by role: {label, value} pairs, exactly three. */
    public static String[][] keyStats(JSONObject p) {
        JSONObject ss = p.optJSONObject("ss");
        int runs = ss == null ? 0 : ss.optInt("runs");
        int balls = ss == null ? 0 : ss.optInt("balls");
        int wkts = ss == null ? 0 : ss.optInt("wkts");
        int conc = ss == null ? 0 : ss.optInt("conc");
        int bwBalls = ss == null ? 0 : ss.optInt("bwBalls");
        int hs = ss == null ? 0 : ss.optInt("hs");
        String role = p.optString("role");
        switch (role) {
            case "Bowl":
                return new String[][]{
                        {"BOWL", String.valueOf(p.optInt("bowl"))},
                        {"WKTS", String.valueOf(wkts)},
                        {"ECON", bwBalls == 0 ? "—" : String.format(Locale.US, "%.1f", conc * 6.0 / bwBalls)}};
            case "AR":
                return new String[][]{
                        {"BAT / BOWL", p.optInt("bat") + " / " + p.optInt("bowl")},
                        {"RUNS", String.valueOf(runs)},
                        {"WKTS", String.valueOf(wkts)}};
            case "WK":
                return new String[][]{
                        {"BAT", String.valueOf(p.optInt("bat"))},
                        {"RUNS", String.valueOf(runs)},
                        {"HS", String.valueOf(hs)}};
            default: // Bat
                return new String[][]{
                        {"BAT", String.valueOf(p.optInt("bat"))},
                        {"RUNS", String.valueOf(runs)},
                        {"SR", balls == 0 ? "—" : String.format(Locale.US, "%.0f", runs * 100.0 / balls)}};
        }
    }

    // ---- 33: squad sorting ---------------------------------------------
    public static final String[] SORTS = {"Rating", "Bat", "Bowl", "Stamina", "Morale", "Age"};

    private static int sortValue(JSONObject p, String key) {
        switch (key) {
            case "Bat": return p.optInt("bat");
            case "Bowl": return p.optInt("bowl");
            case "Stamina": return p.optInt("stam");
            case "Morale": return p.optInt("morale", 70);
            case "Age": return p.optInt("age", 0);
            default: return Game.rating(p);
        }
    }

    /** Squad members sorted by the key, best first; name breaks ties
     *  so the order is stable between renders. */
    public static List<JSONObject> sortPlayers(JSONArray players, String key) {
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = players.optJSONObject(i);
            if (p != null) out.add(p);
        }
        Collections.sort(out, (a, b) -> {
            int d = sortValue(b, key) - sortValue(a, key);
            if (d != 0) return d;
            return a.optString("name").compareTo(b.optString("name"));
        });
        return out;
    }

    // ---- 34: words beside the colours -----------------------------------
    public static String staminaLabel(int stam) {
        if (stam >= 60) return "Fresh";
        if (stam >= 40) return "Tiring";
        if (stam >= 20) return "Tired";
        return "Exhausted";
    }

    // ---- 38: form dots + movement ---------------------------------------
    /** The decided winner of a fixture: the winner field where stored,
     *  else the summary tail (" — X won ..."); "TIE" for a tie, "" when
     *  undecided/unplayed. Same derivation as Game.oppRecentForm. */
    public static String winnerOf(JSONObject f) {
        if (f == null || !f.optBoolean("played")) return "";
        String winner = f.optString("winner");
        if (!winner.isEmpty()) return winner;
        String s = f.optString("summary");
        int cut = s.lastIndexOf(" — ");
        if (cut >= 0) {
            String tail = s.substring(cut + 3);
            if (tail.startsWith("Match tied")) return "TIE";
            int w = tail.indexOf(" won");
            if (w > 0) return tail.substring(0, w);
        }
        return "";
    }

    /** A team's last-5 league results as W/L/T characters, oldest
     *  first ("" when the team has played nothing). */
    public static String formDots(JSONArray fixtures, String team) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fixtures.length(); i++) {
            JSONObject f = fixtures.optJSONObject(i);
            if (f == null || !f.optBoolean("played")) continue;
            if (!team.equals(f.optString("home")) && !team.equals(f.optString("away"))) continue;
            String w = winnerOf(f);
            if (w.isEmpty()) continue;
            sb.append(w.equals("TIE") ? 'T' : w.equals(team) ? 'W' : 'L');
        }
        return sb.length() <= 5 ? sb.toString() : sb.substring(sb.length() - 5);
    }

    /** The most recent match day on which any group fixture was played. */
    public static int latestPlayedDay(JSONArray fixtures) {
        int max = -1;
        for (int i = 0; i < fixtures.length(); i++) {
            JSONObject f = fixtures.optJSONObject(i);
            if (f != null && f.optBoolean("played")) max = Math.max(max, f.optInt("day"));
        }
        return max;
    }

    /** The group order as it stood BEFORE the most recent round of
     *  fixtures (every played fixture with an earlier day replayed:
     *  2 pts a win, 1 a tie, approximate NRR from the stored scores),
     *  or null when there is no earlier round to compare against. */
    public static List<String> previousOrder(JSONArray fixtures, String[] teams) {
        int latest = latestPlayedDay(fixtures);
        if (latest < 0) return null;
        Map<String, int[]> pts = new HashMap<>();   // pts
        Map<String, double[]> nrr = new HashMap<>(); // rf, bf, ra, ba
        for (String t : teams) { pts.put(t, new int[1]); nrr.put(t, new double[4]); }
        boolean any = false;
        for (int i = 0; i < fixtures.length(); i++) {
            JSONObject f = fixtures.optJSONObject(i);
            if (f == null || !f.optBoolean("played") || f.optInt("day") >= latest) continue;
            String home = f.optString("home"), away = f.optString("away");
            if (!pts.containsKey(home) || !pts.containsKey(away)) continue;
            any = true;
            String w = winnerOf(f);
            if (w.equals("TIE")) { pts.get(home)[0] += 1; pts.get(away)[0] += 1; }
            else if (w.equals(home)) pts.get(home)[0] += 2;
            else if (w.equals(away)) pts.get(away)[0] += 2;
            int r1 = f.optInt("r1"), r2 = f.optInt("r2");
            if (r1 > 0 || r2 > 0) {
                int b1 = f.optInt("w1") == 10 ? 120 : f.optInt("b1", 120);
                int b2 = f.optInt("w2") == 10 ? 120 : f.optInt("b2", 120);
                if (b1 <= 0) b1 = 120;
                if (b2 <= 0) b2 = 120;
                double[] h = nrr.get(home), a = nrr.get(away);
                h[0] += r1; h[1] += b1; h[2] += r2; h[3] += b2;
                a[0] += r2; a[1] += b2; a[2] += r1; a[3] += b1;
            }
        }
        if (!any) return null;
        List<String> out = new ArrayList<>();
        Collections.addAll(out, teams);
        Collections.sort(out, (x, y) -> {
            int d = pts.get(y)[0] - pts.get(x)[0];
            if (d != 0) return d;
            double nx = nrrOf(nrr.get(x)), ny = nrrOf(nrr.get(y));
            if (ny != nx) return Double.compare(ny, nx);
            return x.compareTo(y);
        });
        return out;
    }

    private static double nrrOf(double[] v) {
        if (v == null || v[1] == 0 || v[3] == 0) return 0;
        return v[0] * 6.0 / v[1] - v[2] * 6.0 / v[3];
    }

    /** Position movement per team: previous position − current
     *  position (positive = climbed). Empty map when there is no
     *  previous round. Group tables only. */
    public static Map<String, Integer> movement(JSONArray fixtures, String[] teams,
                                                List<String> currentOrder) {
        Map<String, Integer> out = new HashMap<>();
        List<String> prev = previousOrder(fixtures, teams);
        if (prev == null) return out;
        for (int i = 0; i < currentOrder.size(); i++) {
            int before = prev.indexOf(currentOrder.get(i));
            if (before >= 0) out.put(currentOrder.get(i), before - i);
        }
        return out;
    }

    /** Movement as display text: ▲2 / ▼1 / ● (the v12.1-safe glyphs). */
    public static String movementText(int delta) {
        if (delta > 0) return "▲" + delta;
        if (delta < 0) return "▼" + (-delta);
        return "●";
    }

    // ---- 37: finance tiles ----------------------------------------------
    /** {income, spending, net} from a financeTotals() object: income
     *  is the positive categories summed, spending the negative ones
     *  (as a positive figure), and net is their difference — which is
     *  exactly the totals object's own "total". */
    public static int[] financeSummary(JSONObject ft) {
        String[] cats = {"prizes", "gate", "merch", "sponsor", "wages", "transfers", "upgrades", "other"};
        int income = 0, spending = 0;
        for (String k : cats) {
            int v = ft.optInt(k);
            if (v >= 0) income += v; else spending += -v;
        }
        return new int[]{income, spending, income - spending};
    }

    /** Season wages as a whole percentage of season income (0 when
     *  there is no income yet). */
    public static int wageSharePct(JSONObject ft) {
        int[] s = financeSummary(ft);
        if (s[0] <= 0) return 0;
        return Math.round(Math.abs(ft.optInt("wages")) * 100f / s[0]);
    }

    // ---- 36: auction budget ----------------------------------------------
    /** What the user has already spent on WON lots in this auction,
     *  parsed back out of the auction log's settlement lines
     *  ("You signed X for N CF."). */
    public static int auctionSpent(JSONArray log) {
        if (log == null) return 0;
        int sum = 0;
        for (int i = 0; i < log.length(); i++) {
            String s = log.optString(i);
            if (!s.startsWith("You signed ")) continue;
            int cut = s.lastIndexOf(" for ");
            if (cut < 0) continue;
            String tail = s.substring(cut + 5).replace(" CF.", "").replace(" CF", "").trim();
            try { sum += Integer.parseInt(tail); } catch (Exception ignored) {}
        }
        return sum;
    }

    /** The auction's starting budget, reconstructed (see class doc). */
    public static int auctionBase(int currentCf, JSONArray log) {
        return currentCf + auctionSpent(log);
    }

    /** True when at least one rival can still raise over the current
     *  bid (their rolled valuation AND remaining budget both cover the
     *  next increment) — a signal only; the valuations stay hidden. */
    public static boolean roomStillIn(JSONObject auction) {
        if (auction == null) return false;
        JSONObject mx = auction.optJSONObject("aiMax");
        JSONObject budgets = auction.optJSONObject("budgets");
        if (mx == null || budgets == null) return false;
        int next = auction.optInt("curBid") + auction.optInt("inc");
        JSONArray names = mx.names();
        if (names == null) return false;
        for (int i = 0; i < names.length(); i++) {
            String t = names.optString(i);
            if (mx.optInt(t, 0) >= next && budgets.optInt(t, 0) >= next) return true;
        }
        return false;
    }

    // ---- 35: potential bar -------------------------------------------------
    /** The potential bar's inputs: {rating, potLow, potHigh} on the
     *  player's true values — exact POT when known (own squad or
     *  scouted), the displayed range when it is not. */
    public static int[] potBar(Game g, JSONObject p) {
        int pot = p.optInt("pot", 0);
        String name = p.optString("name");
        boolean exact = g.playerByName(name) != null || g.scouted.has(name);
        if (exact) return new int[]{Game.rating(p), pot, pot};
        int low = g.potRangeLowFor(name, pot);
        return new int[]{Game.rating(p), low, low + g.potRangeWidth() - 1};
    }

    // ---- 40: calendar weeks --------------------------------------------------
    /** Week 1 = Days 1–7, Week 2 = Days 8–14, and so on. */
    public static int weekOfDay(int day) {
        return day < 1 ? 1 : (day - 1) / 7 + 1;
    }

    /** The competition kind behind a calendar row's tag text. */
    public static String compKind(String tag) {
        if (tag == null) return "OTHER";
        if (tag.contains("Cup")) return "CUP";
        if (tag.contains("Playoff")) return "PLAYOFF";
        if (tag.contains("Window")) return "WINDOW";
        if (tag.contains("League")) return "LEAGUE";
        if (tag.contains("Friendly") || tag.contains("Challenge") || tag.contains("Scenario")) return "FRIENDLY";
        return "OTHER";
    }
}
