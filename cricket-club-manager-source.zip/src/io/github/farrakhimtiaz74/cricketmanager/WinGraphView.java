package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;
import android.widget.LinearLayout;

/** Professional Pack P3 (suggestion 25): the win-predictor GRAPH —
 *  the user's win % after every completed over of the match (recorded
 *  by MatchEngine.recordWp into the match's wpSeries / inn1Wp), drawn
 *  as a gold area line over a slate plot with a dashed 50% midline.
 *  The final point is dotted and labelled, so the graph always agrees
 *  with the MomentumView split beside it. */
public class WinGraphView extends View {
    private final int[] series;
    private final int color;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    public WinGraphView(Context c, int[] series, int userColor) {
        super(c);
        this.series = series == null ? new int[0] : series;
        this.color = userColor;
        setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 86)));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Ui.dp(c, 2));
        line.setColor(userColor);
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(1);
        grid.setColor(0x665B6B80);
        txt.setColor(0xFFF1F5F9);
        txt.setTextSize(Ui.dp(c, 11));
        txt.setFakeBoldText(true);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || series.length == 0) return;
        float padL = Ui.dp(getContext(), 4), padR = Ui.dp(getContext(), 30);
        float padT = Ui.dp(getContext(), 6), padB = Ui.dp(getContext(), 14);
        float pw = w - padL - padR, ph = h - padT - padB;
        // 50% midline (dashed by segments — framework Paint path effect
        // is overkill; short dashes drawn manually)
        float midY = padT + ph / 2f;
        grid.setColor(0x668A97A8);
        for (float x = padL; x < padL + pw; x += Ui.dp(getContext(), 7)) {
            cv.drawLine(x, midY, Math.min(x + Ui.dp(getContext(), 4), padL + pw), midY, grid);
        }
        txt.setTextAlign(Paint.Align.LEFT);
        txt.setColor(0xFF8A97A8);
        cv.drawText("50", padL + pw + Ui.dp(getContext(), 4), midY + Ui.dp(getContext(), 4), txt);
        cv.drawText("Over " + series.length, padL, h - Ui.dp(getContext(), 2), txt);

        int n = series.length;
        float stepX = n <= 1 ? 0 : pw / (n - 1);
        Path area = new Path();
        Path stroke = new Path();
        for (int i = 0; i < n; i++) {
            float x = n <= 1 ? padL + pw / 2f : padL + stepX * i;
            float y = padT + ph * (100 - Design.clamp100(series[i])) / 100f;
            if (i == 0) { area.moveTo(x, padT + ph); area.lineTo(x, y); stroke.moveTo(x, y); }
            else { area.lineTo(x, y); stroke.lineTo(x, y); }
            if (i == n - 1) area.lineTo(x, padT + ph);
        }
        area.close();
        fill.setShader(new LinearGradient(0, padT, 0, padT + ph,
                (color & 0x00FFFFFF) | 0x55000000, (color & 0x00FFFFFF) | 0x08000000,
                Shader.TileMode.CLAMP));
        cv.drawPath(area, fill);
        fill.setShader(null);
        cv.drawPath(stroke, line);
        // final point + label
        float lx = n <= 1 ? padL + pw / 2f : padL + pw;
        float ly = padT + ph * (100 - Design.clamp100(series[n - 1])) / 100f;
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor(0xFFF8FAFC);
        cv.drawCircle(lx, ly, Ui.dp(getContext(), 4), dot);
        dot.setColor(color);
        cv.drawCircle(lx, ly, Ui.dp(getContext(), 2), dot);
        txt.setColor(0xFFF1F5F9);
        txt.setTextAlign(Paint.Align.RIGHT);
        cv.drawText(series[n - 1] + "%", w - Ui.dp(getContext(), 2),
                Math.max(Ui.dp(getContext(), 11), ly - Ui.dp(getContext(), 5)), txt);
    }
}
