package io.github.farrakhimtiaz74.cricketmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.Random;

/** Design Batch (v13, item 10): a one-shot confetti burst — ~70 paper
 *  pieces in gold + the club accent + white, falling and tumbling for
 *  ~1.5 s over the ceremony / title screens. Non-blocking (touch
 *  passes through: it never consumes events and the overlay is removed
 *  by MainActivity.celebrate() when the burst ends). NEVER created
 *  when Reduce Animations is on — MainActivity gates it. */
public class ConfettiView extends View {
    private static final int COUNT = 70;
    private static final long DURATION = 1500;

    private final float[] px, py, vx, vy, rot, vr, sz;
    private final int[] col;
    private final long start;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    public boolean finished = false;

    public ConfettiView(Context c, int accent) {
        super(c);
        Random rnd = new Random();
        px = new float[COUNT]; py = new float[COUNT];
        vx = new float[COUNT]; vy = new float[COUNT];
        rot = new float[COUNT]; vr = new float[COUNT]; sz = new float[COUNT];
        col = new int[COUNT];
        int[] palette = {Ui.GOLD, 0xFFFDE68A, accent, 0xFFF8FAFC, 0xFF22C55E};
        for (int i = 0; i < COUNT; i++) {
            px[i] = rnd.nextFloat();
            py[i] = -0.08f - rnd.nextFloat() * 0.25f;
            vx[i] = (rnd.nextFloat() - 0.5f) * 0.12f;
            vy[i] = 0.55f + rnd.nextFloat() * 0.5f;
            rot[i] = rnd.nextFloat() * 360f;
            vr[i] = (rnd.nextFloat() - 0.5f) * 540f;
            sz[i] = 0.6f + rnd.nextFloat() * 0.8f;
            col[i] = palette[i % palette.length];
        }
        start = System.currentTimeMillis();
        setClickable(false);
        setFocusable(false);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        float t = Math.min(1f, (System.currentTimeMillis() - start) / (float) DURATION);
        float base = Ui.dp(getContext(), 9);
        for (int i = 0; i < COUNT; i++) {
            float x = (px[i] + vx[i] * t + 0.03f * (float) Math.sin(t * 9 + i)) * w;
            float y = (py[i] + vy[i] * t * 1.35f) * h;
            if (y > h + 20) continue;
            cv.save();
            cv.translate(x, y);
            cv.rotate(rot[i] + vr[i] * t);
            p.setColor(col[i]);
            p.setAlpha((int) (255 * (t < 0.8f ? 1f : 1f - (t - 0.8f) * 5f)));
            float s = base * sz[i];
            cv.drawRect(-s / 2, -s / 4, s / 2, s / 4, p);
            cv.restore();
        }
        if (t < 1f) {
            postInvalidateDelayed(16);
        } else {
            finished = true;
        }
    }
}
