package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/** Batch J (idea 92): the What's New screen — the whole 100-update
 *  mega-batch in plain language, grouped by the version that shipped
 *  it (v3.0 → v12.0), this batch listed fully. Show-once: the Hub shows
 *  a banner whenever the stored lastSeenVersion (app prefs, NOT the
 *  career save — it survives resets) is behind the running versionCode;
 *  dismissing here or on the banner stores the current code. Content is
 *  static text distilled from the BATCHLOG in Game.java. */
public class WhatsNewScreen {

    public static View build(final MainActivity act) {
        LinearLayout root = Ui.col(act);

        Button back = Ui.darkBtn(act, "← Back");
        back.setOnClickListener(v -> { act.whatsNewMode = false; act.render(); });
        root.addView(back);
        root.addView(Ui.h1(act, "🆕 What's New — the 100 Updates"));
        root.addView(Ui.small(act, "Versions 3.0 to 12.0 turned the launch game into a full club-career"
                + " simulator — ten batches of ten, all in this app, all offline."));

        group(act, root, "⭐ v12.0 — App & Quality of Life (this update)", new String[]{
                "💾 Career backup: export your whole career as a .json file from Settings → Backup & Sync.",
                "🔑 Sync codes: your career as one copyable CCM1: code — paste it on any install to move your career. Imports auto-back-up your current career first (undo until you play a match).",
                "🆕 This What's New screen — shown once after each app update.",
                "🗣️ Roman Urdu commentary: switch the ball-by-ball in Settings and matches speak Roman Urdu (scores stay English).",
                "🔊 Sound effects: bat ticks, boundary and six tones, a wicket buzz and a win jingle — live play only, volume Low/Med/High in Settings.",
                "🔠 Big Text (+25%) and Reduce Animations (sims run Instant) in Settings.",
                "⚙️ One Settings screen for everything: speed, sounds, language, text size, backup, reset and About.",
                "🔍 Global Search on the Hub — find any player, club or fixture in seconds.",
                "📤 CSV exports: tournament stats (League tab) and your squad's season stats (Team tab) for spreadsheets.",
                "🏏 About & polish: the app is 'Cricket Club Manager' (CCM on your home screen), fully offline, still zero permissions."});

        group(act, root, "v11.0 — Game Modes", new String[]{
                "🎯 Daily challenge and 6 hand-built scenarios — win set situations for CF.",
                "📜 Weekly quests, 15 achievements and a fan prediction game.",
                "💾 Three career slots plus a hardcore mode with a persistent best-season record.",
                "🎚️ Three difficulties and quick-season mode; result codes you can copy and share."});

        group(act, root, "v10.0 — Media, Fans & Calendar", new String[]{
                "🎤 Press conferences with real effects, newspaper headlines and the Fan Buzz feed.",
                "🖼️ Shareable match report cards, a trophy cabinet and rival manager quotes.",
                "📅 The full season calendar and a Coach's Corner tip every day."});

        group(act, root, "v9.0 — Club Business", new String[]{
                "👔 Hire a head coach, batting/bowling coaches, a physio and a scout.",
                "🏟️ Facilities to Level 10, ticket prices, sponsorship deals and merchandise.",
                "📋 Board confidence — please the board or get sacked. Manager levels and perks."});

        group(act, root, "v8.0 — World & Cups", new String[]{
                "🌍 Pick any of the 8 clubs (or build a custom one); full AI squads that rotate and get injured.",
                "🏆 A 50-over One-Day Cup alongside the league, live world rankings, international call-ups and derbies."});

        group(act, root, "v7.0 — League & Season", new String[]{
                "🏆 Real playoffs — Qualifier, Eliminators and a Final — replace 'top of the table wins'.",
                "📊 Tournament leaderboards, head-to-head records, season awards, a records book and a Hall of Fame."});

        group(act, root, "v6.0 — Transfers & Contracts", new String[]{
                "🔨 The off-season auction, contracts and weekly wages, a mid-season window, loans, free agents and poaching offers."});

        group(act, root, "v5.0 — Squad & Players", new String[]{
                "📈 Season + career stats for every player, form graphs, potential, injuries, morale and milestones.",
                "⭐ Specialist tags and Auto-pick Best XI."});

        group(act, root, "v4.0 — Match Tactics", new String[]{
                "🎯 Powerplay plans, a 20-over bowling rotation plan, field presets with a field map and a pep talk.",
                "🧠 Assistant-coach suggestions and choosing your next batter."});

        group(act, root, "v3.0 — Match Engine", new String[]{
                "🌧️ Rain and revised targets, four pitch types, dew, a live win predictor and a Manhattan chart.",
                "⚡ Super Overs, partnerships, Player of the Match, Highlights mode and match speed."});

        Button done = Ui.goldBtn(act, "Got it — let's play");
        done.setOnClickListener(v -> {
            act.settings.setLastSeenVersion(act.appVersionCode);
            act.whatsNewMode = false;
            act.render();
        });
        root.addView(done);
        return root;
    }

    private static void group(MainActivity act, LinearLayout root, String title, String[] lines) {
        LinearLayout card = Ui.card(act);
        card.addView(Ui.h2(act, title));
        for (String s : lines) card.addView(Ui.body(act, "•  " + s));
        root.addView(card);
    }
}
