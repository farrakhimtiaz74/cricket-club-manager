package io.github.farrakhimtiaz74.cricketmanager;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/** Batch J (idea 92): the What's New screen — every update in plain
 * language, grouped by the version that shipped it. Show-once: the
 * Hub shows a banner whenever the stored lastSeenVersion (app prefs,
 * NOT the career save — it survives resets) is behind the running
 * versionCode; dismissing here or on the banner stores the current
 * code. Content is static text distilled from the BATCHLOG in
 * Game.java.
 *
 * Professional Pack P5 (suggestion 48): presented as a CHANGELOG —
 * newest first, the current version's group expanded as a card, and
 * every older version folded into a collapsible under its version
 * header, so the screen reads as release notes, not a wall. */
public class WhatsNewScreen {

 public static View build(final MainActivity act) {
 LinearLayout root = Ui.col(act);

 // P2 (suggestions 13/19): the standard sub-screen header
 root.addView(Ui.subHeader(act, "What's New",
 "Every update, in plain words — newest first",
 v -> { act.whatsNewMode = false; act.render(); }));
 root.addView(Ui.small(act, "The changelog: what changed in each version, newest at the top. "
 + "Older versions are folded — tap one to open it."));

 group(act, root, "v20.0 — Rich Media Edition (this update)", new String[]{
 "The game now OPENS like a big title: a full-screen stadium title screen and main menu — Continue Career, New Career, Play and Settings — before you ever see the tabs.",
 "Real artwork everywhere: a floodlit stadium splash, a matchday pitch behind your match cards with the blue-to-gold gradient wash, and the trophy art heading your Trophy Cabinet and title ceremony.",
 "Your club HQ is a place now: an aerial map of the grounds — stadium, medical centre, training complex, academy and commercial centre — tap a building to jump to its card.",
 "Every club has a proper crest: original artwork in club colours with stars and initials (custom clubs keep their drawn shield).",
 "The sound is produced, not beeped: real audio files recorded for this game — three full crowd recordings (home, away and derby days), menu and match music, bat cracks, stumps, cheers, groans, the auction gavel and the full-time whistle — all still run through your 5-channel mixer.",
 "Two bundled typefaces: Rajdhani for headings and big numbers, Barlow for reading — plus grass and texture work under the League and World headers, and morale faces beside the morale meter.",
 "The app is bigger now — 17 MB — and every megabyte is this media: the art, the audio and the fonts. No ads, no trackers, still zero permissions, still fully offline."});

 folded(act, root, "v19.0 — Sound & Music", new String[]{
 "The beeps are gone. Every sound is now synthesized inside the app: a real bat-on-ball thock (heavier for boundaries), stumps rattling on a bowled wicket, a pads thud on LBWs.",
 "The crowd is alive: a soft stadium bed under live matches, roars for fours and sixes, a groan when you lose a wicket at home — louder again on derby day, with rain patter when a shower stops play.",
 "Signings chime, bids tick, the auction hammer falls, prize money lands with a soft cash note, and titles get a full celebration sting.",
 "Two quiet music beds — a calm menu theme and a tenser one under live matches — plus a low tension pulse when a chase goes down to the last three overs.",
 "Settings → Sound is a proper mixer now: Match, Crowd, UI, Music and Voice channels, a Quiet Mode that keeps only wickets, boundaries, results and titles, and a test button per channel.",
 "Optional voice score updates (off by default): the score spoken at the innings break, late in a chase, and at full time, through your phone's own voice."});

 group(act, root, "v18.0 — Welcome & Help", new String[]{
 "First launch gets a proper welcome: three short steps before you pick your club — how a season works, and how Club Cash runs it.",
 "Quick Start on the club picker: Lahore Qalandars on Manager difficulty in a single tap. The full picker is still right there.",
 "A Help & Guides screen (Profile and Settings): getting started, picking your XI, money, transfers, playoffs, the board — plus a full glossary.",
 "Little i badges explain the jargon where it appears: NRR in the tables, POT on players and in the market, DLS, Set %, CRR and RRR in a live match.",
 "Settings is organised the way you would expect: Display, Sound, Commentary, Gameplay, Data, Help & About.",
 "Backup speaks plainly — Create my career code, Continue from a career code — and About shows the trust facts: 100% offline, no account, zero permissions."});

 folded(act, root, "v17.0 — Squad & League Look", new String[]{
 "Player cards are compact now: the three numbers that matter, stamina and morale with their words beside the bars — everything else is one tap away.",
 "Player pages have tabs — Overview, Stats, Form, Contract — and the squad can switch to compact rows, sorted by rating, batting, bowling, stamina, morale or age.",
 "The transfer market looks like a market: every listing is a card with a potential bar and the fee in big figures, and the auction is a proper bidding panel with your budget gauge and quick-bid chips.",
 "Finances is a dashboard: income, spending and net tiles, your wage bill's share of income, and the season's biggest single payday and payout.",
 "League tables carry form dots and movement arrows — see who is climbing and who is sliding since the last round.",
 "Honours look like honours: trophy rows in the cabinet, crest rows for champions, record rows with the holder and the mark — and the calendar runs as a week-by-week timeline with competition tags."});

 folded(act, root, "v16.0 — Match Centre", new String[]{
 "The score bug is broadcast-grade: the pair at the crease, the bowler's figures and the last 12 balls, always on screen.",
 "A ball-by-ball timeline for every innings — real ball chips for the latest overs, runs and wicket chips before that.",
 "Commentary is grouped by over, with wickets, fours, sixes and milestones as proper event rows.",
 "Tactics, powerplay plans, field presets and bowling plans are now segmented controls, with visual plan strips.",
 "The win predictor draws its story: a graph of your win % over by over, live and at full time.",
 "Head-to-head comparison bars before the match, a pro scorecard table, and a full-time summary with Player of the Match and the turning point."});

 folded(act, root, "v15.0 — Layout & Flow", new String[]{
 "The Hub is a dashboard now: Today at the top, your next match second, a Needs Attention card only when something is wrong, and a Money snapshot — everything else moved down or home to its own tab.",
 "Bottom nav with drawn icons and a gold indicator on the active tab — you always know where you are.",
 "Sticky filters: the Team role chips and the Transfers market chips stay on screen while the lists scroll.",
 "Pinned action bars: your XI status and Auto-pick on the Team tab, budget and squad room in Transfers, and the Bowl Ball controls during a live match — no more scrolling back up.",
 "Tap a player card for a quick-view sheet; tap any fixture in the League tab for its sheet — the same sheets everywhere.",
 "Long detail folds away: match history, records and career detail now sit in collapsible sections, closed until you want them."});

 folded(act, root, "v14.0 — Professional Look", new String[]{
 "One gold button per card: the main action shines, everything else steps back into dark secondary buttons.",
 "Red means danger now: Reset Career, releasing a player and firing staff wear a red-outline danger button.",
 "Emoji out of the chrome: headers, buttons and labels are clean text and drawn icons — nothing left to render as a stray glyph.",
 "A branded launch moment: your club crest, the app name and \"Manage. Win. Lift the trophy.\" — skipped when Reduce Animations is on.",
 "Crest lockups everywhere: your club shield sits the same way in the header, the team picker, the sacked screen and About.",
 "Room to breathe: wider section spacing and a text diet on the busiest cards — headline, key numbers, action."});

 folded(act, root, "v13.0 — The Design Update", new String[]{
 "Stadium Night theme: a floodlit green-and-gold header band, tinted by YOUR club's colours, with a gold rule under it.",
 "Club crests: every club has a drawn shield in its own colours — league tables, match days, the calendar and head-to-head.",
 "Drawn icons: captain's medallion, injury cross, rest crescent, overseas globe, contract, trophy and CF coin — no more broken font symbols.",
 "Player identity: initials discs in role colours and Bronze / Silver / Gold / Elite card frames by rating.",
 "Broadcast match screen: a sticky score bug, ball-by-ball chips grouped by over, and a momentum bar in both clubs' colours.",
 "Drawn charts: Board and Fan gauges, a Finances bar chart, the manager XP gauge and two-row form charts (runs + wickets).",
 "The Hub's Manager Actions are grouped — Club · Match Centre · Squad · Compete · More — with matching section headers in League and Profile.",
 "Bottom sheets: tap a fixture in the calendar or a squad player in Search for a slide-up quick view.",
 "Trophy confetti in your club's colours, pressed-state buttons and gentle screen transitions — all calmed by Reduce Animations in Settings.",
 "A proper type scale: big display numerals for scores and Club Cash, aligned table numbers, one card/button/chip style everywhere."});

 folded(act, root, "v12.0 — App & Quality of Life", new String[]{
 "Career backup: export your whole career as a .json file from Settings → Backup & Sync.",
 "Sync codes: your career as one copyable CCM1: code — paste it on any install to move your career. Imports auto-back-up your current career first (undo until you play a match).",
 "This What's New screen — shown once after each app update.",
 "Roman Urdu commentary: switch the ball-by-ball in Settings and matches speak Roman Urdu (scores stay English).",
 "Sound effects: bat ticks, boundary and six tones, a wicket buzz and a win jingle — live play only, volume Low/Med/High in Settings.",
 "Big Text (+25%) and Reduce Animations (sims run Instant) in Settings.",
 "One Settings screen for everything: speed, sounds, language, text size, backup, reset and About.",
 "Global Search on the Hub — find any player, club or fixture in seconds.",
 "CSV exports: tournament stats (League tab) and your squad's season stats (Team tab) for spreadsheets.",
 "About & polish: the app is 'Cricket Club Manager' (CCM on your home screen), fully offline, still zero permissions."});

 folded(act, root, "v11.0 — Game Modes", new String[]{
 "Daily challenge and 6 hand-built scenarios — win set situations for CF.",
 "Weekly quests, 15 achievements and a fan prediction game.",
 "Three career slots plus a hardcore mode with a persistent best-season record.",
 "Three difficulties and quick-season mode; result codes you can copy and share."});

 folded(act, root, "v10.0 — Media, Fans & Calendar", new String[]{
 "Press conferences with real effects, newspaper headlines and the Fan Buzz feed.",
 "Shareable match report cards, a trophy cabinet and rival manager quotes.",
 "The full season calendar and a Coach's Corner tip every day."});

 folded(act, root, "v9.0 — Club Business", new String[]{
 "Hire a head coach, batting/bowling coaches, a physio and a scout.",
 "Facilities to Level 10, ticket prices, sponsorship deals and merchandise.",
 "Board confidence — please the board or get sacked. Manager levels and perks."});

 folded(act, root, "v8.0 — World & Cups", new String[]{
 "Pick any of the 8 clubs (or build a custom one); full AI squads that rotate and get injured.",
 "A 50-over One-Day Cup alongside the league, live world rankings, international call-ups and derbies."});

 folded(act, root, "v7.0 — League & Season", new String[]{
 "Real playoffs — Qualifier, Eliminators and a Final — replace 'top of the table wins'.",
 "Tournament leaderboards, head-to-head records, season awards, a records book and a Hall of Fame."});

 folded(act, root, "v6.0 — Transfers & Contracts", new String[]{
 "The off-season auction, contracts and weekly wages, a mid-season window, loans, free agents and poaching offers."});

 folded(act, root, "v5.0 — Squad & Players", new String[]{
 "Season + career stats for every player, form graphs, potential, injuries, morale and milestones.",
 "Specialist tags and Auto-pick Best XI."});

 folded(act, root, "v4.0 — Match Tactics", new String[]{
 "Powerplay plans, a 20-over bowling rotation plan, field presets with a field map and a pep talk.",
 "Assistant-coach suggestions and choosing your next batter."});

 folded(act, root, "v3.0 — Match Engine", new String[]{
 "Rain and revised targets, four pitch types, dew, a live win predictor and a Manhattan chart.",
 "Super Overs, partnerships, Player of the Match, Highlights mode and match speed."});

 Button done = Ui.goldBtn(act, "Got it — let's play");
 done.setOnClickListener(v -> {
 act.settings.setLastSeenVersion(act.appVersionCode);
 act.whatsNewMode = false;
 act.render();
 });
 root.addView(done);
 return root;
 }

 /** The current version: an expanded card of bullet lines. */
 private static void group(MainActivity act, LinearLayout root, String title, String[] lines) {
 LinearLayout card = Ui.card(act);
 card.addView(Ui.h2(act, title));
 for (String s : lines) card.addView(Ui.body(act, "•  " + s));
 root.addView(card);
 }

 /** P5 (suggestion 48): an older version, folded — the version
 * header is the collapsible's title, its changes one tap away. */
 private static void folded(MainActivity act, LinearLayout root, String title, String[] lines) {
 LinearLayout col = Ui.col(act);
 for (String s : lines) col.addView(Ui.body(act, "•  " + s));
 root.addView(Ui.collapsible(act, title.toUpperCase(), col, false));
 }
}
