package io.github.farrakhimtiaz74.cricketmanager;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Batch H (idea 77): draws the match report card to a Bitmap with the
 *  native Canvas — dark slate + gold, matching the app. The card is
 *  viewable in-app (dialog) and shareable as a PNG through the share
 *  sheet (see ShareProvider / MainActivity). Text layout is a simple
 *  measured line stack: build the lines, wrap the long ones, draw. */
public class ReportCard {

    private static final int W = 1000;
    private static final int BG = Color.rgb(15, 23, 42);      // #0f172a
    private static final int CARD = Color.rgb(30, 41, 59);    // #1e293b
    private static final int GOLD = Color.rgb(245, 158, 11);  // #f59e0b
    private static final int INK = Color.rgb(226, 232, 240);
    private static final int MUTED = Color.rgb(148, 163, 184);
    private static final int GREEN = Color.rgb(52, 211, 153);
    private static final int RED = Color.rgb(248, 113, 113);

    private static class Line {
        final String text; final float size; final int color; final boolean bold; final float gapBefore;
        Line(String t, float s, int c, boolean b, float gap) { text = t; size = s; color = c; bold = b; gapBefore = gap; }
    }

    public static Bitmap render(Game g, JSONObject r) {
        List<Line> lines = new ArrayList<>();
        lines.add(new Line("🏏  MATCH REPORT", 54, GOLD, true, 0));
        lines.add(new Line("Season " + r.optInt("season") + " · " + r.optString("compLabel"), 30, MUTED, false, 10));
        lines.add(new Line(r.optString("home"), 44, INK, true, 44));
        lines.add(new Line("vs", 28, MUTED, false, 4));
        lines.add(new Line(r.optString("away"), 44, INK, true, 4));
        if (r.optInt("r1", -1) >= 0) {
            lines.add(new Line(scoreLine(r, true), 34, INK, false, 26));
            lines.add(new Line(scoreLine(r, false), 34, INK, false, 6));
        }
        lines.add(new Line(r.optString("summary"), 30, r.optBoolean("won") ? GREEN : RED, true, 30));
        lines.add(new Line("📍 " + r.optString("ground"), 28, MUTED, false, 26));
        if (!r.optString("potm").isEmpty()) {
            lines.add(new Line("⭐ Player of the Match", 28, GOLD, true, 30));
            lines.add(new Line(r.optString("potm") + (r.optString("potmDesc").isEmpty() ? ""
                    : " — " + r.optString("potmDesc")), 32, INK, false, 6));
        }
        if (!r.optString("topBatLine").isEmpty())
            lines.add(new Line("🔥 Top score: " + r.optString("topBatLine"), 30, INK, false, 26));
        if (!r.optString("bestBowlLine").isEmpty())
            lines.add(new Line("🎯 Best bowling: " + r.optString("bestBowlLine"), 30, INK, false, 8));
        lines.add(new Line(r.optBoolean("won") ? "✅ " + g.userTeam + " won" : "❌ " + g.userTeam + " lost",
                34, r.optBoolean("won") ? GREEN : RED, true, 36));
        lines.add(new Line("Cricket Club Manager", 26, MUTED, false, 44));

        // wrap pass with a measuring paint
        Paint meas = new Paint(Paint.ANTI_ALIAS_FLAG);
        List<Line> wrapped = new ArrayList<>();
        for (Line l : lines) {
            meas.setTextSize(l.size);
            meas.setFakeBoldText(l.bold);
            List<String> parts = wrap(meas, l.text, W - 120);
            for (int i = 0; i < parts.size(); i++)
                wrapped.add(new Line(parts.get(i), l.size, l.color, l.bold, i == 0 ? l.gapBefore : 4));
        }
        float height = 80;
        for (Line l : wrapped) height += l.gapBefore + l.size * 1.35f;
        height += 60;

        Bitmap bmp = Bitmap.createBitmap(W, (int) height, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(BG);
        cv.drawRect(0, 0, W, height, p);
        p.setColor(CARD);
        cv.drawRoundRect(new RectF(24, 24, W - 24, height - 24), 36, 36, p);
        p.setColor(GOLD);
        cv.drawRoundRect(new RectF(24, 24, W - 24, 120), 36, 36, p);

        float y = 60;
        boolean first = true;
        for (Line l : wrapped) {
            y += l.gapBefore;
            p.setColor(l.color);
            p.setTextSize(l.size);
            p.setFakeBoldText(l.bold);
            // the header band's title sits on gold: draw it dark
            if (first) { p.setColor(BG); first = false; }
            y += l.size;
            cv.drawText(l.text, 60, y, p);
            y += l.size * 0.35f;
        }
        return bmp;
    }

    private static String scoreLine(JSONObject r, boolean first) {
        String team = first ? r.optString("home") : r.optString("away");
        int runs = first ? r.optInt("r1", -1) : r.optInt("r2", -1);
        int wkts = first ? r.optInt("w1", -1) : r.optInt("w2", -1);
        if (runs < 0) return team;
        return team + "  " + runs + (wkts >= 0 ? "/" + wkts : "");
    }

    private static List<String> wrap(Paint p, String text, float maxWidth) {
        List<String> out = new ArrayList<>();
        if (text == null || text.isEmpty()) { out.add(""); return out; }
        String[] words = text.split(" ");
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            String trial = cur.length() == 0 ? w : cur + " " + w;
            if (p.measureText(trial) <= maxWidth || cur.length() == 0) cur = new StringBuilder(trial);
            else { out.add(cur.toString()); cur = new StringBuilder(w); }
        }
        if (cur.length() > 0) out.add(cur.toString());
        if (out.isEmpty()) out.add("");
        return out;
    }
}
