package io.github.farrakhimtiaz74.cricketmanager;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Rich Media Edition (v20): the TITLE / MAIN MENU — the app now
 *  opens like the reference managers do: full-bleed stadium artwork
 *  under a scrim, the club crest lockup and the game title in the
 *  bundled display face, then the four doors in:
 *    CONTINUE CAREER — only when a career exists (MainActivity's
 *      careerExists, set from the actual save at launch); shows the
 *      club + season/day summary. It changes nothing: the career the
 *      store loaded stays exactly as it was.
 *    NEW CAREER — the existing team picker (crest-art club cards,
 *      difficulty select, confirm dialogs — the whole v19 flow).
 *      With a career present it first passes a clear replace-warning
 *      dialog; cancelling, or backing out of the picker, leaves the
 *      save byte-identical (the picker never persists anything until
 *      a club is actually picked).
 *    PLAY — the existing Modes & Challenges screen (daily challenge,
 *      scenarios, quick season): the quick-play entry points are
 *      reused, not rebuilt. Needs a career — the modes play with
 *      your squad — so without one it points at New Career.
 *    SETTINGS — the existing Settings screen; its back chevron
 *      returns here when the menu sent us (settingsFromMenu).
 *  The menu is an ENTRY screen only: once a door is taken, the tab
 *  navigation works exactly as before, and the Hub's Manager Actions
 *  (MORE) carries a Main Menu button back here.
 *  If the stadium art fails to decode, the menu still renders over
 *  the plain app background — every element is a normal Ui factory
 *  view, the art is only the backdrop. */
public class MenuScreen {

    public static View build(final MainActivity act) {
        final Game g = act.g;
        FrameLayout root = new FrameLayout(act);
        int screenH = act.getResources().getDisplayMetrics().heightPixels;
        root.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, screenH));

        // backdrop: the stadium art, centre-cropped, under a scrim
        // v21 item 13: the menu backdrop VARIANT — the packed
        // stadium-interior photo alternates with the night hero by
        // day, so the title screen breathes between visits
        boolean interiorDay = (System.currentTimeMillis() / 86400000L) % 2 == 0;
        Bitmap bg = Art.bitmap(act, interiorDay ? Art.INTERIOR : Art.STADIUM, 1080);
        if (bg == null) bg = Art.bitmap(act, Art.STADIUM, 1080);
        if (bg != null) {
            ImageView iv = new ImageView(act);
            iv.setImageBitmap(bg);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            root.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        View scrim = new View(act);
        GradientDrawable grad = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x590F172A, 0xB30F172A, 0xF20F172A});
        scrim.setBackground(grad);
        root.addView(scrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // the gold-foil texture as a low glow behind the buttons at
        // the base of the title screen (skipped if it fails to load)
        android.graphics.drawable.Drawable goldTex = Art.drawable(act, Art.TEX_GOLD, 720, 44);
        if (goldTex != null) {
            View glow = new View(act);
            glow.setBackground(goldTex);
            FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 190));
            glp.gravity = Gravity.BOTTOM;
            root.addView(glow, glp);
        }

        // content column, bottom-weighted like a title screen
        LinearLayout col = Ui.col(act);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(Ui.dp(act, 26), Ui.dp(act, 30), Ui.dp(act, 26), Ui.dp(act, 26));
        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        col.addView(Ui.spacer(act, 26));
        // crest lockup: artwork when the club has it, drawn otherwise
        Bitmap crest = Art.crestBitmap(act, g, g.userTeam, 288);
        if (crest != null) {
            ImageView civ = new ImageView(act);
            civ.setImageBitmap(crest);
            civ.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(act, 84), Ui.dp(act, 94)));
            col.addView(civ);
        } else {
            col.addView(CrestView.forTeam(act, g, g.userTeam, 84));
        }
        TextView title = Ui.display(act, "CRICKET CLUB MANAGER", 29, Ui.INK);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(act, 12), 0, 0);
        col.addView(title);
        TextView tag = Ui.small(act, "Manage. Win. Lift the trophy.");
        tag.setGravity(Gravity.CENTER);
        col.addView(tag);

        View flex = Ui.spacer(act, 10);
        flex.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        col.addView(flex);

        if (act.careerExists) {
            String summary = g.userTeam + " · Season " + g.season + " · Day " + g.day
                    + (g.match != null ? " · a match is waiting" : "")
                    + (g.offseason > 0 ? " · off-season" : "");
            TextView sum = Ui.text(act, summary, 13.5f, Ui.GOLD_BRIGHT, true);
            sum.setGravity(Gravity.CENTER);
            sum.setPadding(0, 0, 0, Ui.dp(act, 6));
            col.addView(sum);
            Button cont = Ui.goldBtn(act, "Continue Career");
            cont.setOnClickListener(v -> { act.menuMode = false; act.render(); });
            col.addView(cont);
        }
        Button newCareer = Ui.darkBtn(act, "New Career");
        newCareer.setOnClickListener(v -> {
            if (!act.careerExists) {
                act.menuMode = false;
                act.pickerMode = true;
                act.render();
                return;
            }
            // HARD RULE: an existing career is never replaced without
            // this explicit warning — and even after confirming, the
            // save survives until a club is actually picked (the
            // picker persists nothing on its own), with the 3 career
            // slots + the backup code as the recovery path.
            new AlertDialog.Builder(act)
                    .setTitle("Start a New Career?")
                    .setMessage("This replaces your current career — " + g.userTeam
                            + ", Season " + g.season + ", Day " + g.day + ".\n\n"
                            + "It is NOT backed up automatically. If you might want it "
                            + "back, first save it to a career slot (Profile) or create "
                            + "a backup code (Settings → Backup & Sync).")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Replace Career", (d, w) -> {
                        act.pickerFromMenu = true;
                        act.pickerMode = true;
                        act.menuMode = false;
                        act.render();
                    })
                    .show();
        });
        col.addView(newCareer);
        Button play = Ui.darkBtn(act, "Play — Challenges & Scenarios");
        play.setOnClickListener(v -> {
            if (!act.careerExists) {
                act.toast("Start a career first — the challenges play with your squad");
                return;
            }
            act.menuMode = false;
            act.modesMode = true;
            act.render();
        });
        col.addView(play);
        Button settings = Ui.darkBtn(act, "Settings");
        settings.setOnClickListener(v -> {
            act.settingsFromMenu = true;
            act.settingsMode = true;
            act.menuMode = false;
            act.render();
        });
        col.addView(settings);

        TextView about = Ui.micro(act, "Cricket Club Manager v" + act.appVersionName
                + " · 100% offline · No account · Zero permissions");
        about.setGravity(Gravity.CENTER);
        about.setPadding(0, Ui.dp(act, 14), 0, 0);
        col.addView(about);
        return root;
    }
}
