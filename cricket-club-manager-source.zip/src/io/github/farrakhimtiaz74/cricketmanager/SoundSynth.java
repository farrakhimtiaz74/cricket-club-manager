package io.github.farrakhimtiaz74.cricketmanager;

import java.util.Random;

/** Audio Pack (v19): the SYNTHESIS CORE — pure Java, no Android, so
 *  every buffer recipe, the event-to-sound mapping, the channel map and
 *  the quiet-mode classification are desktop-testable. SoundEngine (the
 *  Android side) only plays what this class generates: mono 16-bit PCM
 *  at 22050 Hz, synthesized at runtime — the APK carries NO audio
 *  files at all.
 *
 *  Recipes are deliberately simple physics-flavoured models: a bat hit
 *  is a lowpassed noise burst over a low sine thump; crowd noise is
 *  band-shaped noise with slow random swells; stings are sine/triangle
 *  partial phrases. Everything is soft-clipped so no buffer can clip,
 *  and loop buffers are seam-folded so they loop without a click. */
public class SoundSynth {

    public static final int SR = 22050;

    // ---- sound ids ----
    public static final int BAT0 = 1;        // light: dot / single
    public static final int BAT1 = 2;        // medium: 2s and 3s
    public static final int BAT2 = 3;        // heavy: boundaries
    public static final int STUMPS = 4;      // bowled
    public static final int PADS = 5;        // LBW thud + crowd lift
    public static final int SWELL1 = 6;      // crowd swell, small
    public static final int SWELL2 = 7;      // crowd swell, big (six)
    public static final int SWELL3 = 8;      // crowd swell, winning moment
    public static final int GROAN = 9;       // crowd groan (user wicket, home)
    public static final int APPLAUSE = 10;   // milestone patter
    public static final int STING_WICKET = 11;
    public static final int STING_WIN = 12;
    public static final int STING_TITLE = 13;
    public static final int STING_ACHIEVE = 14;
    public static final int STING_LEVELUP = 15;
    public static final int UI_CLICK = 16;
    public static final int UI_CONFIRM = 17;
    public static final int UI_BLOCKED = 18;
    public static final int BID_TICK = 19;
    public static final int GAVEL = 20;
    public static final int CASH = 21;

    // loop kinds (played by SoundEngine's loop tracks, not play())
    public static final int LOOP_BED = 101;
    public static final int LOOP_BED_DERBY = 102;
    public static final int LOOP_RAIN = 103;
    public static final int LOOP_MENU = 104;
    public static final int LOOP_MATCHBED = 105;
    public static final int LOOP_TENSION = 106;

    // ---- event mapping (suggestions 1-8) ----

    /** Bat weight for a ball outcome chip: 0 light (dot/1), 1 medium
     *  (2/3), 2 heavy (4/6), -1 for a wicket (no bat sound). */
    public static int batWeightFor(String lastBall) {
        if (lastBall == null) return -1;
        switch (lastBall) {
            case "0": case "1": return 0;
            case "2": case "3": return 1;
            case "4": case "6": return 2;
            default: return -1;
        }
    }

    public static int batIdForWeight(int w) {
        return w <= 0 ? BAT0 : w == 1 ? BAT1 : BAT2;
    }

    /** Dismissal kind from the scorecard "how" string the engine
     *  writes: 1 bowled ("b X"), 2 lbw ("lbw b X"), 3 run out,
     *  0 anything else (caught etc.). */
    public static int dismissalKind(String how) {
        if (how == null) return 0;
        if (how.startsWith("run out")) return 3;
        if (how.startsWith("lbw")) return 2;
        if (how.startsWith("b ")) return 1;
        return 0;
    }

    /** Which mixer channel a sound belongs to (Settings.CH_*). */
    public static int channelFor(int id) {
        switch (id) {
            case SWELL1: case SWELL2: case SWELL3: case GROAN: case APPLAUSE:
                return Settings.CH_CROWD;
            case UI_CLICK: case UI_CONFIRM: case UI_BLOCKED: case BID_TICK:
            case GAVEL: case CASH:
                return Settings.CH_UI;
            case STING_WIN: case STING_TITLE: case STING_ACHIEVE: case STING_LEVELUP:
                return Settings.CH_MUSIC;
            default:
                return Settings.CH_MATCH;
        }
    }

    /** Quiet Mode (suggestion 24) lets only big events through:
     *  wickets, boundaries, results, titles. */
    public static boolean isBigEvent(int id) {
        switch (id) {
            case BAT2: case STUMPS: case STING_WICKET:
            case SWELL2: case SWELL3: case GROAN:
            case STING_WIN: case STING_TITLE: case STING_LEVELUP:
                return true;
            default:
                return false;
        }
    }

    // ================= buffer generation =================

    public static short[] generate(int id) {
        switch (id) {
            case BAT0: return batHit(0);
            case BAT1: return batHit(1);
            case BAT2: return batHit(2);
            case STUMPS: return stumps();
            case PADS: return pads();
            case SWELL1: return crowdSwell(0, true);
            case SWELL2: return crowdSwell(1, true);
            case SWELL3: return crowdSwell(2, true);
            case GROAN: return crowdSwell(1, false);
            case APPLAUSE: return applause();
            case STING_WICKET: return stingWicket();
            case STING_WIN: return stingWin();
            case STING_TITLE: return stingTitle();
            case STING_ACHIEVE: return stingAchieve();
            case STING_LEVELUP: return stingLevelUp();
            case UI_CLICK: return uiClick();
            case UI_CONFIRM: return confirmChime();
            case UI_BLOCKED: return blockedThud();
            case BID_TICK: return bidTick();
            case GAVEL: return gavel();
            case CASH: return cashChime();
            case LOOP_BED: return crowdBed(6, false);
            case LOOP_BED_DERBY: return crowdBed(6, true);
            case LOOP_RAIN: return rainLoop(4);
            case LOOP_MENU: return menuLoop(8);
            case LOOP_MATCHBED: return matchBedLoop(4);
            case LOOP_TENSION: return tensionLoop(2);
            default: return new short[SR / 10];
        }
    }

    // ---- small DSP helpers ----

    private static float[] sec(double seconds) { return new float[(int) (SR * seconds)]; }

    private static void addSine(float[] b, double freq, double t0, double dur,
                                double amp, double decay) {
        int s = (int) (t0 * SR), n = (int) (dur * SR);
        for (int i = 0; i < n && s + i < b.length; i++) {
            double t = i / (double) SR;
            double env = Math.exp(-decay * t);
            b[s + i] += (float) (amp * env * Math.sin(2 * Math.PI * freq * t));
        }
    }

    /** Triangle-ish tone: fundamental + a little 3rd harmonic. */
    private static void addTri(float[] b, double freq, double t0, double dur,
                               double amp, double decay) {
        addSine(b, freq, t0, dur, amp, decay);
        addSine(b, freq * 3, t0, dur, amp * 0.18, decay * 1.6);
        addSine(b, freq * 2, t0, dur, amp * 0.10, decay * 1.3);
    }

    /** Lowpassed noise burst (one-pole), seeded so tests are stable. */
    private static void addNoise(float[] b, long seed, double t0, double dur,
                                 double amp, double lp, double attack) {
        Random r = new Random(seed);
        int s = (int) (t0 * SR), n = (int) (dur * SR);
        double y = 0;
        for (int i = 0; i < n && s + i < b.length; i++) {
            double t = i / (double) SR;
            double x = r.nextDouble() * 2 - 1;
            y += lp * (x - y);
            double env = Math.min(1, t / Math.max(0.001, attack)) * Math.exp(-3.2 * t / dur);
            b[s + i] += (float) (amp * env * y * 2.4);
        }
    }

    private static short[] finish(float[] b) {
        short[] out = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            double v = Math.tanh(b[i] * 1.15) * 0.92;
            out[i] = (short) Math.max(-32767, Math.min(32767, (int) (v * 32767)));
        }
        return out;
    }

    /** Fold the tail over the head so the buffer loops click-free;
     *  returns a buffer fade-samples shorter than the input. */
    private static short[] seamFold(short[] in, double fadeSec) {
        int fade = (int) (fadeSec * SR);
        if (in.length <= fade * 2) return in;
        short[] out = new short[in.length - fade];
        for (int i = 0; i < out.length; i++) {
            if (i < fade) {
                double w = i / (double) fade;
                out[i] = (short) ((in[i] * w + in[in.length - fade + i] * (1 - w)));
            } else {
                out[i] = in[i];
            }
        }
        return out;
    }

    /** Continuous shaped-noise bed with slow random swells. */
    private static float[] noiseBed(long seed, double seconds, double lp,
                                    double lfoHz, double depth, double base) {
        float[] b = sec(seconds);
        Random r = new Random(seed);
        double y = 0, phase = r.nextDouble() * 6.28;
        double swell = 1, swellT = 0;
        for (int i = 0; i < b.length; i++) {
            double t = i / (double) SR;
            double x = r.nextDouble() * 2 - 1;
            y += lp * (x - y);
            if (i % 2205 == 0) { swellT = 0.75 + r.nextDouble() * 0.5; }
            swell += (swellT - swell) * 0.002;
            double lfo = 1 - depth + depth * (0.5 + 0.5 * Math.sin(2 * Math.PI * lfoHz * t + phase));
            b[i] = (float) (base * lfo * swell * y * 2.2);
        }
        return b;
    }

    // ---- match sounds (1-8) ----

    /** Bat on ball: filtered crack + low thump. Weight 0/1/2 =
     *  defensive / drive / big hit (amplitude + brightness + thump). */
    public static short[] batHit(int weight) {
        float[] b = sec(0.16);
        double lp = weight == 0 ? 0.30 : weight == 1 ? 0.45 : 0.60;
        double amp = weight == 0 ? 0.35 : weight == 1 ? 0.55 : 0.8;
        addNoise(b, 7100 + weight, 0, 0.07, amp, lp, 0.002);
        addSine(b, weight == 2 ? 95 : 120, 0, 0.13, 0.5 + 0.15 * weight, 26);
        return finish(b);
    }

    /** Bowled: wooden clatter — three ticks and a knock. */
    public static short[] stumps() {
        float[] b = sec(0.30);
        addNoise(b, 9201, 0.00, 0.03, 0.75, 0.75, 0.001);
        addNoise(b, 9202, 0.045, 0.03, 0.6, 0.7, 0.001);
        addNoise(b, 9203, 0.11, 0.04, 0.5, 0.65, 0.001);
        addSine(b, 1650, 0, 0.09, 0.22, 30);
        addSine(b, 175, 0.01, 0.16, 0.55, 18);
        return finish(b);
    }

    /** LBW: pads thud + a short crowd lift (the "appeal" is a murmur
     *  swell, not a synthesized voice — a fake shout would sound
     *  worse than none). */
    public static short[] pads() {
        float[] b = sec(0.55);
        addNoise(b, 9301, 0, 0.09, 0.55, 0.16, 0.004);
        addSine(b, 72, 0, 0.16, 0.6, 16);
        float[] swell = noiseBed(9302, 0.55, 0.10, 0, 0, 0.16);
        for (int i = 0; i < b.length; i++) {
            double t = i / (double) SR;
            double env = Math.min(1, t / 0.12) * Math.exp(-2.4 * t);
            b[i] += swell[i] * env * 2.0f;
        }
        return finish(b);
    }

    /** Crowd swell: intensity 0 small / 1 big / 2 winning moment.
     *  Happy = bright rising roar; unhappy = the groan (lower band,
     *  falling shape). */
    public static short[] crowdSwell(int intensity, boolean happy) {
        double dur = intensity == 0 ? 0.9 : intensity == 1 ? 1.5 : 2.6;
        float[] bed = noiseBed(9400 + intensity * 7 + (happy ? 0 : 3),
                dur, happy ? 0.13 : 0.07, 2.2, 0.35, 0.5);
        float[] b = sec(dur);
        for (int i = 0; i < b.length; i++) {
            double t = i / (double) SR;
            double env;
            if (happy) {
                env = Math.min(1, t / (0.10 + 0.08 * intensity))
                        * Math.exp(-1.5 * Math.max(0, t - 0.25) / (0.5 + 0.35 * intensity));
            } else {
                env = Math.min(1, t / 0.15) * Math.exp(-1.9 * t);
            }
            b[i] = (float) (bed[i] * env * (1.5 + 0.45 * intensity));
        }
        if (!happy) { // the groan sags: thin the tail out faster
            for (int i = 0; i < b.length; i++) {
                double t = i / (double) SR;
                b[i] *= (float) Math.exp(-0.7 * t);
            }
        }
        return finish(b);
    }

    /** Milestone applause: pattering hand-clap noise. */
    public static short[] applause() {
        float[] b = sec(1.2);
        Random r = new Random(9501);
        for (int k = 0; k < 46; k++) {
            addNoise(b, 9600 + k, r.nextDouble() * 0.95, 0.035,
                    0.20 + r.nextDouble() * 0.22, 0.55, 0.002);
        }
        return finish(b);
    }

    // ---- stings (13-18 family) ----

    public static short[] stingWicket() {
        float[] b = sec(0.55);
        addTri(b, 196, 0, 0.4, 0.5, 7);
        addTri(b, 98, 0, 0.5, 0.5, 6);
        addNoise(b, 9701, 0, 0.10, 0.3, 0.5, 0.003);
        return finish(b);
    }

    public static short[] stingWin() {
        float[] b = sec(1.15);
        double[] notes = {523.25, 659.25, 783.99, 1046.5};
        for (int i = 0; i < notes.length; i++) addTri(b, notes[i], i * 0.13, 0.55, 0.42, 5);
        addSine(b, 261.6, 0, 1.0, 0.2, 3);
        return finish(b);
    }

    public static short[] stingTitle() {
        float[] b = sec(5.6);
        double[] phrase = {523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.5};
        for (int i = 0; i < phrase.length; i++) addTri(b, phrase[i], i * 0.34, 0.8, 0.4, 4);
        double[] chord = {261.6, 329.6, 392.0, 523.25};
        for (double f : chord) addSine(b, f, 2.6, 2.8, 0.16, 1.1);
        float[] swell = noiseBed(9702, 5.6, 0.11, 0, 0, 0.20);
        for (int i = 0; i < b.length; i++) {
            double t = i / (double) SR;
            b[i] += swell[i] * (float) (Math.min(1, t / 1.2) * Math.exp(-0.35 * Math.max(0, t - 3.4)));
        }
        return finish(b);
    }

    public static short[] stingAchieve() {
        float[] b = sec(0.45);
        addTri(b, 1318.5, 0, 0.3, 0.35, 8);
        addTri(b, 1760.0, 0.10, 0.35, 0.35, 7);
        return finish(b);
    }

    public static short[] stingLevelUp() {
        float[] b = sec(0.85);
        double[] notes = {392.0, 523.25, 659.25, 783.99};
        for (int i = 0; i < notes.length; i++) addTri(b, notes[i], i * 0.11, 0.5, 0.4, 6);
        return finish(b);
    }

    // ---- UI sounds (13-18) ----

    public static short[] uiClick() {
        float[] b = sec(0.05);
        addNoise(b, 9801, 0, 0.03, 0.4, 0.6, 0.001);
        addSine(b, 2400, 0, 0.03, 0.12, 60);
        return finish(b);
    }

    public static short[] confirmChime() {
        float[] b = sec(0.38);
        addSine(b, 880, 0, 0.3, 0.32, 9);
        addSine(b, 880 * 2.76, 0, 0.12, 0.06, 22);
        addSine(b, 1318.5, 0.09, 0.3, 0.32, 8);
        addSine(b, 1318.5 * 2.76, 0.09, 0.12, 0.05, 22);
        return finish(b);
    }

    public static short[] blockedThud() {
        float[] b = sec(0.17);
        addSine(b, 64, 0, 0.16, 0.75, 14);
        addNoise(b, 9802, 0, 0.05, 0.25, 0.12, 0.003);
        return finish(b);
    }

    public static short[] bidTick() {
        float[] b = sec(0.055);
        addSine(b, 2050, 0, 0.045, 0.35, 55);
        addNoise(b, 9803, 0, 0.02, 0.2, 0.7, 0.001);
        return finish(b);
    }

    public static short[] gavel() {
        float[] b = sec(0.32);
        addNoise(b, 9804, 0, 0.03, 0.7, 0.5, 0.001);
        addSine(b, 300, 0, 0.08, 0.5, 30);
        addNoise(b, 9805, 0.10, 0.03, 0.6, 0.5, 0.001);
        addSine(b, 280, 0.10, 0.10, 0.45, 26);
        return finish(b);
    }

    /** Cash register hint: two quick metallic partials, kept subtle. */
    public static short[] cashChime() {
        float[] b = sec(0.42);
        addSine(b, 1567.98, 0, 0.16, 0.28, 16);
        addSine(b, 2093.0, 0.07, 0.3, 0.28, 11);
        addSine(b, 2093.0 * 2.4, 0.07, 0.1, 0.05, 26);
        return finish(b);
    }

    // ---- loops (9-12, 19-20) ----

    public static short[] crowdBed(int seconds, boolean derby) {
        float[] b = noiseBed(derby ? 9902 : 9901, seconds + 0.6,
                derby ? 0.12 : 0.09, 0.35, 0.4, derby ? 0.5 : 0.42);
        return seamFold(finish(b), 0.6);
    }

    public static short[] rainLoop(int seconds) {
        float[] b = noiseBed(9911, seconds + 0.5, 0.35, 0, 0, 0.30);
        Random r = new Random(9912);
        for (int k = 0; k < 90; k++) {
            addNoise(b, 9920 + k, r.nextDouble() * seconds, 0.015,
                    0.10 + r.nextDouble() * 0.10, 0.8, 0.001);
        }
        return seamFold(finish(b), 0.5);
    }

    /** Menu theme: a calm Am-F-C-G pad, one chord every 2 seconds. */
    public static short[] menuLoop(int seconds) {
        float[] b = sec(seconds + 0.8);
        double[][] chords = {
                {220.0, 261.63, 329.63}, {174.61, 220.0, 261.63},
                {261.63, 329.63, 392.0}, {196.0, 246.94, 293.66}};
        for (int c = 0; c < 4; c++) {
            for (double f : chords[c]) {
                addPad(b, f, c * 2.0, 2.3, 0.16);
                addPad(b, f * 2, c * 2.0, 2.3, 0.05);
            }
        }
        return seamFold(finish(b), 0.8);
    }

    /** Match bed: a low, tense pulse under live play. */
    public static short[] matchBedLoop(int seconds) {
        float[] b = sec(seconds + 0.5);
        for (int beat = 0; beat < seconds * 2; beat++) {
            addSine(b, 55, beat * 0.5, 0.30, 0.5, 9);
            addSine(b, 110, beat * 0.5, 0.2, 0.15, 11);
        }
        addPad(b, 146.83, 0, seconds, 0.07);
        addPad(b, 220.0, 0, seconds, 0.05);
        return seamFold(finish(b), 0.5);
    }

    /** Last-overs tension: a slow low throb, ~1 pulse a second. */
    public static short[] tensionLoop(int seconds) {
        float[] b = sec(seconds + 0.4);
        for (int beat = 0; beat < seconds; beat++) {
            addSine(b, 48, beat * 1.0, 0.55, 0.65, 5.5);
            addSine(b, 96, beat * 1.0, 0.3, 0.2, 8);
        }
        return seamFold(finish(b), 0.4);
    }

    /** Slow-attack pad tone (no decay — envelope shaped here). */
    private static void addPad(float[] b, double freq, double t0, double dur, double amp) {
        int s = (int) (t0 * SR), n = (int) (dur * SR);
        for (int i = 0; i < n && s + i < b.length; i++) {
            double t = i / (double) SR;
            double env = Math.min(1, t / 0.6) * Math.min(1, (dur - t) / 0.6);
            if (env < 0) env = 0;
            b[s + i] += (float) (amp * env * Math.sin(2 * Math.PI * freq * t));
        }
    }
}
