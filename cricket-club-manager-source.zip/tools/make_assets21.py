#!/usr/bin/env python3
"""Cricket Club Manager — v21 OVERHAUL asset pipeline.

Extends the v20 pipeline (make_assets.py stays as the v20 record).
Everything here is REAL produced media, generated offline:

  AUDIO   rain.ogg + tension.ogg — the two loops v20 still
          synthesized at runtime (numpy synthesis, like v20's beds),
          so v21 can delete the SoundSynth engine class entirely.
  VOICE   the spoken score-update clip library, generated with the
          flite TTS voice compiled into ffmpeg (CMU Flite, voice
          "slt"). Composable number clips (0-20, tens, hundred) +
          phrase clips + the 8 club names (full + short). The app
          stitches clips into score lines (VoiceLine.java).
  ART     realistic set (stadium interior / dressing room /
          training nets from rich-media/raw2), per-club THEME PACKS
          (club-graded banner + panel art), animated-splash frames,
          metallic player-card tier frames, graded AVATAR variants
          from the fictional portrait grid, crests v2 (richer PIL
          shields overwriting the v20 files), League + Cup emblems,
          and accurate national FLAGS for the 12 World nations.

Run:  python3 tools/make_assets21.py
"""
import math
import os
import subprocess
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "assets")
RAW = os.path.join(ROOT, "..", "rich-media", "raw")
RAW2 = os.path.join(ROOT, "..", "rich-media", "raw2")
SR = 22050

TOTAL = [0]


def report(name, path):
    sz = os.path.getsize(path)
    TOTAL[0] += sz
    print(f"  {name:34s} {sz:>9,} B")


def darken(c, f):
    return tuple(max(0, int(v * f)) for v in c)


def lighten(c, f):
    return tuple(min(255, int(v + (255 - v) * f)) for v in c)


def raw_file(folder, stem):
    for f in sorted(os.listdir(folder)):
        if stem in f and f.endswith(".webp"):
            return os.path.join(folder, f)
    raise FileNotFoundError(stem)


def save_webp(im, name, q=85):
    dst = os.path.join(ASSETS, "art", name)
    im.save(dst, "WEBP", quality=q, method=6)
    report(name, dst)


# ================= AUDIO: the two ex-synth loops =================

def _seam(buf, sr, fade_s=0.35):
    n = int(sr * fade_s)
    if buf.ndim == 1:
        head = buf[:n].copy()
        buf[:n] = buf[:n] * np.linspace(0, 1, n) + buf[-n:] * np.linspace(1, 0, n)
        buf[-n:] = buf[-n:] * 0.0 + head * 0.0 + buf[-n:]  # tail untouched
    else:
        w = np.linspace(0, 1, n)[:, None]
        buf[:n] = buf[:n] * w + buf[-n:] * (1 - w)
    return buf


def rain():
    """Rain patter: layered filtered noise, stereo, 6 s seamless."""
    r = np.random.default_rng(41)
    dur = 6.0
    n = int(SR * dur)
    out = []
    for ch in range(2):
        w = r.normal(0, 1, n)
        # patter = highpassed hiss + a softer mid wash
        hp = np.diff(w, prepend=w[0]) * 0.55
        lp = np.convolve(w, np.ones(24) / 24, mode="same") * 0.5
        x = hp + lp
        # gust envelope: slow swells
        t = np.arange(n) / SR
        env = 0.75 + 0.25 * np.sin(2 * np.pi * 0.31 * t + ch * 1.7) \
            * np.sin(2 * np.pi * 0.083 * t + ch)
        x = x * env
        x = np.tanh(x * 1.4) * 0.5
        out.append(x)
    buf = np.stack(out, axis=1)
    buf = _seam(buf, SR, 0.5)
    pcm = (np.clip(buf, -1, 1) * 32767).astype(np.int16)
    tmp = "/tmp/_rain.wav"
    _write_wav(tmp, pcm, SR)
    dst = os.path.join(ASSETS, "audio", "rain.ogg")
    _to_ogg(tmp, dst, "64k")
    report("rain.ogg", dst)


def tension():
    """Last-overs tension throb: low heartbeat pulse, 4 s seamless."""
    dur = 4.0
    n = int(SR * dur)
    t = np.arange(n) / SR
    # heartbeat: two thumps per 2 s cycle, crossfaded seam by construction
    phase = (t % 2.0)
    thump = np.exp(-((phase - 0.12) ** 2) / 0.004) + 0.7 * np.exp(-((phase - 0.38) ** 2) / 0.005)
    tone = np.sin(2 * np.pi * 55 * t) + 0.5 * np.sin(2 * np.pi * 82.5 * t)
    r = np.random.default_rng(7)
    wash = np.convolve(r.normal(0, 1, n), np.ones(400) / 400, mode="same") * 2.0
    x = tone * (0.25 + 0.75 * thump) * 0.5 + wash * 0.12 * (0.5 + thump)
    x = np.tanh(x * 1.2) * 0.55
    buf = np.stack([x, x * 0.96], axis=1)
    pcm = (np.clip(buf, -1, 1) * 32767).astype(np.int16)
    tmp = "/tmp/_tension.wav"
    _write_wav(tmp, pcm, SR)
    dst = os.path.join(ASSETS, "audio", "tension.ogg")
    _to_ogg(tmp, dst, "64k")
    report("tension.ogg", dst)


def _write_wav(path, pcm, sr):
    import wave
    with wave.open(path, "wb") as w:
        w.setnchannels(pcm.shape[1] if pcm.ndim > 1 else 1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def _to_ogg(wav, dst, bitrate):
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", wav,
                    "-c:a", "libvorbis", "-b:a", bitrate, dst], check=True)


# ================= VOICE PACK (flite TTS via ffmpeg) =================

CLUBS = {  # key -> (code, primary, secondary, stars) — mirror Design.clubColors
    "lahore":    ("LAH", (245, 158, 11), (22, 163, 74), 3),
    "karachi":   ("KAR", (37, 99, 235), (245, 158, 11), 2),
    "islamabad": ("ISL", (220, 38, 38), (249, 115, 22), 3),
    "multan":    ("MUL", (13, 148, 136), (132, 204, 22), 2),
    "peshawar":  ("PES", (250, 204, 21), (51, 65, 85), 2),
    "quetta":    ("QUE", (124, 58, 237), (245, 158, 11), 2),
    "sialkot":   ("SIA", (159, 18, 57), (192, 198, 206), 1),
    "hyderabad": ("HYD", (22, 163, 74), (250, 204, 21), 1),
}
CLUB_FULL = {
    "lahore": "Lahore Qalandars", "karachi": "Karachi Kings",
    "islamabad": "Islamabad United", "multan": "Multan Sultans",
    "peshawar": "Peshawar Zalmi", "quetta": "Quetta Gladiators",
    "sialkot": "Sialkot Stallions", "hyderabad": "Hyderabad Hawks",
}
CLUB_SHORT = {k: v.split()[0] for k, v in CLUB_FULL.items()}

NUM_WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven",
             "eight", "nine", "ten", "eleven", "twelve", "thirteen",
             "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
             "nineteen", "twenty"]
TENS_WORDS = {30: "thirty", 40: "forty", 50: "fifty", 60: "sixty",
              70: "seventy", 80: "eighty", 90: "ninety"}
PHRASES = {
    "innings_break": "Innings break.",
    "the_target_is": "The target is",
    "set_a_target_of": "set a target of",
    "need": "need",
    "off": "off",
    "balls": "balls",
    "runs": "runs",
    "wickets": "wickets",
    "won_by": "won by",
    "won": "won",
    "and": "and",
    "player_of_the_match": "Player of the match.",
    "match_tied": "The match is tied.",
    "fifty": "fifty",
}


def voice():
    outdir = os.path.join(ASSETS, "voice")
    os.makedirs(outdir, exist_ok=True)
    clips = {}
    for i, w in enumerate(NUM_WORDS):
        clips[f"v_n{i}"] = w
    for n, w in TENS_WORDS.items():
        clips[f"v_n{n}"] = w
    clips["v_hundred"] = "hundred"
    for k, text in PHRASES.items():
        clips[f"v_{k}"] = text
    for key in CLUBS:
        clips[f"v_t_{key}"] = CLUB_FULL[key]
        clips[f"v_ts_{key}"] = CLUB_SHORT[key]
    made = 0
    for name, text in sorted(clips.items()):
        dst = os.path.join(outdir, name + ".ogg")
        src = f"flite=text='{text}':voice=slt"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi",
                        "-i", src, "-ar", "22050", "-ac", "1",
                        "-c:a", "libvorbis", "-b:a", "28k", dst], check=True)
        report(name + ".ogg", dst)
        made += 1
    print(f"  voice clips generated: {made}")


# ================= REALISTIC ART SET (item 13) =================

def realistic():
    jobs = [
        ("media-generation-stadium-interior-real", "art_interior.webp", 1400),
        ("media-generation-dressing-room-real", "art_dressing.webp", 1400),
        ("media-generation-training-nets-real", "art_nets.webp", 1400),
    ]
    for stem, name, w in jobs:
        im = Image.open(raw_file(RAW2, stem)).convert("RGB")
        if im.width > w:
            im = im.resize((w, int(im.height * w / im.width)), Image.LANCZOS)
        save_webp(im, name, 82)


# ================= THEME FACTORY (item 1) =================

def _grade(im, primary, secondary, top_w=0.34, bot_w=0.16):
    """Blend club colours into an image: the primary washes the top,
    the secondary glows along the bottom, the middle stays photographic."""
    im = im.convert("RGB")
    W, H = im.size
    arr = np.asarray(im).astype(np.float32)
    ys = np.linspace(0, 1, H)[:, None]
    wtop = np.clip(1 - ys * 2.2, 0, 1) * top_w
    wbot = np.clip((ys - 0.72) / 0.28, 0, 1) * bot_w
    pri = np.array(primary, dtype=np.float32)[None, None, :]
    sec = np.array(secondary, dtype=np.float32)[None, None, :]
    arr = arr * (1 - wtop[:, :, None] - wbot[:, :, None]) \
        + pri * wtop[:, :, None] + sec * wbot[:, :, None]
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


def theme_packs():
    interior = Image.open(raw_file(RAW2, "media-generation-stadium-interior-real")).convert("RGB")
    pitch = Image.open(raw_file(RAW, "media-generation-matchday-pitch")).convert("RGB")
    for key, (code, pri, sec, _s) in CLUBS.items():
        # banner: wide stadium band graded in the club's colours
        bw = 1400
        band = interior.crop((0, 240, 1920, 240 + 900))
        band = band.resize((bw, int(band.height * bw / band.width)), Image.LANCZOS)
        band = band.crop((0, 0, bw, 560))
        save_webp(_grade(band, pri, sec), f"theme_{key}.webp", 82)
        # panel: darker graded pitch art for cards / versus sides
        pw = 1000
        pan = pitch.resize((pw, int(pitch.height * pw / pitch.width)), Image.LANCZOS)
        pan = pan.crop((0, 60, pw, 60 + 420))
        pan = _grade(pan, pri, sec, top_w=0.20, bot_w=0.10)
        pan = pan.point(lambda v: int(v * 0.82))
        save_webp(pan, f"themepanel_{key}.webp", 80)


# ================= ANIMATED SPLASH (item 4) =================

def splash_frames(frames=14):
    hero = Image.open(raw_file(RAW, "media-generation-stadium-night-hero")).convert("RGB")
    W = 700
    hero = hero.resize((W, int(hero.height * W / hero.width)), Image.LANCZOS)
    H = hero.height
    # floodlight bloom centres (fractions of the frame)
    lights = [(0.16, 0.16), (0.84, 0.16), (0.30, 0.30), (0.70, 0.30)]
    base = np.asarray(hero).astype(np.float32)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    for i in range(frames):
        t = i / (frames - 1)
        pulse = 0.55 + 0.45 * math.sin(t * math.pi)          # swell in, settle
        glow = np.zeros((H, W), dtype=np.float32)
        for fx, fy in lights:
            d2 = ((xx - fx * W) ** 2 + (yy - fy * H) ** 2) / (0.16 * W) ** 2
            glow += np.exp(-d2)
        glow = np.clip(glow, 0, 1.4) * (46 * pulse)
        warm = np.array([1.0, 0.86, 0.58], dtype=np.float32)
        arr = base * (1 + 0.05 * math.sin(t * math.pi)) + glow[:, :, None] * warm[None, None, :]
        save_webp(Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)),
                  f"splash_{i:02d}.webp", 74)


# ================= CARD TIER FRAMES (item 3) =================

TIERS = {  # name -> (bright, deep, sparkle?)
    "bronze": ((198, 140, 92), (96, 60, 32), False),
    "silver": ((216, 222, 230), (104, 112, 124), False),
    "gold":   ((251, 191, 36), (146, 90, 6), False),
    "elite":  ((94, 234, 212), (13, 96, 84), True),
}


def tier_frames():
    W, H, B = 1080, 372, 30
    for name, (bright, deep, sparkle) in TIERS.items():
        im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(im, "RGBA")
        # metallic border: stacked rounded strokes interpolating deep->bright->deep
        steps = 14
        for s in range(steps):
            f = s / (steps - 1)
            col = tuple(int(deep[j] + (bright[j] - deep[j]) * math.sin(f * math.pi)) for j in range(3))
            off = 2 + s * (B - 4) / steps
            d.rounded_rectangle([off, off, W - off, H - off], radius=42 - off * 0.4,
                                outline=col + (255,), width=3)
        # corner ornaments: diamonds + rivets
        for cx, cy in [(B + 16, B + 16), (W - B - 16, B + 16),
                       (B + 16, H - B - 16), (W - B - 16, H - B - 16)]:
            r = 11
            d.polygon([(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)],
                      fill=bright + (255,), outline=(255, 255, 255, 190))
            d.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=(20, 24, 34, 255))
        if sparkle:
            r = np.random.default_rng(3)
            for _ in range(26):
                x, y = r.uniform(8, W - 8), r.uniform(8, H - 8)
                if B - 6 < x < W - B + 6 and B - 6 < y < H - B + 6 and not (
                        B + 26 < x < W - B - 26 and B + 26 < y < H - B - 26):
                    d.ellipse([x - 2, y - 2, x + 2, y + 2], fill=(255, 255, 255, 170))
        # hairline inner edge
        d.rounded_rectangle([B + 4, B + 4, W - B - 4, H - B - 4], radius=28,
                            outline=(255, 255, 255, 60), width=2)
        save_webp(im, f"frame_{name}.webp", 88)


# ================= AVATARS (item 14) =================

def avatars():
    grid = Image.open(raw_file(RAW2, "media-generation-player-portraits-grid")).convert("RGB")
    gw, gh = grid.size
    quads = []
    for i in range(4):
        x = (i % 2) * gw // 2
        y = (i // 2) * gh // 2
        q = grid.crop((x + 26, y + 26, x + gw // 2 - 26, y + gh // 2 - 26))
        q = q.resize((288, 288), Image.LANCZOS)
        quads.append(q)
    variants = {"neutral": None}
    variants.update({k: v[1] for k, v in CLUBS.items()})  # slug -> primary
    for slug, pri in variants.items():
        for i, q in enumerate(quads):
            im = q.copy()
            if pri is not None:
                # kit-colour grade: club wash rising from the bottom
                arr = np.asarray(im).astype(np.float32)
                ys = np.linspace(0, 1, im.height)[:, None]
                w = np.clip((ys - 0.52) / 0.48, 0, 1) * 0.34
                col = np.array(pri, dtype=np.float32)[None, None, :]
                arr = arr * (1 - w[:, :, None]) + col * w[:, :, None]
                im = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
                d = ImageDraw.Draw(im, "RGBA")
                d.rounded_rectangle([3, 3, im.width - 4, im.height - 4], radius=26,
                                    outline=pri + (255,), width=7)
            else:
                d = ImageDraw.Draw(im, "RGBA")
                d.rounded_rectangle([3, 3, im.width - 4, im.height - 4], radius=26,
                                    outline=(100, 116, 139, 255), width=7)
            save_webp(im, f"avatar_{slug}_{i}.webp", 84)
    # the four clean base portraits too
    for i, q in enumerate(quads):
        save_webp(q, f"portrait_{i}.webp", 86)


def star(d, cx, cy, r, color):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.45
        pts.append((cx + math.cos(ang) * rad, cy + math.sin(ang) * rad))
    d.polygon(pts, fill=color)


# ================= CRESTS v2 (item 15) =================

def _quad(p0, p1, p2, steps=14):
    pts = []
    for i in range(1, steps + 1):
        t = i / steps
        pts.append(((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t ** 2 * p2[0],
                    (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t ** 2 * p2[1]))
    return pts


def _shield_points(W, H):
    pts = [(0.06 * W, 0.03 * H), (0.94 * W, 0.03 * H), (0.94 * W, 0.50 * H)]
    pts += _quad((0.94 * W, 0.50 * H), (0.93 * W, 0.86 * H), (0.50 * W, 0.97 * H))
    pts += _quad((0.50 * W, 0.97 * H), (0.07 * W, 0.86 * H), (0.06 * W, 0.50 * H))
    pts.append((0.06 * W, 0.03 * H))
    return pts


def crest2(key, code, primary, secondary, stars):
    W, H = 512, 574
    shield = _shield_points(W, H)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).polygon(shield, fill=255)

    def clipped(layer):
        base = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        return Image.composite(layer, base, mask)

    # 1) metallic body: primary -> highlight band -> deep base
    ga = np.zeros((H, W, 4), dtype=np.uint8)
    top = np.array(lighten(primary, 0.18), dtype=np.float32)
    mid = np.array(primary, dtype=np.float32)
    bot = np.array(darken(primary, 0.34), dtype=np.float32)
    ys = np.arange(H) / H
    grad = np.where((ys < 0.45)[:, None],
                    top[None, :] + (mid - top)[None, :] * (ys / 0.45)[:, None],
                    mid[None, :] + (bot - mid)[None, :] * ((ys - 0.45) / 0.55)[:, None])
    ga[:, :, :3] = grad[:, None, :].repeat(W, axis=1).astype(np.uint8)
    ga[:, :, 3] = 255
    im = clipped(Image.fromarray(ga, "RGBA"))
    # brushed-metal noise
    r = np.random.default_rng(hash(key) & 0xFFFF)
    noise = (r.normal(0, 5, (H, W, 1)).repeat(3, axis=2)).astype(np.int16)
    arr = np.asarray(im).astype(np.int16)
    arr[:, :, :3] = np.clip(arr[:, :, :3] + noise * (arr[:, :, 3:4] > 0), 0, 255)
    im = Image.fromarray(arr.astype(np.uint8), "RGBA")
    # 2) embossed sash: dark offset shadow, body, top highlight line
    for dx, dy, col, a in [(5, 6, (0, 0, 0), 110), (0, 0, secondary, 205)]:
        sash = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(sash).polygon(
            [(0.52 * W + dx, dy), (0.90 * W + dx, dy), (0.36 * W + dx, H + dy), (0.04 * W + dx, H + dy)],
            fill=col + (a,))
        im = Image.alpha_composite(im, clipped(sash))
    hl = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(hl).line([(0.545 * W, 0), (0.085 * W, H)], fill=(255, 255, 255, 90), width=4)
    im = Image.alpha_composite(im, clipped(hl))
    # 3) sheen
    shine = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(shine).ellipse([-0.25 * W, -0.40 * H, 0.85 * W, 0.30 * H], fill=(255, 255, 255, 34))
    im = Image.alpha_composite(im, clipped(shine.filter(ImageFilter.GaussianBlur(16))))
    # 4) chest band with a thin secondary rule under it
    band = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(band)
    bd.rectangle([0, 0.335 * H, W, 0.615 * H], fill=(8, 12, 22, 248))
    bd.rectangle([0, 0.615 * H, W, 0.632 * H], fill=secondary + (255,))
    im = Image.alpha_composite(im, clipped(band))

    d = ImageDraw.Draw(im, "RGBA")
    for i in range(stars):
        star(d, W * (0.5 + (i - (stars - 1) / 2.0) * 0.13), 0.165 * H, 0.052 * W, (252, 211, 77, 255))
    try:
        font = ImageFont.truetype(os.path.join(ASSETS, "fonts", "font_display.ttf"), int(H * 0.235))
    except Exception:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", int(H * 0.235))
    # embossed initials: dark drop, light top edge, white face
    d.text((W / 2, 0.475 * H + 3), code, font=font, fill=(0, 0, 0, 160), anchor="mm")
    d.text((W / 2, 0.475 * H - 2), code, font=font, fill=(255, 255, 255, 90), anchor="mm")
    d.text((W / 2, 0.475 * H), code, font=font, fill=(255, 255, 255, 255), anchor="mm")
    # ball with shaded seam
    bx, by, br = W / 2, 0.80 * H, 0.085 * W
    d.ellipse([bx - br, by - br, bx + br, by + br], fill=(150, 26, 34, 255))
    d.ellipse([bx - br, by - br, bx + br * 0.2, by + br * 0.2], fill=(196, 44, 54, 120))
    d.ellipse([bx - br, by - br, bx + br, by + br], outline=(255, 255, 255, 190), width=3)
    for sgn in (-1, 1):
        x = bx + sgn * br * 0.45
        d.arc([x - br * 0.5, by - br * 0.82, x + br * 0.5, by + br * 0.82],
              90, 270 if sgn < 0 else -90, fill=(255, 255, 255, 220), width=3)
    # double bevel: outer light, inner dark
    d.line(shield, fill=(255, 255, 255, 215), width=6, joint="curve")
    inner = [(x + (W / 2 - x) * 0.035, y + (H / 2 - y) * 0.035) for x, y in shield]
    d.line(inner, fill=(0, 0, 0, 130), width=3, joint="curve")
    save_webp(im, f"crest_{key}.webp", 92)


def emblems():
    for kind in ("league", "cup"):
        W = H = 512
        im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(im, "RGBA")
        cx = cy = W / 2
        if kind == "league":
            for rr, col in [(238, (146, 90, 6, 255)), (226, (251, 191, 36, 255)),
                            (206, (12, 20, 38, 255)), (196, (20, 32, 56, 255))]:
                d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=col)
            for i in range(12):
                star(d, cx + 178 * math.cos(i * math.pi / 6), cy + 178 * math.sin(i * math.pi / 6),
                     10, (251, 191, 36, 255))
        else:
            shield = _shield_points(W, H)
            d.polygon(shield, fill=(12, 20, 38, 255))
            d.line(shield, fill=(251, 191, 36, 255), width=10, joint="curve")
            inner = [(x + (W / 2 - x) * 0.06, y + (H / 2 - y) * 0.06) for x, y in shield]
            d.line(inner, fill=(146, 90, 6, 255), width=4, joint="curve")
            cy = H * 0.47
        # trophy glyph
        gold, gold_d = (251, 191, 36, 255), (180, 120, 20, 255)
        d.polygon([(cx - 74, cy - 96), (cx + 74, cy - 96), (cx + 52, cy + 6), (cx - 52, cy + 6)], fill=gold)
        d.arc([cx - 118, cy - 100, cx - 40, cy - 6], 90, 270, fill=gold, width=13)
        d.arc([cx + 40, cy - 100, cx + 118, cy - 6], 270, 90, fill=gold, width=13)
        d.rectangle([cx - 13, cy + 6, cx + 13, cy + 46], fill=gold_d)
        d.rectangle([cx - 52, cy + 46, cx + 52, cy + 66], fill=gold)
        d.rectangle([cx - 66, cy + 66, cx + 66, cy + 84], fill=gold_d)
        d.polygon([(cx - 74, cy - 96), (cx + 74, cy - 96), (cx + 66, cy - 62), (cx - 66, cy - 62)],
                  fill=(255, 226, 130, 255))
        if kind == "cup":
            for sgn in (-1, 1):
                for i in range(5):
                    a = math.radians(215 + sgn * i * 16) if sgn < 0 else math.radians(-35 - (4 - i) * -16)
                    lx = cx + sgn * (118 + i * 4)
                    ly = cy + 62 - i * 22
                    d.ellipse([lx - 13, ly - 7, lx + 13, ly + 7], fill=(34, 140, 74, 255))
        save_webp(im, f"emblem_{kind}.webp", 92)


# ================= FLAGS (item 16) =================

def _union_jack(d, x, y, w, h):
    d.rectangle([x, y, x + w, y + h], fill=(1, 33, 105))
    d.line([x, y, x + w, y + h], fill=(255, 255, 255), width=int(h * 0.20))
    d.line([x + w, y, x, y + h], fill=(255, 255, 255), width=int(h * 0.20))
    d.line([x, y, x + w, y + h], fill=(200, 16, 46), width=int(h * 0.07))
    d.line([x + w, y, x, y + h], fill=(200, 16, 46), width=int(h * 0.07))
    d.rectangle([x + w * 0.375, y, x + w * 0.625, y + h], fill=(255, 255, 255))
    d.rectangle([x, y + h * 0.333, x + w, y + h * 0.667], fill=(255, 255, 255))
    d.rectangle([x + w * 0.425, y, x + w * 0.575, y + h], fill=(200, 16, 46))
    d.rectangle([x, y + h * 0.40, x + w, y + h * 0.60], fill=(200, 16, 46))


def _crescent(d, cx, cy, r, color, bg):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
    d.ellipse([cx - r * 0.28, cy - r * 0.92, cx + r * 1.35, cy + r * 0.92], fill=bg)


def flags():
    FW, FH = 360, 240

    def base(color):
        im = Image.new("RGB", (FW, FH), color)
        return im, ImageDraw.Draw(im)

    def done(im, code):
        save_webp(im, f"flag_{code.lower()}.webp", 90)

    # AUS
    im, d = base((0, 36, 125))
    _union_jack(d, 0, 0, FW // 2, FH // 2)
    star(d, FW * 0.25, FH * 0.75, 17, (255, 255, 255))           # Commonwealth star
    for sx, sy, sr in [(0.72, 0.18, 11), (0.72, 0.52, 11), (0.63, 0.38, 11),
                       (0.82, 0.36, 11), (0.755, 0.42, 8)]:      # Southern Cross
        star(d, FW * sx, FH * sy, sr, (255, 255, 255))
    done(im, "AUS")
    # NZ
    im, d = base((0, 36, 125))
    _union_jack(d, 0, 0, FW // 2, FH // 2)
    for sx, sy in [(0.75, 0.16), (0.75, 0.42), (0.75, 0.68), (0.66, 0.55)]:
        star(d, FW * sx, FH * sy, 13, (255, 255, 255))
        star(d, FW * sx, FH * sy, 10, (204, 20, 43))
    done(im, "NZ")
    # IND
    im, d = base((255, 255, 255))
    d.rectangle([0, 0, FW, FH // 3], fill=(255, 153, 51))
    d.rectangle([0, 2 * FH // 3, FW, FH], fill=(19, 136, 8))
    cx, cy, r = FW / 2, FH / 2, FH / 6 - 4
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(0, 0, 128), width=5)
    for i in range(24):
        a = i * math.pi / 12
        d.line([cx, cy, cx + r * 0.92 * math.cos(a), cy + r * 0.92 * math.sin(a)],
               fill=(0, 0, 128), width=2)
    d.ellipse([cx - 5, cy - 5, cx + 5, cy + 5], fill=(0, 0, 128))
    done(im, "IND")
    # ENG
    im, d = base((255, 255, 255))
    d.rectangle([FW * 0.425, 0, FW * 0.575, FH], fill=(206, 17, 38))
    d.rectangle([0, FH * 0.40, FW, FH * 0.60], fill=(206, 17, 38))
    done(im, "ENG")
    # PAK
    im, d = base((1, 65, 28))
    d.rectangle([0, 0, FW * 0.25, FH], fill=(255, 255, 255))
    _crescent(d, FW * 0.60, FH * 0.50, FH * 0.26, (255, 255, 255), (1, 65, 28))
    star(d, FW * 0.685, FH * 0.315, 15, (255, 255, 255))
    done(im, "PAK")
    # WI
    im, d = base((121, 36, 46))
    cx, cy, r = FW / 2, FH / 2, FH * 0.30
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(242, 168, 0))
    for i, dx in enumerate([-16, 0, 16]):                          # wicket stumps
        d.rounded_rectangle([cx + dx - 5, cy - 22, cx + dx + 5, cy + 30], radius=4,
                            fill=(0, 105, 62))
    d.rectangle([cx - 24, cy - 30, cx - 2, cy - 24], fill=(0, 105, 62))
    d.rectangle([cx + 2, cy - 30, cx + 24, cy - 24], fill=(0, 105, 62))
    done(im, "WI")
    # SL
    im, d = base((141, 21, 58))
    d.rectangle([6, 6, FW - 6, FH - 6], outline=(255, 190, 0), width=6)
    d.rectangle([14, 14, 14 + FW * 0.16, FH - 14], fill=(0, 83, 78))
    d.rectangle([14 + FW * 0.16, 14, 14 + FW * 0.30, FH - 14], fill=(235, 116, 0))
    cx, cy = FW * 0.63, FH * 0.52                              # sword emblem (simplified)
    d.ellipse([cx - 44, cy - 44, cx + 44, cy + 44], outline=(255, 190, 0), width=5)
    d.line([cx, cy - 34, cx, cy + 22], fill=(255, 190, 0), width=7)
    d.line([cx - 14, cy + 22, cx + 14, cy + 22], fill=(255, 190, 0), width=6)
    d.ellipse([cx - 6, cy + 26, cx + 6, cy + 38], fill=(255, 190, 0))
    for bx, by in [(0.40, 0.14), (0.90, 0.14), (0.40, 0.90), (0.90, 0.90)]:  # bo leaves
        d.polygon([(FW * bx, FH * by - 10), (FW * bx + 8, FH * by + 8),
                   (FW * bx, FH * by + 14), (FW * bx - 8, FH * by + 8)], fill=(255, 190, 0))
    done(im, "SL")
    # AFG
    im, d = base((0, 0, 0))
    d.rectangle([FW / 3, 0, 2 * FW / 3, FH], fill=(211, 32, 17))
    d.rectangle([2 * FW / 3, 0, FW, FH], fill=(0, 122, 61))
    cx, cy = FW / 2, FH * 0.46
    for i in range(9):                                            # sun rays
        a = math.pi * (0.08 + i * 0.105)
        d.line([cx, cy + 16, cx + 52 * math.cos(a), cy + 16 - 52 * math.sin(a)],
               fill=(255, 215, 0), width=4)
    d.pieslice([cx - 34, cy - 12, cx + 34, cy + 56], 180, 360, fill=(255, 255, 255))  # dome
    d.line([cx - 44, cy + 22, cx - 44, cy - 8], fill=(255, 255, 255), width=5)
    d.line([cx + 44, cy + 22, cx + 44, cy - 8], fill=(255, 255, 255), width=5)
    d.rectangle([cx - 52, cy + 22, cx + 52, cy + 30], fill=(255, 215, 0))
    done(im, "AFG")
    # ZIM
    im, d = base((255, 255, 255))
    cols = [(0, 158, 96), (255, 210, 0), (222, 32, 39), (0, 0, 0),
            (222, 32, 39), (255, 210, 0), (0, 158, 96)]
    for i, c in enumerate(cols):
        d.rectangle([0, i * FH // 7, FW, (i + 1) * FH // 7], fill=c)
    d.polygon([(0, 0), (FW * 0.42, FH / 2), (0, FH)], fill=(255, 255, 255),
              outline=(0, 0, 0))
    star(d, FW * 0.14, FH * 0.5, 26, (222, 32, 39))
    d.polygon([(FW * 0.14, FH * 0.40), (FW * 0.185, FH * 0.5), (FW * 0.14, FH * 0.60),
               (FW * 0.125, FH * 0.5)], fill=(255, 210, 0))       # bird (simplified)
    done(im, "ZIM")
    # IRE
    im, d = base((255, 255, 255))
    d.rectangle([0, 0, FW / 3, FH], fill=(22, 155, 98))
    d.rectangle([2 * FW / 3, 0, FW, FH], fill=(255, 136, 62))
    done(im, "IRE")
    # SA — green Y fimbriated in gold, blue/red fields, black hoist triangle
    im, d = base((0, 119, 200))
    d.polygon([(0, FH), (FW, FH), (FW, FH * 0.62), (FW * 0.38, FH * 0.5), (0, FH * 0.72)],
              fill=(224, 16, 52))
    yband = [(0, FH * 0.30), (FW * 0.34, FH * 0.44), (FW, FH * 0.44), (FW, FH * 0.56),
             (FW * 0.34, FH * 0.56), (0, FH * 0.70)]
    d.polygon([(x, y + (6 if y > FH / 2 else -6)) for x, y in yband], fill=(255, 182, 18))
    d.polygon(yband, fill=(0, 119, 73))
    tri = [(0, FH * 0.345), (FW * 0.315, FH * 0.5), (0, FH * 0.655)]
    d.polygon([(x + 4, y) for x, y in tri], fill=(255, 182, 18))
    d.polygon(tri, fill=(0, 0, 0))
    done(im, "SA")
    # BAN
    im, d = base((0, 106, 78))
    r = FH * 0.30
    d.ellipse([FW * 0.45 - r, FH / 2 - r, FW * 0.45 + r, FH / 2 + r], fill=(244, 42, 65))
    done(im, "BAN")


def main():
    print("== ex-synth loops ==")
    rain(); tension()
    print("== voice pack (flite) ==")
    voice()
    print("== realistic art ==")
    realistic()
    print("== theme factory ==")
    theme_packs()
    print("== splash frames ==")
    splash_frames()
    print("== tier frames ==")
    tier_frames()
    print("== avatars ==")
    avatars()
    print("== crests v2 ==")
    for key, (code, p, s, stars) in CLUBS.items():
        crest2(key, code, p, s, stars)
    print("== emblems ==")
    emblems()
    print("== flags ==")
    flags()
    print(f"\nTOTAL NEW/REGENERATED MEDIA: {TOTAL[0]:,} B")


if __name__ == "__main__":
    main()
