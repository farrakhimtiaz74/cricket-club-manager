#!/usr/bin/env python3
"""Rich Media Edition (v20) asset pipeline for Cricket Club Manager.

Reproducible: `python3 tools/make_assets.py` regenerates EVERY bundled
media asset into native/assets/ from (a) the generated hero art in
../../rich-media/raw/, (b) numpy-synthesized audio encoded with ffmpeg,
(c) PIL-drawn textures + original crest artwork, and (d) OFL fonts
downloaded from the official google/fonts GitHub repo.

Rules honoured here (Farrakh's order): every byte in the final APK is
REAL media — no silent padding, no duplicated/renamed filler. Audio is
layered synthesis (crowd beds with murmur swells and distant chant
rhythm, Karplus-Strong plucked melodies over pad chords), crests are
original art in club colours + initials (no official logos), fonts are
genuine OFL TTFs verified by magic bytes + size.

Requires: python3, numpy, scipy, Pillow, ffmpeg (libvorbis).
"""
import io, math, os, sys, subprocess, urllib.request
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # native/
ASSETS = os.path.join(ROOT, "assets")
RAW = os.path.join(os.path.dirname(ROOT), "rich-media", "raw")
SR = 44100
rng = np.random.default_rng(20261113)

os.makedirs(os.path.join(ASSETS, "audio"), exist_ok=True)
os.makedirs(os.path.join(ASSETS, "art"), exist_ok=True)
os.makedirs(os.path.join(ASSETS, "fonts"), exist_ok=True)
TMP = os.path.join(ROOT, "build", "asset-tmp")
os.makedirs(TMP, exist_ok=True)

def report(name, path):
    print(f"  {name:28s} {os.path.getsize(path)/1024:9.1f} KB")

# =====================================================================
# 1. FONTS — OFL families from github.com/google/fonts (raw TTFs)
# =====================================================================
FONTS = {
    "font_display.ttf":     "ofl/rajdhani/Rajdhani-Bold.ttf",
    "font_display_sb.ttf":  "ofl/rajdhani/Rajdhani-SemiBold.ttf",
    "font_body.ttf":        "ofl/barlow/Barlow-Regular.ttf",
    "font_body_med.ttf":    "ofl/barlow/Barlow-Medium.ttf",
}
def fetch_fonts():
    print("== fonts ==")
    for out, rel in FONTS.items():
        dst = os.path.join(ASSETS, "fonts", out)
        if not (os.path.exists(dst) and os.path.getsize(dst) > 50_000):
            url = "https://github.com/google/fonts/raw/main/" + urllib.parse.quote(rel)
            req = urllib.request.Request(url, headers={"User-Agent": "ccm-asset-pipeline"})
            data = urllib.request.urlopen(req, timeout=60).read()
            open(dst, "wb").write(data)
        with open(dst, "rb") as f:
            magic = f.read(4)
        ok = magic in (b"\x00\x01\x00\x00", b"true", b"OTTO") and os.path.getsize(dst) > 50_000
        print(f"  {out:28s} {'OK real TTF' if ok else 'FAILED verification'} {os.path.getsize(dst)} B")
        if not ok:
            raise SystemExit("font download failed for " + out)

# =====================================================================
# 2. AUDIO — layered numpy synthesis -> WAV -> ffmpeg OGG (libvorbis)
# =====================================================================
def lp(x, a):
    """One-pole lowpass, vectorised-ish via scipy lfilter."""
    from scipy.signal import lfilter
    return lfilter([a], [1.0, -(1.0 - a)], x)

def bp(x, lo_a, hi_a):
    return lp(x, hi_a) - lp(x, lo_a)

def soft(x, drive=1.1):
    return np.tanh(x * drive)

def env_ad(n, atk, dec_pow=1.0):
    t = np.arange(n) / SR
    e = np.minimum(1.0, t / max(atk, 1e-4)) * np.exp(-dec_pow * t)
    return e

def loop_fold(x, fade_s=3.0):
    """Circular-crossfade the tail into the head -> seamless loop.
    Works on (n,) or (n,2) arrays; returns a slightly shorter buffer."""
    fade = int(fade_s * SR)
    if len(x) <= fade * 2:
        return x
    out = x[:-fade].copy()
    w = np.linspace(0.0, 1.0, fade)
    if out.ndim == 2:
        w = w[:, None]
    out[:fade] = x[:fade] * w + x[-fade:] * (1 - w)
    return out

def murmur_envelope(n, seed, rate=0.25, depth=0.5):
    """Slow random-walk swell envelope, smoothed — the sound of a crowd
    breathing. Built from a handful of sine harmonics of the loop so it
    is periodic (seam-safe) plus smoothed noise."""
    r = np.random.default_rng(seed)
    t = np.arange(n) / SR
    e = np.ones(n)
    for k in range(1, 7):
        e += depth / k * np.sin(2 * np.pi * k * rate * t / (n / SR) * (n / SR) / (n / SR) * 1.0
                                + r.uniform(0, 2 * np.pi)) * 0  # placeholder, replaced below
    # simpler + truly periodic: harmonics of the loop fundamental
    e = np.ones(n)
    fund = 1.0 / (n / SR)
    for k in range(1, 9):
        e += (depth / k) * np.sin(2 * np.pi * k * fund * (0.7 + 0.3 * k) * t + r.uniform(0, 2 * np.pi))
    return np.clip(e, 0.25, 1.9)

def crowd_stereo(seconds, seed, density=1.0, chant=0.0, base_gain=0.5):
    """A stadium crowd: three band layers (low wash, murmur band, hiss
    sparkle) per ear with independent swell envelopes, periodic chant
    bursts (distant, rhythmic) and random swell bumps."""
    n = int(seconds * SR)
    r = np.random.default_rng(seed)
    out = np.zeros((n, 2))
    for ear in range(2):
        w = r.standard_normal(n)
        wash = lp(w, 0.045) * 2.6                      # low body
        murmur = bp(w, 0.012, 0.16) * 2.2              # voice band
        sparkle = bp(w, 0.10, 0.55) * 0.5              # air / hiss
        e1 = murmur_envelope(n, seed + ear * 31 + 1, depth=0.55)
        e2 = murmur_envelope(n, seed + ear * 31 + 7, depth=0.8)
        layer = wash * 0.75 + murmur * e2 * 0.9 + sparkle * 0.35
        layer *= (0.55 + 0.45 * e1)
        # random swell bumps (a chance goes up, a Mexican wave...)
        t = np.arange(n) / SR
        for _ in range(int(7 * density)):
            c = r.uniform(4, seconds - 4) if seconds > 9 else r.uniform(0.1, max(0.2, seconds - 0.1))
            width = r.uniform(0.8, 2.2)
            amp = r.uniform(0.25, 0.65) * density
            layer *= 1.0 + amp * np.exp(-0.5 * ((t - c) / width) ** 2)
        # distant chant episodes: rhythmic pulsing in the voice band
        if chant > 0:
            chant_layer = bp(r.standard_normal(n), 0.02, 0.13) * 1.6
            gate = np.zeros(n)
            episodes = int(3 * chant) + 1
            for _ in range(episodes):
                if seconds <= 11:
                    continue  # too short for a chant episode
                c = r.uniform(2, seconds - 9)
                dur = r.uniform(4.5, 7.5)
                m = (t >= c) & (t < c + dur)
                pulse = 0.72 + 0.28 * np.sin(2 * np.pi * 1.7 * t)
                fade = np.minimum(1.0, np.minimum((t - c) / 0.7, (c + dur - t) / 0.7))
                gate[m] = np.maximum(gate[m], pulse[m] * np.clip(fade[m], 0, 1))
            layer += chant_layer * gate * (0.5 * chant)
        out[:, ear] = layer * base_gain
    return soft(out, 1.05)

def pluck(freq, dur, gain=0.5, bright=0.5):
    """Karplus-Strong plucked string — a real physical-model note."""
    N = max(2, int(SR / freq))
    buf = rng.standard_normal(N) * (0.4 + 0.6 * bright)
    n = int(dur * SR)
    out = np.zeros(n)
    line = buf.copy()
    idx = 0
    damp = 0.996 - 0.001 * bright
    for i in range(n):
        cur = line[idx]
        nxt = line[(idx + 1) % N]
        new = damp * 0.5 * (cur + nxt)
        line[idx] = new
        out[i] = cur
        idx = (idx + 1) % N
    return out * gain * np.exp(-np.arange(n) / SR * 0.55)

def pad_chord(freqs, dur, gain=0.16, t=None):
    n = int(dur * SR)
    tt = np.arange(n) / SR
    y = np.zeros(n)
    for f in freqs:
        for det, g in ((1.0, 1.0), (1.003, 0.5), (2.0, 0.22), (0.5, 0.35)):
            y += g * np.sin(2 * np.pi * f * det * tt + rng.uniform(0, 6.28))
    env = np.minimum(1, tt / (dur * 0.3)) * np.minimum(1, (dur - tt) / (dur * 0.3))
    return y * gain * np.clip(env, 0, 1)

def add(dst, sig, at_s, gain=1.0):
    s = int(at_s * SR)
    e = min(len(dst), s + len(sig))
    if e > s:
        dst[s:e] += sig[:e - s] * gain

def music_menu(seconds=150):
    """Warm menu theme: Am–F–C–G pads (one chord / 4s), a soft plucked
    pentatonic melody, gentle bass. Seamless loop."""
    n = int(seconds * SR)
    y = np.zeros(n)
    chords = [  # (pad freqs, bass, pentatonic pool)
        ([220.00, 261.63, 329.63], 110.00, [440.0, 523.25, 659.25, 783.99]),
        ([174.61, 220.00, 261.63], 87.31, [349.23, 440.0, 523.25, 659.25]),
        ([261.63, 329.63, 392.00], 130.81, [392.0, 523.25, 659.25, 783.99]),
        ([196.00, 246.94, 293.66], 98.00, [392.0, 493.88, 587.33, 783.99]),
    ]
    r = np.random.default_rng(777)
    chord_dur = 4.0
    steps = int(seconds / chord_dur)
    last = None
    for i in range(steps):
        freqs, bass, pool = chords[i % 4]
        add(y, pad_chord(freqs, chord_dur + 1.6, 0.105), i * chord_dur)
        add(y, np.sin(2 * np.pi * bass * np.arange(int(3.6 * SR)) / SR)
            * np.minimum(1, np.arange(int(3.6 * SR)) / SR / 0.4) * 0.20, i * chord_dur)
        # melody: 2-4 plucks per chord, walking the pool
        pos = r.integers(0, len(pool)) if last is None else last
        for k in range(r.integers(2, 5)):
            pos = int(np.clip(pos + r.integers(-1, 2), 0, len(pool) - 1))
            at = i * chord_dur + 0.35 + k * (chord_dur - 0.8) / 4 + r.uniform(0, 0.14)
            add(y, pluck(pool[pos], 1.7, 0.30, 0.45), at)
        last = pos
    # air: a whisper of breath noise + high shimmer so the pads feel
    # produced rather than pure-tone (and the mix breathes)
    tt = np.arange(n) / SR
    y += bp(r.standard_normal(n), 0.06, 0.35) * 0.014 * (0.6 + 0.4 * np.sin(2 * np.pi * tt / 31))
    y += pad_chord([880.0, 1108.7, 1318.5], seconds, 0.012)
    return soft(loop_fold(y.reshape(-1, 1), 4.0).ravel(), 1.0) * 0.9

def music_match(seconds=120):
    """Match bed: low tense pulse — minor drone, heartbeat kick,
    sparse dark plucks, slow filter-breathing pad. 90 s loop."""
    n = int(seconds * SR)
    y = np.zeros(n)
    t = np.arange(n) / SR
    drone = pad_chord([110.0, 164.81, 220.0], seconds, 0.10)
    y += drone
    # pulse: two-beat heartbeat every 2 s (sine pitch-drop kick)
    for b in range(int(seconds / 2)):
        for off, g in ((0.0, 0.5), (0.34, 0.32)):
            kt = np.arange(int(0.32 * SR)) / SR
            kick = np.sin(2 * np.pi * (52 - 18 * kt / 0.32) * kt) * np.exp(-kt * 11) * g
            add(y, kick, b * 2 + off)
    r = np.random.default_rng(4242)
    pool = [220.0, 261.63, 329.63, 392.0, 440.0]
    for i in range(int(seconds / 6)):
        f = pool[r.integers(0, len(pool))]
        add(y, pluck(f / 2, 2.4, 0.20, 0.25), i * 6 + r.uniform(0.5, 3.0))
    shimmer = bp(r.standard_normal(n), 0.05, 0.3) * 0.012 * (0.6 + 0.4 * np.sin(2 * np.pi * t / 23))
    y += shimmer
    return soft(loop_fold(y.reshape(-1, 1), 3.0).ravel(), 1.0) * 0.95

# ---- SFX recipes (each a small layered production) ----
def sfx_bat(hard=True):
    dur = 0.42 if hard else 0.3
    n = int(dur * SR)
    y = np.zeros(n)
    crack = bp(rng.standard_normal(n), 0.25, 0.9) * env_ad(n, 0.0015, 55) * (1.15 if hard else 0.6)
    tt = np.arange(n) / SR
    thump = np.sin(2 * np.pi * (150 - 80 * tt / dur) * tt) * np.exp(-tt * 22) * (0.85 if hard else 0.45)
    body = np.sin(2 * np.pi * 318 * tt) * np.exp(-tt * 30) * 0.3
    lift = lp(rng.standard_normal(n), 0.05) * env_ad(n, 0.05, 7) * 0.22  # slight crowd lift
    return soft(crack + thump + body + lift)

def sfx_stumps():
    n = int(0.5 * SR)
    y = np.zeros(n)
    for i, (at, g) in enumerate(((0.0, 1.0), (0.055, 0.8), (0.13, 0.62))):
        tick_n = int(0.06 * SR)
        tick = bp(rng.standard_normal(tick_n), 0.4, 0.95) * env_ad(tick_n, 0.001, 60) * 0.9 * g
        ping = np.sin(2 * np.pi * (1750 + i * 130) * np.arange(tick_n) / SR) * env_ad(tick_n, 0.001, 38) * 0.25 * g
        add(y, tick + ping, at)
    tt = np.arange(n) / SR
    y += np.sin(2 * np.pi * 165 * tt) * np.exp(-tt * 16) * 0.5
    return soft(y)

def sfx_pad():
    n = int(0.8 * SR)
    tt = np.arange(n) / SR
    thud = np.sin(2 * np.pi * 72 * tt) * np.exp(-tt * 13) * 0.9
    thud += lp(rng.standard_normal(n), 0.03) * env_ad(n, 0.004, 26) * 0.9
    murmur = crowd_stereo(0.8, 5150, density=0.3, base_gain=0.16)[:, 0] * env_ad(n, 0.09, 2.6)
    return soft(thud + murmur)

def sfx_whistle():
    n = int(0.6 * SR)
    tt = np.arange(n) / SR
    trill = 0.82 + 0.18 * np.sin(2 * np.pi * 26 * tt)
    tone = np.sin(2 * np.pi * 2250 * tt + 40 * np.sin(2 * np.pi * 26 * tt)) * trill
    env = np.minimum(1, tt / 0.03) * np.minimum(1, (0.6 - tt) / 0.12)
    breath = bp(rng.standard_normal(n), 0.3, 0.8) * 0.12
    return soft((tone * 0.5 + breath) * env)

def sfx_cheer(big=True):
    dur = 3.2 if big else 1.9
    c = crowd_stereo(dur, 6001 if big else 6002, density=1.4 if big else 1.0,
                     chant=0.25 if big else 0.0, base_gain=0.62)
    tt = np.arange(len(c)) / SR
    env = np.minimum(1, tt / (0.09 if big else 0.13)) * np.exp(-tt * (0.85 if big else 1.5))
    return soft(c * env[:, None])

def sfx_groan():
    dur = 2.0
    c = crowd_stereo(dur, 6003, density=0.5, base_gain=0.5)
    low = np.stack([lp(c[:, 0], 0.03), lp(c[:, 1], 0.03)], axis=1) * 1.6
    tt = np.arange(len(c)) / SR
    env = np.minimum(1, tt / 0.14) * np.exp(-tt * 1.7)
    return soft(low * env[:, None])

def sfx_applause():
    dur = 1.7
    n = int(dur * SR)
    y = np.zeros((n, 2))
    r = np.random.default_rng(808)
    for ear in range(2):
        for _ in range(260):
            at = r.uniform(0, dur - 0.06)
            ln = int(0.045 * SR)
            tick = bp(r.standard_normal(ln), 0.3, 0.85) * env_ad(ln, 0.001, 42) * r.uniform(0.10, 0.3)
            add(y[:, ear], tick, at)
    tt = np.arange(n) / SR
    env = np.minimum(1, tt / 0.1) * np.exp(-tt * 1.1)
    return soft(y * env[:, None])

def _tone(freq, at, dur, y, gain=0.4, decay=5.0, harm=0.18):
    n = int(dur * SR)
    tt = np.arange(n) / SR
    sig = np.sin(2 * np.pi * freq * tt) + harm * np.sin(2 * np.pi * freq * 3 * tt) \
        + 0.1 * np.sin(2 * np.pi * freq * 2 * tt)
    add(y, sig * np.exp(-tt * decay) * gain, at)

def sfx_sting_win():
    n = int(2.4 * SR)
    y = np.zeros(n)
    for i, f in enumerate((523.25, 659.25, 783.99, 1046.5)):
        _tone(f, i * 0.13, 1.4, y, 0.34, 3.2)
        add(y, pluck(f, 1.3, 0.22, 0.5), i * 0.13)
    _tone(261.63, 0, 2.2, y, 0.18, 1.6)
    swell = crowd_stereo(2.4, 9101, density=0.5, base_gain=0.14)[:, 0]
    tt = np.arange(n) / SR
    return soft(y + swell * np.minimum(1, tt / 0.5))

def sfx_sting_title():
    n = int(5.4 * SR)
    y = np.zeros(n)
    for i, f in enumerate((523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.5)):
        _tone(f, i * 0.32, 1.8, y, 0.30, 2.6)
        add(y, pluck(f, 1.5, 0.18, 0.5), i * 0.32)
    for f in (261.63, 329.63, 392.0, 523.25):
        _tone(f, 2.5, 2.8, y, 0.13, 1.0)
    c = crowd_stereo(5.4, 9102, density=1.1, chant=0.3, base_gain=0.30)
    tt = np.arange(n) / SR
    env = np.minimum(1, tt / 1.0) * np.exp(-0.30 * np.maximum(0, tt - 3.2))
    return soft(np.stack([y, y], axis=1) * 0.8 + c * env[:, None])

def sfx_sting_achievement():
    n = int(0.8 * SR)
    y = np.zeros(n)
    _tone(1318.5, 0, 0.55, y, 0.32, 7)
    _tone(1760.0, 0.1, 0.65, y, 0.32, 6)
    return soft(y)

def sfx_ui_click():
    n = int(0.06 * SR)
    y = bp(rng.standard_normal(n), 0.5, 0.95) * env_ad(n, 0.001, 70) * 0.6
    tt = np.arange(n) / SR
    y += np.sin(2 * np.pi * 2350 * tt) * np.exp(-tt * 90) * 0.16
    return soft(y)

def sfx_ui_confirm():
    n = int(0.45 * SR)
    y = np.zeros(n)
    _tone(880.0, 0, 0.35, y, 0.30, 8, harm=0.06)
    _tone(1318.5, 0.09, 0.36, y, 0.30, 7, harm=0.06)
    return soft(y)

def sfx_ui_blocked():
    n = int(0.2 * SR)
    tt = np.arange(n) / SR
    y = np.sin(2 * np.pi * 63 * tt) * np.exp(-tt * 15) * 0.95
    y += lp(rng.standard_normal(n), 0.02) * env_ad(n, 0.003, 30) * 0.5
    return soft(y)

def sfx_cash():
    n = int(0.5 * SR)
    y = np.zeros(n)
    _tone(1567.98, 0, 0.2, y, 0.26, 14, harm=0.3)
    _tone(2093.0, 0.07, 0.4, y, 0.26, 9, harm=0.3)
    return soft(y)

def sfx_gavel():
    n = int(0.42 * SR)
    y = np.zeros(n)
    for at, g in ((0.0, 1.0), (0.11, 0.9)):
        ln = int(0.07 * SR)
        knock = bp(rng.standard_normal(ln), 0.3, 0.9) * env_ad(ln, 0.001, 55) * 0.9 * g
        knock += np.sin(2 * np.pi * 290 * np.arange(ln) / SR) * env_ad(ln, 0.001, 30) * 0.5 * g
        add(y, knock, at)
    return soft(y)

def write_wav(name, data):
    """data: mono (n,) or stereo (n,2) float in [-1,1] -> 16-bit WAV."""
    from scipy.io import wavfile
    if data.ndim == 1:
        data = data.reshape(-1, 1)
    pcm = np.clip(data, -1, 1)
    pcm = (pcm * 32767).astype(np.int16)
    path = os.path.join(TMP, name + ".wav")
    wavfile.write(path, SR, pcm)
    return path

def encode_ogg(wav, out_name, quality):
    dst = os.path.join(ASSETS, "audio", out_name)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", wav,
                    "-c:a", "libvorbis", "-q:a", str(quality), dst], check=True)
    report(out_name, dst)
    return dst

def build_audio():
    print("== audio (numpy -> wav -> ogg/vorbis) ==")
    # crowd beds: stereo, long, seamless — the honest MB carriers
    home = loop_fold(crowd_stereo(203, 101, density=1.0, chant=0.55, base_gain=0.52), 3.5)
    encode_ogg(write_wav("crowd_home", home), "crowd_home.ogg", 5)
    away = loop_fold(crowd_stereo(203, 202, density=0.55, chant=0.15, base_gain=0.40), 3.5)
    encode_ogg(write_wav("crowd_away", away), "crowd_away.ogg", 5)
    derby = loop_fold(crowd_stereo(203, 303, density=1.35, chant=1.0, base_gain=0.58), 3.5)
    encode_ogg(write_wav("crowd_derby", derby), "crowd_derby.ogg", 5)
    # music loops
    encode_ogg(write_wav("music_menu", music_menu(150)), "music_menu.ogg", 5)
    encode_ogg(write_wav("music_match", music_match(120).reshape(-1, 1)), "music_match.ogg", 5)
    # one-shots
    shots = {
        "sfx_bat_hard": sfx_bat(True), "sfx_bat_soft": sfx_bat(False),
        "sfx_stumps": sfx_stumps(), "sfx_pad": sfx_pad(),
        "sfx_whistle": sfx_whistle(), "sfx_cheer_big": sfx_cheer(True),
        "sfx_cheer": sfx_cheer(False), "sfx_groan": sfx_groan(),
        "sfx_applause": sfx_applause(), "sting_win": sfx_sting_win(),
        "sting_title": sfx_sting_title(), "sting_achievement": sfx_sting_achievement(),
        "ui_click": sfx_ui_click(), "ui_confirm": sfx_ui_confirm(),
        "ui_blocked": sfx_ui_blocked(), "cash": sfx_cash(), "gavel": sfx_gavel(),
    }
    for name, sig in shots.items():
        encode_ogg(write_wav(name, sig), name + ".ogg", 6)

# =====================================================================
# 3. ART — hero re-encode, textures, original crests (PIL)
# =====================================================================
def find_raw(prefix):
    for f in sorted(os.listdir(RAW)):
        if f.startswith(prefix) and f.endswith(".webp"):
            return os.path.join(RAW, f)
    raise SystemExit("raw art missing: " + prefix)

def hero(src_prefix, out, max_w, q):
    im = Image.open(find_raw(src_prefix)).convert("RGB")
    if im.width > max_w:
        im = im.resize((max_w, int(im.height * max_w / im.width)), Image.LANCZOS)
    dst = os.path.join(ASSETS, "art", out)
    im.save(dst, "WEBP", quality=q, method=6)
    report(out, dst)

def tex_grass():
    W, H = 1024, 512
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im, "RGBA")
    stripes = 8
    for i in range(stripes):
        x0 = i * W // stripes
        base = (24, 68, 34) if i % 2 == 0 else (30, 80, 40)
        d.rectangle([x0, 0, x0 + W // stripes, H], fill=base + (255,))
    noise = np.random.default_rng(5).normal(0, 7, (H, W, 1)).repeat(3, axis=2)
    arr = np.clip(np.asarray(im).astype(np.int16) + noise, 0, 255).astype(np.uint8)
    im = Image.fromarray(arr).filter(ImageFilter.GaussianBlur(0.6))
    dst = os.path.join(ASSETS, "art", "tex_grass.webp")
    im.save(dst, "WEBP", quality=80, method=6)
    report("tex_grass.webp", dst)

def tex_carbon():
    S = 512
    im = Image.new("RGB", (S, S), (13, 18, 30))
    d = ImageDraw.Draw(im, "RGBA")
    step = 16
    for y in range(0, S, step):
        for x in range(0, S, step):
            if (x // step + y // step) % 2 == 0:
                d.rounded_rectangle([x + 1, y + 1, x + step - 1, y + step - 1], 4, fill=(24, 32, 48, 255))
            else:
                d.rounded_rectangle([x + 1, y + 1, x + step - 1, y + step - 1], 4, fill=(9, 13, 22, 255))
    noise = np.random.default_rng(6).normal(0, 4, (S, S, 1)).repeat(3, axis=2)
    arr = np.clip(np.asarray(im).astype(np.int16) + noise, 0, 255).astype(np.uint8)
    dst = os.path.join(ASSETS, "art", "tex_carbon.webp")
    Image.fromarray(arr).save(dst, "WEBP", quality=80, method=6)
    report("tex_carbon.webp", dst)

def tex_gold():
    W, H = 1024, 256
    grad = np.zeros((H, W, 3), dtype=np.float32)
    stops = [(0.0, (217, 119, 6)), (0.35, (251, 191, 36)), (0.55, (245, 158, 11)),
             (0.8, (252, 211, 77)), (1.0, (180, 83, 9))]
    xs = np.linspace(0, 1, W)
    for c in range(3):
        grad[:, :, c] = np.interp(xs, [s[0] for s in stops], [s[1][c] for s in stops])[None, :].repeat(H, axis=0)
    r = np.random.default_rng(7)
    brush = r.normal(0, 6, (1, W, 1)).repeat(H, axis=0) + r.normal(0, 3, (H, W, 1))
    arr = np.clip(grad + brush.repeat(3, axis=2), 0, 255).astype(np.uint8)
    dst = os.path.join(ASSETS, "art", "tex_gold.webp")
    Image.fromarray(arr).save(dst, "WEBP", quality=82, method=6)
    report("tex_gold.webp", dst)

CLUBS = {  # key -> (code, primary, secondary, stars) — colours mirror Design.clubColors
    "lahore":    ("LAH", (245, 158, 11), (22, 163, 74), 3),
    "karachi":   ("KAR", (37, 99, 235), (245, 158, 11), 2),
    "islamabad": ("ISL", (220, 38, 38), (249, 115, 22), 3),
    "multan":    ("MUL", (13, 148, 136), (132, 204, 22), 2),
    "peshawar":  ("PES", (250, 204, 21), (51, 65, 85), 2),
    "quetta":    ("QUE", (124, 58, 237), (245, 158, 11), 2),
    "sialkot":   ("SIA", (159, 18, 57), (192, 198, 206), 1),
    "hyderabad": ("HYD", (22, 163, 74), (250, 204, 21), 1),
}

def _darken(c, f):
    return tuple(max(0, int(v * f)) for v in c)

def _quad(p0, p1, p2, steps=14):
    pts = []
    for i in range(1, steps + 1):
        t = i / steps
        x = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t ** 2 * p2[0]
        y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t ** 2 * p2[1]
        pts.append((x, y))
    return pts

def _shield_points(W, H):
    """A symmetric heraldic shield: flat top, straight sides, then two
    quadratic curves sweeping to the bottom point."""
    pts = [(0.06 * W, 0.03 * H), (0.94 * W, 0.03 * H), (0.94 * W, 0.50 * H)]
    pts += _quad((0.94 * W, 0.50 * H), (0.93 * W, 0.86 * H), (0.50 * W, 0.97 * H))
    pts += _quad((0.50 * W, 0.97 * H), (0.07 * W, 0.86 * H), (0.06 * W, 0.50 * H))
    pts.append((0.06 * W, 0.03 * H))
    return pts

def _star(d, cx, cy, r, color):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.45
        pts.append((cx + math.cos(ang) * rad, cy + math.sin(ang) * rad))
    d.polygon(pts, fill=color + (255,))

def crest(key, code, primary, secondary, stars):
    W, H = 512, 574
    shield = _shield_points(W, H)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).polygon(shield, fill=255)

    def clipped(layer):
        """Composite a full-size layer through the shield mask."""
        base = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        return Image.composite(layer, base, mask)

    # 1) vertical gradient body: primary -> darkened primary
    ga = np.zeros((H, W, 4), dtype=np.uint8)
    top = np.array(primary, dtype=np.float32)
    bot = np.array(_darken(primary, 0.40), dtype=np.float32)
    grad_col = (top[None, :] + (bot - top)[None, :] * (np.arange(H) / H)[:, None]).astype(np.uint8)
    ga[:, :, :3] = grad_col[:, None, :].repeat(W, axis=1)
    ga[:, :, 3] = 255
    im = clipped(Image.fromarray(ga, "RGBA"))
    # 2) diagonal sash in the secondary colour
    sash = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sash).polygon([(0.52 * W, 0), (0.90 * W, 0), (0.36 * W, H), (0.04 * W, H)],
                                 fill=secondary + (170,))
    im = Image.alpha_composite(im, clipped(sash))
    # 3) soft top shine
    shine = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(shine).ellipse([-0.25 * W, -0.38 * H, 0.8 * W, 0.28 * H], fill=(255, 255, 255, 30))
    im = Image.alpha_composite(im, clipped(shine.filter(ImageFilter.GaussianBlur(18))))
    # 4) chest band
    band = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(band).rectangle([0, 0.335 * H, W, 0.615 * H], fill=(10, 15, 26, 244))
    im = Image.alpha_composite(im, clipped(band))

    d = ImageDraw.Draw(im, "RGBA")
    # stars row
    for i in range(stars):
        _star(d, W * (0.5 + (i - (stars - 1) / 2.0) * 0.13), 0.165 * H, 0.052 * W, (252, 211, 77))
    # initials in the bundled display font
    try:
        font = ImageFont.truetype(os.path.join(ASSETS, "fonts", "font_display.ttf"), int(H * 0.235))
    except Exception:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", int(H * 0.235))
    d.text((W / 2, 0.475 * H), code, font=font, fill=(255, 255, 255, 255), anchor="mm",
           stroke_width=2, stroke_fill=(0, 0, 0, 90))
    # cricket ball motif under the band
    bx, by, br = W / 2, 0.79 * H, 0.082 * W
    d.ellipse([bx - br, by - br, bx + br, by + br], fill=(168, 32, 40, 255), outline=(255, 255, 255, 170), width=3)
    for sgn in (-1, 1):
        x = bx + sgn * br * 0.45
        d.arc([x - br * 0.5, by - br * 0.82, x + br * 0.5, by + br * 0.82],
              90, 270 if sgn < 0 else -90, fill=(255, 255, 255, 210), width=3)
    # outline
    d.line(shield, fill=(241, 245, 249, 210), width=5, joint="curve")
    dst = os.path.join(ASSETS, "art", f"crest_{key}.webp")
    im.save(dst, "WEBP", quality=90, method=6)
    report(f"crest_{key}.webp", dst)

def build_art():
    print("== art ==")
    hero("media-generation-stadium-night-hero", "art_stadium.webp", 1120, 88)
    hero("media-generation-hq-campus", "art_campus.webp", 1600, 88)
    hero("media-generation-trophy-celebration", "art_trophy.webp", 1080, 87)
    hero("media-generation-matchday-pitch", "art_pitch.webp", 1600, 86)
    tex_grass(); tex_carbon(); tex_gold()
    for key, (code, p, s, stars) in CLUBS.items():
        crest(key, code, p, s, stars)

if __name__ == "__main__":
    fetch_fonts()
    build_audio()
    build_art()
    total = 0
    for base, _, files in os.walk(ASSETS):
        for f in files:
            total += os.path.getsize(os.path.join(base, f))
    print(f"== TOTAL assets: {total/1e6:.2f} MB ==")
